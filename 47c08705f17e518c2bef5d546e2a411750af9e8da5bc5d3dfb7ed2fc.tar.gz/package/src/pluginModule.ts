export interface PluginEnv {
  userRequest: string;
  CODEGEN_APP_ROOT: string;
  WIX_TOKEN: string;
  WIX_SITE_ID: string;
  PHOTO_THEME: string;
  // TODO: Replace with generateImagesForItems that will generate all the needed images for the data.
  generateImage: (
    prompt: string,
    options: { width: number; height: number },
  ) => Promise<string>;
  // TODO: Replace with generateTextByProject and generateTextByPrompt
  providers: unknown;
}

export interface PluginModule<TResult = unknown> {
  /**
   * Provision the plugin and copy all of the plugin's additional files.
   * @param env - All the parameters needed to provision the plugin.
   * @returns - A promise that resolves when the plugin is installed and all of the plugin's additional files were copied.
   */
  install?: (env: PluginEnv) => Promise<TResult>;
  /**
   * Generate the initial data for the plugin.
   * @param env - All the parameters needed to generate the data.
   * @returns - A promise that resolves when the data is ready.
   */
  generateData?: (env: PluginEnv) => Promise<void>;
  /**
   * Generate dynamic instructions based on the result of the plugin's install function and the static instructions of the plugin in dev center.
   *
   * If this function is not provided, the static instructions will be used.
   *
   * @param params - The result of the plugin's install function and the plugin's static instructions.
   * @returns - A promise that resolves with the updated instructions.
   */
  getInstructions?: (params: {
    result: TResult;
    originalInstructions: string | undefined;
  }) => Promise<string>;
}

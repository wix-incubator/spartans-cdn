# picasso-codegen-cli

Library flow package generated with Yoshi.

## Getting Started

To use this CLI tool, follow these steps:

1. Install the package, cd into cli directory and run:
   ```
   yarn
   ```

2. Build the package:
   ```
   yarn build
   ```

3. Create a symlink for the package:
   ```
   npm link
   ```

4. Go to your destination package (e.g., picasso-codegen-app) and run:
   ```
   cd ../picasso-codegen-app
   gen run
   ```

   This works because npm link creates a global symlink to your CLI package, making the `gen` command available in any directory.

## Node Version Management

When working with multiple terminal windows (one for the CLI/linking and another for the app), ensure that both terminals are using the same Node.js version. The easiest way is to properly configure your shell to automatically detect and use the correct Node version from the `.nvmrc` file.

### For zsh users

Add the following to your `~/.zshrc` file:

```bash
autoload -U add-zsh-hook
load-nvmrc() {
  local node_version="$(nvm version)"
  local nvmrc_path="$(nvm_find_nvmrc)"

  if [ -n "$nvmrc_path" ]; then
    local nvmrc_node_version=$(nvm version "$(cat "${nvmrc_path}")")

    if [ "$nvmrc_node_version" = "N/A" ]; then
      nvm install
    elif [ "$nvmrc_node_version" != "$node_version" ]; then
      nvm use
    fi
  elif [ "$node_version" != "$(nvm version default)" ]; then
    echo "Reverting to nvm default version"
    nvm use default
  fi
}
add-zsh-hook chpwd load-nvmrc
load-nvmrc
```

This script automatically switches to the Node version specified in the `.nvmrc` file whenever you change directories.

## CLI Commands

The CLI provides several commands to help you generate and manage code:

### App Command

Builds a full application based on a description.

```bash
gen app -d "Your app description"
```

#### Options:

- `-d, --description <description>` (required): Description of the app to build
- `-e, --edit`: Edit mode to update an existing app

#### Examples:

```bash
# Create a new app from scratch
gen app -d "A todo app with task management features"

# Edit an existing app
gen app -e -d "Add dark mode toggle to the navbar"
```

### Spec Command

Generates app specification from description.

```bash
gen spec -d "Your app description"
```

#### Options:

- `-d, --description <description>` (required): Description of the app to build

### Other Commands

- `gen lint`: Run the linter agent
- `gen model`: Run the architect agent
- `gen coder`: Run the coder agent

Run `gen --help` to see all available commands and options.

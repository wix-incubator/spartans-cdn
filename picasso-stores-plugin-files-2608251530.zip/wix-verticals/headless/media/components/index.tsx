export { WixMediaImage } from './Image';

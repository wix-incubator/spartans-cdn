---
portal: build-apps
name: "About App Accessibility"
type: ARTICLE_RESOURCE
resourceId: bbd4b5f2-5ba3-43ae-826b-348f56be52ba
---

# About App Accessibility

# About App Accessibility
An accessible app is one that can be accessed and used by anyone, regardless of physical, mental, or situational disabilities, or socioeconomic restrictions on internet speed and bandwidth.

Advantages of an accessible app include:
* **Broader reach:** Your app can be used by a wider range of people, including those with disabilities, situational limitations, and older adults. 
* **Better user experience:** Your app is also easier to use for those without disabilities or limitations, resulting in an enhanced user experience.
* **Fosters inclusivity:** Ensures that technology is available to everyone equitably.

## Best practices
To make your app's [site extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) accessible, see the following articles:
* [Web accessibility best practices](https://www.wix.com/blog/website-accessibility-best-practices)
* [How to make your website accessible](https://www.wix.com/blog/how-to-make-a-website-accessible)

> **Note:** Many of the principles for making a website accessible are applicable to all parts of your app, especially [frontend extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions#frontend-extensions). It’s worthwhile reading the articles above even if your app doesn't include site extensions.

The following list isn't exhaustive, but includes some ways you can make your app accessible.

### Accessibility guidelines
Familiarize yourself with accessibility guidelines, such as the [Web Content Accessibility Guidelines](https://www.w3.org/WAI/standards-guidelines/wcag/) (WCAG). These resources provide detailed recommendations for making digital content accessible.

### Semantic HTML and proper markup 
Properly label your app's structure using semantic HTML elements. Use headings, lists, and [landmarks](https://www.w3schools.com/accessibility/accessibility_landmarks.php) to improve navigation for users accessing a site with screen reader. Proper markup helps assistive technologies interpret and present content accurately to users with disabilities.

### Structure and naming
A screen reader should be able to understand all the important content on the page just from the HTML. Content, structure, and relationships between elements should be clear.

### Clear and consistent navigation
Design intuitive navigation pathways and ensure consistency across your app's interface. Straightforward navigation aids users with cognitive disabilities and helps all users find what they need efficiently.

### Test your app using assistive technologies
Test your app using screen readers, keyboard navigation, voice input, and other assistive technologies to ensure compatibility and usability for users with disabilities. Learn more about [browsing with assistive technology](https://www.youtube.com/playlist?list=PLTqm2yVMMUKVxQ6eYth4_vvbM3IcrSPlk).

## See also
* [Accessibility (MDN)](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Accessibility)
* [Accessibility (web.dev)](https://web.dev/articles/accessibility)
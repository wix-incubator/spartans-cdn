---
portal: build-apps
name: "About Site Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 99bdc6e6-edea-48e5-bc0c-478022ba8b2b
---

# About Site Plugin Extensions

# About Site Plugin Extensions

With site plugins, you can create interactive and feature-rich components that seamlessly [integrate into Wix’s business solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions), such as Wix Stores, Wix Bookings, and Checkout & Orders, extending their functionality and user experience.

Wix users can easily place site plugins into predefined [slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots) within Wix apps, using the plugin explorer available in all Wix editors.

![plugin-flow](https://wixmp-833713b177cebf373f611808.wixmp.com/images/71c2ec2dcfeeff1db782f291c2441d39.gif)

## Terminology

The following are key terms related to site plugins:

| Term | Definition |
|-----|----|
| Host widget | A widget belonging to a Wix business solution, which contains 1 or more slots. |
| [Slot](#slots) | A placeholder within a host widget in which Wix users can add a plugin. |
| Site plugin | A component you can add inside a slot, extending the host widget's functionality. |
| [Plugin API](#plugin-api) | The data each host widget exposes to your plugin at runtime. |

## How site plugins work

A site plugin integrates with its host widget in 2 ways:

* **Visually**, by embedding its UI inside one of the host's slots. 
* **Logically**, by implementing a communication interface with the host through their [plugin API](#plugin-api). 

## Slots

[Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots) are UI placeholders where you can place plugins. Wix apps offer a range of slots across different app widgets.  

When developing a plugin, you must declare the specific slots Wix users can add a plugin to. Each host widget passes context data to your plugin as props, which you can use to call [Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis), implement your plugin's logic, and extend a host widget's functionality.

For a list of available slots, see [About Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots).

## Plugin API

Each slot exposes a plugin API, which is a set of context data passed to your plugin at runtime as props. For example, the Product page plugin API provides `productId`, `selectedVariantId`, and other data about the current product. Use these props to call related [Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis) and implement your plugin's logic. 

## Implementation options

You can add a site plugin extension using:

* [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/add-a-site-plugin-extension-in-the-cli): Create a site plugin using the CLI and custom element technology, with your code by default deployed on our servers. The creation and setup process of your widget takes place in the terminal. Then, to edit your plugin, you write code directly in your CLI app project's files.
* [Self-hosted custom element](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/site-widgets-and-plugins/add-self-hosted-site-plugin-extensions-with-custom-elements): Create a site plugin using custom element technology, with your code deployed on your own server. The custom element is essentially a new HTML tag that you define, which is made available in the Wix editors as a widget.
* [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-plugins/build-a-site-plugin-in-blocks): Create a site widget in Wix's native app editor. Design your site plugin using visual layout and design tools, and code your business logic using Velo, Wix’s native coding solution.

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

## Design and layout guidelines

Some host widgets include design and UX guidelines for building plugins that integrate with the host widget's layout and Wix's design standards. Follow these guidelines to ensure your plugin appears native to the host widget.

## Sandboxing in the editor

Site plugins are sandboxed when rendered in the editor to enhance security. This means they're treated as if they come from a different domain, which impacts access to browser storage APIs and other same-origin resources.

<blockquote class="important">

__Important:__ The format of the Wix editor URL is changing due to new cookies introduced for authorization. The new URL format is `{username}-{sitename}.{editor|studio|harmony}.wix.com`. If your app uses CORS and whitelists specific origins, update your allowed origins to match the new format to avoid blocked requests.

</blockquote>

Learn more about [handling sandboxing in the editor](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/handle-sandboxing-in-the-editor).
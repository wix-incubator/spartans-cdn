---
portal: build-apps
name: "About Slots"
type: ARTICLE_RESOURCE
resourceId: 8b780014-e938-4425-88aa-638d22da5f75
---

# About Slots

# About Slots


Wix offers a range of slots across Wix app widgets where you can place [site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions). 

The following diagram shows how slots can appear in a host widget:

![Wireframe showing slot positions in a host widget](https://wixmp-833713b177cebf373f611808.wixmp.com/images/460c008b9392743ed24384f272b68abf.png "slots wireframe")

## How slots work

A host widget can contain multiple slots, and each slot has a unique ID. When building your plugin, you declare the specific slots in which Wix users can place it. Each host widget passes context data to your plugin as props, which you can use to call [Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis) and implement your plugin's logic.

A Wix user can place your plugin in a slot manually, or your plugin can be placed automatically on installation. If you configure automatic placement, your plugin is placed in the first available slot in the order you define. If that slot is occupied, it moves to the next slot, and so on. If no slots are available, it isn't placed.

## Available slots

The following host widgets support slots where you can place a site plugin. Learn more about each host widget's slots and integration details.

Wix eCommerce:

- [Checkout page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-checkout-page)
- [Side cart](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-side-cart)
- [Thank You page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-thank-you-page)

Wix Stores:

- [Product page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-product-page)
- [Category page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-category-page)
- [Shop page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-shop-page)
- [Gallery widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-gallery-widget)

Wix Bookings:

- [Service page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-bookings/wix-bookings-service-page)

Wix Events:

- [Event Details page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-events/wix-events-event-details-page)

Wix Blog:

- [Post page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-blog/wix-blog-post-page)

## See also

- [About Site Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions)
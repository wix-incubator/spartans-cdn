---
portal: build-apps
name: "About Developing Apps"
type: ARTICLE_RESOURCE
resourceId: 59f0dfe9-7573-4f86-b0a1-d8f0bd01cfd4
---

# About Developing Apps

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# About Developing Apps

To support you on your app development journey, Wix offers a wide range of tools and technologies. From planning and setup to building, launching, and managing your app, we provide everything you need. This article provides an overview of the app dashboard, development frameworks, extensions, business solutions, API integrations, access protocols, and the Wix Design System, with links to more detailed articles on each topic.

[<button class="wix-button">Start Developing
</button>](https://manage.wix.com/account/custom-apps)

## App dashboard

The app dashboard is a hub for connecting and managing your app within the Wix ecosystem. Regardless of how you build your app, your journey will likely include a visit to the app dashboard. It offers various tools to help you prepare, build, integrate, launch, and manage your app.

For more information, see [About the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).

## Frameworks

Wix offers 3 [development frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) for building apps, each providing a comprehensive development model. A framework allows you to extend your app's functionality. The framework you choose depends on the type of extension you want to implement.

The 3 frameworks are:
- **Wix CLI**: Code and deploy with Wix’s React/Node.js stack.
- **Self-hosting**: Use your own tech stack.
- **Wix Blocks**: Design, code, and deploy on Wix’s native app editor.

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

For more information, see [About Development Frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks#about-development-frameworks).

## Extensions

An [extension](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix) is a specific functionality of an app, categorized into two broad types: frontend and backend. Both frontend and backend extensions are typically developed using one of Wix’s development frameworks. Frontend extensions include site extensions and dashboard extensions, focusing on user interface enhancements. Backend extensions, on the other hand, enhance backend capabilities through service plugins, schema plugins and notifications. Apps can incorporate multiple extensions that work together to offer diverse features across various user interfaces and backend services.

For more information, see [About extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions#about-extensions) and [Map your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)

## App Settings

App settings define how the app behaves during and after installation. For example, you can specify the destination where the site owner is directed after app installation completes. With these settings, you can define and manage app-level configuration conveniently in one place. 

For more information, see [App Settings](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/app-settings).

## Business Solutions

Business solutions are native apps built by Wix that provide capabilities like eCommerce, running events, writing blogs, managing restaurants, and more. Users add Wix business solutions to their sites by installing these apps. Your app can integrate with Wix's business solutions through plugins or APIs.

For more information, see [About Wix Business Solutions](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/about-wix-business-solutions#about-wix-business-solutions).

## API Integrations

With Wix APIs, you can transfer data, extend Wix business solutions, and customize your app's interactions with site visitors. Each API includes events, which are automated responses sent to your app when specific site actions occur.  Wix offers a variety of API technologies, including REST, JavaScript SDK, GraphQL, and Velo, to suit your app's requirements. These APIs enable integration with different areas of the Wix ecosystem.

For more information, see [About Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/about-wix-business-solutions#about-wix-business-solutions).

<blockquote class="tip">

**Tip:** We recommend subscribing to [app management events](https://dev.wix.com/docs/rest/app-management/app-instance/introduction), such as [App Instance Installed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed), [App Instance Removed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-removed), and [Paid Plan Purchased](https://dev.wix.com/docs/rest/app-management/app-instance/paid-plan-purchased). These events notify your app when it's installed or removed from a site, allowing you to perform essential tasks like saving instance data, provisioning resources, or cleaning up when users uninstall your app.

Learn more [about events](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-events).

</blockquote>

## Access

Access to Wix APIs requires successful authentication and authorization. Authentication confirms the identity of the entity making the request, while authorization determines the permitted actions for that identity. Recognized identities include site visitors, site members, Wix users (or admins), and Wix apps. Third-party apps integrating with Wix APIs need to authenticate following the [OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth) protocol. Authorization protects your site data by ensuring that only authorized users can perform specific actions.

For more information, see [About Access for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-access#about-access-for-wix-apps).

## App instances

When a Wix user installs your app on their site, Wix generates an app instance. An app instance represents a unique installation of your app on a specific site, identified by an `instanceId`. This ID is essential for identifying users, managing site-specific data, and handling billing logic for paid apps. The app instance also provides useful information such as the site owner's email, the app's billing cycle, and the purchased pricing package. You can retrieve app instance data through webhooks, API calls, or encoded query parameters.

For more information, see [About App Instances](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances).

## Wix Design System

The Wix Design System is a comprehensive toolkit for developers and designers to craft beautiful and intuitive product experiences. The Wix Design System offers a range of resources, including React libraries, design patterns, Figma kits, component documentation, interactive playgrounds, color palettes, icons, fonts, and more. For developers, the Wix Design System includes a React library of core reusable components. For designers, the Wix Design System includes a Figma kit to integrate Wix design assets into their design workflow.

For more information, see [About the Wix Design System](https://dev.wix.com/docs/build-apps/develop-your-app/design/about-the-wix-design-system).

## Pricing and billing

If you plan to monetize your app through the Wix App Market, you'll need to set up pricing plans and implement the corresponding logic in your app. While Wix handles billing and payment processing, it's your responsibility to code the behavior that differentiates between pricing tiers. This includes identifying which plan a user has installed, restricting access to premium features for free or lower-tier users, and providing clear upgrade paths.

For more information, see [Monetize Your App](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/about-monetizing-your-app).

## See also

- [About the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard)
- [About Development Frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks#about-development-frameworks)
- [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions#about-extensions)
- [Map your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
- [About Wix Business Solutions](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/about-wix-business-solutions#about-wix-business-solutions)
- [About Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/about-wix-business-solutions#about-wix-business-solutions)
- [About Access for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-access#about-access-for-wix-apps)
- [About the Wix Design System](https://dev.wix.com/docs/build-apps/develop-your-app/design/about-the-wix-design-system)
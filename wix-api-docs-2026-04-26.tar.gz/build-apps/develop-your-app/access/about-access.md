---
portal: build-apps
name: "About Access"
type: ARTICLE_RESOURCE
resourceId: 72229921-d7bc-46a3-8e8f-e9c51bd782c2
---

# About Access

# About Access for Wix Apps

Access to Wix APIs requires successful authentication and authorization. Authentication confirms the identity of the entity making the request, while authorization determines the permitted actions for that identity.

You can access Wix APIs using the [REST API](https://dev.wix.com/docs/rest), [JavaScript SDK](https://dev.wix.com/docs/sdk), or [Velo](https://dev.wix.com/docs/velo) (for Wix Blocks).

## Identities

Identities are essential to managing interactions within the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem). Recognized identities include site visitors, site members, Wix users (or admins), and Wix apps. These classifications affect both authentication and authorization processes.

For more information, see [About Identities](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities).

## Authentication

To guarantee a secure connection, third-party apps integrating with Wix APIs need to authenticate following the [OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth) protocol. Your app can authenticate as an app instance, on behalf of a Wix user, or on behalf of a site visitor or member.

For more information, see [About Authentication](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication).

> **Note:** Wix offers [API keys](https://dev.wix.com/docs/rest/articles/getting-started/api-keys) for authentication, but they aren’t available for use in third-party Wix apps.

## Authorization

App permission scopes specify the allowed actions and data access limits. When you register an app in the app dashboard, you define the required permission scopes that site owners need to approve. To understand the permissions needed for your app, refer to the documentation for each API your app uses.

For more information, see [About Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions).

## See also

* [About Webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks)
---
portal: build-apps
name: "About Identities"
type: ARTICLE_RESOURCE
resourceId: fcfb6691-0a43-41f7-9b44-7abe482ff02f
---

# About Identities

# About Identities

Identities are essential to managing interactions within the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem). Every request made to a Wix API is associated with an identity type, and the ability for an entity to use an API depends on their identity type. For example, site visitors can't create new products for the site, and apps can't add items to a visitor's cart unless authenticated on their behalf.

## Identity types

The following are recognized identity types:

* **[Site visitors:](#site-visitors)** Site visitors that access a Wix site for the first time or aren’t logged in as members.
* **[Site members:](#site-members)** Site visitors with a member account who are logged in to the site. 
* **[Wix users:](#wix-users)** Site owners or collaborators that access the [site editor](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem#site-editors) or [site dashboard](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem#site-dashboard).
* **[Wix apps:](#wix-apps)** Apps that access and integrate with any aspect of the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem), such as the site editor, site dashboard, and Wix APIs.

> **Note**: Wix apps can authenticate on behalf of other identity types. For more information, see [About Authentication for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication).

### Site visitors

Site visitors that access the live site for the first time or aren't logged in as members are also known as anonymous visitors. Wix assigns anonymous visitors a visitor ID and saves this ID in browser cookies.

<blockquote class="warning">

__Warning:__ If a site visitor cleans their cookies, they’re assigned a new visitor ID, and Wix can’t associate them with their previous visits.

</blockquote>

### Site members

When a site visitor creates an account on the site, and logs in, they become a [site member](https://support.wix.com/en/article/about-the-members-area). Wix assigns a member ID to each member and stores this information in a persistent manner. Site owners can use [member roles](https://support.wix.com/en/article/site-members-creating-member-roles) to control permissions. To get member data, use [Query Members](https://dev.wix.com/api/rest/members/members/query-members) and [List Members](https://dev.wix.com/api/rest/members/members/list-members).

<blockquote class="important">

__Important:__ When Wix apps authenticate on behalf of Wix members, [member roles](https://support.wix.com/en/article/site-members-creating-member-roles) can affect the permissions your app is granted. This behavior is currently only supported for Wix Blocks. For more information, see [About Authentication for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication).

</blockquote>

When a site visitor first shares their contact information with a site, which commonly happens on member sign up, a contact entry is created. Therefore, members are often linked to a contact. However, contacts aren't identities, and site visitors and members aren't recognized by their contact ID during site interactions. Contact IDs are primarily used for tasks like sending emails, unrelated to the visitor identity within the site. To get contact data, use [Query Contacts](https://dev.wix.com/docs/rest/crm/members-contacts/contacts/contacts/contact-v4/query-contacts) or [List Contacts](https://dev.wix.com/docs/rest/crm/members-contacts/contacts/contacts/contact-v4/list-contacts).

> **Note:** Any correlation between member ID and contact ID is coincidental.

### Wix users

A Wix user is someone who is logged into their account on **.wix.com*. Users can be site owners or site collaborators, including app owners and collaborators who create test sites. Users who create a site are automatically designated as the owner of that site.

When a user registers, Wix assigns them a unique user ID and an account ID. All sites that a user creates are automatically assigned to their account, as well as any domains, teams, custom templates and custom apps. Users can log in to multiple accounts using their unique login credentials.

Site owners can invite collaborators and assign them specific [user roles](https://support.wix.com/en/article/roles-permissions-overview) to control permissions. Site collaborators are authenticated at the site-level and don't have access to account-level data. However, account-level access can be shared and managed via [teams](https://support.wix.com/en/article/wix-studio-managing-your-team), which offer default team roles and permissions. Accounts are particularly useful for businesses with multiple staff members who need access to manage sites or apps.

<blockquote class="important">

__Important:__ When Wix apps authenticate on behalf of Wix users, [user roles](https://support.wix.com/en/article/roles-permissions-overview) can affect the permissions your app is granted. For more information, see [About Authentication for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication).

</blockquote>

### Wix apps

[Wix apps](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps) are packages of reusable functionality that users can add to their sites. To learn about how apps fit into the Wix ecosystem, see [How Apps Extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).

Each Wix app has a unique app ID, which can be found on the **OAuth** page of your [app's dashboard](https://dev.wix.com/apps/my-apps). When an app is installed on a Wix site, an [app instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances) is generated with a distinct ID representing the app on that particular site.

Apps can authenticate as an app instance (specific to a site) or on behalf of other identity types, such as for apps featuring a [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions). For more information, see [About Authentication for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication).

## Identities and API access

Upon successful authentication, an access token is returned specific to the requesting identity. If you try to access an API method with an unauthorized identity type, the request results in an unauthorized error response.

For example, site visitors and site members are restricted from using [Create Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/create-product), and Wix users and apps are restricted from using [Add to Current Cart](https://dev.wix.com/docs/rest/business-solutions/e-commerce/cart/add-to-current-cart). 

## Elevated API calls
In some app [extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions), your app's Wix API calls have [visitor](#site-visitors), [member](#site-members), or [Wix user](#wix-users) authentication by default. In these cases, you can use the Javascript SDK to elevate specific calls to use [Wix app](#wix-apps) authentication.

Learn more about [elevated permissions](https://dev.wix.com/docs/sdk/articles/working-with-the-sdk/about-elevated-permissions).

## See also

* [About Authentication](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication)
* [About Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions)
---
portal: build-apps
name: "About Authentication"
type: ARTICLE_RESOURCE
resourceId: 33935aa3-e956-42bd-ae5a-72f137b893cd
---

# About Authentication

# About Authentication for Wix Apps

To ensure a secure connection, third-party apps integrating with Wix APIs must authenticate using the [OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth) protocol. The access token and permissions granted vary depending on the authentication method:

* [App instance](#authentication-as-an-app-instance), or an instance of your app on a specific site
* [On behalf of a Wix user](#authentication-on-behalf-of-a-wix-user)
* [On behalf of a site visitor or member](#authentication-on-behalf-of-a-site-visitor-or-member)

To learn more, see [About Identities](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities).

> **Note:** Wix offers [API keys](https://dev.wix.com/docs/rest/articles/getting-started/api-keys) for authentication, but they aren’t available for use in third-party Wix apps.

## Authentication as an app instance

<blockquote class="warning">

**Deprecated:** Custom authentication is no longer available for new apps. Existing apps that already use [custom authentication](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/custom-authentication-legacy) can continue to do so. To migrate to the new authentication, see [Authenticate Using OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth#migrate-from-custom-authentication-legacy).

</blockquote>

When your app authenticates as an [app instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances), the authentication token grants access only to the permissions associated with the app. To authenticate as an app, you’ll need the app ID, app secret, and the app instance ID, which serves as a unique identifier for the app within a given website.

For more information, see [Authenticate Using OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth).

## Authentication on behalf of a Wix user

Your app can authenticate on behalf of a Wix user to get an access token that includes the permissions granted to both the app and the user. With this capability, apps with a dashboard page can identify requests that match the permissions of the Wix user in the dashboard. Wix users can have distinct [user roles](https://support.wix.com/en/article/roles-permissions-overview), resulting in variations in the permissions your app is granted for each user.

![Intersection of app and user permissions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f57860caa572da74871f6328b3a6c71d.png)

For example, if your app has permissions to add products to a store, but the current user doesn't, your app won't be able to add products to the store. Conversely, if the current user has permissions to add products to a store, but your app doesn't, your app won't be able to add products to the store. The only way your app can add products to a store is if both your app and the current user have permissions to do so.

In Wix-hosted apps, such as those built with [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) or the [CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), authentication is built-in.

For self-hosted apps, learn how to [Authenticate on behalf of a Wix User](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-on-behalf-of-a-wix-user).

<blockquote class="important">

__Important:__ This authentication approach is currently only supported for [dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions).

</blockquote>

## Authentication on behalf of a site visitor or member

Your app can authenticate on behalf of a site visitor or member to get an access token that includes the permissions granted to both the app and the site visitor or member.

For example, APIs like [Get Current Cart](https://dev.wix.com/docs/rest/business-solutions/e-commerce/cart/get-current-cart), which are normally accessible only by site visitors or members, can also be called by your app if it has the required permissions listed in the API reference.

In Wix-hosted apps, such as those built with [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) or the [CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), authentication is built-in.

For self-hosted apps, implement this method for:

* [Site widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/site-widgets-and-plugins/authenticate-using-the-wix-client-in-custom-elements-for-self-hosted-site-extensions)
* [Embedded scripts](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/embedded-scripts/authenticate-using-the-wix-client-in-self-hosted-embedded-script-extensions)

## See also

* [About Identities](https://github.com/wix-private/developer-docs/blob/405f748442d1ba2414a9d6b26f1dc9a53fa7d48f/build-apps-portal/develop-your-app/access/about-identities.md*original::../about-identities.md)
* [About Permissions](https://github.com/wix-private/developer-docs/blob/405f748442d1ba2414a9d6b26f1dc9a53fa7d48f/build-apps-portal/develop-your-app/access/authorization/about-permissions.md*original::../authorization/about-permissions.md)
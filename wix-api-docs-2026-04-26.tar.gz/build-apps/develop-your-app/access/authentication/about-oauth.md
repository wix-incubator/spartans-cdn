---
portal: build-apps
name: "About OAuth"
type: ARTICLE_RESOURCE
resourceId: e8841927-0030-48c7-83a7-756dbd4e263c
---

# About OAuth

# About OAuth

Your app must authenticate Wix API calls using the OAuth protocol. OAuth is a secure and simple method that eliminates the need for redirects and token management.

## OAuth

OAuth authentication follows the [OAuth Client Credentials protocol](https://oauth.net/2/grant-types/client-credentials/).
Using this approach, you don’t need to implement an OAuth handshake for each
installation of your app. Instead, your app can directly request an access token by calling [Create Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/create-access-token)
with the following values:

* App ID
* App secret
* The relevant [app instance ID](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances)

OAuth has the following advantages compared to custom authentication (deprecated):

* OAuth helps prevent corrupted installations.
* OAuth is simpler to implement, since you don't need to setup and run a server for redirects or manage a database for refresh tokens.
* With custom authentication (deprecated), cloned sites can bypass consent flows, potentially causing issues with refresh tokens. Users may need to reinstall the app to obtain the required refresh token for proper installation.

To get started, see [Authenticate Using OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth).

## Custom authentication (deprecated)

<blockquote class="warning">

**Deprecated:** Custom authentication is no longer available for new apps. This section is only relevant for existing apps that already use custom authentication. Note that apps using custom authentication must prompt users to reinstall the app when a site is cloned. Cloning creates a new [app instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances) without triggering the consent flow, resulting in the absence of a refresh token. To migrate to the new authentication, see [Authenticate Using OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth#migrate-from-custom-authentication-legacy).

</blockquote>

Wix offers [custom authentication](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/custom-authentication-deprecated) to allow for more control over user identification and redirection during the app installation process. Apps may use custom authentication when they need to redirect users to a URL outside the Wix ecosystem during the app installation flow. For example, when you need to automatically create an account using the [information in the access token](https://dev.wix.com/docs/rest/app-management/oauth-2/token-info).

Custom authentication follows the industry-standard [OAuth 2.0 protocol](https://oauth.net/2/),
which provides a secure way for site owners to grant your app permissions.
Whenever a site owner installs your app, your app's code must complete an OAuth
handshake. This requires that you set up a server to handle the relevant
redirects. Then, you need to store the refresh token for the new app instance
in your database. Finally, you can use the refresh token to retrieve an access
token and call the relevant Wix API.

With custom authentication, it's critical that your app saves the refresh token during
installation. If the process fails, you're unable to retrieve access tokens
using [Refresh an Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/refresh-an-access-token).
Though from the site owner's point-of-view, it seems that the app installation
has succeeded. You have 2 options in this situation: Ask the site owners to
re-install your app, or fall back to retrieving access tokens with the
OAuth strategy by calling [Create Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/create-access-token).

## See also

* [Authenticate Using OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth)
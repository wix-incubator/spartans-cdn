---
portal: build-apps
name: "Authenticate on Behalf of a Wix User"
type: ARTICLE_RESOURCE
resourceId: 182e6c58-652a-4459-bdaa-036e504f5695
---

# Authenticate On-Behalf-Of a Wix User

# Authenticate on behalf of a Wix User

Your app can authenticate on behalf of a Wix user to access site data and perform actions, combining the permissions of the app and the user. Wix users may have different [user roles](https://support.wix.com/en/article/roles-permissions-overview), resulting in different permissions granted to your app for each user.

On behalf of user authentication is supported for [dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions), which facilitate user site and business management. It allows your app to recognize requests aligned with the permissions of the Wix user within the dashboard.

This article explains how to authenticate on behalf of a Wix user using the [Javascript SDK](https://dev.wix.com/docs/sdk/core-modules/sdk/introduction). The SDK manages the OAuth process for you behind the scenes. This functionality isn't currently supported using the REST API.

<blockquote class="important">

__Important:__ This authentication strategy is currently only supported for [dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions).

</blockquote>

## Javascript SDK

To authenticate your app on behalf of a Wix user using the JavaScript SDK:

1. Install the [SDK](https://dev.wix.com/docs/sdk/core-modules/sdk/introduction):

    ```bash
    npm install @wix/sdk
    ```

   The SDK module is used to communicate with the Wix platform from JavaScript code by providing a client for making authenticated calls to Wix APIs.

1. Install the [Dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/introduction):

    ```bash
    npm install @wix/dashboard
    ```
	
    The Dashboard SDK allows code in custom dashboard components to interact with the Wix dashboard. This includes features like navigating users, displaying modals, and sending alerts and updates. 
    
1. Create a [`WixClient`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client) instance with the dashboard host and authentication strategy:

    ```javascript
    import { createClient } from '@wix/sdk';
    import { dashboard } from '@wix/dashboard';
    
    const myClient = createClient({
      host: dashboard.host(),
      auth: dashboard.auth(),
      modules: {
        dashboard,
      },
    });
    ```

    The dashboard authentication strategy considers the Wix user in context, providing an app access token with combined app and user permissions.

1. Make an API request. Behind the scenes, the client makes a request to obtain an access token and incorporates it into the `Authorization` request header. For example:

    ```javascript
    import { products } from '@wix/stores';
    
    const { items } = await myClient.products.queryProducts({
      filter: { 
        name: { $startsWith: 'shoes' } 
      },
      cursorPaging: { limit: 4 }
    });
    ```

    <blockquote class="tip">

    __Tip:__ If a REST API isn't available in the SDK, you can still access it using the [`fetch()`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client#fetch) method.
    
    </blockquote>


## See also

* [About Authentication for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication)
* [About Identities](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities)
---
portal: build-apps
name: "Authenticate Using OAuth"
type: ARTICLE_RESOURCE
resourceId: 60cb0675-a81a-461a-8492-eda00a0898b8
---

# Use OAuth

# Authenticate Using OAuth

This article explains how to authenticate API calls to Wix using [OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth).

<blockquote class="important">

**Important:** Extensions built with [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) or the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) handle authentication automatically.

</blockquote>

## Step 1 | Get app credentials and instance ID

To authenticate, you need the following information:

* **App ID:** Find it on the [**OAuth**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Foauth) page of your app's dashboard.
* **App secret:** Find it on the [**OAuth**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Foauth) page of your app's dashboard. Keep this value confidential.
* **App instance ID:** The unique identifier (`instanceId`) for your app on a site.

There are different ways to get the `instanceId`, depending on your app's logic. The most common methods for getting it to generate an access token are:

* [App Instance Installed webhook](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed): Triggered when your app is installed on a Wix site. We recommend saving the `instanceId` at this point.
* [Webhook payloads](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks): Each webhook sent by Wix includes the `instanceId`.
* [Service plugin metadata](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions): Each service plugin request from Wix includes the `instanceId` in the metadata.
* [app instance query parameter](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances#app-instance-query parameter): External pages and iframe extensions receive an app instance query parameter with the `instanceId`.

To learn more, see [About App Instances](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances).

## Step 2 | Make an authenticated API request

The authentication process varies depending on whether you use the JavaScript SDK or REST API.

### JavaScript SDK

To make an authenticated API request with the JavaScript SDK in a self-hosted extension:

1. Create a [`WixClient`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client) using the [`AppStrategy`](https://dev.wix.com/docs/sdk/core-modules/sdk/app-strategy).

    ```javascript
    import { createClient, AppStrategy } from '@wix/sdk';
    import { products } from '@wix/stores';
    
    const myClient = createClient({
      auth: AppStrategy({
        appId: '<APP_ID>',
        appSecret: '<APP_SECRET>',
        publicKey: '<APP_PUBLIC_KEY_FOR_WEBHOOKS>',
        instanceId: '<INSTANCE_ID>'
      }),
      modules: {
        products,
      }
    });
    ```

1. Make an API request. The client automatically obtains and includes the access token in the `Authorization` header. For example, call [`queryProducts()`](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/query-products).

    ```javascript
    const { items } = await myClient.products.queryProducts({});
    ```

<blockquote class="tip">

**Important:** The [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) also uses the JavaScript SDK but handles authentication automatically. To make API requests from CLI extensions, use the [httpClient](https://dev.wix.com/docs/sdk/core-modules/essentials/http-client).

</blockquote>

### REST API

To make an authenticated API request with the REST API:

1. Send a request to [Create Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/create-access-token). Include your app ID, app secret, and `instanceId` in the HTTP body.

    ```curl
    curl -X POST 'https://www.wixapis.com/oauth2/token' -H 'Content-Type: application/json' -d '{
      "grant_type": "client_credentials",
      "client_id": "<APP_ID>",
      "client_secret": "<APP_SECRET_KEY>",
      "instance_id": "<APP_INSTANCE_ID>"
    }'
    ```

1. Store the `access_token` from the response. The token is valid for 4 hours.

1. Make an API request by including the `access_token` in the `Authorization` header. For example, call [Query Products](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/query-products).

    ```curl
    curl -X POST \
       'https://www.wixapis.com/stores/v1/products/query' \
        --data-binary '{}' \
       -H 'Content-Type: application/json' \
       -H 'Authorization: <ACCESS_TOKEN>'
    ```

## Migrate from custom authentication (legacy)

To migrate from custom authentication to OAuth:

1. Replace requests to [Refresh an Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/refresh-an-access-token) with [Create an Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/create-access-token).
1. Make sure that you have a method to get `instanceId` as described in step 1. We recommend subscribing to the [App Instance Installed webhook](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed).

## See also

* [About OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth)
* [About Authentication for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication)
* [JavaScript SDK: About Self-Hosted Apps](https://dev.wix.com/docs/sdk/articles/get-started/about-self-hosted-apps)
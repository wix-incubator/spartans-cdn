---
portal: build-apps
name: "Custom Authentication (deprecated)"
type: ARTICLE_RESOURCE
resourceId: d4ff6eaf-785c-455d-843b-21a9eb53b055
---

# Use Advanced OAuth

# Custom Authentication (Deprecated)

<blockquote class="warning">

**Deprecated:** Custom authentication is no longer available for new apps. This article is only relevant for existing apps that already use custom authentication. For new apps and migration, see [Authenticate Using OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth). 

</blockquote>

Custom authentication follows the industry-standard [OAuth 2.0 protocol](https://oauth.net/2/),
which provides a secure way for site owners to grant your app permissions.
Whenever a site owner installs your app, your app’s code must complete an OAuth
handshake.

Before you start, it's important to understand how the custom authentication flow works.
The diagram below shows the complete flow including all actions that your app,
Wix, and the user must take.

![custom authentication flow](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6a42cc18f6365efcf8717c3b017a740f.png)

## Step 1 | Set up custom authentication in your app's dashboard

Before setting up your app’s custom authentication settings, complete the OAuth
settings in your [app's dashboard](https://manage.wix.com/account/custom-apps).

1. Under **Build your app,** go to **OAuth**.
1. Find your app’s **secret key** and store securely. Don’t share it with
   anyone or make it public in any way.
1. Enter an **App URL**. Wix redirects your new users to this URL when they
   install your app. You must use an HTTPS URL. During your app’s development,
   you may use localhost or ngrok URLs, but you need to change the URL before
   submitting your app for review.
1. Enter a **Redirect URL**. When a new user agrees to give your app the
   requested permissions, Wix redirects them to this URL. The redirect includes
   your app’s temporary authorization code.
1. Make sure to click **Save** before navigating away from the OAuth settings
   page.
1. Confirm that the
   [Cross-Origin-Opener-Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cross-Origin-Opener-Policy)
   of both the app URL and redirect URL is set to `unsafe-none`. This enables
   Wix to close the redirect window as part of the flow. If the COOP of either
   URL has a different value, set it to `unsafe-none`.

## Step 2 | Set up custom authentication in your app

1. When a new user installs your app, they're asked to approve the complete list of required
   [permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions) that your app is requesting.
1. Once approved, Wix redirects the user to your app URL with the authorization token. Make
   sure to save the `token` query parameter value. We recommend that, at this
   point, you omit a sign-up or log-in step on your end.
1. Redirect the user to Wix at `https://www.wix.com/installer/install`. Include the `token`, your 
   `appId`, and `redirectUrl` as query parameters. You may also pass a `state` to identify your customers along the installation process.
1. Wix redirects the user back to your app’s `redirectUrl`. From the redirect’s query parameters, save 
   the `code` and `instanceId`. Wix also includes `state` as a query parameter
   value. If the value doesn’t match the one provided by you, the request may
   have been created by a third party. Then, we recommend aborting the process.
1. This temporary authorization `code` is valid for 10 minutes. Use it to
   request your app’s refresh and access token by calling
   [Request an Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/request-an-access-token).
   The access token is only valid for 5 minutes. You need to request a new
   access token to make Wix API calls after it expires.
1. Optional: If your app requires user login or sign-up, you can present the
   relevant modal to the user. Note that you can't do this prior to this point,
   but may choose to do at any later point.
1. Optional: If your app includes a
   [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions)
   or [dashboard extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions)
   that opens inside of Wix as an iframe, or another internal component of your
   app, your app needs to close the user’s browser window that has displayed
   the permission consent agreement. To close the consent window, redirect the
   user to this URL: `https://www.wix.com/installer/close-window?access_token=<ACCESS_TOKEN>`.
   Make sure to replace `<ACCESS_TOKEN>` with your app instance’s access token.
1. Optional: Update Wix about the status of your new app instance. At this
   point, your app instance’s `state` is`“Setup Incomplete”`. This state is
   useful if your app requires users to create an account or set other
   configuration parameters for the app to become active. If your app doesn’t
   require user input to become active, or after the user has completed their
   part, update your app instance’s state by calling
   [Send BI Event](https://dev.wix.com/docs/rest/app-management/bi-event/send-bi-event).
   Make sure to pass `{"eventName": "APP_FINISHED_CONFIGURATION"}`.

## Step 3 | Make API calls

After you successfully set up custom authentication, you can call the relevant Wix
APIs described in our [API Reference](https://dev.wix.com/docs/api-reference).

1. Request a new access token by calling
   [Refresh an Access token](https://dev.wix.com/docs/rest/app-management/oauth-2/refresh-an-access-token).
   Pass `{"grant_type": "refresh_token"}` and your app’s secret key as
   `client_secret` in the request.
1. Use the access token as an `Authorization` header in the relevant API call. The access token is only valid for 5 minutes.
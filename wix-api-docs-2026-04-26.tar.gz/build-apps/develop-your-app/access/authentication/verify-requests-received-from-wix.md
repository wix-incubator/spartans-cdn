---
portal: build-apps
name: "Verify Requests Received from Wix"
type: ARTICLE_RESOURCE
resourceId: ce006740-631a-4d9b-bfcc-c2c5f2b0703b
---

# Verify Requests Received from Wix

# Verify Requests Received from Wix

When you receive a data payload from Wix, it includes a header called `digest`. The header holds a [JSON Web Token (JWT)](https://jwt.io/introduction/) with the signed data.

Before using the data you've received, you should:

* Verify the JWT's signature to confirm that the data was sent by Wix.
* Verify the integrity of the data (for encrypted payloads only – not webhooks).

Here's a sample JWT:

```json
eyJraWQiOiJxRzFrRDJkeiIsImFsZyI6IlJTMjU2In0.eyJkYXRhIjp7IlNIQTI1NiI6IjNmZDA1ZGZlNDI5ODM3ZGE4NmNiYzcxMDE5MGM5YTY3Mjk2MjAzYmJkNGJkMzE2MGFiMGZmMDdiNjU5YjAxNjAifSwiaWF0IjoxNTUwOTM2NzMxLCJleHAiOjE1NTEyMzY3MzF9.JSRB5MbSNQEXd3we4SJR9voXTIePHlVGSGOb6OXV2v7oHBfRxaisE-ZIdNDMW2Wyy_u48VbKOUxOMdaBGRbP9Vy8S7AuXwixswBYqBS-CG2VffHVAbuijTxUkRzu7Fp29xfC14nDOdF_-aOS5morA_4j-Vbcju3ZwJsk23XLvqLuNmjCgces5QHqYDYazhX8oIqncfEHr1ZJadSFrFZeDhwQmwUGr6xwW8pNi5EJqby1sOAe8r7I3OnYG6qSWrnUHaHfSNJxEzZGST-oFJhaWSc2jGJ8ZyOhtr6UA-j6zdcqEuJBpA_YFpL23eI5vDCkVs6hSOtQ8FkiyFPy07OFzQ
```

## Step 1 | Verify that the data came from Wix

To verify that the data came from Wix:

1. Select your app from the [Custom Apps page](https://manage.wix.com/studio/custom-apps) in your Wix Studio Workspace.
1. At the top of your app's home page, click **More Actions** ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/45e14aa3d153b022e301df2cea4fabfb.png) and select **View ID & keys**.
1. Copy the public key and use it to decode the JWT.

Here's what the data looks like once its been decoded and verified with your public key:

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ac/d0d6e5d7-1e68-49aa-8fbd-c4454894592e/2019/02/24/69f3af93-5c9a-4b8a-9a97-a03009c9bc62.png)

</div>

> **Note:** View a sample decoded JWT in the [JWT debugger](https://jwt.io/#debugger-io?token=eyJraWQiOiJxRzFrRDJkeiIsImFsZyI6IlJTMjU2In0.eyJkYXRhIjp7IlNIQTI1NiI6IjNmZDA1ZGZlNDI5ODM3ZGE4NmNiYzcxMDE5MGM5YTY3Mjk2MjAzYmJkNGJkMzE2MGFiMGZmMDdiNjU5YjAxNjAifSwiaWF0IjoxNTUwOTM2NzMxLCJleHAiOjE1NTEyMzY3MzF9.JSRB5MbSNQEXd3we4SJR9voXTIePHlVGSGOb6OXV2v7oHBfRxaisE-ZIdNDMW2Wyy_u48VbKOUxOMdaBGRbP9Vy8S7AuXwixswBYqBS-CG2VffHVAbuijTxUkRzu7Fp29xfC14nDOdF_-aOS5morA_4j-Vbcju3ZwJsk23XLvqLuNmjCgces5QHqYDYazhX8oIqncfEHr1ZJadSFrFZeDhwQmwUGr6xwW8pNi5EJqby1sOAe8r7I3OnYG6qSWrnUHaHfSNJxEzZGST-oFJhaWSc2jGJ8ZyOhtr6UA-j6zdcqEuJBpA_YFpL23eI5vDCkVs6hSOtQ8FkiyFPy07OFzQ&publicKey=-----BEGIN%20PUBLIC%20KEY-----%0AMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlhQbczvgh7Z%2BA0G9d1VR%0A9V8eXtq2KPCagZZHaEpagm9oAeUYWoyy4ibsl3m6qMNCBgl6LXyCpGl9UtyEhx2m%0Ag80RJNRLdETagydxvYO6SwcAFs7DheVfSble852LQ2m%2BVM1TgW4JQQrwZcFObLfi%0AujfBEr7eRK7hB0i6K0zHt7BvF9THIJQifO7r9sKkMdu%2B%2FcNJxN2Q%2B%2Bs%2F9pSUlnB3%0AzEPmvZHfbf3v04A5Nl%2FZw%2ButD5u9A81FElz8RoXCgMH3CCTBmwORcriv5qDOsAYR%0A9J2gKhpvx5fxaoCzjx1k7npTp%2Fx1D5Xi3WMW338S6edZSYlEopzO7NAuP%2F%2BmdSrO%0ATwIDAQAB%0A-----END%20PUBLIC%20KEY-----%0A).

## Step 2 | Verify the integrity of the data

In some cases, the payload data will be encrypted as a security precaution. If the data is encrypted, it's crucial to ensure its integrity and confirm that it hasn't been altered during transit.

> **Note:** Webhook payloads are not encrypted.

The encrypted payload data includes an object with a hash of the payload data, and the hash type as its key. For example: 

```json
"data": 
{
    "SHA256": "3fd05dfe429837da86cbc710190c9a67296203bbd4bd3160ab0ff07b659b0160"
}
```

To verify the integrity of the data:

1.  Take the encrypted body data you received and hash it using the same hashing algorithm listed in the data object. In our example: 

    *   Hash type: **SHA256**
    *   Body data: **{"mydata":"is secured"}**

2. Compare the new hash with the hash listed in the data object. For example: **Sha256({"mydata":"is secured"})** yields **3fd05dfe429837da86cbc710190c9a67296203bbd4bd3160ab0ff07b659b0160**.
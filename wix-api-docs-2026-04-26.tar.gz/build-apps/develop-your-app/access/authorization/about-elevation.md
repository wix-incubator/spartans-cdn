---
portal: build-apps
name: "About Elevation"
type: ARTICLE_RESOURCE
resourceId: daa2bbf0-7053-4271-96e8-33c2405eb515
---

# About Elevation

# About Elevation

When you use site visitor, site member, or Wix user [authentication](https://dev.wix.com/docs/rest/articles/getting-started/about-identities), you can only make calls to APIs that allow calls from those identity types. In some app workflows, you may be making API calls with site visitor or site member authentication, but occasionally need to call APIs that require the elevated level of a Wix app identity for authentication. This can happen when coding in a frontend environment such as a [site extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) or a [dashboard extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions).

For example, if an app includes a [site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions), most of the API calls made from the extension are probably APIs that can be called with site visitor or member authentication, such as [Create Booking](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/create-booking) to create a booking for the current visitor or member. However, the app may also need to call related APIs that require Wix app authentication, such as [Confirm Booking](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/confirm-booking) which cannot be called when authenticating as a visitor or member.

In these cases, you can elevate the permissions of specific API calls in your workflow to use Wix app authentication. Elevating permissions for specific API calls allows you to move seamlessly between authentication types within your app's code. 

## How to elevate API calls

You can only elevate permissions in your app's backend code. You can elevate the permissions for an API call by sending an authenticated request to an endpoint or method exposed in your app's backend code. The backend code makes an elevated API call and returns the response to your frontend.

The process for elevating permissions depends on:

- The [API technology](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis#api-technologies). For example, SDK or REST.
- The [development framework](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks) of your app's backend. For example, the Wix CLI or self-hosting.

For step-by-step guidance, see the relevant article:

<!-- - [Elevate SDK Call Permissions with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/development/elevate-api-call-permissions) -->
- [Elevate SDK Call Permissions with Self-Hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/elevate-sdk-call-permissions-with-self-hosting)
- [Elevate REST API Call Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/elevate-rest-api-call-permissions-for-self-hosting)
- [Elevate API Calls in Blocks](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/authorization/elevation)

## See also

- [About Identities](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities)
- [About Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions)
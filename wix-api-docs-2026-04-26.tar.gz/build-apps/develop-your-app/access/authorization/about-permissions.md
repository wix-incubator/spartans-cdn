---
portal: build-apps
name: "About Permissions"
type: ARTICLE_RESOURCE
resourceId: b3197ac8-c458-443b-900a-3682c0f16243
---

# About Permissions

# About Permissions for Wix Apps

Your app can access site data through API calls or webhooks. To do so, it must request the necessary permissions specified in the API and webhook references. Permissions are essential for protecting site data and ensuring only authorized users can perform specific actions.

In the [app dashboard](https://dev.wix.com/apps/my-apps), you specify the permission scopes your app requires from site owners. Upon installing your app, site owners are prompted to grant these permissions. Then, when the app authenticates, an access token with the relevant permissions is returned.

## APIs

In the [REST API](https://dev.wix.com/docs/rest), [JavaScript SDK](https://dev.wix.com/docs/sdk), and [Velo](https://dev.wix.com/docs/velo) (for Wix Blocks) reference, each endpoint and method lists supported permission scopes. To use the endpoint or method, your app needs to have at least one of the listed permission scopes.

To set up permissions, see [Configure Permissions for Your App](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/configure-permissions-for-your-app).

## Webhooks

With [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks), permissions are configured during the subscription process as follows:

* If a single permission scope is required to use the webhook, Wix automatically adds that permissions scope to your app.
* If there are multiple possible permission scopes that allow you use the webhook, you're prompted to select the desired permission scope. For example:
    
    ![Select permission scope during webhook subscription webhook](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-permissions-md_build-apps-portal_develop-your-app_access_authorization_assets_webhook-permissions.png)

When you click **Subscribe**, the permissions are added to your app.

## App Market guidelines

For your app to be approved on the app market, it must request only the necessary permissions for app functionality. This requirement includes refraining from requesting permissions that are redundant or contained within others. For example, if your app requires and requests **Manage Stores - All Permissions**, it shouldn't also request **Manage Products** because those permissions are already included in the greater permission set.

## See also

* [Configure Permissions for Your App](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/configure-permissions-for-your-app)
---
portal: build-apps
name: "Configure Permissions for Your App"
type: ARTICLE_RESOURCE
resourceId: b1f7abe8-3509-4de0-a646-1ca4bf57ee41
---

# Configure Permissions for Your App

# Configure Permissions for Your App

This article explains how to identify the required permissions and add them to your app configuration. For more information, see [About Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions).

<blockquote class="important">

__Important:__ When your app authenticates on behalf of a Wix user, it takes into account the roles specific to that user, which can influence the permissions granted to your app. Learn more about [user roles](https://support.wix.com/en/article/roles-permissions-overview). 

</blockquote>

## Step 1 | Identify required permissions

To identify which permissions your app requires:

1. Go to the [REST API](https://dev.wix.com/docs/rest), [JavaScript SDK](https://dev.wix.com/docs/sdk), or [Velo](https://dev.wix.com/docs/velo) (for Wix Blocks) reference.
1. Search for the endpoints or methods your app uses.
1. Find the supported permission scopes under **Permission Scopes**:

    ![Permission scopes in reference](https://wixmp-833713b177cebf373f611808.wixmp.com/images/configure-permissions-md_build-apps-portal_develop-your-app_access_authorization_assets_permission-scopes.png)

1. Select one of the permission scopes listed to include in your app. You can click on a scope to prompt the addition to your app, as described in the next section.

<blockquote class="warning">

__Warning:__ Only request the permissions your app requires. Apps that request unnecessary permissions aren’t allowed on the app market.

</blockquote>

## Step 2 | Add permissions to your app

To add permissions to your app:

1. Go to [**Permissions**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fdev-center-permissions) in your app's dashboard. 
1. Click **Add Permissions**.
1. Search or filter for the relevant scope.
1. Select the relevant scopes from the results.

    <blockquote class="tip">
    
    __Tip:__ Keep in mind that some high-level permission scopes, like **Read Stores - All Read Permissions**, encompass multiple other permission scopes, such as **Read Products** and **Read Orders**. Therefore, you don’t need to add the lower scopes separately.
    
    </blockquote>

1. Click **Save**.

When a site owner installs your app, they’re prompted to approve the specified permissions.
---
portal: build-apps
name: "About Wix APIs"
type: ARTICLE_RESOURCE
resourceId: 43c317a9-e461-449a-a2db-a06113f2020f
---

# About Wix APIs

# About Wix APIs

Wix APIs act as the bridge between your app and the Wix ecosystem, enabling communication and integration between your app and Wix. 

With the Wix APIs, you can:
- Transfer data between your app and the site it's installed on.
- Extend [apps created by Wix](https://dev.wix.com/docs/rest/articles/getting-started/apps-created-by-wix), such as Wix eCommerce or Wix Bookings. 
- Customize your app’s interactions with site visitors.

<blockquote class="important">

__Important:__
Use of Wix APIs are subject to the [Wix App Market guidelines](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/app-market-guidelines).

</blockquote>

## API categories
Wix offers a variety of APIs that enable integration with different areas of the Wix ecosystem, including:
- **Business solutions**: Interact with Wix’s business solutions, such as eCommerce, Bookings, Events, and Restaurants.
- **Payments**: Manage payments with Pricing Plans, Payments, and Billing APIs.
- **CRM and Members**: Interact with and manage site contacts and members.
- **Data**: Work with data stored in Wix-hosted and external databases.
- **Automations**: Streamline work processes and send notifications.

## API technologies
Wix offers the following API technologies for integrating your app with Wix:
- [REST](https://dev.wix.com/docs/rest)
- [JavaScript SDK](https://dev.wix.com/docs/sdk)
- [GraphQL](https://dev.wix.com/docs/graphql)
- [Velo with Blocks](https://www.wix.com/velo/reference/api-overview)

Each API technology offers a similar set of APIs, and each API technology is suitable for use in different contexts:

### REST
[Wix REST APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/rest) use standard HTTPS protocols and authentication, and return JSON-encoded responses. REST APIs can be called from any programming language, and are the most common choice of API if you’re self-hosting your app and developing it in a language other than JavaScript.

### JavaScript SDK
The [Wix JavaScript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk) consists of npm packages containing wrapper functions for Wix REST APIs. 
The SDK is useful if you're building a Wix-hosted app using the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), or you're [self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps) your app and using JavaScript.

### GraphQL
You can streamline your API calls using [GraphQL](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/graph-ql). With GraphQL, the API response is clean, concise, and includes only the data that you need.

### Velo with Blocks
If you’re building your app in [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks), you can access Wix APIs via [Velo](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/velo-for-blocks), a powerful JavaScript-based developer platform.

## Events
Wix APIs include [events](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-events), such as [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks). 
Events are automated responses including a payload that are sent to your app when specific site actions occur.

## Service Plugins (formerly SPIs)
[Service Plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions) are a way to inject custom logic into Wix backend APIs. 
You can set up Service Plugins in your app's dashboard and handle them on your server.
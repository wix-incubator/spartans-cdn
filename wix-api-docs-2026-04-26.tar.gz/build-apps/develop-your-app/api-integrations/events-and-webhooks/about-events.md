---
portal: build-apps
name: "About Events"
type: ARTICLE_RESOURCE
resourceId: aca43c1c-1b82-4292-b4a3-1f3f85ff4cb2
---

# About Events

# About Events
Events are triggered when specific conditions on your app or a user’s site are met. You can write code that runs when an event occurs. 

For example, an event might be triggered when an eCommerce order is canceled. You can implement logic that sends an email to the site visitor when the event is triggered.

How you handle events depends on which [frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks) you use to build your app:
- **[Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)**: Handle events using [event extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/events/about-event-extensions). Event extensions use the JavaScript SDK.
- **[Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks)**: [Handle events](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/backend-code/events/about-backend-events) using Velo.
- **[Self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps)**: Implement [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks) using REST APIs or the Javascript SDK.

> **Note:** Event extensions are built on [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks). Changes to events automatically create a new minor app version. Learn more about [webhooks and versioning](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks#webhooks-and-versioning).

## Where to find event information

The [API Reference](https://dev.wix.com/docs/api-reference) documentation sidebar lists events alongside their related API methods.

For example, information about the [Cart Created](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/purchase-flow/cart/cart/cart-created) event is located under **eCommerce** > **Purchase Flow** > **Cart**.

## Recommended events

Subscribe to [app management events](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed) to track your app's lifecycle, particularly:

- **App Instance Installed**: Triggered when your app is installed on a site. Use this to save the instance ID, provision resources, or initialize settings.
- **App Instance Removed**: Triggered when your app is uninstalled. Use this to clean up data or revoke access.
---
portal: build-apps
name: "FAQ for Webhooks"
type: ARTICLE_RESOURCE
resourceId: 6a7e4bd7-c427-4ef5-9cc6-d32a37edf475
---

# FAQ for Webhooks

# FAQ for Webhooks

## I haven’t received any webhooks in a long time. How can I know if something is wrong?

It’s possible that the relevant sites haven’t had any relevant activity that would trigger webhooks. The easiest way to begin troubleshooting this is to call a related List or Query endpoint for a relevant site. For example, if you haven’t received an [Event Guest Created](https://dev.wix.com/docs/rest/business-solutions/events/event-guests/event-guest-created) webhook in 24 hours, you can call the [Query Event Guests](https://dev.wix.com/docs/rest/business-solutions/events/event-guests/query-event-guests) endpoint, sorted by created date, and compare the returned data with the data on your server.  
If the returned data includes guests that your app didn’t receive webhooks for, Wix recommends the following:  
- Check that your servers are up and running.
- Check the webhook log, available in the Webhooks page of your app's dashboard.

## Why am I receiving webhooks out of order/duplicates?

Duplicate webhooks are generally sent when Wix believes that the webhook was not received - so make sure you are sending a 200 success response so Wix knows the webhook was received. Otherwise Wix will continue to send duplicates.

For various reasons, including any delays from Wix's servers or when a delivery attempt fails, Wix will make additional attempts to send the webhook. See the [webhook resend policy](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks#resend-policy) for details.

This might mean that you'll receive webhooks out of order, or occasionally receive duplicates, so make sure your app can handle these scenarios.  

## I listen to webhooks and then take a specific update action based on the returned data. But I keep getting duplicate webhooks that include the old data. Why isn’t the data updating?

Duplicate webhooks will always include the same data, even if the entity has been updated since. Chances are that you aren’t sending the expected 200 status, so Wix is continuing to send retries. The webhook data won’t update between retries.

## Why doesn't the webhook I signed up for include all the data I need?

Most of Wix’s webhooks include the full entity that was created or updated, but in some cases, (generally legacy webhooks) it won’t return all the data stored for the entity. In these cases, if you need the data that isn’t returned in a webhook, you can call the relevant Get endpoint with the entity ID returned in the webhook to get the full entity.  
For example, the legacy [Wix Stores Product Changed](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-changed) webhook only returns the fields that were updated in a flat list, and not according to the object structure returned in the calls.  
Alternatively, you might find that data that is documented as returned in a specific webhook isn’t being returned. This means that those specific parameters aren’t required, and in this instance we don’t have any data for it.

## How am I getting webhooks for a site that didn’t go through the installation flow for my app?

Sometimes, when your app uses [custom authentication (legacy)](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth#advanced-oauth-settings), a site owner that has installed your app will duplicate their site, and your app will automatically be initialized for the duplicated site. Because they didn’t actively install, your app won’t have access and refresh tokens to make calls for the site, but you may automatically be signed up for webhooks for that site.

Here's what you can do:
- If you sign up for the [App Installed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed) webhook, when your app is duplicated you’ll get a webhook notifying you that your app was installed and its payload will include the `originInstanceId`, which is the app instance ID from the original site, so you’ll know which user the site is associated with.
- In addition, if you notice someone accessing your app's dashboard and you don't have valid tokens for them, you can ask them to update/install the app by sending them into the [installation flow](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth#advanced-oauth-settings).
- Alternatively, you can use the standard [OAuth flow](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-using-oauth) for the site. With this flow, it’s common that the first notification you’ll receive about the installation to be when you receive the [App Installed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed) webhook.

## Why do I sometimes get an error when I make a GET call immediately upon receipt of a webhook about entity creation? 

Wix's infrastructure is eventually-consistent. In some rare cases your server may receive a webhook while some of the database replicas are still behind. Most webhooks include the full entity that was created or updated, so whenever possible you should use the webhook response rather than making a GET call for the latest state of the entity. If your webhook handler tries to get data from the API, and fails with 404 (not found), you should retry the call after a few seconds.

## Are webhook timestamps sent in the site's time zone?

Webhook `eventTime` timestamps are sent in [ISO-8601](https://en.wikipedia.org/wiki/ISO_8601) format and UTC time. For example: 2020-04-26T13\:57\:50.699Z
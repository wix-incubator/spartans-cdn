---
portal: build-apps
name: "GraphQL"
type: ARTICLE_RESOURCE
resourceId: b8609b1c-b6ac-4962-99ff-63e8407f60ee
---

# GraphQL

# The Wix GraphQL API

The Wix GraphQL API streamlines access to a Wix site’s data through GraphQL, a query language that allows the combination of multiple queries or mutations into a single request. Queries and mutations are read and write operations that allow for targeted data retrieval and modification within objects, without the need to handle the entire object.

The GraphQL API is exposed over REST and can be used in the same applications as our [REST API](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/rest), for querying and modifying the same data. 

To use the Wix GraphQL API, simply call our REST API’s GraphQL endpoint with your GraphQL query details in the request body.

To get started, see the [Wix GraphQL API reference](https://dev.wix.com/docs/graphql).

## Advantages of using the Wix GraphQL API

Use the Wix GraphQL API if you have complex query requirements or want to retrieve only specific data from larger objects. In these situations, using GraphQL can improve application performance, reduce server response times, and simplify your code.

## Authentication and permissions

The simplest way to authenticate your app's Wix GraphQL API calls is by implementing [Wix's OAuth solution](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-as-an-app-instance).

To use Wix APIs, site owners must grant you explicit permission to access their data. They do this when they install your app on their site. Therefore, you must provide a list of permissions you need from the site owner on the Permissions page in your app's dashboard. You can see which permissions each endpoint requires in its **Permissions Scopes** section in the [REST API reference](https://dev.wix.com/docs/rest/).

![Permissions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/graphql-md_build-apps-portal_develop-your-app_api-integrations_assets_permissions.png)

Read more about [permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions).

## Events
To handle events in your app, consider implementing [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks) using the REST API.

## Service plugins
To integrate service plugins (formerly SPIs) into your app, you need to implement REST endpoints. For more information, see [Service Provider Interfaces](https://dev.wix.com/docs/rest/articles/getting-started/service-provider-interface).
---
portal: build-apps
name: "JavaScript SDK"
type: ARTICLE_RESOURCE
resourceId: b1a88545-6cdc-48f8-b50b-e031dee83086
---

# JavaScript SDK

# Wix JavaScript SDK

The [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) consists of npm packages containing wrapper functions for Wix REST APIs. These functions enable you to access and manage Wix functionality through function calls in your JavaScript code. When using the Wix JavaScript SDK, you only need to configure authentication once. You don’t need to handle it in every API call. 

The Wix JavaScript SDK has two core modules - the SDK module (`@wix/sdk`) and the React SDK module (`@wix/sdk-react`). 

The SDK module provides:

- A client for executing authenticated API requests and handling webhooks.
- Authentication strategies for API requests.
- Features for working with media content returned by the APIs.

The React SDK module includes everything from the SDK module and enables the integration of Wix JavaScript SDK APIs within React components. 

The Wix JavaScript SDK is easy to integrate into your app. You simply install a core module (`@wix/sdk` or `@wix/sdk-react`), and then backend modules for each Wix domain your app uses (such as `@wix/contacts`.) 

## Advantages of using the Wix JavaScript SDK

The Wix JavaScript SDK’s functions represent a simpler, cleaner alternative to REST API calls for Javascript developers. 

It’s the natural choice if you’re building an app using the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). The Wix JavaScript SDK is also a good option if you’re building a [self-hosted app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps) and coding in Javascript.

## Authentication and permissions

Your Javascript SDK API calls must be authenticated using the OAuth protocol. You can authenticate either as an instance of your app, or on behalf of a user. For more information, see [About Authentication](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-authentication).

Site owners must also grant your app explicit permission to access their data. They do this when they install your app on their site. Therefore, you must provide a list of permissions you need from the site owner in the [Permissions page](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fdev-center-permissions) in your app's dashboard. You can see which permissions each endpoint requires in its **Permissions Scopes** section in the [JavaScript SDK API reference](https://dev.wix.com/docs/sdk).

![Permissions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5976bd7f832b550a30a80ebfc144c106.png)

Depending on the context of your code, you may need to [elevate](https://dev.wix.com/docs/sdk/core-modules/essentials/auth) the method you want to call.

Read more about [permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions).

### Wix-hosted vs self-hosted apps

When developing an app with the SDK, we recommend using one of Wix's native frameworks: [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) or the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). These platforms provide a superior development experience for most use cases.

Apps developed using these frameworks are hosted on Wix's cloud services, so server management is handled by Wix.
Authentication is much simpler for these Wix-hosted apps because you don't need to use a [Wix Client](https://dev.wix.com/docs/sdk/articles/set-up-a-client/about-the-wix-client) to make API calls with the SDK. 

However, if necessary, you also have the option of [self-hosting](https://dev.wix.com/docs/sdk/articles/get-started/about-self-hosted-apps) your app outside of Wix.

In self-hosted apps, you need to handle server management yourself and use a [Wix Client](https://dev.wix.com/docs/sdk/articles/set-up-a-client/about-the-wix-client) to call the SDK. 

For more details see [About Development Frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks).

## Events

The JavaScript SDK offers functionality for [processing Wix webhook events](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client#process). For an example, see [Handle Events With Webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/handle-events-with-webhooks).

## Service plugins

To integrate service plugins (formerly SPIs) into your app, you need to implement REST endpoints. For more information, see [Service Provider Interfaces](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions).
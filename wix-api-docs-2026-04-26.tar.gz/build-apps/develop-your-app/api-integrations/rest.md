---
portal: build-apps
name: "REST"
type: ARTICLE_RESOURCE
resourceId: 510100df-6b6f-4792-a47c-83bca6151f82
---

# REST

# REST APIs

Wix REST APIs allow your app to access Wix users' site data, extend Wix business solutions, and customize interactions with site visitors. 

REST APIs can be used in any programming language. They use standard HTTPS and return JSON-encoded responses.

## Advantages of using REST APIs

The advantage of using REST APIs over other Wix API technologies is that it gives you the flexibility to work with any programming language. It's a good choice for when you want to:

- Host your own app and prefer to code in a language other than JavaScript.
- Create an app that integrates with an existing external service whose codebase is in a language other than JavaScript.

## Authentication and permissions
The simplest way to authenticate your app's REST API calls is by implementing [Wix's OAuth solution](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-as-an-app-instance).

To use Wix APIs, site owners must grant you explicit permission to access their data. They do this when they install your app on their site. Therefore, you must provide a list of permissions you need from the site owner in the Permissions page in your app's dashboard. You can see which permissions each endpoint requires in its Permissions Scopes section in the [REST API reference](https://dev.wix.com/docs/rest/).

![Permissions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/rest-md_build-apps-portal_develop-your-app_api-integrations_assets_permissions.png)

Read more about [permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions).

## Events
You can implement [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks) to listen for and handle events over REST. Webhooks listen to events in real time and notify you whenever something happens in your app or on a site that your app is installed on.

## Service Plugins (formerly SPIs)
Wix offers a range of service plugins that you can implement over REST, allowing you to inject custom logic into Wix services. Learn more about [Service Plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions).
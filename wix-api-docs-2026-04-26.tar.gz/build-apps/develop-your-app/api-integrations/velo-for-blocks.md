---
portal: build-apps
name: "Velo for Blocks"
type: ARTICLE_RESOURCE
resourceId: 9ec7f85b-f09c-47ad-9e50-b86ae1d2a23c
---

# Velo for Blocks

# Velo APIs for Blocks

[Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) is a visual editor for building responsive applications for Wix sites. Like [Wix Studio](https://www.wix.com/studio), it lets you design widgets on-stage, configure floating menus and panels, and use Wix’s Velo platform to write JavaScript code and access Wix site data.

[Velo](https://www.wix.com/velo/reference/getting-started) is a JavaScript-based, full-stack development platform built into Wix Blocks. It allows you to write code for individual widgets in your app, or for your app as a whole. 

Velo provides the APIs you need for integrating app components created with Blocks. With these APIs, you can use JavaScript functions to integrate your app with Wix business solutions, as well as to access and manage information about a site, its users, and more.

## Advantages of using Velo for Blocks

Velo includes many features that benefit app development. For example, you can:

- Write JavaScript code directly in the Velo IDE, and call Wix Velo APIs with simple JavaScript functions.
- Enjoy serverless coding. Your app will be hosted on Wix's cloud services, so server setup, maintenance, scaling, and security are all handled by Wix. 
- Install [npm packages](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/packages/work-with-npm-packages), use our [fetch](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/integrations/fetching-services/accessing-3rd-party-services-with-the-fetch-api) to call external APIs, and [expose your app's functionality as an API](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/expose-a-blocks-app-api-with-http-functions).

For more information about these features and more, see [About Velo by Wix](https://dev.wix.com/docs/develop-websites/articles/getting-started/about-velo-by-wix).

## Authentication and permissions

In Velo for Wix Blocks, authentication is built in, as the site running your app knows the identity of the site member, visitor, or admin calling the API.

>**Note**: The permissions requirements documented below are not yet implemented at the time of writing. However, you should take these requirements into account while developing your app.

Site owners must also grant your app explicit permission to access their data. When developing your app in Wix Blocks, you must add the permissions scopes your app will request from site owners. For example, if you want your app to be able to read and manage the site’s business profile information, you would add the Manage Business Profile permission scope to your app’s required permissions. Site owners will then be asked to grant these permissions when installing your app.

## Events
Many Velo modules include events that are triggered when required conditions are met. You can handle these events directly in Velo. Learn more about [Velo events](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/backend-code/events/about-backend-events).

## Service plugins
To integrate service plugins (formerly SPIs) into your app, you need to implement REST endpoints. For more information, see [About Service Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions).
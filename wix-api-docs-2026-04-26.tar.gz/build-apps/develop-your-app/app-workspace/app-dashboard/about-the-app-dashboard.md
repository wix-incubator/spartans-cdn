---
portal: build-apps
name: "About the App Dashboard"
type: ARTICLE_RESOURCE
resourceId: 8fac6ae8-70d3-403a-976c-5c7739f5aa50
---

# Dev Center Overview

# About the app dashboard

The [app dashboard](https://manage.wix.com/account/custom-apps) is a hub for connecting your app to the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem) and managing it. 

Regardless of how you are building your app, your journey will most likely include a visit to the app dashboard. 

## Working in the app dashboard

The menu on the left of the dashboard guides you through the tasks for setting up your app. You can progress through most tasks in any order, and return to tasks later, according to your needs. 

Generally, the order of the tasks are:

1. [Plan](#which-tasks-must-i-do-which-tasks-can-i-skip)
1. [Get started](#getting-started)
1. [Develop and build](#developing-and-building-your-app)
1. [Integrate](#integrating-your-app)
1. [Launch](#launching-your-app)
1. [Manage](#managing-your-app)

You will learn more about each task below. But first... it is important to note that you can skip tasks you don't need. 

## Which tasks must I do? Which tasks can I skip?

The tasks you do, and the tasks you skip, are based on the [framework](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) you choose and if your app will be public. For example, if your app is private, you can skip many of the options in the Launch task, as there is no need to price, market, or handle payments for your app. 

Here are ideas for which tasks to do in the app dashboard, depending on the type of app you are building.  

<details><summary><strong>Public self-hosted app - published in the Wix App Market</strong></summary>

This is a basic flow for launching a public, self-hosted app that you can market and sell. 

| Task | Options to Consider | How |
| ----- | ------------- | -- |
| Get started | Log in and set up your app | app dashboard |
| Develop and build | Add extensions</br>OAuth</br>Permissions</br>Webhooks</br>Test | app dashboard |
| Integrate | Code and design | Using your own tech stack |
| Launch | Translations</br>Marketing</br>Pricing</br>Contact info</br>Security & privacy</br>Payouts</br>Coupons</br>Collaborators</br>Company info</br>Submit | app dashboard |
| Manage | Versions</br>Reviews</br>Stats | app dashboard |

</details>

<details><summary><strong>Private enterprise app with Wix Blocks</strong></summary>

This scenario shows that: 

- You can share an app in your enterprise, perhaps for code reuse purposes, without ever marketing or selling your app. 

- You can extend Wix functionality using a combination of both Wix Blocks and other extensions in the same app. 

- Your enterprise app can accommodate translations even if it is never launched to the app market. 

| Task | Options to Consider | How |
| ----- | ------------- | --- |
| Get started | Log in and set up your app | app dashboard or Wix Blocks |
| Develop and build with Wix Blocks | Add [supported Wix Blocks extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/supported-extensions/about-extensions-in-blocks) | Wix Blocks |
| Develop and build | Add [extensions without Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/supported-extensions/about-extensions-in-blocks)</br>OAuth</br>Permissions</br>Webhooks</br>Test | app dashboard |
| Integrate | Code and design | Wix Blocks |
| Launch | Translations | app dashboard |
| Manage | Versions | Wix Blocks or app dashboard |

</details>

<details><summary><strong>Private app with Wix Blocks</strong></summary>

This task demonstrates that there are scenarios where you can build an app without using the app dashboard at all. 

- Because this scenario is a private app, there is no need to launch or market the app. 

- Depending on what your app needs to do, it is possible that all the tasks for designing, coding, and managing your app can be done entirely with Wix Blocks.

| Task | Options to Consider | How |
| ----- | ------------- | -- |
| Get started | Set up your app | Wix Blocks |
| Develop and build | Add [supported Wix Blocks extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/supported-extensions/about-extensions-in-blocks) | Wix Blocks |
| Integrate | Code and design | Wix Blocks |
| Manage | Manage versions | Wix Blocks |

</details>


<details><summary><strong>Public app with Wix CLI, published in the Wix App Market</strong></summary>

This is a basic flow for launching a public app created with the Wix CLI that you can market and sell. 

- Some of the development and configuration that is available in the app dashboard is also available in the CLI.

- You can extend Wix functionality using a combination of extensions developed in both the Wix CLI elsewhere in the same app.

| Task | Options to Consider | How |
| ----- | ------------- | --- |
| Get started | Log in and set up your app | Wix CLI |
| Develop and build | Permissions</br>Webhooks</br>Add extensions without CLI </br>Permissions</br>Webhooks | app dashboard |
| Develop and build | Add [supported CLI extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions)</br>Test</br>Create version | Wix CLI |
| Integrate | Code, design, and preview | Wix CLI |
| Launch | Translations</br>Marketing</br>Pricing</br>Contact info</br>Security & privacy</br>Payouts</br>Coupons</br>Collaborators</br>Company info | app dashboard |
| Manage | Versions</br>Reviews</br>Stats | app dashboard |

</details>

<details><summary><strong>Public app that does not require external integrations, published in the Wix App Market</strong></summary>

This type of public app is developed, marketed, and managed totally within the app dashboard. There is no need to use any frameworks at all. We can relate to the extensions used in this type of app as "configuration-only" apps.

| Task | Options to Consider | How | 
| ----- | ------------- | -- | 
| Get started | Log in and set up your app | app dashboard |
| Develop and build | OAuth</br>Permissions</br>Webhooks</br>Add "configuration-only" extensions such as:</br>    - [Site pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/about-site-page-extensions)</br>    - [External links](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/external-links/about-external-link-extensions)</br>    - [Dashboard menu plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions) <!-- Wrong link! --></br>    - [Schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions)</br>Test | app dashboard |
| Launch | Translations</br>Marketing</br>Pricing</br>Contact info</br>Security & privacy</br>Payouts</br>Coupons</br>Collaborators</br>Company info | app dashboard |
| Manage | Versions</br>Reviews</br>Stats | app dashboard |

</details>

## Getting started

First, log into your Wix Studio account. If you don't already have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).

Once logged in, [set up](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps) an app in the app dashboard. This task lets you set up your app so you can manage it using the app dashboard.


## Developing and building your app

From within the app dashboard, you can utilize a set of tools and extensions to help you build and release apps. For example, you can: 

- [Extend Wix functionality](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions)
- [Sign up to webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks)
- [Set up permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/configure-permissions-for-your-app)
- [Set up OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth)
- [Test the app locally](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/test-your-app-on-a-premium-site)

<!--Depending on which dev framework you use, you can skip some of these app dashboard options: 

- If developing with [Wix Blocks](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/wix-blocks/getting-started/welcome-to-wix-blocks.md*original::../../wix-blocks/getting-started/welcome-to-wix-blocks.md), don't add Wix Blocks extensions also using the app dashboard. Of course you can use the app dashboard to add other extensions that you did not add with Wix Blocks.

- Similarly, the [Wix CLI](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/wix-cli-for-apps/get-started/about-the-wix-cli-for-apps.md*original::../../wix-cli-for-apps/get-started/about-the-wix-cli-for-apps.md) handles some app dashboard options for you, including authorization and adding extensions. Skip those options in the app dashboard.
-->

## Integrating your app

You generally develop, code, and design your app outside of the app dashboard. 

This task is about integrating what you developed externally using the app dashboard. 

For example, using the app dashboard, you can: 
- Connect any iframes you coded externally, by providing the relevant URLs and settings data. 
- Integrate with any custom business logic you externally coded by adding a [service plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions). 

<!-- Develop your app using:
- [Frameworks](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/develop-your-app/about-building-your-app-using-a-dev-framework.md*original::../../develop-your-app/about-building-your-app-using-a-dev-framework.md)
- [APIs](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/apis/about-apis.md*original::../../apis/about-apis.md)
- [Wix business solutions](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/wix-business-solutions/about-wix-business-solutions.md*original::../../wix-business-solutions/about-wix-business-solutions.md)
- [Wix Blocks with Velo](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/wix-blocks/getting-started/welcome-to-wix-blocks.md*original::../../wix-blocks/getting-started/welcome-to-wix-blocks.md)
- [Wix CLI](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/wix-cli-for-apps/get-started/about-the-wix-cli-for-apps.md*original::../../wix-cli-for-apps/get-started/about-the-wix-cli-for-apps.md)

Design your app with:   
- [Wix Blocks](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/wix-blocks/getting-started/welcome-to-wix-blocks.md*original::../../wix-blocks/getting-started/welcome-to-wix-blocks.md)
- [Wix Design System](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/dev-tools/wix-design-system/about-the-wix-design-system.md*original::../../dev-tools/wix-design-system/about-the-wix-design-system.md)
- [Wix Patterns](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/dev-tools/wix-patterns/about-wix-patterns.md*original::../../dev-tools/wix-patterns/about-wix-patterns.md) 
--> 

## Launching your app

If you are setting up a public app, use the app dashboard to: 

- [Price your app](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/about-pricing-plans-and-business-models)
- [Distribute your app](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/about-app-distribution)
- [Set up your Market listing](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/about-market-listings). If your app depends on a Wix business solution being installed on a site for your app to work, [add the dependency](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/add-your-app-audience-info) in the app dashboard when setting up your market listing. This prevents users from installing your app until the relevant business solution is installed.
- [Create promotional assets](https://dev.wix.com/docs/build-apps/launch-your-app/app-promotion/about-app-promotion)
- [Submit your app for Wix approval](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/submit-your-first-app-version). Check the bottom left of the app dashboard to see if there are any blockers. Did you skip an essential step? Is information missing? Click **Fix blockers** for a summary of the blockers to fix, including suggestions you might want to consider. 
    <!-- ![Dev Center](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6ebdc93ed070efd89334461d08b56d90.png) --> 

<!-- Enterprise and private apps are not available on the Wix App Market. When building these apps you can skip quite a few of the options in this task. But you might want to consider, for example, [translations](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/launch-your-app/translations/localize-your-app.md*original::../../launch-your-app/translations/localize-your-app.md) and [versions](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/launch-your-app/launching/app-versions-and-updates.md*original::../../launch-your-app/launching/app-versions-and-updates.md). -->


## Managing your app

Once your app is up and running, you can make changes. For example, you can:  

- Respond to [reviews](https://dev.wix.com/docs/build-apps/manage-your-app/user-support/user-reviews)
- Check [analytics](https://dev.wix.com/docs/build-apps/manage-your-app/data-and-analytics/bi-events)
- Process [refunds](https://dev.wix.com/docs/build-apps/manage-your-app/user-support/issue-a-refund)
- Track [statistics](https://dev.wix.com/docs/build-apps/manage-your-app/data-and-analytics/app-stats)
- View [transactions](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/payouts-dashboard)
- Provide [coupons](https://dev.wix.com/docs/build-apps/launch-your-app/app-promotion/create-a-coupon) for your app
- Update your [company information](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/add-your-company-info)
- Determine who can [collaborate](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/manage-collaborators) on your app
- Make sure your app's users can [contact](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/add-your-contact-info) you


## See also 

- [Tutorial | Set Up an App with the App Dashboard](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-set-up-an-app-with-the-app-dashboard)
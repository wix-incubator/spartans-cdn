---
portal: build-apps
name: "About the Code Identifier"
type: ARTICLE_RESOURCE
resourceId: 90b1ec1f-d38f-41a2-becb-14a0980d6b14
---

# About the Code Identifier

# About the Code Identifier

<blockquote class="caution">

__Alpha:__
Building apps with AI is currently in alpha. This feature is subject to change and may have bugs, issues, and limitations. We're actively improving it based on your feedback.

</blockquote>

The code identifier is a unique, JavaScript-compatible name for your app and its extensions.

## Set your code identifier

When you build an app using AI, your namespace is generated automatically. Wix then suggests a code identifier based on that namespace. You can accept the suggestion or enter your own value.

> **Note:** In the Wix CLI flow, you choose your namespace manually during app creation.

Your code identifier must follow these rules:

- Use only JavaScript-friendly characters. These include letters (`A-Z`, `a-z`), digits (`0-9`, but not as the first character), underscores (`_`), and dollar signs (`$`).
- Avoid using the word "Wix".
- Use camelCase for readability.

Once set, you can't change your code identifier.

## View your code identifier

To view your app's code identifier:

1. Go to [Custom Apps](https://manage.wix.com/account/custom-apps).
1. Select the app whose code identifier you want to view.
1. Click the **More Actions** icon at the top of the page.
1. Select **View ID & Keys**.

Your app's code identifier appears there.
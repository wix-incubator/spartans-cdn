---
portal: build-apps
name: "Add Your Contact Info"
type: ARTICLE_RESOURCE
resourceId: e0f95b54-c82b-495e-aa93-c37fc9eb9ebd
---

# Add Your Contact Info

# Add Your Contact Info
Ensuring that your app's users and Wix can easily reach you is crucial for maintaining a successful app on the Wix App Market. To achieve this, it's important to keep your contact info accurate and up-to-date.

To add or update your contact info:

1. Go to the **Contact Info** page in your app's dashboard.
2. Provide at least one email address for each field:
    - **Support email**: This email is essential for handling user support requests, both from users and the App Market team. It is displayed in the App Market for users seeking assistance. You can input up to 10 email addresses, separated by commas.
    - **Billing email**: All billing-related info, including periodic reports on earnings and invoice requests, is directed to this email address. Only one email address is permitted in this field. If multiple team members require access to billing information, we suggest creating a shared group email address.
    - **Urgent email and number**: Critical support requests from the App Market team and important updates regarding features and changes are communicated through this channel. You can enter up to 10 email addresses, separated by commas. While email will serve as the primary mode of contact, in exceptional circumstances we may use the phone number provided.
3. Click **Save**.

<blockquote class="tip">

**Tip:** As you enter email addresses, the last one entered is registered once you click outside the field, add a comma after it, or press Enter.

</blockquote>

## See also
- [Add your company info](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/add-your-company-info)
- [Manage team collaborators](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/manage-collaborators)
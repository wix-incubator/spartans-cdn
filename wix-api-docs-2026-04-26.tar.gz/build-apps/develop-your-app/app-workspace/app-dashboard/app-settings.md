---
portal: build-apps
name: "App Settings"
type: ARTICLE_RESOURCE
resourceId: 370d08e5-4379-46de-b03d-bb7425ab989d
---

# App Settings

# App Settings

The **App Settings** page lets you customize your app's post-installation behavior, both for the app in general and for specific extensions.

## Post-installation navigation

When a Wix user installs your app, the page that they're directed to by default to depends on your app's extensions:

- If your app has no extensions, Wix users are directed to the [Manage Apps](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Fmanage-installed-apps) page in their dashboard.
- If your app has at least one site extension, such as a site widget or a site page, Wix users are directed to the editor.
- If your app has only dashboard page extensions, Wix users are directed to the first dashboard page created in your app.

In the **Post-installation navigation** section, you can change the default behavior. If you've added one or more dashboard page extensions, you can choose to direct Wix users to one of these pages.

## Extension installation behavior

In addition to navigation, you can configure post-installation behavior for specific extensions. For example, you can choose to add a site widget to a site page upon installation, instead of requiring the Wix user to add the widget themselves.

The **Extension installation behavior** section directs you to the [**Extensions**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) page in the app dashboard, where you can configure specific behavior for each extension.

## See also

- [About the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard)
- [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions)
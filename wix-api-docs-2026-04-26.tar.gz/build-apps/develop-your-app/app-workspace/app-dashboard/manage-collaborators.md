---
portal: build-apps
name: "Manage Collaborators"
type: ARTICLE_RESOURCE
resourceId: a9cd4cec-2055-4eeb-8b27-cf1fb751ac23
---

# Manage Collaborators

# Manage Collaborators
As an App Owner, you can invite people to work on your app, assign them roles, and set their permissions in the App Dashboard.

## Role types

- **App Owner**: Can perform any action in the account and is considered an admin. Only the Owner can request to close an account.
- **App Co-owner**: Can edit, publish and manage the app, including creating extensions, adding webhooks and permissions, and inviting people. They can’t archive or change ownership of the app.

<blockquote class="standard">
  <strong>Note:</strong>
  
  If you need to transfer Owner rights to another user let us know and we'll do it for you.
</blockquote>

## Invite a new collaborator
1. Go to the **Collaborators** page in your app’s dashboard.
2. Click **+ Invite Collaborators** in the top right corner.
3. Enter the email address of the collaborator. To add multiple invitees, enter each email separated by a comma.
4. Click **Send Invite**.

<blockquote class="tip">
  <strong>Tip:</strong>
  
  After you've sent the invite you can also click the **More Actions** icon next to the relevant collaborator to resend the invite or get an invite link.
</blockquote>

## Remove a collaborator
1. Go to the **Collaborators** page in your app’s dashboard.
2. Click the **More Actions** icon next to the relevant collaborator.
3. Click **Remove**.

## See also
- [Add your contact info](https://dev.wix.com/docs/build-apps/develop-your-app/dev-center-setup/add-your-contact-info)
- [Add your company info](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/add-your-company-info)
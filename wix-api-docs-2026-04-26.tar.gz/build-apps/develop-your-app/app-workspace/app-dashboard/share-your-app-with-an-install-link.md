---
portal: build-apps
name: "Share Your App with an Install Link"
type: ARTICLE_RESOURCE
resourceId: fe4d3dbf-93e8-4604-ace5-ca2f1f341f89
---

# Share Your App with an Install Link

# Share Your App with an Install Link
An Install Link enables Wix site-creators to install your app on their site. This is useful when you want to share your app with a small number of specific site creators, early adopters, or use it for testing purposes.

## Generate an Install Link
1. Go to the **Custom Apps** page.
2. Click the **More Actions** menu next to the app you want to share.
3. Click **Share install link** to install app.
4. Click **Generate Link**.
5. Click **Copy Link**.

![Share](https://wixmp-833713b177cebf373f611808.wixmp.com/images/812f9b020d5fd1f1dfbe08f770140d3c.png)

## Disable an Install Link
There can only be one Install Link at any given time. If you want to disable an Install Link, create a new link and it will disable the old one.

## See also
- [Create a market listing](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/about-market-listings)
- [About app promotions](https://dev.wix.com/docs/build-apps/launch-your-app/app-promotion/about-app-promotion)
---
portal: build-apps
name: "About Extensions"
type: ARTICLE_RESOURCE
resourceId: bab119aa-d5aa-4c0b-a271-36eb4eef660a
---

# About Extensions

# About Extensions

An [extension](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix) is a specific functionality of an app. An app can have multiple extensions that work together to provide various features across different user interfaces and backend services. Most extensions, whether frontend or backend, are created using one of Wix’s [development frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks#wixs-development-frameworks).

You can view your dashboard extensions in the **Extensions** tab in the [app dashboard](https://manage.wix.com/account/custom-apps).

## Frontend extensions

Frontend extensions enhance Wix sites with additional functionality, including adding site pages, draggable widgets, site plugins, embedded scripts, and dashboard interfaces.

- **Site Pages:** Appear in the site's main navigation menu. They function like any other page and are composed of one or more of the app’s widgets.  
- **Site Widgets:** Are draggable components that you can add to and place anywhere on your site.  
- **Site Plugins:** Allow you to extend Wix-created apps by being placed in designated areas within the hosting app’s site widget.  
- **Embedded Scripts:** Allow you to inject custom HTML code into a site’s HTML.  
- **Dashboard Pages:** Pages that you can add to the dashboard that are only visible to site admins with the necessary permissions.  
- **Dashboard Modals:** Allow you to expand Wix's dashboard capabilities by to importing a modal onto a dashboard page.
- **Dashboard Plugins:** Allow you to customize Wix dashboard pages by adding new functionalities to predefined slots and introducing new items to dashboard menus. This customization directs administrators to different pages or modals within the dashboard.
- **Dashboard Menu Plugins:** Allow you to place a new menu item in a predefined slot, or UI placeholder, in a menu on the dashboard page of an app built by Wix.

## Backend extensions

Backend extensions allow you to customize Wix's backend business logic to suit your app's needs, enhancing the value your apps provide to site owners.

- **Data Collections Extensions:** Automatically create CMS data collections when your app is installed on a site. Configure collection schemas and add optional initial data.
- **Schema Plugin Extensions:** Enable field extensions to Wix's objects. They enrich and extend Wix's data by adding additional fields to service objects.
- **Service Plugin Extensions:** Wix-defined APIs that apps can implement to become service providers. This enables Wix to call the service during specified flows and proceed based on the response.
- **Notifications:** Send predefined alerts with customizable data to users through their site dashboard or the Wix Owner mobile app. This is useful for informing users of important updates and events.
- **Web Method Extensions:** Define functions in your app's backend that you can call from your frontend code.
- **Automations:** Automate business processes using triggers, actions, and pre-installed automations.
- **APIs:** Expose backend methods that can be called from frontend code.
- **Events:** Allow you to run custom code in response to specific events that occur on a site.

## See also

- [How apps extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix)
- [Mapping your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
- [About Site Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions)
- [About Dashboard Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions)
- [About Backend Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/about-backend-extensions)
---
portal: build-apps
name: "About Backend Extensions"
type: ARTICLE_RESOURCE
resourceId: b545d042-da98-49e1-b75a-39cb7088797c
---

# About Backend Extensions

# About Backend Extensions


Backend extensions enable apps to customize Wix's backend business logic and add value to site builders and apps.

## Data collections extensions
The data collections extension allows your app to automatically create CMS data collections when it's installed on a site. You configure the collection schemas and optional initial data in a JSON configuration file. When a Wix user installs your app, the collections are automatically created in the site's CMS.

This extension automatically enables the site's code editor, which is required for the Wix Data APIs to work. This means your app can use Data APIs to read and write data in the collections without requiring Wix users to manually enable the code editor.

For example, a small business app might use a data collections extension to create a "Customer Feedback" collection that stores customer reviews and ratings. The app could pre-populate the collection with sample feedback entries to help Wix users understand how the app works.

## Service plugin extensions (formerly SPIs)
Service plugins are APIs that are defined by Wix, which you can choose to implement.
When you implement a Wix service plugin in your app, you become a service provider. Wix then calls your service during one or more specified flows, waits for your response, and then continues the flow based on your response.

For example, a Local Delivery Provider app may implement the Restaurants Local Delivery service plugin, which includes a Get Delivery Estimate endpoint. Wix then calls this provider when they need to fetch applicable delivery estimates during a customer’s checkout flow.

## Schema plugin extensions
Schema plugins are field extensions to Wix’s objects that you can use to enrich and extend Wix’s data. Every Wix API has a service object with predefined fields, that can’t be removed or changed. But sometimes there is a business need to include additional data that Wix doesn’t save by default.

For example, an app managing bookings and equipment rental for outdoor adventure companies may want to include equipment rental data as part of the booking. With a schema plugin, the app can add an `equipment` field to the Bookings Service object. The `equipment` field becomes a part of the object, and the app can retrieve and manage it with the Bookings APIs.

## Notifications
Notifications allow you to send predefined messages with customizable data to your app's users in their site dashboard and/or the Wix Owner mobile app. This can be a useful way to alert users about important updates and events.

For example, an app managing a business’ social media presence may want to notify site builders about new media posts they are referenced in, likes, and so on.

## Automations
Automations allow you to predefine functionality of multiple types, based on [triggers](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/about-triggers) and [actions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/actions/about-actions). Automations leave site owners free to focus on their business, instead of having to deal with the details of running their site.

For example, an app managing a business' community building tasks might automate a welcome email to everyone who signs up for the site's newsletter or purchases a product.

## API extensions

API extensions allow you to define functions that can be invoked from any frontend component in your app.

There are 2 types of API extensions:

- [Web method extensions](#web-methods)
- [HTTP function extensions](#http-functions)

### Web methods

Web methods allow you to define functions in your app's backend that you can call from your frontend code. You can import web methods into frontend files as you would any other function in your project. Wix handles the communication between your frontend and backend under the hood.

Web methods provide several advantages over using [API extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/apis/about-api-extensions) to call your app's backend.

For example, an app may collect feedback from site visitors using frontend code and save the feedback in a database using backend code.

### HTTP functions

HTTP function extensions allow you to define HTTP endpoints in your app's backend that you can call from your frontend code.

Use an HTTP function extension instead of [web methods](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions) when you require HTTP-specific features, such as header codes.

For example, an app authenticating a user attempting to log in may want to use HTTP functions.

## Events
[Events](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-events) are triggered when specific conditions on your app or a user's site are met. Using event extensions, you can write code that runs when an event occurs.

For example, an event might be triggered when a [booking is confirmed](https://dev.wix.com/docs/sdk/backend-modules/bookings/bookings/on-booking-confirmed). You can implement logic, such as sending a booking confirmation email, when the event is triggered.

## App namespace

An app namespace is a unique identifier for your app. Some backend extensions, such as [data collections](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions) and [schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions), require an app namespace. You set the namespace the first time you create an extension that requires one, and you can't change it after that.

To view your app namespace:

1. Go to the **Home** page of your [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).
1. Click the 3-dot menu at the top right of the page.
1. Select **View ID and keys**.

## See also
- [About Service Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions)
- [About Schema Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions)
- [About Data Collections Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions)
- [About Notification Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/notifications/about-notification-extensions)
- [About Automation Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/about-automations)
- [About Web Methods Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions)
- [About HTTP Function Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/apis/about-api-extensions)
- [About Events Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/events/about-event-extensions)
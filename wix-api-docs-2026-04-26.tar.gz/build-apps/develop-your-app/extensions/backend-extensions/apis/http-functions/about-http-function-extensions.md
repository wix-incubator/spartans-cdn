---
portal: build-apps
name: "About HTTP Function Extensions"
type: ARTICLE_RESOURCE
resourceId: e6571c15-4707-4a22-8ef2-6e6a125ccb87
---

# About API Extensions

# About HTTP Function Extensions

<blockquote classname="note">

**CLI Documentation Notice**
	
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Before continuing, [determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

If your app uses the new CLI, use [HTTP endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints) instead of http function extensions.

If your project uses the Wix CLI for Apps, continue with this documentation.

</blockquote>


HTTP function extensions allow you to define HTTP functions in your app's backend that you can call from your frontend code.

You can only add HTTP function extensions in the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) for Apps, which handles the setup and hosting of the backend code for you, simplifying the development process. You can invoke HTTP functions added in HTTP function extensions from any frontend component in your CLI project.

<blockquote class="tip">

__Tip:__ In Wix Blocks, you access similar functionality using [Blocks App APIs](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/expose-a-blocks-app-api-with-http-functions).

</blockquote>

## HTTP function extensions vs web methods
In many cases, using [web methods](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions) to call backend code from your app's frontend may be a more suitable option than an HTTP function extension. Web methods require less boilerplate code and have simpler error handling. Use an HTTP function extension when you require HTTP-specific features, such as header codes.

Learn more about the advantages of using [web methods over HTTP function extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions#web-methods-vs-api-extensions).

## See also
- [Add HTTP function Extensions with the CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/api/add-api-extensions-with-the-cli)
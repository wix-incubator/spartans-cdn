---
portal: build-apps
name: "About Web Method Extensions"
type: ARTICLE_RESOURCE
resourceId: d80e0a19-1498-4974-9d3f-43c4b66cc835
---

# About Web Method Extensions

# About Web Method Extensions

<blockquote classname="note">

**CLI Documentation Notice**
	
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Before continuing, [determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 
	
If your app uses the new CLI, use [Astro Endpoints](https://docs.astro.build/en/guides/endpoints) instead of web method extensions.
	
If your project uses the Wix CLI for Apps, continue with this documentation.

</blockquote>

Web method extensions allow you to define functions in your app's backend that you can call from your frontend code.

You can import web methods into frontend files as you would any other function in your project. Wix handles the communication between your frontend and backend under the hood.

You can use web methods when developing [sites](https://dev.wix.com/docs/develop-websites/articles/getting-started/about-developing-websites), apps in [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks), and apps in the [Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/web-methods/add-web-method-extensions-with-the-cli). 


## Web method permissions

Web methods allow you to specify the permissions required to call the function from the frontend.

**Permission types:**

- `Permissions.Anyone`: Any site visitor can call the function.
- `Permissions.Admin`: Only site admins can call the function.
- `Permissions.SiteMember`: Only site members can call the function.

These are versions of the site visitor and site member [identity types](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities).

Be careful when selecting a permission, as exposing a function with the wrong permissions can create security risks.

## Web methods vs HTTP function extensions

Web methods provide several advantages over using [HTTP function extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/apis/about-api-extensions) to call your app's backend:

- Strongly typed communication between client and server.
  - [Type safety](https://en.wikipedia.org/wiki/Type_safety).
  - Auto complete for function names and parameters.
- Intuitive, high-level communication between frontend and backend: 
  - You can call your backend the same way you call functions in your frontend. You don't have to manually extract values from a request, serialize responses, or handle HTTP headers and query parameters as you would with API extensions.
  - Easier error handling. Instead of handling HTTP errors, you can throw exceptions like you would for any other function.
  - (CLI only) Hot module reloading (HMR) in your [local preview](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#development-and-testing) on backend changes.

## See also

- [Add web method extensions with the Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/web-methods/add-web-method-extensions-with-the-cli)
- [Web Methods API](https://dev.wix.com/docs/sdk/core-modules/web-methods/introduction)
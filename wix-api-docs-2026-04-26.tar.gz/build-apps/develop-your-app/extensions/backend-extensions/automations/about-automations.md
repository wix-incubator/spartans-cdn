---
portal: build-apps
name: "About Automations"
type: ARTICLE_RESOURCE
resourceId: 6d2df207-fa42-4336-9258-87f0ec5640f8
---

# About Automations

# About Automations

As a user gains more and more traffic to their site, it becomes harder for them to manage certain site actions on their own. For example, a user with an online store doesn’t have time to send invoices manually if they receive dozens of customer orders. Likewise, it’s hard for a user with a fitness site to manually manage tens or even hundreds of new sign-ups every day.

This is where Wix Automations comes in. Automations remove the burden of manually handling certain functions from site owners and automates these processes. This leaves site owners free to focus on their business, instead of having to deal with the details of running their site.

Every automation has a [trigger](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/about-triggers), which reports some event to Wix, and at least one [action](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/actions/about-actions), which carries out some kind of process such as sending an email or setting up a user account. Apps built by Wix, like Wix Stores and Wix Bookings, often come with pre-made automations that are available to the user upon installation. Apps can also offer specific triggers or actions, which site owners can use to [create their own custom automations](https://support.wix.com/en/article/wix-automations-creating-an-automation-with-the-new-builder).

As an app developer, you can provide actions, triggers, and full automations (known as pre-installed automations) as part of your app. You can configure all three in [**Automations**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site[…]%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fautomations-dev-center) in your app's dashboard.

## Triggers

When you provide a trigger as part of your app, you are essentially telling Wix that your app can [report a specific event](https://dev.wix.com/docs/rest/business-management/automations/triggers/triggered-events/report-event). For example, if your app helps a user make their site more secure, you may report events like suspicious purchases made on their online store.

When your app reports the event, it sends a [payload](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema) to Wix containing data about the event. You define this payload structure when you set up the trigger in your app's dashboard. This data is sent to whatever action the user chooses to connect the trigger to, and some or all of it may be used by that action.

Learn more [about triggers](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/about-triggers).

## Actions

You can provide a standalone action as part of your app. If a site owner uses your action in an automation, your app will carry out some process when that automation is triggered. For example, your security app might send the user a notification email when suspicious activity is reported on their site.

Any data that the action requires to run are defined in the action’s [input schema](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/actions/about-the-action-input-schema). The action can accept data from the trigger payload if necessary, or it may just need static data defined by the user when configured on the site. As an action provider, you can choose to [validate the action’s configuration](https://dev.wix.com/docs/rest/business-management/automations/action-spi/validate-configuration).

Learn more [about actions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/actions/about-actions).

## Pre-installed Automations

Pre-installed automations let you combine a trigger and one or more actions into a full automation. This automation is then added to a user’s site when they install your app.

Unlike a trigger or an action, you don’t need to create a schema for a pre-installed automation when you set it up in your app's dashboard. However, it does involve creating an automation on a site, then exporting that automation to your app's dashboard.

Learn more [about pre-installed automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations).
---
portal: build-apps
name: "About Pre-installed Automations"
type: ARTICLE_RESOURCE
resourceId: 572b1f01-bacf-4f51-a363-b7768f7fb5cb
---

# About Pre-installed Automations

# About Pre-installed Automations

As an app developer, you can separately provide [triggers](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/about-triggers) and [actions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/actions/about-actions) to sites. Using pre-installed automations, you can also provide a full automation that combines a trigger and an action that you choose.

Pre-installed automations let you combine triggers and actions into a single automation, and include it as part of your app. When users install your app on their site, your automation is included as part of the app.

## When to add pre-installed automations to your app

If there’s a particular trigger-action combination that you believe is very helpful to your app’s functionality, adding a pre-installed automation is a good choice. This way, you don’t have to suggest to users to create the automation themselves because it’s already set up and available to them from installation, with only some possible action configuration required.

## How to create pre-installed automations

To [create a pre-installed automation](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/add-a-pre-installed-automation-to-your-app), you first create the automation on a site, then export it to the app dashboard. You can use a trigger from any Wix app when creating the automation, including your own. Keep in mind that if you use a trigger from another app, the user must also have that app installed on their site in order for the automation to work.

You can only select certain actions, including actions from your own app. You can configure the action when you create the pre-installed automation. Users will see the same action configuration on their site when they install your app.

## How users interact with your pre-installed automations

Users will see your automation listed in their [**Automations**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Ftriggers)  dashboard page under the **Installed for you** tab after they install your app. They are able to activate or deactivate the automation as needed.

The automation you create is **global**, and is applied to all sites that install your apps. You can think of a global automation as a master version. Every time a user installs your app, this master version is installed on their site.

If a user modifies the automation’s action configuration, the site creates a copy that contains their changes. This copy **overrides** the global automation. This means that when the automation is triggered, the site runs this override automation instead of the global one.

The creation of the override automation when a user changes the action configuration ensures that the global automation is not altered. For example, imagine users A, B, and C install your app on their site. Users A and B accept the default action configuration in your pre-installed automation. However, User C modifies the action configuration. Therefore, User C’s site creates an override automation that runs in place of the global pre-installed automation. But the changes that User C makes do not affect the automation for Users A or B.

The following graphic illustrates this:

<div style="text-align:center">

![Changes to the pre-installed action config on one site don't affect other sites](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-preinstalled-automations-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_override-graphic.png)

</div>

Users can’t do the following to your pre-installed automation:

* Switch the automation’s trigger to a different trigger.
* Switch the automation’s action to a different action.
* Rename the automation.
* Make changes to the global pre-installed automation that you created.
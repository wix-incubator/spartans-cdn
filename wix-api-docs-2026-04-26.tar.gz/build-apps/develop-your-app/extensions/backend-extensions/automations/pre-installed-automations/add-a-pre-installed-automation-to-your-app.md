---
portal: build-apps
name: "Add a Pre-installed Automation to your App"
type: ARTICLE_RESOURCE
resourceId: eebc7594-af86-4b42-a1e0-d644cd370539
---

# Add a Pre-installed Automation to your App

# Add a Pre-Installed Automation to your App

Follow this guide to learn how to add a pre-installed automation to your app.

## Before you begin

The app you want to set up an automation for needs to be installed on a Wix website. Learn how to install your app on a [free Premium development site](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/test-your-app-on-a-premium-site).

## Step 1 | Select a site to create an automation template

1. Go to the [**Automations**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fautomations-dev-center) page in your app's dashboard.
2. Click the **Pre-installed** tab.
3. Click **Create New > Pre-installed automation**.

    ![How to create a pre-installed automation](https://wixmp-833713b177cebf373f611808.wixmp.com/images/db0182ab0fb552e4a257a483d80baf0e.png)

4. Click **Select a Site to Create the Automation** and choose a site from the site selector to create the automation on.

    ![Select a site to build a pre-installed automation on](https://wixmp-833713b177cebf373f611808.wixmp.com/images/be10c71126b2b7cbdffc402ffe108c56.png)

5. A new tab opens on the site's **Automations** page, with **Advanced Mode** turned on.

## Step 2 | Create your automation

1. In the [**Automations**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Ftriggers) page on your site's dashboard, click **\+ New Automation**.
2. Select the app you want to create an automation for.
3. Select one of the available triggers and configure it. You can use any trigger created by Wix or a 3rd party, except for **Schedule trigger**.
4. Connect your trigger with one or more actions. Currently, you can only use the following actions to create a pre-installed automation:
    + **Send an email**.
    + **Send a push notification**.
    + **Give loyalty points**.
    + **Issue a receipt**.
    + Any actions that belong to the app you're creating the automation for.

    <blockquote class="important">

    __Important:__
    Once your pre-installed automation is published, you can't change its trigger.

    </blockquote>

5. Click **Activate**.
6. You're redirected back to the site's **Automations** page.

## Step 3 | Export your automation to the app dashboard

1. Click the actions menu ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ac/0e041dbb-8bbe-4be4-a1ae-883b5cb05e2b/2021/06/01/2a9acf13-da92-4860-a071-03e40202208f/39775e8b-9759-43c3-9c70-c076c64df1f7.png) for the automation you created and select **Generate link**.
2. Copy the generated automation link.
3. Return to the **New Pre-installed Automation** tab in your [app's dashboard](https://manage.wix.com/account/custom-apps).
    
    If the tab was closed, return to the [**Automations**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Ftriggers) page in your app and click **Create New > Pre-installed automation**.

4. Paste the copied automation link in the section labeled **Step 2: Paste the automation link**.

    ![Paste automation link](https://wixmp-833713b177cebf373f611808.wixmp.com/images/d2bba22c761cdc2f79bb7542e21c38f9.png)

    The trigger and action(s) appear in the automation's preview, and the automation name is automatically populated.

5. Go to the next section to configure the pre-installed automation's settings.

    ![Configure pre-installed automation settings](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5fcba3a5f032a91024a47caae2075798.png)

    In the field labeled **Name your automation**, you can rename the automation. Keep in mind:
        
    * Users can’t change the automation name themselves.
    * You can translate the name to other languages in the **Translations** page.
    * Tips for naming an automation:
        * Start with an imperative verb describing what the automation does (for example, Notify members).
        * Describe what triggers it (for example, when a new blog post is published).
        * Use sentence case, no period.

6. Choose the automation's default status when installed on a site:
    * **Active**
    * **Inactive**

7. Configure user settings for the automations:
    * **Allow users to edit timing:** Select this to let users edit the automation's timing, which includes the delay of each action, and how frequently the same contact can trigger it.
    * **Allow users to add & edit conditions:** Select this to let users set conditions that control the automation flow.

8. Click **Save & Close** and you'll be taken back to the **Automations** page.

Your automation is now listed in your app's dashboard under the **Pre-installed** tab.

![Your automation appears under the pre-installed tab](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4babc2bd5c5bf0fb3eaf44f01052768c.png)

## Step 4 | Test your automation

Your automation is now ready to be tested on a site.

1. In the top right corner of your [app's dashboard](https://manage.wix.com/account/custom-apps), click **Test App** and select **Test on dev site**.
1. Select an existing development site or click **+ Create Dev Site** to create a new site. Select the editor and the Wix Business Solution you want to use and click **Create Dev Site**.
1. Click **Test App**. Wix installs your app and opens the site in a new tab. You can set which site page opens in your [app settings](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fapp-settings). If you don't set a page, the site editor opens by default.

<blockquote class="tip">

**Tip:**
If you're using the same site you used to create the pre-installed automation template, make sure you deactivate the template so that it isn't triggered twice.

</blockquote>
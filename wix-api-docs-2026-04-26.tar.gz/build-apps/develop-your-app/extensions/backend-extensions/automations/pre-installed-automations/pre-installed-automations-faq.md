---
portal: build-apps
name: "Pre-installed Automations FAQ"
type: ARTICLE_RESOURCE
resourceId: 98909308-4e01-4701-b465-725e9947a685
---

# Pre-installed Automations FAQ

# Pre-installed Automations FAQ

Below is a list of commonly asked questions about pre-installed automations. We recommend also reviewing the following articles for more information:

+ [About Pre-installed Automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations)
+ [Add a Pre-installed Automation to your App](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/add-a-pre-installed-automation-to-your-app)

## Can I use any trigger?

Currently, **Schedule trigger** is not available for use in preinstalled automations. Otherwise, you can use [any trigger](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations#how-to-create-pre-installed-automations) that belongs to a Wix or 3rd-party app, as long as the app is installed on your site.

## Can I use any action?

Currently, you can [only use the following actions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations#how-to-create-pre-installed-automations) in a pre-installed automation:

* **Send an email**.
* **Send a push notification**.
* **Give loyalty points**.
* **Issue a receipt**.
* Any actions that belong to the app you are creating the pre-installed automation for.

## Can I use triggers with filter fields in pre-installed automations?

Yes, all types of [filter fields](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/filter-fields) can be used. Take note that adding specific items might cause the automation not to work unless these items will be added to sites upon app installation.

## Can app users change the trigger or edit its configuration?

No, in [pre-installed automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations#how-users-interact-with-your-pre-installed-automations) users can’t change the trigger or edit its configuration. They also can't change the action. However, users can edit action configurations.

## If I make changes to the original automation I used as a template, will it affect the pre-installed automation?

No, it’s only used as an initial template and is completely disconnected from the pre-installed automation created in the app dashboard.
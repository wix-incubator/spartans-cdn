---
portal: build-apps
name: "Translate Pre-Installed Automation SMS Messages"
type: ARTICLE_RESOURCE
resourceId: 4127237f-694c-48ba-bd61-e9657a6de536
---

# Translate Pre-Installed Automation SMS Messages

# Translate Pre-Installed Automation SMS Messages

This article guides you through the process of creating and translating a [pre-installed automation](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations) that sends SMS messages. You'll learn how to translate the message content to make it accessible in various languages. Translating SMS messages allows site owners to send automated messages in their preferred language and effectively engage with site visitors.

## Before you begin

+ Install the app that you want to set up an automation for on a Wix site owned by you. This is required to create the pre-installed automation. Learn how to install your app on a [free Premium development site](https://dev.wix.com/docs/build-apps/launch-your-app/app-submission/test-your-app-on-a-premium-site).
+ Learn how to [set up pre-installed automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/add-a-pre-installed-automation-to-your-app) in your app.

## Step 1 | Create an SMS automation to pre-install

To create a pre-installed automation, you first need to build the automation on a site. Create an automation that sends an SMS message as its action.

1. Select an app from the [Custom Apps](https://manage.wix.com/studio/custom-apps) page in your Wix Studio workspace.
1. Go to [**Automations**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fautomations-dev-center) in your app's dashboard.
1. Click **Create New > Pre-installed automation**.
1. Click **Select a site to create the automation**, then select a site that your app is installed on. This action opens the **Automations** page on your site's dashboard in a new browser tab.
1. In your site's dashboard, click **+ New Automation**. Configure a trigger for your app by selecting one of the available triggers. You can use any trigger created by Wix or a 3rd-party. Learn more about [automation triggers](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/about-triggers).
1. Add the **Send an SMS** action.

    ![send an sms](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_send-an-sms.png)

1. Fill out the message content for your SMS automation and copy the text to your clipboard. Fill out any other relevant fields.

    ![sms message content](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_sms-message.png)

    Leave the site open while you complete the next few steps in your app's dashboard. 

## Step 2 | Create the SMS action message extension

In order to translate the SMS message, we need to create an SMS Action Message extension. This extension is necessary for managing the SMS automation.

1. Go to [**Extensions**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) in your app's dashboard.
1. Click **Create Extension**.
1. Search for the **SMS Action Message** extension and click **Create**.
1. Enter a name for your extension, and then paste the message you copied in the steps above.

    ![sms action message](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_sms-action-message.png)

1. Click **Save** to return to the **Extensions** page in your app's dashboard.

## Step 3 | Translate the SMS message and activate

Translate the message content into the available languages of your choice. Each individual translation for the SMS needs to be activated.

1. Go to [**Translations**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Ftranslations-dev-center) in your app's dashboard.
1. Add languages for the translation by clicking **+ Add Language**.
1. Enable the **Activate** option on your extension in each language intended for translation.
1. Click **Translate** to translate the SMS.

    ![activate and translate sms](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_activate-translate.png)

1. Enter the translation for your SMS message and click **Save**.

    ![translated sms](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_translated-sms.png)

<blockquote class="important">

__Important:__
You must manually translate and update the SMS message content for each language you select. Updates to the content in one language aren't applied across all languages. Make sure to follow steps 3 through 5 for each language you translate your message to.

</blockquote>

## Step 4 | Activate the SMS automation

Activate the pre-installed automation using your Wix site:

1. Go to [**Dashboard**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fgiza-dashboard) in your app's dashboard and copy the App ID.
1. Return to the site where you started to create the automation in [Step 1](#step-1--create-an-sms-automation-to-pre-install). Scroll down to the section labeled **Translate the message**.
1. Paste the app ID you copied from the app dashboard, and select your extension name from the dropdown.

    ![paste app ID and select extension](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_appid-extensionname.png)

1. Click **Add Recipients** and select **Contact phone** from the dropdown.

    ![add phone recipient](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_add-recipient.png)

1. Click **Activate** and give your automation a name when prompted.

## Step 5 | Export the SMS automation from the Wix site to the App Dashboard

To complete the automation's configuration and save it to the app, you need to generate a link for your automation from your Wix site and export it to the app dashboard. 

1. While still on the site, find the automation you created under the **Created by you** tab in the automations section of your site dashboard. Click the actions ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ac/0e041dbb-8bbe-4be4-a1ae-883b5cb05e2b/2021/06/01/2a9acf13-da92-4860-a071-03e40202208f/39775e8b-9759-43c3-9c70-c076c64df1f7.png) menu and select **Generate link**.

1. Copy the generated automation link.
1. Return to [**Automations**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fautomations-dev-center) in your app's dashboard. If the tab was closed, click **Create New > Pre-installed automation**.
1. Paste the generated automation link you copied from your site's dashboard.

    ![paste link](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_paste-generated-link.png)

1. Configure the [pre-installed settings](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/add-a-pre-installed-automation-to-your-app#step-3--export-your-automation-to-the-dev-center).
1. Click **Save & close**.

View your new automation under the Pre-installed tab on the Automations page in your app's dashboard.

## Step 6 | View the SMS message translations

Once your automation is fully set up, use your site to see how your SMS message translations will be displayed to your app's users.

1. Return to the site you used to create the automation, and go to your [account settings](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Fsettings).  
1. Change the business manager language to one of the languages selected in section 3.

    ![change account language](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_change-account-language0.png)

1. Go to the [**Automations**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Ftriggers) page on your site dashboard. Note that your site is now displayed in a different language.
1. Find your automation and click **View Summary**.

    ![view-summary-translation](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_view-summary-spanish.png)

1. Click **Edit Action**.

    ![edit-translation](https://wixmp-833713b177cebf373f611808.wixmp.com/images/pre-installed-automated-sms-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_preinstalled_images_edit-translation-spanish.png)
  
1. Scroll down to the **Translate the message** section.
1. You'll see the SMS message translated into the current language of the site.

Learn how to [test your pre-installed automation](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/add-a-pre-installed-automation-to-your-app#step-4--test-your-automation). Don't forget to [submit your app for review](https://dev.wix.com/docs/build-apps/launch-your-app/app-submission/submit-your-first-app-version).
---
portal: build-apps
name: "About Triggers"
type: ARTICLE_RESOURCE
resourceId: 48820bc2-2c4f-44a3-8c6a-3e97002083e2
---

# About Triggers

# About Triggers

The trigger is the event that causes an automation to run.
This is typically something that a visitor does on a site
(for example, purchasing a product),
or something a site owner does (for example, creating an invoice).

Triggers are provided by Wix apps,
including apps made by Wix as well as third-party apps.
You can configure triggers to be installed with your Wix app,
which site owners can use in their automations.
Some apps and their triggers include:

| Wix app | Available triggers |
|---|---|
| Invoices | Invoice overdue <br /> Invoice paid <br /> Invoice sent <br /> Recurring payment starts <br /> Recurring payment canceled |
| Tasks | Task overdue |
| Wix Members Area | Member approved <br /> Member logs in <br /> Visitor signs up to your site |

![Screenshot showing the Wix Automations trigger selection](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-triggers-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_site-dashboard-automation-trigger.png)

As an app developer,
you can configure triggers to be installed with your app,
which site owners can use in their automations. 

The main mechanism for configuring your trigger is through a
[payload schema](https://github.com/wix-private/developer-docs/blob/38a768523274edf864d55ac361c6652da7842ee3/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema.md*original::./payload-schema.md),
which is a JSON schema that tells Wix what data to expect in payloads.
You provide your payload schema to Wix
when you configure your app's triggers in the app dashboard.
Your payload schema contains a list of properties and their data types, as well as
[whether a field contains a Wix contact ID or a date-time of a scheduled event](https://github.com/wix-private/developer-docs/blob/38a768523274edf864d55ac361c6652da7842ee3/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema.md#connecting-payload-schema-properties*original::./payload-schema.md#connecting-payload-schema-properties).

## Overview of events

It's important to understand the difference between a trigger and an event
and what all this means for your users:

- A **trigger** is the configuration you create in your app's dashboard,
  which causes an automation to run.
- An **event** is something that happens in your service,
  which you then report to Wix.

For more complete definitions, see
[Terminology](https://dev.wix.com/docs/rest/business-management/automations/introduction#terminology)
in the Wix Automations API documentation.

The distinction between triggers and events is hidden from users.
From your user's perspective, they interact with triggers only,
whereas events are something that you handle behind the scenes.
When your app reports an event,
the user's automations that use the trigger are run.

Wix Automations supports two types of events for triggers:
real-time events and scheduled events.
Both are described in the next sections.

### Real-time events

Real-time events occur at the time they're reported.
Some examples of real-time events are
a member joining a site or an email being opened.

**Requirements**: <br />
This is the default event type for all triggers.
No special configuration is needed.

**Effect on your user's automations**: <br />
Users can choose to run automations at the moment they're reported
or after a set delay.

![Screenshot showing trigger delay options](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-triggers-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_trigger-delay-one-day-after.png)

### Scheduled events

Scheduled events occur at some future time
relative to the time they're reported.
Some examples of scheduled event fields are
an invoice due date or a session start time.

**Requirements**:

- The payload schema must include a property where the type is `"string"`
  and the format is `"date-time"`.
- You must specify that the
  [date-time property contains the date-time of a scheduled event](https://github.com/wix-private/developer-docs/blob/38a768523274edf864d55ac361c6652da7842ee3/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema.md#scheduled-event-property*original::./payload-schema.md#scheduled-event-property).

**Effect on your user's automations**:
Users can choose to run automations immediately when the event is reported,
or at a certain amount of time before or after the reported event.

![Screenshot showing trigger delay options](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-triggers-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_trigger-delay-one-day-before.png)

## Overview of filter fields

Filter fields allow users to filter their trigger results
based on conditions they select when configuring the automation.
The conditions can be as simple as a boolean selector,
which allows automations to run
based on whether a given payload boolean property is `true` or `false`.
Or it can be as complex as an item selector,
which allows automations to run only when specific forms are submitted.

To summarize: Without a filter field,
an automation runs under all configured conditions,
whereas a filter field allows users to suppress automations
if the user-selected criteria aren't met.

The available filter fields are:

- **Number**:
  Allows users to set a number threshold for a given payload property.
- **Toggle (boolean)**:
  Allows users to compare a boolean value against a payload property.
- **Dropdown**:
  Allows users to select one or more specific values
  from a dropdown list to compare against  a payload property.
  You define the static list of options when you're configuring the filter field.
- **Item selection**:
  Allows users to select one or more specific items on their site
  from a dropdown list to compare against a payload property.
  The dropdown list of items is dynamically generated based on the user's site.

For more information:

- For a complete list of filter field configuration options, see
  [Filter Fields](https://github.com/wix-private/developer-docs/blob/38a768523274edf864d55ac361c6652da7842ee3/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/filter-fields.md*original::./filter-fields.md).
- To learn how to configure a trigger with filter fields, see
  [Add an Automations Trigger Extension](https://github.com/wix-private/developer-docs/blob/38a768523274edf864d55ac361c6652da7842ee3/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/add-an-automations-trigger-extension.md*original::./add-an-automations-trigger-extension.md).
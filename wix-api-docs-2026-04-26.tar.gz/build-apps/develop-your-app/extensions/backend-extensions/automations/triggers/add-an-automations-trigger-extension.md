---
portal: build-apps
name: "Add an Automations Trigger Extension"
type: ARTICLE_RESOURCE
resourceId: d2edc0da-b74f-4cfd-b63a-ffe68d0bdac4
---

# Add an Automations Trigger Extension

# Add an Automations Trigger Extension

To add a trigger extension to your app, follow the procedure below.

## Before you begin

Before getting started,
make sure that you implement your app using
[OAuth with app instance authentication](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/authenticate-as-an-app-instance).
This is required because only your app can report and cancel your trigger's events.

## Step 1 | Set up the trigger

In this step, you'll configure the trigger name and key.

1. In your app's
  [Automations](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fautomations-dev-center)
  page, click **Create New > Trigger**.
  The New Trigger page opens.

    ![App Dashboard screenshot, hovering over the Create New button and highlighting the Trigger option](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-create-new-trigger.png)

2. Set your **Trigger name**.
  The trigger name will be displayed to users,
  so create a name that indicates what the trigger does.

      <div class="tip">

      To keep your trigger name user-friendly and consistent with other triggers,
      we recommend following these best practices:

      - Use passive voice.
      - Keep the name singular.
      - Use sentence case, and don't end with a period.
      - Make sure it can't be confused with another app or trigger.
        For example, "Reservation made" can mean several different types of reservations,
        so "Guest reserves a table" is a less ambiguous name.

      Some examples of good trigger names are:

      - **Invoice sent**
      - **Form submitted**
      - **Member approved**

      </div>

3. Create a **Trigger key**. This identifies your trigger when you
  [report and cancel events](https://dev.wix.com/docs/rest/business-management/automations/triggers/triggered-events/reporting-and-canceling-events).
  It won't be visible to users.

      Using the suggested _<app_name>_-_<trigger_name>_ format,
      choose a trigger key that's meaningful to you.
      After you publish your app, the trigger key can't be changed.

      The trigger key must conform to these requirements:

      - Starts with a letter or number.
      - Contains only lowercase letters, numbers, hyphens, and underscores.
      - Isn't the same as another trigger key in your app.

      ![App Dashboard screenshot showing the New Automations Trigger page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-new-automations-trigger-page.png)

## Step 2 | Configure the payload schema

You specify the expected payload for your trigger using JSON schema.
When users create their automations,
the trigger payload is used to present the available trigger options
(such as whether the user can schedule the automation)
and action options
(such as allowing the user to set a trigger payload property as a variable in an action).

In this step, you'll create the payload schema.
Before you continue,
you'll need a sample of the expected payload as a JSON object.
The JSON object will be used to create the initial version of your payload schema,
which you can build out from there.

> **Note**:
>
> To show how to use all the available options, 
> make sure these fields are included in the sample JSON object:
>
> - String in UUID format.
> - String in date-time format.
>
> If your final payload does not require these fields,
> you can remove them later.

At the end of this step, you'll have a fully configured payload schema.

![App Dashboard screenshot showing the Configure Payload Schema page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-configure-payload-schema.png)

1. To create the initial draft of a schema from your sample payload data,
  click **Create Schema from Payload**.

    ![App Dashboard screenshot showing the Convert a payload to a schema modal](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-convert-payload-to-schema.png)

2. In the **Convert a payload to a schema** modal,
  paste your sample JSON object, and click **Convert to Schema**.
  The modal closes and your schema is generated in the main textbox.

    ![App Dashboard screenshot showing the generated schema](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-sample-schema.png)

3. Click **Process Schema**
  to ensure the schema fields can be used by the rest of the configuration.
4. To further configure your schema, click **Manage Schema Properties**.
5. In the **Manage schema properties** modal,
  configure each field's **Display name** and **Required?** setting.

    ![App Dashboard screenshot showing the Manage schema properties modal](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-manage-schema-properties-modal.png)

6. When you're finished, click **Update Schema**.
  The modal closes and your schema is updated in the main textbox.

Your schema now contains all the fields in your sample JSON,
the display names are set, and the relevant fields are marked as required.
In the next steps, you'll continue to refine and finalize the schema.

## Step 3 | Review and fix the schema

In the previous step, you generated a JSON schema from a sample payload.
However, the payload schema may not be a true representation of the schema you intended.
For example,
data types and string formats are inferred from data you provided in the sample payload,
but some of those details could be incorrect.

In this step, review the generated payload schema and revise as needed.
For a complete payload schema spec, see [Payload Schema](https://github.com/wix-private/developer-docs/blob/6c1dd4340767a465c26d832178ad73e832933c7e/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema.md*original::./payload-schema.md).
Continue when you're happy with your schema.

## Step 4 | Connect schema properties

In this step,
you'll specify if there are schema properties that can be connected to Wix functionality.

Connecting schema properties is optional,
but recommended if it's relevant to your payload.

The available options are:

- Whether a GUID-formatted field is a contact ID.
- Whether a date-time-formatted field contains a scheduled date and time.

Both options are limited to one field each.

### Connect a property to a contact ID

This option is available only for fields where the type is `"string"`
and the format is `"uuid"`.
This option is required for your users
to be able to configure an action to send an email to a contact.

For more about what it means to connect a property to a contact ID, see
[Contact ID property](https://github.com/wix-private/developer-docs/blob/6c1dd4340767a465c26d832178ad73e832933c7e/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema.md#contact-id-property*original::./payload-schema.md#contact-id-property).

To connect a property to a contact ID:

1. Click **Connect a property to a ContactID**.
  A list containing the available fields is displayed.

    ![Screenshot showing the Connect a property to a ContactID dropdown](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-connect-property-to-contactid.png)

2. Select the relevant field from the list.
  The `"identityType": "contact"` key-value pair is added to the connected field
  in the schema.

### Allow scheduled events with predefined date & time

This option is available only for fields where the type is `"string"`
and the format is `"date-time"`.

For more about what it means to allow scheduled events, see
[Scheduled event property](https://github.com/wix-private/developer-docs/blob/6c1dd4340767a465c26d832178ad73e832933c7e/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/payload-schema.md#scheduled-event-property*original::./payload-schema.md#scheduled-event-property).

To specify a scheduled event field:

1. Click **Allow scheduled events with predefined date & time**.
  A list containing the available fields is displayed.

    ![Screenshot showing the Allow scheduled events with predefined date & time dropdown](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-allow-scheduled-events.png)

2. Select the relevant field from the list.
  The `"futureDate": true` key-value pair is added to the scheduled event field
  in the schema.

## Step 5 | Add filter fields to the trigger

This step is optional.
You can configure your trigger to display filter fields.
This allows users to set their automations to run only if certain conditions are met.

![App Dashboard screenshot showing the Create Filter Field button](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-add-filter-fields.png)

To get started, click **Create Filter Field**,
select the filter field type you want to add,
and fill in the required information.
The information needed for each type of filter field is different,
so see [Filter Fields](https://github.com/wix-private/developer-docs/blob/6c1dd4340767a465c26d832178ad73e832933c7e/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/filter-fields.md*original::./filter-fields.md) for the full list of options.

When you're finished configuring your filter field,
click **Apply** to save your settings.

## Step 6 | Provide translations for trigger text

This step is optional.
You can provide translations for some written elements of your trigger into different languages
to make it more accessible to audiences in other languages.

1. Go to [Translations](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Ftranslations-dev-center) in your app's dashboard.
2. Click **Add Language** to open the **Add languages** modal.
3. Select the languages you want to provide, and click **Add**.
4. Find the triggers whose strings you want to translate, and click **Translate**.
  The translation editing page is displayed.
5. Enter the translation for each string, and then click **Save**.
6. Activate each trigger whose translations you want visible for users.

## Step 7 | Test the trigger

In this step you'll install your trigger on a test site,
create a test automation, and report a test event.
Note that, because only the app that created the trigger can report its events,
you must run the test call from your servers using an OAuth token.

To test your trigger:

1. If you haven't saved your trigger already, click **Save & Close** to save it now.
2. Install your app on a test site.
3. [Create an automation](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Ftriggers/rules).
  Make sure the automation uses these settings:

    - **Trigger**: Use your new trigger and configure accordingly.
    - **Action**: Use Send an email, and use these settings:

        - When editing the email template,
          click **Add Dynamic Value** in the left pane
          to include placeholders for your payload properties.
        - In **Set recipients**,
          select **Include additional recipients**,
          select **Add Recipients > Collaborator roles**,
          and then select **Owner**.
          Click **Save** to return to the automation configuration screen.

            ![Screenshot showing the Select Roles modal](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-an-automations-trigger-extension-md_build-apps-portal_develop-your-app_extensions_backend-extensions_automations_triggers_assets_dev-center-select-roles-modal.png)

4. To save your automation,
  complete all the required information and click **Activate**.
5. [Create](https://dev.wix.com/docs/rest/app-management/oauth-2/create-access-token) or
  [refresh](https://dev.wix.com/docs/rest/app-management/oauth-2/refresh-an-access-token)
  an OAuth access token for the test site,
  depending on the OAuth method you used.
6. Send a test payload to [Report Event](https://dev.wix.com/docs/rest/business-management/automations/triggers/triggered-events/report-event).

If you completed this task successfully,
you'll receive an email populated with the payload values.
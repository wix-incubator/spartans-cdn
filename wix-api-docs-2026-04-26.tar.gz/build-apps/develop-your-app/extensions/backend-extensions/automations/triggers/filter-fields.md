---
portal: build-apps
name: "Filter Fields"
type: ARTICLE_RESOURCE
resourceId: 455d2162-0068-413e-abff-1071c5b8866e
---

# Filter Fields

# Filter Fields

This article gives the available options for filter fields for your triggers.

To learn how to configure a trigger with filter fields, see
[Add an Automations Trigger Extension](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/extensions/backend-extensions/automations/triggers/add-an-automations-trigger-extension.md).

## Number

Number filters allow users to set a number threshold for a given payload property.
If you configure this filter, it's a required field for users when they use your trigger.

Example use case: <br />
A customer buys 5 products.

This table shows the available configuration options:

| Option | Details |
|---|---|
| **Label (user-facing)** | Use this field to describe the options the user is selecting. |
| **Tooltip (user-facing)** | Give users more information or explain how this field affects the automation. If left empty, the tooltip icon isn't displayed. |
| **Select the item's property from your schema** | The property in the payload that's used to filter the trigger. |
| **Minimum value** | Minimum value the user can set. |
| **Maximum value** | Maximum value the user can set. |
| **Default value** | Default value displayed to the user. |
| **Comparison operator** | Comparison operator to set the filter to. Currently limited to **Equal to**. |

## Toggle (boolean)

Toggle filters allow users to compare a boolean value against a payload property.
If you configure this filter, it's a required field for users when they use your trigger.

This table shows the available configuration options:

| Option | Details |
|---|---|
| **Label (user-facing)** | Use this field to describe the options the user is selecting. |
| **Tooltip (user-facing)** | Give users more information or explain how this field affects the automation. If left empty, the tooltip icon isn't displayed. |
| **Select the item's property from your schema** | The property in the payload that's used to filter the trigger. |
| **Default state** | Default value displayed to the user. |

## Dropdown

Dropdown filters allow users to select one or more specific values
from a dropdown list to compare against a payload property.
You define the static list of options at the time you're configuring the filter field.
If you configure this filter, it's a required field for users when they use your trigger.

Example use case: <br />
A customer buys a specific product, specified by you.

This table shows the available configuration options:

| Option | Details |
|---|---|
| **Label (user-facing)** | Use this field to describe the options the user is selecting. |
| **Tooltip (user-facing)** | Give users more information or explain how this field affects the automation. If left empty, the tooltip icon isn't displayed. |
| **Select the item's property from your schema** | The property in the payload that's used to filter the trigger. |
| **Enter dropdown choices** | Use this option to provide a static set of options to the user. One per line, with a comma separating display name (user-facing) and value passed in the payload. |
| **Choose a selection method** | Supported values: <ul><li>**Multiple**: Allow the user to select multiple options from the dropdown.</li><li>**Single**: Limit the user to a single option selection.</li></ul> |

## Item selection

Item selection filters allow users to select
one or more specific items on their site from a dropdown list
to compare against a payload property.
The dropdown list of items is dynamically generated based on the user's site.
If you configure this filter, it's a required field for users when they use your trigger.

You can optionally configure multiple item selection fields in sequence
by clicking **Add Follow-up Step**.
Each follow-up step can be used to filter the step that comes before it.

Example use case: <br />
A customer buys a specific, user-specified product.

This table shows the available configuration options:

| Option | Details |
|---|---|
| **Label (user-facing)** | Use this field to describe the options the user is selecting. |
| **Tooltip (user-facing)** | Give users more information or explain how this field affects the automation. If left empty, the tooltip icon isn't displayed. |
| **Item for selection (provider)** | List of entities from Wix apps. Based on your selection, the user is presented with a selectable list of items when they configure an automation with your trigger. For example, if you select Tiers (Loyalty), users can select one or more loyalty tiers when they configure their automation. |
| **Item from previous step to filter this selection (Search param field)** | Payload property, linked to the previous step's item selection field, to further filter by. |
| **Select the item's property from your schema** | The property in the payload that's used to filter the trigger. |
| **Choose a selection method** | Supported values: <ul><li>**Multiple**: Allow the user to select multiple options from the dropdown.</li><li>**Single**: Limit the user to a single option selection.</li></ul> |
| **Users can set this filter to "all items"** | If selected, users can choose not to filter by specific items from the dropdown list. |
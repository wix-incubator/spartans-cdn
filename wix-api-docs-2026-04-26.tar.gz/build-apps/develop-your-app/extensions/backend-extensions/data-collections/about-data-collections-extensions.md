---
portal: build-apps
name: "About Data Collections Extensions"
type: ARTICLE_RESOURCE
resourceId: 347aea6f-a2ad-404c-aef3-dd7742b83ac9
---

# About Data Collections Extensions

# About Data Collections Extensions

<blockquote class="caution"> 
This feature is in Developer Preview and is subject to change.
</blockquote>

The data collections extension allows your app to automatically create CMS [data collections](https://dev.wix.com/docs/api-reference/business-solutions/cms/collection-management/data-collections/introduction) when it's installed on a site. You configure the collection schemas and optional initial data in a JSON configuration file. When a Wix user installs your app, the collections are automatically created in the site's CMS with the schemas and data you specified. 

For the complete JSON schema and field definitions, see the [Data Collections Extension JSON Reference](https://dev.wix.com/docs/api-reference/business-solutions/cms/collection-management/data-collections-extension/introduction). 

## Before you begin

It's important to note the following before using the data collections extension:

- This extension automatically enables the site's [code editor](https://dev.wix.com/docs/develop-websites/articles/getting-started/development-environments#code-editor), which is required for the [Wix Data APIs](https://dev.wix.com/docs/api-reference/business-solutions/cms/introduction) to work. This means your app can use Data APIs to read and write data in the collections without requiring the Wix user to manually enable the code editor.
- Without this extension, apps using Data APIs would need the Wix user to manually enable the code editor on their site, which isn't guaranteed. With the data collections extension, your app can reliably use Data APIs to read and write data in the collections.
- **Blocks apps don't need this extension.** If you're building a [Blocks app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks), you can add collections directly in the Blocks editor. Learn more about [CMS Collections in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/about-cms-collections-in-blocks).


## When to use the extension

Use the data collections extension when your app needs to store data on a site for any reason. This includes:

- **App-specific data storage**: Store member preferences, app settings, cached data, or any other data your app needs to persist on the site.
- **Content management**: Pre-populate collections with templates, sample content, or starter data that helps Wix users get started with your app.
- **Analytics and tracking**: Store analytics data, events, or visitor activity logs that your app collects and manages.
- **User-generated content**: Create collections for visitor submissions, reviews, or custom content that your app helps Wix users manage.

## Implementation options

You can add and configure a data collections extension [in the app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/add-a-data-collections-extension-in-the-app-dashboard).
<!-- When CLI option is available, replace the above with this bulleted list format:
You can add a data collections extension using:

- [App dashboard configuration](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/add-a-data-collections-extension-in-the-app-dashboard): Configure collections using the JSON editor in the app dashboard.
- [Wix CLI](https://github.com/wix-private/developer-docs/blob/cafa160ef7f8f29f06357caf7bd6bd6fbfb62c9d/build-apps-portal/develop-your-app/extensions/backend-extensions/data-collections/URL_TBD*original::URL_TBD): Add and configure a data collections extension using the CLI.
-->

## App version updates

Changes to your data collections extension require releasing a new major version of your app. When a user updates to the new major version, their collections are updated as follows:

- **Adding a new collection:** The new collection is created on the site.
- **Removing a collection:** If the old app version defined a collection and the new version doesn't, the collection is removed from the site.
- **Modifying a collection schema:** Field additions, removals, and type changes are applied to the collection. Existing data is preserved.

When updating a data collections extension, keep these points in mind:

- Collection changes only affect users who update to the new major version. Users who don't update retain their current collections.
- Collection changes take up to 5 minutes to propagate after an update.
- Initial data is only imported when a collection is created. If a collection already contains data, initial data is ignored during updates.

## See also

- [Add a data collections extension in the app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/add-a-data-collections-extension-in-the-app-dashboard)
- [Data collections extension JSON reference](https://dev.wix.com/docs/api-reference/business-solutions/cms/collection-management/data-collections-extension/introduction) 
- [About the Wix Data APIs](https://dev.wix.com/docs/rest/business-solutions/cms/introduction)
<!--- [Add a data collections extension with the CLI](https://github.com/wix-private/developer-docs/blob/cafa160ef7f8f29f06357caf7bd6bd6fbfb62c9d/build-apps-portal/develop-your-app/extensions/backend-extensions/data-collections/URL_TBD*original::URL_TBD)-->
---
portal: build-apps
name: "Add a Data Collections Extension in the App Dashboard"
type: ARTICLE_RESOURCE
resourceId: cf08d119-1e9a-4595-bd1d-7d3d178ebece
---

# Add a Data Collections Extension in the App Dashboard

# Add a Data Collections Extension in the App Dashboard

<blockquote class="caution"> 
This feature is in Developer Preview and is subject to change.
</blockquote>

This article describes how to add a [data collections extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions) to your app using the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).

## Add a data collections extension to your app

Add the extension by doing the following:

1. In the [Custom Apps page](https://manage.wix.com/account/custom-apps), select an app.

1. In the left menu, select **Develop > Extensions**.

1. Click **+ Create Extension** and find the **Data Collections** extension.

1. Click **+ Create**.

1. If you haven't set an [app namespace](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/about-backend-extensions#app-namespace) yet, a popup prompts you to choose a namespace. You can't change your app namespace after you set it.

1. On the **Data Collections** extension configuration page, use the JSON editor to configure your collections. For the complete JSON schema, see the [Data Collections Extension JSON Reference](https://dev.wix.com/docs/api-reference/business-solutions/cms/collection-management/data-collections-extension/introduction). The editor's linter indicates if there are any errors in your JSON configuration. The JSON schema documentation is also available in the JSON editor.

1. Optionally, add initial data to populate the collections when they're created. To do this, include an `initialData` array in your configuration. Make sure the initial data you add is structured according to the schema you defined.

1. Click **Save**.

1. [Release a new app version](https://dev.wix.com/docs/build-apps/manage-your-app/versioning/release-a-new-app-version) to apply the extension changes.

Your app now has a data collections extension. When your app is installed on a site, the collections are automatically created in the site's CMS with the schemas and initial data you specified.

## Example configuration

Here's an example of a data collections extension configuration that creates a "Customer Feedback" collection with a schema and initial data:

```json
{
  "collections": [
    {
      "idSuffix": "customer-feedback",
      "displayName": "Customer Feedback",
      "displayField": "customerName",
      "fields": [
        {
          "key": "customerName",
          "type": "TEXT",
          "displayName": "Customer Name"
        },
        {
          "key": "rating",
          "type": "NUMBER",
          "displayName": "Rating"
        },
        {
          "key": "comments",
          "type": "TEXT",
          "displayName": "Comments"
        },
        {
          "key": "feedbackDate",
          "type": "DATETIME",
          "displayName": "Feedback Date"
        }
      ],
      "dataPermissions": {
        "itemInsert": "CMS_EDITOR",
        "itemUpdate": "CMS_EDITOR",
        "itemRemove": "CMS_EDITOR",
        "itemRead": "ANYONE"
      },
      "initialData": [
        {
          "customerName": "John Doe",
          "rating": 5,
          "comments": "Excellent service!",
          "feedbackDate": { "$date": "2024-01-15T10:30:00.000Z" }
        },
        {
          "customerName": "Jane Smith",
          "rating": 4,
          "comments": "Very satisfied with my purchase.",
          "feedbackDate": { "$date": "2024-01-20T14:45:00.000Z" }
        }
      ]
    }
  ]
}
```

This configuration:
- Creates a collection with ID suffix `customer-feedback`. The full ID in the CMS becomes `@company/app-name/customer-feedback`.
- Defines 4 fields: customer name, rating, comments, and feedback date.
- Sets `displayField` to `customerName`, so the CMS displays this value when referencing items in this collection from other collections.
- Sets permissions so CMS editors can manage data and anyone can read it.
- Includes 2 sample feedback entries as initial data.

## See also

- [About data collections extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions)
- [Data collections extension JSON reference](https://dev.wix.com/docs/api-reference/business-solutions/cms/collection-management/data-collections-extension/introduction)
- [About the Wix Data APIs](https://dev.wix.com/docs/rest/business-solutions/cms/introduction)
<!--- [Add a data collections extension with the CLI](https://github.com/wix-private/developer-docs/blob/f0bbea6866215fca44b523c0a2fb34d8375328e3/build-apps-portal/develop-your-app/extensions/backend-extensions/data-collections/URL_TBD*original::URL_TBD)-->
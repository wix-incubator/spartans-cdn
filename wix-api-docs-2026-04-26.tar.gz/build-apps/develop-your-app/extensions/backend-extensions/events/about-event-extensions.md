---
portal: build-apps
name: "About Event Extensions"
type: ARTICLE_RESOURCE
resourceId: 12582eed-1fb2-49e4-a569-ef473ca16809
---

# About Event Extensions

# About Event Extensions

[Events](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-events) are triggered when specific conditions on your app or a user's site are met. Your app can include code that runs when an event occurs.

For example, an event might be triggered when a [booking is confirmed](https://dev.wix.com/docs/sdk/backend-modules/bookings/bookings/on-booking-confirmed). You can implement logic, such as sending a booking confirmation email, when the event is triggered.

Use event extensions to handle events in the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). You can define events in the CLI using Javascript SDK webhooks. Event extensions subscribe your app to these webhooks.

<blockquote class="tip">

__Tip:__
- In Wix Blocks, you can [handle events using Velo](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/backend-code/events/about-backend-events).
- When self-hosting, you can implement [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks) using REST APIs or the Javascript SDK.

</blockquote>

## See also
- [About Events](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-events)
- [Add Event Extensions with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/events/add-event-extensions)
---
portal: build-apps
name: "About Notification Extensions"
type: ARTICLE_RESOURCE
resourceId: 6a85db66-4e78-471f-a036-97bbd9f9565c
---

# About Notification Extensions

# About Notification Extensions
Your app can use Wix’s notification extensions to send customizable notifications to your app's users in their site dashboard and / or the Wix Owner mobile app. This can be a useful way to alert your users about important updates and events.


## How notifications appear to users
Wix supports several types of user notifications. Here’s how each type looks to users.

### Wix site dashboard
All Wix site builders have a dashboard where they manage their site. Your app can trigger a notification to your users’ dashboard. 
![Dashboard notification](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_dashboardnotification.png) 

### Wix Owner mobile app 
Many users have the companion [Wix Owner app](https://www.wix.com/mobile/wix-app) (available from the Google Play and Apple App Store). This app lets users manage their site from anywhere.

The Wix Owner app supports 2 types of notifications:
- **App dashboard notifications**. Users can see these notifications when they enter the dashboard.
- **App push notifications**. Users can see these notifications without opening the app. The notifications display in the top section of the mobile device or on the lock screen.

Pushing a mobile app notification triggers both types of notifications to users. 
![Owner app notifications](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_ownerappnotifications.png) 

## Implementation options

Notification extensions must be self-hosted. 

## Next steps
To manage your notifications, you’ll need to:
- Set up at least one notification topic extension, which controls how users will decide whether to subscribe.
- Set up at least one notification extension, where you create a template that Wix will use to send your notifications.
- Work with the Notifications API, and specifically call the Notify endpoint to trigger a notification.

## See also
- [Site owner notification settings](https://support.wix.com/en/article/managing-your-sites-notification-settings)
- [Add notification extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/notifications/add-notification-extensions)
- [Notifications API](https://dev.wix.com/docs/rest/business-management/notifications/notifications/introduction)
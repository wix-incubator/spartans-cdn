---
portal: build-apps
name: "Add Notification Extensions"
type: ARTICLE_RESOURCE
resourceId: 58653f0f-3db1-4652-be85-8342aa8cfbcf
---

# Add Notification Extensions

# Add Notification Extensions

Notifications instantly alert site builders with important updates and information that helps them manage their businesses. You can use Wix’s notification extensions to handle your app’s notifications. When you send your notifications via Wix, site contributors get all their notifications in the same way they are accustomed to get Wix’s notifications.    

To extend Wix functionality to include notifications, you add 2 notification extensions: a notification topic extension and a notification extension, and work with the [Notifications](https://dev.wix.com/docs/rest/business-management/notifications/notifications/introduction) API.

Once you’ve set up the relevant extensions, you can send customizable notifications to site contributors with ease.

## Step 1 | Create a notification topic extension
Topics group notifications into types that make it simple for users to decide which types of notifications they want to receive. All of the notifications you create should be assigned to a topic (for example, “New Purchases”) under a relevant section (typically your app’s name).

> **Note**: Notification topics can be created for site contributor notifications, and for site visitor notifications (contacts and members), but currently your app can only send site contributor notifications. 

<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_examplenotificationtopicdisplay.png" style="max-width: 8vw" />

To create a new topic:
1. Go to [**Extensions**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) in your app's dashboard and click **+ Create Extension**.
1. Filter for Notifications, select **Notification Topic**, and then click **+ Create**.
  ![Notification topic App Dashboard UI](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_dcnotificationtopic.png) 

1. Enter a **Section Name** that your notification topic will be displayed under - typically your app’s name. All your app’s notification topics will be displayed under this section name.
1. Enter a **group** (meaning: topic) name for your notification that your users will subscribe to, such as “New purchases.” 
1. Add a **Description** (this is visible only to you).
1. Skip assigning a type to your topic. These types are only relevant for notifications to site visitors, which are currently not available to apps. Therefore, this assignment won’t affect your notifications at all.
1. Set the default state. This determines whether this topic is toggled on or off by default when new users first install your app.
  - **On**: New users will receive notifications about this topic unless they opt out.
  - **Off**: New users won't receive notifications about this topic unless they opt in.

Now that you’ve created a notification topic, you’re ready to create a notification extension.

## Step 2 | Create a notification extension

Notification extensions are templates that store your base notification data so that you can quickly and easily trigger a notification for a predefined topic. You can customize individual notifications by including dynamic values (placeholders that you can replace with customized text when sending notifications) in the template. 

To create a new template:
1. Go to [**Extensions**](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) in your app's dashboard and click **+ Create Extension**.
1. Filter for Notifications,select **Notification**, and click **Create**.
  ![Notification template App Dashboard UI](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_dcnotificationtemplate.png) 

1. Choose a **Notification name** (visible only to you).
1. Add a **Description** (visible only to you).
1. Assign this notification to a topic. If you haven’t already created a topic, click **+ Create Notification Topic** to create one.
1. Copy the **Notification Template ID**. You’ll send this auto-generated ID as a parameter in the [Notify](https://dev.wix.com/docs/rest/business-management/notifications/notifications/notify) API call, to identify the notification you want to send. Note that this ID is only valid once you click **Save**.
1. Choose which site contributors get the notification:
  ![Notification recipients](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_dcnotificationrecipients.png) 
    - **All site contributors**: Site contributors include the site owner, and anyone the owner has invited to manage the site.
    - **Site owner only**: The site owner is the person who created the site (or received ownership, if the site was transferred).

1. Choose where users see the notification:
    - **Dashboard**: The user sees the notification in the Dashboard (desktop website).
    - **Mobile app**: The user both:
      - Receives a push notification from the Wix Owner app.
      - Gets a notification in the app’s notification center.
1. Define the notification’s message content. For example, "You have a new order". Follow these guidelines:
    - You can use a max of 200 characters.
    - Be clear and succinct in your message.
    - Check for spelling and grammar.
    - Use dynamic values to personalize the notification. To include dynamic values, use double brackets: {{DynamicValues}}. You’ll provide the actual values in the Notify API call.
  ![Notification message](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_dcnotificationmessage.png)

1. Once your changes are saved, an example of the HTTP request that enables you to trigger the notification will be displayed.
  ![Notification API request example](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-notification-extensions-md_build-apps-portal_develop-your-app_extensions_backend-extensions_notifications_assets_dcnotificationapiconsumption.png)

> **Note**: Remember your notification template ID and the names of placeholders for dynamic values in your message and title, as you'll need them to invoke the API and trigger notifications. But don't worry if you forget them. You can always return to your app's dashboard to look these details up.

## Step 3 | Code your app and trigger a test notification  
Configure your app to invoke Wix’s [Notify](https://dev.wix.com/docs/rest/business-management/notifications/notifications/notify) API call whenever the relevant trigger is fired, passing the relevant notification template ID and all the dynamic values you included in the template to the call.

Once you’ve set up your app to handle all your expected flows, it’s important to test that your notifications are sent as expected. To do so, you’ll need to:
1. Ensure you’ve requested the 'Manage Notifications' permission scope for your app.
1. Install your app on a test site where you or a team member are the site owner.
1. Trigger your app’s notification flow, including calling Wix’s [Notify](https://dev.wix.com/docs/rest/business-management/notifications/notifications/notify) call.
1. Log in to the test site and confirm that the expected notifications are displayed.

## See also 
- [Site owner notification settings](https://support.wix.com/en/article/managing-your-sites-notification-settings)
- [Notification API](https://dev.wix.com/docs/rest/business-management/notifications/notifications/introduction) reference
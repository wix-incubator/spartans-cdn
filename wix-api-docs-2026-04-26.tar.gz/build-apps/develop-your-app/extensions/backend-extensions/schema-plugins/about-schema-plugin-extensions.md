---
portal: build-apps
name: "About Schema Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 7e864ebe-b9bf-4d12-9871-9eba8c1b15d2
---

# About Schema Plugin Extensions

# About Schema Plugin Extensions
Every Wix API has a service object with predefined fields, which can’t be removed or changed. Sometimes, you might want to add additional fields to an object. For example, if your app uses the [Booking](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/booking-object) object to help outdoor adventure companies book their services, you may want to add a field to include equipment rental as part of the booking.

Schema plugins allow you to extend an object with additional fields. Schema plugins add an `extendedFields` property at different levels:

- **Root-level extensions**: Fields are added to an object's `extendedFields` property at the root level.
- **Nested field extensions**: Fields are added to an `extendedFields` property within a nested array.

## Testing your schema plugin extension
When you create a schema plugin extension in your app dashboard, a draft schema is created (or updated, if one already exists). The schema service will then fetch this draft for test sites, allowing for breaking changes compared to previous drafts.
Once you release a version of your app with the schema plugin extension, the schema service takes the draft version and publishes it to production for all sites that have the app installed. Wix ensures that the released schema is always backwards compatible.

## Reading and writing schema plugin fields
Once added, you can read and write schema plugin fields using the object's regular endpoints, just like any other field in the object. Schema plugin fields your app can read or write to depend on the [field permissions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#defining-field-permissions) defined in the schema plugin.

## Namespaces
Inside `extendedFields` is a nested object called `namespaces`. The `namespaces` object contains the namespaces of any apps that extend the same API object. The schema plugin fields defined by your app are found in your app's namespace object, and user-defined fields are found in the `user_defined` namespace object. Your app can add fields to a site's `user_defined` namespace to add fields that are specific to the site with the [Data Extension Schema API](https://dev.wix.com/docs/rest/business-management/data-extension-schema/about-the-data-extension-schema-api).

<details>
<summary>Learn more about namespaces</summary>

For example, you could create a schema plugin for the [Booking](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/booking-object) object with the namespace `myApp`. This namespace will be listed in the `namespaces` object. Inside the namespace are the fields you defined in your schema plugin.

A site that installs your app could install another app that also extended the Booking object. In this case, your app needs to know which fields belong to it. This is where namespaces come in. The object separates your plugin data from the other app's. It contains two separate objects in `namespaces` and places your respective schema plugins in the appropriate object.

The `extendedFields` object looks something like this:

```json
  "extendedFields": {
    "namespaces": {
      "@account1/myApp": {
        "myFirstField": "My field value",
        "mySecondField": "Another field value for the same app"
      },
      "@account2/anotherApp": {
        "otherField": "A field value for a different app"
      }
    }
  }
```

When your app reads or writes to a field defined by your schema plugin, it must include your namespace in the call to access the correct field.

</details>

## Nested field extensions

Schema plugins can extend nested arrays by adding `extendedFields` properties within those nested structures. This allows you to add custom fields to individual items in an array rather than only at the root level of the main object.

For example, if an object contains an array of line items, you can extend each line item with additional fields specific to your app's needs. The nested `extendedFields` follow the same namespace structure as root-level extensions.

```json
{
  "lineItems": [
    {
      "id": "item1",
      "name": "Standard Product",
      "extendedFields": {
        "namespaces": {
          "@myAccount/myApp": {
            "customization": "Blue color",
            "warranty": "2 years"
          }
        }
      }
    },
    {
      "id": "item2", 
      "name": "Another Product",
      "extendedFields": {
        "namespaces": {
          "@myAccount/myApp": {
            "customization": "Red color",
            "warranty": "1 year"
          }
        }
      }
    }
  ]
}
```

When working with nested extensions, you access and modify the fields using the same APIs and namespace conventions as root-level extensions, and you target the specific nested object or array item that contains the `extendedFields` you want to work with.

## Use cases
Here are a few possible use cases for schema plugins:

**Root-level extensions:**
* Include accessories, such as sports equipment, in the [Booking](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/booking-object) object.
* Add a warranty field to the eCommerce [Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-object) object.
* Add a field to the [Checkout](https://dev.wix.com/docs/rest/business-solutions/e-commerce/checkout/checkout-object) object giving users the option to send products as a gift.

**Nested field extensions:**
* Add customization options (color, size, personalization) to individual line items in an order.
* Include rental duration or condition tracking for each line item in a booking's equipment list at checkout.
* Add delivery preferences or special handling instructions to specific line items at checkout.

You’re not restricted to these examples. You can add a schema plugin to any object that supports it and use them in any way that you need.

> **Note:** Only use a schema plugin when an object doesn’t have a field to support your data. Be aware that many objects contain nested fields that may already meet your app’s needs. Before creating a schema plugin, check the object to make sure you don’t add fields that already exist.

## Supported objects
You can add a schema plugin to any object that has an `extendedFields` property. This includes:

- **Root-level objects**: Objects that have `extendedFields` at the root level.
- **Nested objects**: Arrays that contain their own `extendedFields` properties.

Each `extendedFields` property, whether at the root level or nested, can be extended independently with schema plugins.

## See also
* [Extend an existing object with a schema plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/extend-an-existing-object).
* [Extend an existing object array field with a schema plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/extend-an-existing-object-array-field).
* [The JSON schema](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema).
* [Schema plugins FAQ](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/schema-plugin-faq).
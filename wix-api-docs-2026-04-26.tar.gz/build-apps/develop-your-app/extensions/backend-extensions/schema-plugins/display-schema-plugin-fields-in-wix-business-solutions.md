---
portal: build-apps
name: "Display Schema Plugin Fields in Wix Business Solutions"
type: ARTICLE_RESOURCE
resourceId: 94500cd7-66ba-47a0-a1b9-79a22f1edc6c
---

# Display Schema Plugins in Wix Business Solutions

# Display Schema Plugin Fields in Wix Business Solutions

Schema plugins enable you to extend Wix entities with custom fields. [Wix business solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions) incorporate these entities into their dashboard tables, such as eCommerce Orders in the **Orders** table or Bookings in the **Bookings List** table.

This article explains how to make sure your custom schema plugin fields can be seen by Wix users in the dashboard pages of supported Wix business solutions.

## Step 1 | Choose a supported data type

To display your schema plugin field in dashboard tables, it must use one of the following data types:

* `boolean`
* `string`
* `number`
* `integer`

Schema plugin fields of other types, such as `array` and `object`, won't be visible in the table.

## Step 2 | Assign permissions

For Wix users to see your fields, you must assign `read` permissions for `users` in your schema definition.

For example:

```json
"age": {
  "x-wix-permissions": {
    "read": ["apps", "users", "users-of-users"],
    "write": ["users", "users-of-users"]
  },
  "description": "Age in years which must be equal to or greater than zero.",
  "title": "Age",
  "minimum": 0,
  "type": "integer"
}
```

Learn more about [defining field permissions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#defining-field-permissions).

## Step 3 | Test your field

To test that Wix users can see your field in the relevant Wix business solutions tables:

1. Submit your app for approval. Once approved, you can test your schema plugin.
1. In the dashboard table of a test site, select **Customize Columns** and verify that your field appears.

![Bookings table example](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a7c63c15863f7c13554e065faa122743.png)

## See also

* [About Schema Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions)
* [The JSON Schema](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema)
* [Schema Plugin FAQ](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/schema-plugin-faq)
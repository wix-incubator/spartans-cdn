---
portal: build-apps
name: "Extend an Existing Object Array Field"
type: ARTICLE_RESOURCE
resourceId: aa1b5f43-5abc-4abc-ace1-a6c6c1e46a3e
---

# Extend an Existing Object Array Field

# Extend an Existing Object Array Field with a Schema Plugin

[Schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions) are backend extensions that allow you to add fields to API objects. In addition to extending objects at the root level, schema plugins can extend nested arrays within objects by adding fields to individual array items. Once added, these nested fields can be read and written using the object's regular endpoints, just like any other field in the object.

For example, you can extend individual line items in an eCommerce order, allowing you to add custom data specific to each array item.

## Extending an object array field with a schema plugin

To add a schema plugin extension for a nested array field to your app:

1. Select an app from the [Custom Apps page](https://manage.wix.com/account/custom-apps) in your Wix Studio workspace.
1. Select [**Extensions**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) in the left side-menu, and click **+ Create Extension**.

   ![add component](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3d5238b1bfae827fb4ab4d3de1b4460e.png)

1. Search for **schema plugin** in the search bar. Choose the object that contains the specific field you want to extend and click **Create**.

1. If you haven't set an [app namespace](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/about-backend-extensions#app-namespace) yet, a popup prompts you to choose a namespace. You can't change your app namespace after you set it.

   ![create namespace](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a33ee11374b2baa1f3408c9e0c7e9e82.png)

1. Use the **JSON Editor** to define your schema plugin as a [JSON Schema](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema). When defining a schema plugin for nested array fields, you'll target the specific array property path rather than the root object.

   For example, to extend line items in an order, your schema might target the `lineItems` array:

   ```json
    {
   "type": "object",
   "properties": {
     "warranty": {
       "type": "string",
       "maxLength": 128,
       "description": "Warranty information for this item",
       "x-wix-permissions": {
         "read": [
           "apps",
           "users"
         ],
         "write": [
           "apps",
           "users"
         ]
       }
     },
     "customization": {
       "type": "string",
       "maxLength": 128,
       "description": "Product customization details",
       "x-wix-permissions": {
         "read": [
           "apps",
           "users"
         ],
         "write": [
           "apps",
           "users"
         ]
       }
     }
   }
   ```

   ![json editor](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f6ff4bf62d9e0e7c5f0b0650c6742df8.png)

1. Once your schema plugin is defined, click **Save**.  
   > **Important:** Once you add a schema plugin to an app, it can't be removed. You can [archive](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#archiving-schema-fields) the plugin fields to prevent them from being read or written.

Your app now has a schema plugin extension for nested array fields. When working with the extended object, each array item will have its own `extendedFields` property that contains your custom fields in your app's namespace.

## Accessing nested schema plugin fields

When reading or writing to nested schema plugin fields, you access them through the specific array item's `extendedFields` property:

```json
{
  "lineItems": [
    {
      "id": "item1",
      "name": "Standard Product",
      "extendedFields": {
        "namespaces": {
          "@myAccount/myApp": {
            "customization": "Blue color",
            "warranty": "2 years"
          }
        }
      }
    }
  ]
}
```

You can return to the JSON editor to make non-breaking [changes](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#editing-the-schema) to the schema.
---
portal: build-apps
name: "Extend an Existing Object"
type: ARTICLE_RESOURCE
resourceId: 5ac6e7de-250d-4883-85e4-95fc1ad3236f
---

# Extend an Existing Object

# Extend an Existing Object with a Schema Plugin

[Schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions) are backend extensions that allow you to add fields to an APIs object. Once added with a schema plugin, fields can be read and written using the object's regular endpoints, just like any other field in the object.

To add a schema plugin extension to your app:

1. Select an app from the [Custom Apps page](https://manage.wix.com/account/custom-apps) in your Wix Studio workspace.
1. Select [**Extensions**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) in the left side-menu, and click **+ Create Extension**.

   ![add component](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3d5238b1bfae827fb4ab4d3de1b4460e.png)

1. Search for **schema plugin** in the search bar. Choose the object you want to extend and click **Create**.

1. If you haven't set an [app namespace](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/about-backend-extensions#app-namespace) yet, a popup prompts you to choose a namespace. You can't change your app namespace after you set it.

   ![create namespace](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a33ee11374b2baa1f3408c9e0c7e9e82.png)

1. Use the **JSON Editor** to define your schema plugin as a [JSON Schema](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema). The editor's linter indicates if there are any errors in the JSON Schema.

   ![json editor](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f6ff4bf62d9e0e7c5f0b0650c6742df8.png)

1. Once your schema plugin is defined, click **Save**.  
   > **Important:** Once you add a schema plugin to an app, it can't be removed. You can [archive](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#archiving-schema-fields) the plugin fields to prevent them from being read or written.

Your app now has a schema plugin extension. You can return to the JSON editor to make non-breaking [changes](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#editing-the-schema) to the schema.
---
portal: build-apps
name: "Schema Plugin FAQ"
type: ARTICLE_RESOURCE
resourceId: a2816e96-3f3d-41ff-a008-b6ddb513a212
---

# Schema Plugin FAQ

# Schema Plugins FAQ

Below is a list of commonly asked questions about schema plugins. Be sure to also review the following articles before getting started with schema plugins:

+ [About Schema Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions)
+ [Extend an Existing Object with a Schema Plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/extend-an-existing-object)

## What JSON types and formats does the schema support?

The schema supports the basic types defined by JSON schema, including:

+ Strings
+ Booleans
+ Numbers
+ Integers
+ Objects
+ Arrays

For string fields, the schema supports the following formats:

+ Hostnames
+ Resource identifiers
+ Dates and times
+ Emails
+ Phone numbers
+ Single-line text

For more information on the types and keywords the schema supports, see [The JSON Schema](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema) specification.

## How large can my JSON schema be?

The schema can take up a maximum of 10KB in memory. It can have a maximum of 256 properties.

The schema's size in memory is calculated based on the [field types](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#supported-types) defined in the schema:

+ Strings: 1 byte/character
+ Numbers: 8 bytes
+ Integers: 4 bytes
+ Arrays: Varies
+ Objects: Varies

The size of a string is determined by the string's maximum length, which you're required to define for all string properties. For example, a string with a defined maximum length of 20 characters has a size of (1 byte/character) × 20 characters = 20 bytes.

The size of an array is calculated based on the maximum number of items the array can hold, and on its data type. An array that holds a maximum of 10 integers, for example, has a size of 10 × 4 bytes = 40 bytes.

An object's size varies depending on which fields it contains. For example, an object that contains 2 string fields, both with a maximum length of 100, and one number field, the size is 2 × 100 bytes + 8 bytes = 208 bytes.

## Are archived fields counted in the size?

Yes. [Archived fields](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#archiving-schema-fields) remain in the database, so they still count towards the amount of memory your schema takes up.

## I’m getting a JSON schema validation error when I try to create my schema. What does it mean?

It means that the schema you’ve added doesn’t align with the JSON schema restrictions set by Wix. Follow the error message and amend your schema accordingly.

Some common [error messages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#json-validation-errors) are explained in the JSON schema reference.

## Which API objects can I extend?

Currently you can [extend](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/extend-an-existing-object) the following objects:

+ eCommerce [Checkout](https://dev.wix.com/docs/rest/business-solutions/e-commerce/checkout/checkout-object) and [Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-object)
+ [Booking](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/booking-object)
+ [Booking Service](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/service-object)

## Can I edit my JSON schema after it’s been published?

Once you save the schema, you can only make [non-breaking changes](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#editing-the-schema) to it. Examples of non-breaking changes include:

+ Adding a new field.
+ Changing a field’s display parameters, e.g. title, description, and placeholder.
+ Removing minimum or maximum limits on a field.
+ Adding or removing a field’s read or write permissions.

You will receive an error if you try to make any breaking changes, such as:

+ Changing a field’s type.
+ Increasing a field’s minimum limit or decreasing its maximum limit.

## Can I delete fields from my JSON schema?

It isn’t possible to delete fields from the schema, but you can [archive them](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#archiving-schema-fields). An archived field remains in the database, but is hidden during read and write operations. Note that once you archive a certain key, you cannot use that key again in your schema, since it still appears in the database.

To archive a field, add the `x-wix-archived` key to its object, and set the key's value to `true`. To unarchive the field, set the value to `false` or delete the `x-wix-archived` key entirely.

## How can I see fields that are archived when reading the API object?

An [archived field](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#archiving-schema-fields) is hidden during API calls, but it is still visible in the [JSON schema you defined](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/extend-an-existing-object) in your app's dashboard.

## What permissions I can give my schema plugin fields?

You can define any of four [permissions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema#defining-field-permissions) when you create a field in the JSON schema:

+ `owning-app`: The app that created the extended field.
+ `apps`: Any other apps that are installed on the user’s site.
+ `users-of-users`: An identified member or site visitor.
+ `user`: The site owner.

Each field has its own set of permissions that are defined in the [`x-wix-permissions`](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/the-json-schema) object. For example, one field may give users and site visitors read and write permissions, but another field in the same schema can limit read and write to only other apps or the owning app.

Note that all fields defined in a schema in your app's dashboard automatically have `owning-app` permissions, so there is no need to define those permissions explicitly.

## Data isn't saving when users fill out the extended fields, what's going wrong?

This symptom has 2 common causes:

1) Schema plugin namespace is incorrect.
The namespace in your code doesn't match your app's schema plugin namespace in Wix Studio. In **Wix Studio**, navigate to **Custom Apps > Your App > Extensions**, confirm your schema plugin namespace (for example, `@your-account/your-app-name`), and update the constant in your code:
```javascript
const SCHEMA_PLUGIN_NAMESPACE = '@your-account/your-app-name'
```
2) Extended fields update fails silently.
Extended fields update happens after entity creation but fails without blocking the operation. Verify the update code and check for errors:
```javascript
// After creating/updating an entity (e.g., checkout, order)
if (wixClient.checkout && hasExtendedFields) {
  try {
    const extendedFieldsData = {}

    // Only include fields that have values
    if (isGift) extendedFieldsData.isGift = isGift
    if (giftMessage?.trim()) extendedFieldsData.giftMessage = giftMessage.trim()
    if (deliveryInstructions?.trim()) {
      extendedFieldsData.deliveryInstructions = deliveryInstructions.trim()
    }
    if (preferredDeliveryTime) {
      // Convert datetime-local to ISO-8601 format
      const date = new Date(preferredDeliveryTime)
      extendedFieldsData.preferredDeliveryTime = date.toISOString()
    }

    if (Object.keys(extendedFieldsData).length > 0) {
      await wixClient.checkout.updateCheckout(checkoutId, {
        extendedFields: {
          namespaces: {
            [SCHEMA_PLUGIN_NAMESPACE]: extendedFieldsData
          }
        }
      })
      console.log('Extended fields updated successfully')
    }
  } catch (updateError) {
    console.error('Failed to update extended fields:', updateError)
    console.error('Error details:', {
      message: updateError.message,
      code: updateError.code,
      data: updateError.data
    })
    // Operation continues even if extended fields fail
  }
}
```
In the **Console**, check for warnings about extended fields update. Ensure the schema plugin is published, not just in draft.
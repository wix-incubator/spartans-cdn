---
portal: build-apps
name: "About Service Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: e68963a0-5a92-4e35-8eb3-90de7b47b986
---

# About Service Plugin Extensions

# About Service Plugin Extensions

Service plugin extensions (formerly SPIs) are a set of APIs defined by Wix that you can use to enable your app to inject custom logic into existing app flows or to introduce entirely new flows to Wix sites. 

<iframe width="560" height="315" src="https://youtube.com/embed/Kgrd9NBvgtw" title="Intro to Backend Events on Wix Studio" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## Don't call us, we'll call you

Unlike traditional API endpoints where your app initiates a call with Wix, service plugins invert the process. Here, Wix calls your service during a specific flow, waits for your response, and then continues the flow based on your response.  

For example, your app can use the [Validations service plugin](https://dev.wix.com/docs/rest/business-solutions/e-commerce/service-plugins/validations-integration-service-plugin/introduction) to validate a site visitor's checkout and check for additional violations, such as restricting certain purchases to site members only. When a customer updates a checkout on a site with your app installed, Wix sends a [Get Validation Violations](https://dev.wix.com/docs/rest/business-solutions/e-commerce/service-plugins/validations-integration-service-plugin/get-validation-violations) service plugin request to your app.  

Your server [validates the request](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/backend-extensions/add-self-hosted-service-plugin-extensions-with-rest) and returns a response. Note that the response must be returned per the specification exactly as documented or Wix will not handle your response correctly. In this case, your app returns an object containing an empty list if the validation is successful, or an object detailing the violation if unsuccessful.

## Simplify with the SDK

Use the Wix JavaScript SDK to further simplify the entire process. With a single `provideHandlers()` function you define the logic you want to inject all in one convenient place. The `process()` function decodes JWT-encrypted requests and allows you to expose all of your service plugin functionalities at once, without worrying about the specific sub-path for each endpoint.

## Streamline with the CLI

Use [the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) for a streamlined alternative with minimal setup and configuration. Automatically add a service plugin extension to your app, generate the necessary code files, and have Wix host the endpoints for you. Simply provide the configuration details and define the handler functions that implement your business logic.

## See also

+ [Add a service plugin with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/service-plugins/add-service-plugin-extensions).
+ Add a self-hosted service plugin extension [with SDK](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/backend-extensions/add-self-hosted-service-plugin-extensions-with-the-sdk) or [with REST](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/backend-extensions/add-self-hosted-service-plugin-extensions-with-rest).
+ [Add a service plugin for a single site with Velo](https://dev.wix.com/docs/velo/articles/api-overview/service-plugins-spis).
+ [List of available service plugins](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#service-plugins)
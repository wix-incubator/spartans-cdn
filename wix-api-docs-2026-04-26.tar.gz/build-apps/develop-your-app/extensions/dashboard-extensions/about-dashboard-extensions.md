---
portal: build-apps
name: "About Dashboard Extensions"
type: ARTICLE_RESOURCE
resourceId: ca5b196e-83d1-4ad1-bf1a-2b8d93353d0c
---

# About Dashboard Extensions

# About Dashboard Extensions

Dashboard extensions are back-office services that can help users manage their business or websites more effectively. They allow your app to extend the functionality of the Wix Dashboard with customizable features, such as a page or a plugin. Dashboard extensions aren’t visible on live sites. You can view your dashboard extensions in the Extensions tab of your app in the [app dashboard](https://manage.wix.com/account/custom-apps). 

Dashboard extensions can be implemented by using one or more of the following [frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks#wixs-development-frameworks):
- Self-hosting: your extension is built using your own tech stack and is integrated with Wix using the [app dashboard](https://manage.wix.com/account/custom-apps).
- Wix CLI: your extension is built with Wix’s React/Node.js stack and is integrated with Wix using the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli).
- Wix Blocks: your extension is built and integrated with Wix using Wix’s native app editor, [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks). 

## Dashboard page extensions
Dashboard pages are administrative pages that you can design and add to the dashboard of a Wix Site. They are only accessible to site administrators with the required permissions. The dashboard page extension allows you to add your own dashboard page with some administrative functionality. Dashboard page extensions can be implemented using Wix Blocks, the Wix CLI, or a self-hosted solution. 

Learn more about [dashboard page extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions).

## Dashboard modal extensions

Dashboard modals are graphical user interfaces (GUIs) that appear as pop-up windows in the center of dashboard pages. The dashboard modal extension allows you to import a modal, built and hosted externally, onto a dashboard page. Dashboard modal extensions can be self-hosted, or they can be implemented using the Wix CLI. 

Learn more about [dashboard modal extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals).

## Dashboard plugin extensions 

Dashboard plugins are interactive widgets added to dashboard pages. The dashboard plugin extension allows you to place a plugin into predefined slots, or UI placeholders, on the dashboard pages of apps built by Wix. Dashboard plugins can be self-hosted, or they can be implemented using the Wix CLI. 

Learn more about [dashboard plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions).

## Dashboard menu plugin extensions

Dashboard menu plugins are menu items that are added to menus on dashboard pages. The dashboard menu plugin extension allows you to place a new menu item in a predefined slot, or UI placeholder, in a menu on the dashboard page of an app built by Wix. When clicked, the added menu item can direct a site administrator to a different dashboard page, or can open a dashboard modal. Dashboard menu item plugin extensions can be self-hosted, or they can be implemented using the Wix CLI. 

Learn more about [dashboard menu item plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions). 

## See also
- [How Apps Extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix)
- [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions)
- [Add Self-hosted Dashboard Page Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-page-extensions)
- [Add Dashboard Page Extensions with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions#add-dashboard-page-extensions-with-the-cli)
- [Add Self-hosted Dashboard Modal Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-modal-extensions)
- [Add Dashboard Modal Extensions with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [Add Dashboard Plugin Extension with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions in the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
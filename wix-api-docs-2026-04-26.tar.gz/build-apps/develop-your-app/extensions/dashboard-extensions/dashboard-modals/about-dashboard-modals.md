---
portal: build-apps
name: "About Dashboard Modals"
type: ARTICLE_RESOURCE
resourceId: 916a0c0f-c600-4d61-b9e3-a90cd71b758e
---

# About Dashboard Modals

# About Dashboard Modal Extensions

A modal is like a pop-up window that appears in the middle of the page.

The dashboard modal extension lets you create a modal that appears in the dashboard. You can manage the modal in your dashboard using the `openModal()` and `closeModal()` functions from the [dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/introduction). 

>**Note:** You can also open your modal from [dashboard menu plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions). 

For example, in the Wix Blogs app, the following modal appears when adding a writer:

![Modal example](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4f0471f99a9e2ba58f14d7c4b76afeb1.png)


## When to use a dashboard modal extension

Use this extension when you want to add a modal to your app. Examples of using a dashboard modal in your app include:

- Logging in/ signing up
- Agreeing to terms and conditions
- Subscribing to a newsletter
- Confirming a choice, such as, "Are you sure you want to delete this?"

## Implementation options

You can host a dashboard modal extension in one of the following ways:
- Using the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli).
- By self-hosting, meaning you must build and host your dashboard modal externally. Provide the extension with your dashboard modal's host URL and use the dashboard modal's extension ID to render it in your app.

    > **Note:** For a more streamlined approach to developing your dashboard modal, try out the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions) instead of self-hosting.

When it comes to designing the UI, consider using the [Wix Design System](https://www.wixdesignsystem.com/). It is a collection of reusable React components that you can use to make your app appear and feel like a native Wix app. Your app must have the look and feel of a Wix app, or it may not be approved for the app market.

### Advantages to implementing a modal using the dashboard modal extension

There are several advantages to implementing a modal using the dashboard modal extension instead building it directly into your app:
- **Better UI**: Dashboard modals always render in the center of the page. When a modal pops up, you want it to appear centrally in the app.
- **Reusability**: If you build a few apps, you can reuse the same dashboard modal in all of them without needing to copy the code into each app. This also means if you make a change to the modal, you need to edit the modal in only one place, rather than in every app.

## See also
- [Add Self-hosted Dashboard Modal Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-modal-extensions)
- [Add Dashboard Modal Extensions with the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions)
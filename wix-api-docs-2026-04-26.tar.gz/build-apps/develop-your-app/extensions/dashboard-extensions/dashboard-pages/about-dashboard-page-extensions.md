---
portal: build-apps
name: "About Dashboard Page Extensions"
type: ARTICLE_RESOURCE
resourceId: f45ecbd5-bc56-46a9-97ab-40124e9e1c5c
---

# About Dashboard Page Extensions

# About Dashboard Page Extensions

Dashboard pages are administrative pages you can add to the dashboard of a Wix site or project. They do not appear on the live site, so site visitors never see them. However, dashboard pages are visible to site admins with the required permissions.

For example, if a site has Wix Blog installed, your app can extend the site’s functionality by adding a dashboard page that shows which blog posts were viewed and liked the most.

![Dashboard Page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b8ed53faf25a77f74898d007a12bd8f9.png)

## When to use the dashboard page extension

Use this extension when you want to add administrative functionality to your site or project dashboard. This might include:

- Rendering site or business data for monitoring and analysis.
- Configuring functionality of the editor or live site.
- Integrating data or services hosted outside of Wix.

For example, you might want to add a dashboard page for configuring content to display, the speed of an animation, or the behavior of a chatbot.

## Implementation options

You can add a dashboard page extension using:

- [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions)
- [A self-hosted solution](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-page-extensions)
- [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/build-a-dashboard-page-in-blocks)

> **Note:** For a more streamlined approach to developing your dashboard page, try out the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions) or [Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/build-a-dashboard-page-in-blocks) instead of self-hosting.

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When it comes to designing the UI, consider using the [Wix Design System](https://dev.wix.com/docs/build-apps/develop-your-app/design/about-the-wix-design-system), a collection of reusable React components that you can use to make your app appear and feel like a native Wix app.

<blockquote class="important">

__Important:__ The format of the Wix dashboard URL is changing due to new cookies introduced for authorization. The new URL format is `{username}-{sitename}.{editor|studio|harmony}.wix.com`. If your app uses CORS and whitelists specific origins, update your allowed origins to match the new format to avoid blocked requests.

</blockquote>

## See also

- [Tutorial | Creating a “Top Blog Posts” Dashboard Page Using the Wix CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-top-blog-posts-dashboard-page-with-the-cli)
- [Tutorial | Create a Self-hosted App](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-a-self-hosted-app)
---
portal: build-apps
name: "Add Dashboard Menu Plugin Extensions "
type: ARTICLE_RESOURCE
resourceId: 1c9ef4a4-da51-4e32-a651-5a28287205d0
---

# Add Dashboard Menu Plugin Extensions 

# Add Dashboard Menu Plugin Extensions in the App Dashboard

This article describes how to add a [dashboard menu plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions) into a pre-configured slot in an app built by Wix, using the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).

> **Note**:
>
> - Alternatively, you can add a dashboard menu plugin extension with the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions).
> - You can only add this extension to some apps built by Wix. Learn more about [plugin slots in dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots).
> - To minimize errors, instruct your user to install the app built by Wix on their site before installing your app.

## Add a dashboard menu plugin to your app

Add the extension by doing the following:

1. In your app dashboard, click **Extensions** in the sidebar menu.
2. Click **Create Extension**.
3. In the **Choose the extension you want to create** modal, select **Dashboard Menu Plugin** and click **Create**.
4. On the **Dashboard Menu Plugin** extension configuration page, use the JSON editor to configure the following properties:

| Property    | Description        |
| ----------- | ------------------ |
| **extends** | **Required**. The [slot ID](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) for the slot your extension plugs into. |
| **hostingPlatform** | **Required**. The Wix platform that hosts the extension. Use `BUSINESS_MANAGER`. |
| **iconKey** | The icon that appears next to your extension in the menu it's added to. Select a normal-size [icon from the Wix Design System](https://www.wix-pages.com/wix-design-system-employees/?path=/story/foundations-icons--icons) and paste its name. |
| **action**| **Required**. What your extension does when clicked. Enter `openModal` to direct site administrators to a dashboard modal, or `navigateToPage` to direct them to another dashboard page. |
| **action.navigateToPage** | When **action** is set to `navigateToPage`, the page navigation configuration object. This contains the ID of the target dashboard page, as well as additional parameters. Learn how to find the [extension ID](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/find-a-dashboard-extension-id). |
| **action.navigateToPage.pageId** | **Required** when using `navigateToPage`. The ID of the dashboard page to which site administrators are directed. Learn how to find the [extension ID](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/find-a-dashboard-extension-id). |
| **action.navigateToPage.relativeUrl** | A URI segment attached to the base URI of the target dashboard page. It can include path segments, search parameters and hash information. |
| **action.openModal** | When **action** is set to `openModal`, the dashboard modal configuration object. This contains the ID of the dashboard modal to display, as well as additional parameters. </br> </br> Learn more about [dashboard modals](https://github.com/wix-private/developer-docs/blob/e9bfa48669095511e734a635727ae2e5e792a286/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals.md*original::../../dashboard-modals/about-dashboard-modals.md). |
| **action.openModal.componentId** | **Required** when using `openModal`. The ID of the dashboard modal to display when the extension is clicked. Learn how to find the [extension ID](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/find-a-dashboard-extension-id). |
| **action.openModal.componentParams** | Additional parameters you can pass to your [dashboard modal](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals). Note that if an additional parameter shares a name with a [parameter passed by the slot](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#slots-and-plugin-apis), the additional parameter overrides the slot's parameter.  |
| **componentName** | A unique name for this extension that appears in the app dashboard. |

5. Click **Save**.

When the site admins clicks the dashboard menu plugin extension, they are directed to the specified dashboard page or shown the modal.

## See also

- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [About Dashboard Page Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions)
- [About Dashboard Modals](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals)
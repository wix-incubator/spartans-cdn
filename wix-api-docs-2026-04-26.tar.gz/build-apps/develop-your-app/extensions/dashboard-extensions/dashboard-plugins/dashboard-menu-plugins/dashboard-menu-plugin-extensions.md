---
portal: build-apps
name: "Dashboard Menu Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 94d51527-3b18-4c70-bfed-efa8cecb2a6d
---

# Dashboard Menu Plugin Extensions

# About Dashboard Menu Plugin Extensions

The dashboard menu plugin extension integrates with apps built by Wix, such as Wix Bookings, to enhance their functionality. The extension adds an item into a pre-configured slot in the menu of a dashboard page added by the app. When a Wix user clicks the added menu item, it directs them to a different dashboard page or displays a dashboard modal.

![Dashboard Menu Plugin](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0e1fd658453d2845618d9a07170b33fb.png)

Since menu plugin extensions are added to dashboard pages, they do not appear on the live site, so site visitors never see them. They are, however, visible to Wix users with the required permissions.

## About Plugin Slots

Some apps built by Wix contain slots in one or more of dashboard pages. Slots are UI placeholders that can be populated with plugin extensions, such as the dashboard menu plugin or the generic [dashboard plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#dashboard-plugin). When building a plugin extension, you need to specify [the ID of the slot](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) where you want your plugin to be placed.

For instance, if a user has the Wix Bookings app installed on their site, your app can add a menu item to the **More Actions** menu in the **Calendar** dashboard page. When clicked, your app can display a dashboard modal that summarizes the total hours booked in the current week, or allows the site owner to manage their staff schedule without having to leave the calendar page.

Apps built by Wix also determine the data that is passed through slots. The menu plugin passes parameters, such as an ID, from the dashboard page it's hosted on, through the slot, to its target page or modal. You can then retrieve and use the data in the menu plugin's target. For example, if your menu plugin opens a modal, you can retrieve the dashboard page data in the modal extension itself. 
The parameters being passed are specific to the slot on the dashboard page that hosts the menu plugin. Some slots don't pass any parameters. You can retrieve the dashboard page data using the `observeState()` function from the [dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/observe-state).

> **Note**:
>
> - Only some apps built by Wix include pre-configured menu plugin slots. Learn more about [Plugin Slots in Dashboard Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots).

## When to use the dashboard menu plugin extension

Use the dashboard menu plugin extension when you want to add a menu item that directs the user to another dashboard page or opens a dashboard modal. You can create functionality such as:

- Directing the user to another dashboard page that's part of your app, with additional parameters such as path and search parameters.
- Directing the user to another dashboard page that's part of a Wix business solution, such as Wix Stores or Wix Blog.
- Changing service settings without having to leave the current dashboard page.

## Implementation options

To configure the dashboard menu plugin extension, you can use either the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions) or the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions).

## See also

- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [About Dashboard Page Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions)
- [About Dashboard Modals](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals)
- [About External URL Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/external-links/about-external-link-extensions)
---
portal: build-apps
name: "Wix Blog: Edit Post Page"
type: ARTICLE_RESOURCE
resourceId: 1f168d30-aef9-4882-8e0d-d547d54661bf
---

# Wix Blog: Edit Post Page

# Wix Blog: Edit Post Page

The Edit Post page has 1 dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Navigate to this page by creating a new post or editing an existing post:
- Blog > Overview/Posts > Create New Post
- Blog > Posts > _Hover over a post_ > Edit

## Dashboard menu plugin slots

The Edit Post page features 1 dashboard menu plugin slot.

### Slot 1: More actions menu

This dashboard menu plugin slot is located in the top right corner in the Edit Post page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-create-edit-post-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-create-edit-post-more-actions1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `1e756df4-6c2e-403c-b81c-c3de62aebac7`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "1e756df4-6c2e-403c-b81c-c3de62aebac7",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Blog APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/blog/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/blog/introduction)

## Slot IDs

| Slot | ID | Parameters |
| ---- | -- | ---------- |
| More actions menu | `1e756df4-6c2e-403c-b81c-c3de62aebac7` | |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
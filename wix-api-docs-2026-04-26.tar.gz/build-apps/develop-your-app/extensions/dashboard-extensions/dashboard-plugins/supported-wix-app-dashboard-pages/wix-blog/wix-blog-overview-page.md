---
portal: build-apps
name: "Wix Blog: Overview Page"
type: ARTICLE_RESOURCE
resourceId: 5c54ad3d-617d-4a66-9649-14113a5a9e11
---

# Wix Blog: Overview Page

# Wix Blog: Blog Overview Page

The Blog Overview page has 2 plugin slots: 1 dashboard, and 1 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Blog > Overview

## Dashboard plugin slots

The Blog Overview page features 1 dashboard plugin slot.

### Slot 1: Blog Overview page

This dashboard plugin slot is positioned at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-blog-overview-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-blog-overview-main-plugin1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `65fae040-bbeb-4c62-ba14-e0ecb5e08661`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "65fae040-bbeb-4c62-ba14-e0ecb5e08661",
  "description": "Blog Overview Dashboard Plugin",
  "title": "Blog Overview Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "blogOverviewPlugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom of the slot.

## Dashboard menu plugin slots

The Blog Overview page features 1 dashboard menu plugin slot.

### Slot 2: More actions menu

This dashboard menu plugin slot is located in the more actions menu at the top of the Blog Overview page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-blog-overview-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-blog-overview-more-actions1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `eee8a260-88cb-432b-b32e-e154b0a1030a`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "eee8a260-88cb-432b-b32e-e154b0a1030a",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Blog APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/blog/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/blog/introduction)

## Slot IDs

| Slot | ID | Parameters |
| ---- | -- | ---------- |
| Blog Overview page | `65fae040-bbeb-4c62-ba14-e0ecb5e08661` | |
| More actions menu | `eee8a260-88cb-432b-b32e-e154b0a1030a` | |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
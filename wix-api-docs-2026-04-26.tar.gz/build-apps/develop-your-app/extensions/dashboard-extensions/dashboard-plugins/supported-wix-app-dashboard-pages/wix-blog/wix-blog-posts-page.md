---
portal: build-apps
name: "Wix Blog: Posts Page"
type: ARTICLE_RESOURCE
resourceId: 87f30080-0773-467a-b628-80bc9861c7fa
---

# Wix Blog: Posts Page

# Wix Blog: Posts Page

The Posts page has 7 plugin slots: 1 dashboard, and 6 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Blog > Posts

## Dashboard plugin slots

The Posts page features 1 dashboard plugin slot.

### Slot 1: Posts page

This dashboard plugin slot is positioned at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-main-plugin1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `46035d51-2ea9-4128-a216-1dba68664ffe`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "46035d51-2ea9-4128-a216-1dba68664ffe",
  "description": "Blog Posts Dashboard Plugin",
  "title": "Blog Posts Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "blogPostsPlugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom of the slot.

## Dashboard menu plugin slots

The Posts page features 6 dashboard menu plugin slots.

### Slot 2: Published posts more actions menu

This dashboard menu plugin slot is located in the more actions menu for published posts in the Posts page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-published-more-actions1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `62eee170-31e0-4e71-b3ac-e357a9326a8c`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "62eee170-31e0-4e71-b3ac-e357a9326a8c",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedId` | String | ID of the post. |

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

### Slot 3: Published posts bulk actions more actions menu

This dashboard menu plugin slot is located in the published posts bulk actions more actions menu in the Posts page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-published-bulk-actions1.png)

> **Note:** The more actions button does not appear on the page if an app hasn't configured any menu plugins in this slot.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `8111d033-915a-48c5-89b3-1a55a8a35d01`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "8111d033-915a-48c5-89b3-1a55a8a35d01",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedIds` | Array | Array of the selected posts' IDs. |

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

### Slot 4: Draft posts more actions menu

This dashboard menu plugin slot is located in the more actions menu for draft posts in the Posts page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-drafts-more-actions1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `a1f0f711-0e09-42e3-977a-ad7270c56344`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "a1f0f711-0e09-42e3-977a-ad7270c56344",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedId` | String | ID of the post. |

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

### Slot 5: Draft posts bulk actions more actions menu

This dashboard menu plugin slot is located in the draft posts bulk actions more actions menu in the Posts page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-drafts-bulk-actions1.png)

> **Note:** The more actions button does not appear on the page if an app hasn't configured any menu plugins in this slot.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `cd44424e-ad9e-4b66-965c-7e2e29ef8352`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "cd44424e-ad9e-4b66-965c-7e2e29ef8352",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedIds` | Array | Array of the selected posts' IDs. |

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

### Slot 6: Scheduled posts more actions menu

This dashboard menu plugin slot is located in the more actions menu for scheduled posts in the Posts page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-scheduled-more-actions1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `1cefe952-7874-46ff-97ec-ebafef92ec38`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "1cefe952-7874-46ff-97ec-ebafef92ec38",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedId` | String | ID of the post. |

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

### Slot 7: Scheduled posts bulk actions more actions menu

This dashboard menu plugin slot is located in the scheduled posts bulk actions more actions menu in the Posts page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-posts-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-posts-scheduled-bulk-actions1.png)

> **Note:** The more actions button does not appear on the page if an app hasn't configured any menu plugins in this slot.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `83edea8a-a945-429d-b24b-3f109ae2b3e3`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "83edea8a-a945-429d-b24b-3f109ae2b3e3",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedIds` | Array | Array of the selected posts' IDs. |

#### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Blog APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/blog/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/blog/introduction)

## Slot IDs

| Slot | ID | Parameters |
| ---- | -- | ---------- |
| Posts page | `46035d51-2ea9-4128-a216-1dba68664ffe` | |
| Published posts more actions menu | `62eee170-31e0-4e71-b3ac-e357a9326a8c` | `selectedId` |
| Published posts bulk actions more actions menu | `8111d033-915a-48c5-89b3-1a55a8a35d01` | `selectedIds` |
| Draft posts more actions menu | `a1f0f711-0e09-42e3-977a-ad7270c56344` | `selectedId` |
| Draft posts bulk actions more actions menu | `cd44424e-ad9e-4b66-965c-7e2e29ef8352` | `selectedIds` |
| Scheduled posts more actions menu | `1cefe952-7874-46ff-97ec-ebafef92ec38` | `selectedId` |
| Scheduled posts bulk actions more actions menu | `83edea8a-a945-429d-b24b-3f109ae2b3e3` | `selectedIds` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
---
portal: build-apps
name: "Wix Blog: Tags Page"
type: ARTICLE_RESOURCE
resourceId: 1f59a7f2-1c22-4f1a-9aa2-455f0a6646fb
---

# Wix Blog: Tags Page

# Wix Blog: Tags Page

The Tags page has 3 plugin slots: 1 dashboard, and 2 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Blog > Tags

## Dashboard plugin slots

The Tags page features 1 dashboard plugin slot.

### Slot 1: Tags page

This dashboard plugin slot is positioned at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-tags-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-tags-main-plugin1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `0e336381-34a3-4f12-86f7-f98ab928f950`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "0a208a9f-3b45-449c-ba8e-13a842ea5b84",
  "description": "Blog Tags Dashboard Plugin",
  "title": "Blog Tags Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "blogTagsPlugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom of the slot.

## Dashboard menu plugin slots

The Tags page features 2 dashboard menu plugin slots.

### Slot 2: Tags more actions menu

This dashboard menu plugin slot is located in the more actions menu for tags in the Tags page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-tags-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-tags-more-actions1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `9f88f31c-9f0c-461c-86c4-6e8ee6b9c23d`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "9f88f31c-9f0c-461c-86c4-6e8ee6b9c23d",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedId` | String | ID of the tag. |

### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

### Slot 3: Tags bulk actions more actions menu

This dashboard menu plugin slot is located in the tags bulk actions' more actions menu in the Tags page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-blog-tags-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_blog-tags-bulk-actions1.png)

> **Note:** The more actions button does not appear on the page if an app hasn't configured any menu plugins in this slot.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `87d49224-cf15-46d1-b39e-e8987549471f`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "87d49224-cf15-46d1-b39e-e8987549471f",
  "title": "My Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "myMenuPlugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/92f106403e40d49da6f1afbc49dc165e9d57f2a2/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type | Description |
| ---- | ---- | ----------- |
| `selectedIds` | Array | Array of the selected tags' IDs. |

### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Blog APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/blog/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/blog/introduction)

## Slot IDs

| Slot | ID | Parameters |
| ---- | -- | ---------- |
| Tags page | `0e336381-34a3-4f12-86f7-f98ab928f950` | |
| Tags more actions menu | `9f88f31c-9f0c-461c-86c4-6e8ee6b9c23d` | `selectedId` |
| Tags bulk actions more actions menu | `87d49224-cf15-46d1-b39e-e8987549471f` | `selectedIds` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
---
portal: build-apps
name: "Wix Bookings: Booking List Page"
type: ARTICLE_RESOURCE
resourceId: f4a4d248-792d-42a1-9b7c-e06bcf4a3bd9
---

# Wix Bookings: Booking List Page

# Wix Bookings: Booking List Page
The Booking List page has 3 plugin slots: 1 dashboard, and 2 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in your [app's dashboard](https://dev.wix.com/apps).

## Location in Dashboard
Booking Calendar > Booking List

## Dashboard plugin slots
The Booking List page features a dashboard plugin slot. 

### Slot 1: Booking List page

The booking list page dashboard plugin slot is positioned at the top of the page. 

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-booking-list-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_bookings-list-dashboard-plugin.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard: 

**slot ID**: `0f756363-1659-4929-b4ef-5ff2c458eb7d`

For example:
```json
{
 "hostingPlatform": "BUSINESS_MANAGER",
 "extends": "0f756363-1659-4929-b4ef-5ff2c458eb7d",
 "description": "Dashboard Plugin on the Wix Bookings Booking List page.",
 "title": "Booking List Dashboard Plugin",
 "width": 300,
 "height": 400,
 "iframeUrl": "https://www.example.com",
 "componentName": "Booking List Widget Plugin"
}
```
<blockquote class="important">

__Important:__
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/266e954d34364d6dffae16b2ad69f08c02e30daa/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Multiple plugins in the same slot

This plugin slot can host multiple plugins. 

The plugins are displayed next to each other and ordered by date created, with the most recently created plugin displayed furthest left. 


## Dashboard menu plugin slots

The Booking List page features 2 dashboard menu plugin slots.

### Slot 2: Each booking's more actions menu

This dashboard menu plugin slot is located in each booking's more actions menu in the booking list.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-booking-list-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_bookings-list-dashboard-menu-plugin-1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `38fbe11f-6bc6-4df7-a742-e3e169a16cef`

For example:
```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "38fbe11f-6bc6-4df7-a742-e3e169a16cef",
  "description": "Dashboard Menu Plugin in Each Booking's More Actions Menu.",
  "title": "Bookings Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Bookings Dashboard Menu Plugin"
} 

```

<blockquote class="important">
   
   __Important:__
The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>


#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/266e954d34364d6dffae16b2ad69f08c02e30daa/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `bookingId` | String  | Booking ID.    |

### Slot 3: Bulk actions more actions menu

This dashboard menu plugin slot is located in the bulk actions more actions menu in the booking list. The bulk actions menu appears when at least 1 booking is selected.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-booking-list-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_bookings-list-dashboard-menu-plugin-2.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard: 

**slot ID**: `f1ab2ce9-a790-4e3e-a0f7-fae4da37a668`

For example:
```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "f1ab2ce9-a790-4e3e-a0f7-fae4da37a668",
  "description": "Dashboard Menu Plugin in the bulk actions menu on the Wix Bookings Booking List page.",
  "title": "Bookings Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Bulk Actions Bookings Dashboard Menu Plugin"
} 

```

<blockquote class="important">
   
   __Important:__
The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>


#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/266e954d34364d6dffae16b2ad69f08c02e30daa/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `selectedBookingIds` | [String]  | Selected booking IDs.    |

### Multiple plugins in the same slot

These menu plugin slots can host multiple plugins. 

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the top.

## Wix APIs
You can implement logic in your plugin using the Wix Bookings APIs:
- [SDK](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/bookings/about-wix-bookings)

## Slot IDs

| Slot | ID      | Parameters |
|---|----------------|---|
| Booking List page | `0f756363-1659-4929-b4ef-5ff2c458eb7d`  |
| Each Booking's more actions menu  | `38fbe11f-6bc6-4df7-a742-e3e169a16cef` | `bookingId` |
| Booking List bulk actions menu    |  `f1ab2ce9-a790-4e3e-a0f7-fae4da37a668` | `selectedBookingIds` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
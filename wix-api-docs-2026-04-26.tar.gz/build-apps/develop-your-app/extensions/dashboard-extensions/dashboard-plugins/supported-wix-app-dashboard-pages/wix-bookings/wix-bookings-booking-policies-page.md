---
portal: build-apps
name: "Wix Bookings: Booking Policies Page"
type: ARTICLE_RESOURCE
resourceId: 44b1324c-08ff-44ff-82d7-63bf4857339f
---

# Wix Bookings: Booking Policy Page

# Wix Bookings: Booking Policies Page

The Booking Policies page has 1 dashboard plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [app dashboard](https://dev.wix.com).

## Location in Dashboard

Settings > Booking Settings > Booking policies > Default policy

## Dashboard plugin slots

The Booking Policies page features 1 plugin slot.

### Slot: Staff assignment

This dashboard plugin slot is positioned at the bottom of the **Automatic staff assignment** section.

![Bookings policies slot](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f021709c1c610d985bd58f14373f4415.png)

#### Configuration

Use the following slot ID for the `extends` property when configuring your plugin in your app's dashboard:

**slot ID:** `9cec51b2-78a7-4270-ac1b-4152ff19a124`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "9cec51b2-78a7-4270-ac1b-4152ff19a124",
  "description": "Dashboard plugin on the Wix Bookings Policies Page.",
  "title": "Plugin Slot",
  "height": 300,
  "iframeUrl": "https://www.example.com/my-plugin",
  "componentName": "Slot"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/21aaea29ef53f90d1e41ae053da2898883795046/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name              | Type   | Description        |
| ----------------- | ------ | ------------------ |
| `policyId` | String | Policy ID. |


### Multiple dashboard plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.


## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
---
portal: build-apps
name: "Wix Bookings: Edit Staff Profile Page"
type: ARTICLE_RESOURCE
resourceId: a61ff7c9-4af8-44d2-ac61-af7ce8ec473f
---

# Wix Bookings: Edit Staff Profile Page

# Wix Bookings: Edit Staff Profile Page

The Bookings Edit Staff Profile page has 2 plugin slots: 1 dashboard, and 1 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in Dashboard

Settings > Booking Settings > Staff > Edit or Add staff member

## Dashboard plugin slots

The Bookings Edit Staff Profile page features a dashboard plugin slot.

### Slot 1: Edit staff profile page

This dashboard plugin slot is positioned at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-edit-staff-profile-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_edit-staff-profile-page-plugin.jpg)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `049fb0fe-cc4a-4e33-b0a9-d8cda8e7a79f`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "049fb0fe-cc4a-4e33-b0a9-d8cda8e7a79f",
  "description": "Dashboard Plugin on the Wix Bookings Staff Profile page.",
  "title": "Edit Staff Profile Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "Edit Staff Profile Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name              | Type   | Description        |
| ----------------- | ------ | ------------------ |
| `staffId`         | String | Staff ID.          |
| `staffResourceId` | String | Staff resource ID. |

### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the top of the page.

## Dashboard menu plugin slots

The Bookings Edit Staff Profile page features a dashboard menu plugin slot.

### Slot 2: Main more actions menu

This dashboard menu plugin slot is located in the more actions menu in the staff profile page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-edit-staff-profile-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_edit-staff-profile-page-menu-plugin.png)

> **Note:** The more actions button does not appear on the page if an app hasn't configured any menu plugins in this slot.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `ce533e85-9419-4c18-baf8-b3bb2423bcd1`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "ce533e85-9419-4c18-baf8-b3bb2423bcd1",
  "title": "Edit Staff Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Bookings Edit Staff Page Menu Plugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name              | Type   | Description        |
| ----------------- | ------ | ------------------ |
| `staffId`         | String | Staff ID.          |
| `staffResourceId` | String | Staff resource ID. |

### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Bookings APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/bookings/about-wix-bookings)

## Slot IDs

| Slot                    | ID                                     | Parameters                   |
| ----------------------- | -------------------------------------- | ---------------------------- |
| Edit Staff Profile Page | `049fb0fe-cc4a-4e33-b0a9-d8cda8e7a79f` | `staffId`, `staffResourceId` |
| Main more actions menu  | `ce533e85-9419-4c18-baf8-b3bb2423bcd1` | `staffId`, `staffResourceId` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
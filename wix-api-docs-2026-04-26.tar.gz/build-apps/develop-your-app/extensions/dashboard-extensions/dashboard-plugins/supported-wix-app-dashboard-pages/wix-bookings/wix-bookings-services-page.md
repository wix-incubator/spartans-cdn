---
portal: build-apps
name: "Wix Bookings: Services Page"
type: ARTICLE_RESOURCE
resourceId: 516cc117-074b-45b7-b78f-57702f2fd594
---

# Wix Bookings: Services Page

# Wix Bookings: Services Page

The Bookings Services page has 3 plugin slots: 1 dashboard, and 2 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in Dashboard

Catalog > Bookings Services

## Dashboard plugin slots

The Bookings Services page features a dashboard plugin slot.

### Slot 1: Services page

This slot is positioned between **Business setup recommendations** and **Service list**.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-services-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_services-dashboard-plugin.jpg)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `78cc4a47-8f47-489b-acc2-fd9e4208c8bd`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "78cc4a47-8f47-489b-acc2-fd9e4208c8bd",
  "description": "Dashboard Plugin on the Wix Bookings services page.",
  "title": "Services Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "Services Widget Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed next to each other and ordered by date created, with the most recently created plugin displayed furthest left.

## Dashboard menu plugin slots

The Bookings Services page features 2 dashboard menu plugin slots.

### Slot 2: Main more actions menu

This dashboard menu plugin slot is located in the main more actions menu on the Services page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-services-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_services-menu-plugin-1.jpg)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `5f8f3737-461a-43de-b790-e9079ba07d62`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "5f8f3737-461a-43de-b790-e9079ba07d62",
  "description": "Dashboard Menu Plugin in the Main More Actions Menu.",
  "title": "Services Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Services Main More Actions Dashboard Menu Plugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Slot 3: Each service's more actions menu

This dashboard menu plugin slot is located in each service's more actions menu in the service list.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-services-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_service-menu-plugin-2.jpg)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `70f397fb-0007-43df-99f3-b3b0a9fa0712`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "70f397fb-0007-43df-99f3-b3b0a9fa0712",
  "description": "Dashboard Menu Plugin in the Services Page.",
  "title": "Services Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Services Dashboard Menu Plugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name        | Type   | Description |
| ----------- | ------ | ----------- |
| `serviceId` | String | Service ID. |

### Multiple plugins in the same slot

These menu plugin slots can host multiple plugins.

The plugins are displayed next to each other and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Bookings APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/bookings/about-wix-bookings)

## Slot IDs

| Slot                             | ID                                     | Parameters  |
| -------------------------------- | -------------------------------------- | ----------- |
| Services page                    | `78cc4a47-8f47-489b-acc2-fd9e4208c8bd` |             |
| Each service's more actions menu | `5f8f3737-461a-43de-b790-e9079ba07d62` |             |
| Services list more actions menu  | `70f397fb-0007-43df-99f3-b3b0a9fa0712` | `serviceId` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
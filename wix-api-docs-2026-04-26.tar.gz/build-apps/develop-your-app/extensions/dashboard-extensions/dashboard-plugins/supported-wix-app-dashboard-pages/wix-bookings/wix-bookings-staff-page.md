---
portal: build-apps
name: "Wix Bookings: Staff Page"
type: ARTICLE_RESOURCE
resourceId: 0c849ebc-028e-4ea0-93aa-fbd564809608
---

# Wix Bookings: Staff Page

# Wix Bookings: Staff Page

The Bookings Staff page has 3 plugin slots: 1 dashboard, and 2 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com).

## Location in Dashboard

Settings > Booking Settings > Staff

## Dashboard plugin slots

The Bookings Staff dashboard page features a plugin slot positioned at the top of the page.

### Slot 1: Staff page

![Bookings staff slot](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-staff-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_bookings-staff-slot.png)

#### Configuration

Use the following slot ID for the `extends` property when configuring your plugin in your app's dashboard:

**slot ID:** `261e84a2-31d0-4258-a035-10544d251108`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "261e84a2-31d0-4258-a035-10544d251108",
  "description": "Dashboard plugin on the Wix Bookings Staff Page.",
  "title": "Plugin Slot",
  "height": 300,
  "iframeUrl": "https://www.example.com/my-plugin",
  "componentName": "Slot"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name              | Type   | Description        |
| ----------------- | ------ | ------------------ |
| `staffResourceId` | String | Staff resource ID. |
| `scheduleId`      | String | Schedule ID.       |
| `timezone`        | String | Time zone.         |

### Multiple dashboard plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the top.

## Dashboard menu plugin slots

The Bookings Staff page features 2 dashboard menu plugin slots.

### Slot 2: Main more actions menu

This dashboard menu plugin slot is located in the main more actions menu on the Staff page.

![main menu slot](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-staff-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_staff-page-menu-plugin-1.jpg)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID:** `3ad7e6d2-35ce-45c1-ab59-64c51b60a104`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "3ad7e6d2-35ce-45c1-ab59-64c51b60a104",
  "title": "Staff Main More Actions Menu Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Staff More Actions Dashboard Menu Plugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Slot 3: Each staff member's more actions menu

This dashboard menu plugin slot is located in each staff member's more actions menu in the staff list.

![staff menu slot](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-bookings-staff-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_staff-page-menu-plugin-2.jpg)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID:** `884a208a-7c23-4641-856a-d6561ed4c64b`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "884a208a-7c23-4641-856a-d6561ed4c64b",
  "title": "Staff Plugin",
  "iconKey": "Smile",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "My Staff Dashboard Menu Plugin"
}
```

<blockquote class="important">
   
   __Important:__
   The hosting platform must be "BUSINESS_MANAGER".
   
   </blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name              | Type   | Description        |
| ----------------- | ------ | ------------------ |
| `staffId`         | String | Staff ID.          |
| `staffResourceId` | String | Staff resource ID. |

### Multiple menu plugins in the same slot

These plugin slots can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs

You can implement logic in your plugin using the Wix Bookings APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/bookings/about-wix-bookings)

## Slot IDs

| Slot                                  | ID                                     | Parameters                                  |
| ------------------------------------- | -------------------------------------- | ------------------------------------------- |
| Staff page                            | `261e84a2-31d0-4258-a035-10544d251108` | `staffResourceId`, `scheduleId`, `timezone` |
| Main more actions menu                | `3ad7e6d2-35ce-45c1-ab59-64c51b60a104` |                                             |
| Each staff member's more actions menu | `884a208a-7c23-4641-856a-d6561ed4c64b` | `staffId`, `staffResourceId`                |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
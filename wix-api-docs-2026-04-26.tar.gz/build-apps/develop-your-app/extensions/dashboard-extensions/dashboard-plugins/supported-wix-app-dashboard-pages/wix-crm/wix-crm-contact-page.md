---
portal: build-apps
name: "Wix CRM: Contact Page"
type: ARTICLE_RESOURCE
resourceId: 02e36d2d-1aa9-474b-9b6f-c6dd7dfffbe3
---

# Wix CRM: Contact Page

# Wix CRM: Contact Page
The Wix CRM contact page has a dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in Dashboard
Customers & Leads > Contacts (hover over a contact) > select **View**  

## Dashboard menu plugin slots

The Wix CRM contact page features a dashboard menu plugin slot. 

### Slot: More Actions menu

This slot is located in the **More Actions** menu in each contact's page. 

From the Contacts page, hover over a contact and select **View** to access the corresponding contact page. The **More Actions** menu is located at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-crm-contact-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_contact-page-dashboard-menu-plugin.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `79963a99-8680-4164-8961-8867fcb1751a`


For example:
```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "79963a99-8680-4164-8961-8867fcb1751a",
  "title": "Contact Workflows",
  "iconKey": "Webhook",
  "action": {
    "navigateToPage": {
      "pageId": "511fe7f0-d0fe-4acb-84bc-b9887e4c92b7"
    }
  },
  "componentName": "Contact page More Actions menu plugin"
}
```

<blockquote class="important">

__Important:__
+ The hosting platform must be "BUSINESS_MANAGER".  
+ This slot must include an [icon](https://www.wix-pages.com/wix-design-system-employees/?path=/story/foundations-icons--icons) to comply with Wix's style requirements. Provide the icon's name as the value for `"iconKey"`. 

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/8326666b43c2a136bf66d097bac4fb423771e420/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `contactId` | String  | Contact ID.    |


### Multiple dashboard menu plugins in the same slot

This menu plugin slot can host multiple plugins. 

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Wix APIs
You can implement logic in your plugin using the Wix CRM Contacts APIs:
- [SDK](https://dev.wix.com/docs/sdk/backend-modules/crm/contacts/introduction)
- [REST](https://dev.wix.com/docs/rest/crm/members-contacts/contacts/introduction)

## Slot IDs

| Slot | ID      | Parameters |
|---|----------------|---|
| More Actions menu |  `79963a99-8680-4164-8961-8867fcb1751a` | `contactId` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
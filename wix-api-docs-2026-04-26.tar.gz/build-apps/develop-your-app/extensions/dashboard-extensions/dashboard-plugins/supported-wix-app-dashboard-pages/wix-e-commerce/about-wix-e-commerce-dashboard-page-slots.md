---
portal: build-apps
name: "About Wix eCommerce Dashboard Page Slots"
type: ARTICLE_RESOURCE
resourceId: ccbc9804-bcbb-4951-8188-28ea3c152276
---

# About Wix eCommerce Dashboard Page Slots

# About Wix eCommerce Dashboard Page Slots

Wix eCommerce provides both dashboard and dashboard menu plugin slots. These slots are available on Wix eCommerce dashboard pages, such as the Order Page, which supports orders from Wix Stores, Wix Bookings, and other [Wix Business Solutions](https://support.wix.com/en/business-solutions-apps). Additionally, specific Wix eCommerce slots can be found on other Wix Business Solutions dashboard pages, such as the Wix Bookings Calendar page.

Below are all Wix eCommerce slots, including their IDs and locations: 

| Wix eCommcerce Slot         | Slot ID     | Locations    |
| :-------------------------- | ----------- | -------------| 
| Order Page plugin slot      | `cb16162e-42aa-41bd-a644-dc570328c6cc`| **Wix eCommerce:** <ul><li>[Order Page](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboad-pages/wix-ecom-order-page.md*original::./wix-ecom-order-page.md)</li></ul> |
| Pre-collect payment modal plugin slot      |`b92f0e25-535f-4bef-b130-8e5abc85b2fe`| **Wix eCommerce:** <ul><li>[Order Page](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboad-pages/wix-ecom-order-page.md*original::./wix-ecom-order-page.md)</li></ul> **Wix Bookings:** <ul><li>[Calendar Page](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboad-pages/wix-bookings-calendar-page.md#slot-ids*original::./wix-bookings-calendar-page.md#slot-ids)</li></ul> |
| Collect payment button menu plugin slot      |`bb4aa225-86d8-47fe-87d1-f519b1b93473`| **Wix eCommerce:** <ul><li>[Order Page](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboad-pages/wix-ecom-order-page.md*original::./wix-ecom-order-page.md)</li></ul> **Wix Bookings:** <ul><li>[Calendar Page](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboad-pages/wix-bookings-calendar-page.md#slot-ids*original::./wix-bookings-calendar-page.md#slot-ids)</li></ul> |
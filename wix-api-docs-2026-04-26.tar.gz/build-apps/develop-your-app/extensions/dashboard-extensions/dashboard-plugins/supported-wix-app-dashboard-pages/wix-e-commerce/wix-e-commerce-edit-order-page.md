---
portal: build-apps
name: "Wix eCommerce: Edit Order Page"
type: ARTICLE_RESOURCE
resourceId: b860fca4-39af-40c4-85f2-f4649ae73f8b
---

# Wix eCommerce: Edit Order Page

# Wix eCommerce: Edit Order Page
The eCommerce Edit Order page has a dashboard plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard
Sales > Orders > Order > More Actions > Edit Order

To test your plugin on a site, do the following:

1. Install any Wix app that integrates with the Wix eCommerce platform. For example, Wix Stores.
2. Add a new order manually, or let a customer generate the order (for example, by purchasing a product).
3. Click on the order, and then click **More Actions > Edit order** in the top right corner of the page.

## Dashboard plugin slots

The eCommerce Edit Order page features a dashboard plugin slot. 

### Slot: Additional Fees

This dashboard plugin slot is located on the right side of the page, in the Order summary card.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/696942d7f6bb0147ac680a674695f1df.png)


#### Sample use case

Add a plugin that enables site owners to manage custom fees for orders. By integrating with this plugin, your app can provide merchants with the ability to add or remove order fees according to your custom logic and functionality.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard: 

**slot ID**: `057f1726-f0b3-40ef-8903-1bd104e18369`

For example:
```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "057f1726-f0b3-40ef-8903-1bd104e18369",
  "description": "Dashboard Plugin on the eCommerce Edit Order page.",
  "title": "Edit Order Page Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "Edit Order Page Plugin"
}

```
<blockquote class="important">

  __Important:__
  The hosting platform must be "BUSINESS_MANAGER".

</blockquote>


#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/3440a9d3fa10e4d2d7f97f3bc588c967aa58d197/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `draftOrderId` | String  | ID of the order that is being edited.     |
| `onDraftOrderUpdate()` | `()=>Promise<void>`  | Callback that notifies the host page about a draft order update, prompting a UI refresh. It returns a promise indicating when the UI update on the host page is complete.    |


### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Slot IDs

| Slot | ID      | Parameters       |
|---|----------------|---|
| Edit Order page | `057f1726-f0b3-40ef-8903-1bd104e18369`  |  `draftOrderId`, `onDraftOrderUpdate` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
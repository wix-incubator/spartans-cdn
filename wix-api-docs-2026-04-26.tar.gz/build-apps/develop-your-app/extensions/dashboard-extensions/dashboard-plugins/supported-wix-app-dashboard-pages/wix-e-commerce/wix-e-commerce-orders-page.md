---
portal: build-apps
name: "Wix eCommerce: Orders Page"
type: ARTICLE_RESOURCE
resourceId: e25ddeb8-679d-4812-8010-f804589f944f
---

# Wix eCommerce: Orders Page

# Wix eCommerce: Orders List Page
The eCommerce Orders List page has a dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard
Sales > Orders 

To test your plugin on a site, do the following:

+ Install any Wix app that integrates with the Wix eCommerce platform. For example, Wix Stores.
+ Add a new order manually, or let a customer generate the order (for example, by purchasing a product).
+ Click on the order, and then click **More Actions** in the bulk actions toolbar that appears above the orders list.

## Dashboard menu plugin slots

The eCommerce Orders List page features a dashboard menu plugin slot. 

### Slot: Bulk action toolbar's More Actions menu 

This dashboard menu plugin slot is located in the **More Actions** menu of the bulk actions toolbar. The bulk action toolbar appears when at least 1 product is selected.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-ecom-orders-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_ecom-orders-bulk-actions-more-actions.png)

#### Sample use case

Add a menu item that enables site owners to manage custom fees for orders. This can provide merchants with the ability to add or remove order fees according to your custom logic.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard: 

**slot ID**: `3172f3e2-236f-41db-84ca-a744e5edfcd9`

For example:
```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "3172f3e2-236f-41db-84ca-a744e5edfcd9",
  "description": "Orders list dashboard menu plugin in the bulk actions toolbar More Actions menu.",
  "title": "Orders List Bulk Action Toolbar More Actions Dashboard Menu Plugin",
  "iconKey": "Order",
  "action": {
    "navigateToPage": {
      "pageId": "99bc7dcb-312d-4462-9ff6-ca764606cfbb"
    }
  },
  "componentName": "Bulk Actions More Actions"
}

```
<blockquote class="important">

__Important:__
+ The hosting platform must be "BUSINESS_MANAGER".  
+ Each slot must include an [icon](https://www.wix-pages.com/wix-design-system-employees/?path=/story/foundations-icons--icons) to comply with Wix's style requirements. Provide the icon's name as the value for `"iconKey"`. 

</blockquote>


#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/a045b155f3f1f0db90cdd2b2c1d5396f9d381778/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

Name | Type       | Description
-|------------|-
`selectedIds` | `string[]` | An array of IDs representing the orders that have been selected.
`uncheckedIds` | `string[]` | An array of IDs representing the orders that have been unchecked. Applicable only when the "Select All" option was selected.
`isSelectAll` | `boolean`  | A boolean value indicating whether the "Select All" option was selected.
`total` | `number`  | The total number of orders that were selected.
`onSuccess()` | `()=>Promise<void>`  | Callback that notifies the host after successful handling of the flow associated with the new menu item.

### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.

## Slot IDs

| Slot | ID      | Parameters       |
|---|----------------|---|
| Bulk action toolbar's More Actions menu | `3172f3e2-236f-41db-84ca-a744e5edfcd9`  | `selectedIds`, `uncheckedIds`, `isSelectAll`, `total`, `onSuccess()` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
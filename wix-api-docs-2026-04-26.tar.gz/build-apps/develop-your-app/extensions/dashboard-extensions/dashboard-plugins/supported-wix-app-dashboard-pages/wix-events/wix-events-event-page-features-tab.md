---
portal: build-apps
name: "Wix Events: Event Page Features Tab"
type: ARTICLE_RESOURCE
resourceId: d46e07b7-1c47-4c7d-bbca-7661d6eddcd6
---

# Wix Events: Event Page Features Tab

# Wix Events: Event Page Features Tab

The Event page's Features tab has a dashboard plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Events > Published or Drafts > Event > Features tab

To test your plugin on a site, do the following:

1. Install the Wix Events app from the App Market.
2. Add a ticketed or RSVP event.
3. Create a draft of the event, or publish the event.

## Dashboard plugin slots

The Event page's Features tab features a dashboard plugin slot.

### Slot: Features tab page

This dashboard menu plugin slot is located in the features grid.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-events-event-features-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_events-features_6_dp.png)

#### Sample use case

Add a plugin to the Event page's Features tab that allows the site owner to add an FAQ section to the event details.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `5566727b-e5a2-4a43-a26d-961aa4fe0898`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "5566727b-e5a2-4a43-a26d-961aa4fe0898",
  "description": "Dashboard Plugin on the Event page's Features tab.",
  "title": "Event Features tab Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "Features Widget Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name      | Type   | Description |
| --------- | ------ | ----------- |
| `eventId` | String | Event ID.   |

### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed as the last items in the grid. They are shown in cards positioned next to each other and are ordered by date created, with the most recently created plugin displayed at the top.

## Wix APIs

You can implement logic in your plugin using the Wix Events APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/events/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/events/events-v3/introduction)

## Slot IDs

| Slot                      | ID                                     | Parameters |
| ------------------------- | -------------------------------------- | ---------- |
| Event page's Features tab | `5566727b-e5a2-4a43-a26d-961aa4fe0898` | `eventId`  |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
---
portal: build-apps
name: "Wix Events: Event Page Overview Tab"
type: ARTICLE_RESOURCE
resourceId: 7c75455c-17dd-4c84-99fa-49dee35e7de9
---

# Wix Events: Event Page Overview Tab

# Wix Events: Event Page Overview Tab
The Event page's Overview tab has a dashboard plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard
Events > Published or Drafts > Event > Overview tab

To test your plugin on a site, do the following:

1. Install the Wix Events app from the App Market.
2. Add a ticketed or RSVP event. 
3. Create a draft of the event, or publish the event.

## Dashboard plugin slots
The Event page's Overview tab features a dashboard plugin slot.

### Slot: Overview tab page

This dashboard plugin slot is located at the bottom of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-events-event-overview-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_events-overview_2_dp.png)

#### Sample use case

Add a plugin to the Event page's Overview tab that displays earnings for each ticket type so the site owner can easily compare them. 

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard: 

**slot ID**: `d2c6965a-7d50-47a0-881a-beb184135df3`

For example:
```json
{
 "hostingPlatform": "BUSINESS_MANAGER",
 "extends": "d2c6965a-7d50-47a0-881a-beb184135df3",
 "description": "Dashboard Plugin on the Event page's Overview tab.",
 "title": "Event Overview tab Dashboard Plugin",
 "width": 300,
 "height": 400,
 "iframeUrl": "https://www.example.com",
 "componentName": "Overview Widget Plugin"
}
```
<blockquote class="important">

  __Important:__
  The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/8326666b43c2a136bf66d097bac4fb423771e420/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `eventId` | String  | Event ID.    |


### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed at the bottom of the page and ordered by date created, with the most recently created plugin displayed at the top.

## Wix APIs
You can implement logic in your plugin using the Wix Events APIs:
- [SDK](https://dev.wix.com/docs/sdk/backend-modules/events/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/events/events-v3/introduction)


## Slot IDs

| Slot | ID      | Parameters       |
|---|----------------|---|
| Event page's Overview tab | `d2c6965a-7d50-47a0-881a-beb184135df3`  |  `eventId` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
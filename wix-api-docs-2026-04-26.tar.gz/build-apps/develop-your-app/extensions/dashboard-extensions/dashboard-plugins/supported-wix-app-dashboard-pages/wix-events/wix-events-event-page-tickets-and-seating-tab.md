---
portal: build-apps
name: "Wix Events: Event Page Tickets and Seating Tab"
type: ARTICLE_RESOURCE
resourceId: 03628bda-2b23-48dc-8b3a-3386b3f8d629
---

# Wix Events: Event Page Tickets and Seating Tab

# Wix Events: Event Page Tickets and Seating Tab

The Event page's Tickets and Seating tab has a dashboard plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Events > Published or Drafts > Event > Tickets and Seating tab

To test your plugin on a site, do the following:

1. Install the Wix Events app from the App Market.
2. Add a ticketed event.
3. Create a draft of the event, or publish the event.

## Dashboard plugin slots

The Event page's Tickets and Seating tab features a dashboard plugin slot.

### Slot: Tickets and seating tab page

This dashboard plugin slot is located on the right side of the page below **Settings and discounts**.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-events-event-tickets-seating-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_events-tickets-and-seating_3_dp.png)

#### Sample use case

Add a ticket sales scheduler plugin to the Event page's Tickets and Seating tab to allow the site owner to review the current ticket sale status, and set up start and end dates for all ticket sales in one place.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `80b95e22-26db-4063-a31f-76d4bb8797ba`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "80b95e22-26db-4063-a31f-76d4bb8797ba",
  "description": "Dashboard Plugin on the Event page's Tickets and Seating tab.",
  "title": "Event Tickets and Seating tab Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "Tickets and Seating Widget Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name      | Type   | Description |
| --------- | ------ | ----------- |
| `eventId` | String | Event ID.   |

### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed by date created, with the most recently created plugin displayed at the top.

## Wix APIs

You can implement logic in your plugin using the Wix Events APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/events/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/events/events-v3/introduction)

## Slot IDs

| Slot                                 | ID                                     | Parameters |
| ------------------------------------ | -------------------------------------- | ---------- |
| Event page's Tickets and Seating tab | `80b95e22-26db-4063-a31f-76d4bb8797ba` | `eventId`  |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
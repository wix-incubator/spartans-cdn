---
portal: build-apps
name: "Wix Events: Event Page (Tickets) Guests Tab"
type: ARTICLE_RESOURCE
resourceId: 13a3ab7c-71cd-4d97-8f6e-922c27875357
---

# Wix Events: Event Page (Tickets) Guests Tab

# Wix Events: Ticketed Event Page Guests Tab 
The RSVP Event page's Guests tab has a dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard
Events > Published > Event (ticketed event) > Guests tab

To test your plugin on a site, do the following:

1. Install the Wix Events app from the App Market.
2. Add a ticketed event.
3. Publish the event.
4. Add a guest to the event manually, or create an invitation to the event and have guests sign up for the event.

## Dashboard menu plugin slots

The Ticketed Event page's Guests tab features a dashboard menu plugin slot. 

### Slot: More actions menu

This dashboard menu plugin slot is located in the more actions menu in the Guests tab.

  ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-events-event-guests-tickets-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_events-guests-tickets_8_dmp.png)

  #### Sample use case

  Add a menu item that allows site owners to send an sms notification to selected guests.

  #### Configuration

  Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard: 

  **slot ID**: `b9f7d36e-4035-4079-8781-4f78b4bec183`

  For example:
  ```json
  {
    "hostingPlatform": "BUSINESS_MANAGER",
    "extends": "b9f7d36e-4035-4079-8781-4f78b4bec183",
    "description": "Dashboard Menu Plugin on the Wix Bookings guests page.",
    "title": "Ticketed Guests Menu Plugin",
    "action": {
      "navigateToPage": {
        "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
        "relativeUrl": "?home"
      }
    },
    "componentName": "My Ticketed Guests Dashboard Menu Plugin"
  } 

  ```
<blockquote class="important">

  __Important:__
  The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/ade22eda9affa6d42b702ef57e44fe6a0b09aa46/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `ticketNumber` | String  | Ticket Number.    |


### Multiple plugins in the same slot 

This menu plugin slot can host multiple plugins. 

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the top.

## Wix APIs
You can implement logic in your plugin using the Wix Events APIs:
- [SDK](https://dev.wix.com/docs/sdk/backend-modules/events/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/events/events-v3/introduction)


## Slot IDs

| Slot | ID      | Parameters       |
|---|----------------|---|
| More actions menu |  `b9f7d36e-4035-4079-8781-4f78b4bec183` | `ticketNumber` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
---
portal: build-apps
name: "Wix Events: Published or Drafts Page"
type: ARTICLE_RESOURCE
resourceId: c23ca717-0543-438c-bb7c-2f4c59518b5f
---

# Wix Events: Published or Drafts Page

# Wix Events: Published or Drafts Page
The Events Published page and the Drafts page each have a dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard
Events > Published or Drafts 

To test your plugin on a site, do the following:

1. Install the Wix Events app from the App Market.
2. Add a ticketed or RSVP event. 
3. Create a draft of the event, or publish the event.

## Dashboard menu plugin slots

The Events Published page and the Drafts page each feature a dashboard menu plugin slot. 

### Slot: More actions menu

This dashboard menu plugin slot is located in the more actions menu on the Published or Drafts page. 

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-events-event-published-or-drafts-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_events-published_7_dmp.png)


#### Sample use case

Add a menu item that allows the site owner to apply bulk actions on selected events. For example, the site owner can add custom questions to the event registration forms of specific events. 

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard: 

**slot ID**: `190f00be-4e0f-4463-a3a6-f1cfee681bca`

For example:
```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "190f00be-4e0f-4463-a3a6-f1cfee681bca",
  "description": "Dashboard Menu Plugin on the Events Published page or the Drafts page.",
  "title": "Events Published page or the Drafts page Dashboard Menu Plugin",
  "action": {
    "navigateToPage": {
      "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "relativeUrl": "?home"
    }
  },
  "componentName": "Events Published page or the Drafts page Dashboard Menu Plugin"
}

```
<blockquote class="important">

  __Important:__
  The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/6e48e0586e3722162327dd244bb5721818b02d78/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type      | Description       |
|------|-----------|-------------------|
| `eventId` | String  | Event ID.    |


### Multiple plugins in the same slot

This menu plugin slot can host multiple plugins. 

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the top.

## Wix APIs
You can implement logic in your plugin using the Wix Events APIs:
- [SDK](https://dev.wix.com/docs/sdk/backend-modules/events/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/events/events-v3/introduction)


## Slot IDs

| Slot | ID      | Parameters       |
|---|----------------|---|
| Event page's published or draft menu | `190f00be-4e0f-4463-a3a6-f1cfee681bca`  |  `eventId` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)
---
portal: build-apps
name: "Wix Restaurants: Online Orders Page"
type: ARTICLE_RESOURCE
resourceId: dddb38db-64dc-4110-bc0b-07284adae39b
---

# Wix Restaurants: Online Orders Page

<!-- You need to add your new pages (and their slots) to [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) and write a [release note](https://dev.wix.com/docs/build-apps/get-started/what-s-new/build-apps-release-notes). -->


# Wix Restaurants: Online Orders Page

The Online Orders page has 1 dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [app dashboard](https://manage.wix.com/account/custom-apps).

## Location in dashboard

Sales > Restaurant Orders (New)
    




        
## Dashboard menu plugin slots

The Online Orders page features 1 dashboard menu plugin slot.


   
### Slot 1: Order card more actions menu 

This dashboard menu plugin slot is positioned in the more actions menu at the bottom of each order's card.
    
<!-- ADD YOUR IMAGE HERE -->
![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/712348cb9cc48d8766a96ae562269803.png)


    
#### Configuration
    
Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:
    
**slot ID**: `d6b9230e-7388-4b5a-bb50-86afe3e344b2`
    
For example:
    
```json
{
    "hostingPlatform": "BUSINESS_MANAGER",
    "extends": "d6b9230e-7388-4b5a-bb50-86afe3e344b2",
    "title": "Orders Menu Plugin",
    "iconKey": "Smile",
    "action": {
      "navigateToPage": {
        "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
        "relativeUrl": "?home"
      }
    },
    "componentName": "My Orders Dashboard Menu Plugin"
  }
```
    
<blockquote class="important">
    
**Important:**
The hosting platform must be "BUSINESS_MANAGER".
    
</blockquote>
    

#### Interaction between the dashboard page and your plugin
    
Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#slots-and-plugin-apis).
    
This slot passes the following parameters:
    
| Name | Type | Description |
| ---- | ---- | ----------- |
| `orderId` | string | Order ID. |
    

    

#### Multiple plugins in the same slot
    
This plugin slot can host multiple plugins.
    
The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.


    
        


    
## Wix APIs

You can implement logic in your plugin using the [eCommerce Orders API](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/orders/introduction).
    


    
## Slot IDs

| Slot | ID | Parameters |
| ---- | -- | ---------- |
| Order card more actions menu | `d6b9230e-7388-4b5a-bb50-86afe3e344b2` | `orderId` |
    


    
## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
---
portal: build-apps
name: "Wix Restaurants: Restaurant Menus Page"
type: ARTICLE_RESOURCE
resourceId: 387c8ce0-4b2f-4389-a6ce-bc4d88072cb5
---

# Wix Restaurants: Restaurant Menus Page

<!-- You need to add your new pages (and their slots) to [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) and write a [release note](https://dev.wix.com/docs/build-apps/get-started/what-s-new/build-apps-release-notes). -->


# Wix Restaurants: Restaurant Menus Page

The Restaurant Menus page has 1 dashboard menu plugin slot. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Catalog > Restaurant Menus (New)
    




        
## Dashboard menu plugin slots

The Restaurant Menus page features 1 dashboard menu plugin slot.


   
### Slot 1: Menus main more actions menu 

This dashboard menu plugin slot is positioned in the more actions menu at the top of the page.
    
![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/8e3918c6023fcb12c301a61d795e6f50.png)


    
#### Configuration
    
Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:
    
**slot ID**: `e2a7ffb0-5e9c-4eda-bc0c-14724ff3e407`
    
For example:
    
```json
{
    "hostingPlatform": "BUSINESS_MANAGER",
    "extends": "e2a7ffb0-5e9c-4eda-bc0c-14724ff3e407",
    "title": "Restaurant Menus dashboard menu plugin",
    "iconKey": "Smile",
    "action": {
      "navigateToPage": {
        "pageId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
        "relativeUrl": "?home"
      }
    },
    "componentName": "My menu plugin for the Restaurant Menus page"
  }
```
    
<blockquote class="important">
    
**Important:**
The hosting platform must be "BUSINESS_MANAGER".
    
</blockquote>
    

    

#### Multiple plugins in the same slot
    
This plugin slot can host multiple plugins.
    
The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the bottom.


    
        


    
## Wix APIs

You can implement logic in your plugin using the Wix Restaurants APIs:
    
- [SDK](https://dev.wix.com/docs/sdk/backend-modules/restaurants/wix-restaurants-new/menus/menus/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/restaurants/wix-restaurants-new/menus/menus/introduction)
    


    
## Slot IDs

| Slot | ID | Parameters |
| ---- | -- | ---------- |
| Menus main more actions menu | `e2a7ffb0-5e9c-4eda-bc0c-14724ff3e407` |  |
    


    
## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
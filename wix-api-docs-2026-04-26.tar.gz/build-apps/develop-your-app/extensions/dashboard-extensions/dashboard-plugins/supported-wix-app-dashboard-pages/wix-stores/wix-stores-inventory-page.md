---
portal: build-apps
name: "Wix Stores: Inventory Page"
type: ARTICLE_RESOURCE
resourceId: 1671ed12-d7e2-4767-8aea-928dc11eaae3
---

# Wix Stores: Inventory Page

# Wix Stores: Inventory Page

The Inventory page has 4 plugin slots: 1 dashboard, and 3 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. When configuring the plugin in the [App Dashboard](https://dev.wix.com/apps), use the slot ID as the value for the required `extends` field.

## Location in Dashboard

Catalog > Store Products > Inventory

## Dashboard plugin slots

The Stores Inventory page features 1 dashboard plugin slot.

### Slot 1: Inventory page

The inventory page dashboard plugin slot is positioned above the inventory list.

![Inventory page slot](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-catalog-inventory-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_wix-stores-inventory-dashboard-plugin-1.png)

#### Sample use case

Add a plugin to the Inventory page that sums the total number of available items in each product category.

#### Configuration

When configuring the dashboard plugin in your app's dashboard, use the following slot ID for the `extends` property:

**slot ID**: `c9b19070-3e25-4f3d-9d27-4e0f74164835`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "c9b19070-3e25-4f3d-9d27-4e0f74164835",
  "description": "Dashboard Plugin on the Inventory page.",
  "title": "Inventory Page Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com",
  "componentName": "Inventory Page Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be `BUSINESS_MANAGER`.

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data from built-in dashboard page slots to your plugin. Learn how to use [the Wix SDK](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#slots-and-plugin-apis) to interact with and retrieve data from the dashboard.

#### Multiple plugins in the same slot

This plugin slot can host multiple plugins.

Dashboard plugins added to this slot are displayed horizontally by creation date, with the newest plugin displayed furthest left.

## Dashboard menu plugin slots

The Inventory page features 3 dashboard menu plugin slots.

### Slot 2: Inventory item menu action

This dashboard menu plugin slot is located in each inventory item's more actions menu:

![Inventory item menu action](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-catalog-inventory-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_wix-stores-inventory-dashboard-plugin-2b.png)

#### Sample use case

Add a plugin to the more actions menu that opens a modal with a product quick view.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `1b9742f8-2b93-4e66-85f2-47289bf548bb`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "1b9742f8-2b93-4e66-85f2-47289bf548bb",
  "description": "Inventory Item Menu Action Plugin.",
  "title": "Show Quick View",
  "action": {
    "openModal": {
      "componentId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "componentParams": {}
    }
  },
  "componentName": "My Show Product Quick View Item Menu Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be `BUSINESS_MANAGER`.

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#slots-and-plugin-apis).

This slot passes the following parameters:

| Name         | Type   | Description                                                                                                                                     |
| ------------ | ------ | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `selectedId` | string | When the item is the default product version, the value is `${productId}`. When the item is a variant, the value is `${productId}_${variantId}` |

#### Multiple dashboard plugins in the same slot

This plugin slot can host multiple plugins.

Dashboard menu plugins added to this slot are displayed vertically by creation date, with the latest plugin added at the bottom.

### Slot 3: Global more actions menu

This dashboard menu plugin slot is located in the global more actions menu at the top of the page. It can contain action items that perform actions on the entire page, all products, all variants, or any combination of items.

> **Note:** The global more actions menu is only visible when at least one plugin is added to its built-in slot.

![Global More actions menu](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-catalog-inventory-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_wix-stores-inventory-dashboard-plugin-3.png)

#### Sample use case

Add a plugin that allows users to export their inventory items to a CSV file.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `b9e4104f-9beb-4258-8bdb-6a34d6bf7fd0`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "b9e4104f-9beb-4258-8bdb-6a34d6bf7fd0",
  "description": "Global More Actions Plugin",
  "title": "Export Inventory",
  "action": {
    "openModal": {
      "componentId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "componentParams": {}
    }
  },
  "componentName": "My Export Inventory Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be `BUSINESS_MANAGER`.

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data from built-in dashboard page slots to your plugin. Learn how to use [the Wix SDK](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#slots-and-plugin-apis) to interact with and retrieve data from the dashboard.

#### Multiple dashboard plugins in the same slot

This plugin slot can host multiple plugins.

Dashboard plugins added to this slot are displayed vertically by creation date, with the latest plugin on top.

### Slot 4: Bulk more actions menu

This dashboard menu plugin slot is located in the more actions menu of the bulk actions toolbar. It can contain items that perform bulk actions on all selected items.

> **Note:** The bulk action toolbar appears when at least 1 product is selected. Its more actions menu appears when at least 1 plugin is added to its built-in slot.

![Bulk more actions menu](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-catalog-inventory-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_wix-stores-inventory-dashboard-plugin-4.png)

#### Sample use case

Add a plugin that allows users to perform bulk actions on all selected items, such as syncing the Wix Stores inventory with an external inventory.

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `b9f2ad03-7407-48d9-9e89-fe2f2df63e8a`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "b9f2ad03-7407-48d9-9e89-fe2f2df63e8a",
  "description": "Bulk More Actions Plugin",
  "title": "Bulk Sync Inventory",
  "action": {
    "openModal": {
      "componentId": "36bceb0e-5ac3-4b12-a40d-df0bf5e8dc89",
      "componentParams": {}
    }
  },
  "componentName": "My Bulk Sync Inventory Plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be `BUSINESS_MANAGER`.

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions#slots-and-plugin-apis).

This slot passes the following parameters:

| Name           | Type             | Description                                                                           |
| -------------- | ---------------- | ------------------------------------------------------------------------------------- |
| `selectedIds`  | array of strings | Array of IDs of selected items.                                                       |
| `allSelected`  | boolean          | Whether the **Select All** checkbox was selected.                                     |
| `uncheckedIds` | array of strings | When `allSelected` is `true`, an array of IDs of items that were manually deselected. |
| `total`        | number           | Total number of selected items.                                                       |

#### Multiple dashboard plugins in the same slot

This plugin slot can host multiple plugins.

Dashboard plugins added to this slot are displayed vertically by creation date, with the latest plugin on top.

## Wix APIs

You can implement logic in your plugin using the Wix Stores APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/stores/products/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/stores/about-wix-stores)

## Slot IDs

| Slot                                      | ID                                     | Parameters                                            |
| ----------------------------------------- | -------------------------------------- | ----------------------------------------------------- |
| Inventory page plugin                     | `c9b19070-3e25-4f3d-9d27-4e0f74164835` |                                                       |
| Inventory item menu action                | `1b9742f8-2b93-4e66-85f2-47289bf548bb` | `selectedId`                                          |
| Global more actions menu slot             | `b9e4104f-9beb-4258-8bdb-6a34d6bf7fd0` |                                                       |
| Bulk action in the bulk more actions menu | `b9f2ad03-7407-48d9-9e89-fe2f2df63e8a` | `selectedIds`, `allSelected`, `uncheckedIds`, `total` |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
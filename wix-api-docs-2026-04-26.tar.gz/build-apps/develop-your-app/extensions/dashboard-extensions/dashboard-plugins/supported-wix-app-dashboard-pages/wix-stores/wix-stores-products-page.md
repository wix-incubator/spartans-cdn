---
portal: build-apps
name: "Wix Stores: Products Page"
type: ARTICLE_RESOURCE
resourceId: 554526c4-17d7-421a-8e1e-ac31c0c03332
---

# Wix Stores: Products Page

# Wix Stores: Products Page

The Products page has 4 plugin slots: 1 dashboard, and 3 dashboard menu. [Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) are the placeholders in the UI for plugins. The slot ID is the value for the required `extends` field when configuring the plugin in the [App Dashboard](https://dev.wix.com/apps).

## Location in dashboard

Catalog > Store Products > Products

## Dashboard plugin slots

The Stores Products page features a dashboard plugin slot.

### Slot 1: Products Page

This dashboard plugin slot is located at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-products-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_stores-dashboard-plugin.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard plugin's configuration in your app's dashboard:

**slot ID**: `3ca518a6-8ae7-45aa-8cb9-afb3da945081`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "3ca518a6-8ae7-45aa-8cb9-afb3da945081",
  "description": "Dashboard Plugin on the Wix Stores Products page.",
  "title": "Products page Dashboard Plugin",
  "height": 400,
  "iframeUrl": "https://www.example.com/products-list-plugin",
  "componentName": "Products Page dashboard plugin"
}
```

<blockquote class="important">

**Important:**
The hosting platform must be "BUSINESS_MANAGER".

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Multiple dashboard plugins in the same slot

This plugin slot can host multiple plugins.

The plugins are displayed next to each other and ordered by date created, with the most recently created plugin displayed farthest right.

## Dashboard menu plugin slots

The Products page features 3 dashboard menu plugin slots.

### Slot 2: Main more actions menu

This dashboard menu plugin slot is located in the more actions menu at the top of the page.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-products-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_stores-dashboard-menu-plugin-1.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `c87531bd-12df-42f6-bd78-c929ece48be4`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "c87531bd-12df-42f6-bd78-c929ece48be4",
  "description": "Main More Actions Menu Plugin",
  "title": "Stores Main More Actions Menu",
  "iconKey": "Payment",
  "action": {
    "navigateToPage": {
      "pageId": "98052ea0-bfe4-4095-88ba-d5c65c03254b"
    }
  },
  "componentName": "My Stores Main More Actions Menu Plugin"
}
```

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Slot 3: Each product's more actions menu

This dashboard menu plugin slot is located in each product's more actions menu.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-products-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_stores-dashboard-menu-plugin-2.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `5c6c70b7-5041-404d-81b6-1f7ce19acf0f`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "5c6c70b7-5041-404d-81b6-1f7ce19acf0f",
  "description": "Product More Actions Menu Plugin",
  "title": "Product Overview",
  "iconKey": "Payment",
  "action": {
    "navigateToPage": {
      "pageId": "98052ea0-bfe4-4095-88ba-d5c65c03254b"
    }
  },
  "componentName": "My Product Overview More Actions Menu Plugin"
}
```

<blockquote class="important">

**Important:**

- The hosting platform must be "BUSINESS_MANAGER".
- Each slot must include an [icon](https://www.wix-pages.com/wix-design-system-employees/?path=/story/foundations-icons--icons) to comply with Wix's style requirements. Provide the icon's name as the value for `"iconKey"`.

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix pass parameters via dashboard slots for you to utilize in your plugin's functionality. Learn how to [interact with and retrieve parameters from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

This slot passes the following parameters:

| Name | Type   | Description |
| ---- | ------ | ----------- |
| `id` | String | Product ID. |

### Slot 4: Bulk actions toolbar's More Actions menu

This dashboard menu plugin slot is located in the **More Actions** menu of the bulk actions toolbar. The bulk action toolbar appears when at least 1 product is selected.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/wix-stores-products-page-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_dashboard-plugins_supported-wix-app-dashboad-pages_assets_stores-dashboard-menu-plugin-3.png)

#### Configuration

Use the following slot ID for the `extends` property in your dashboard menu plugin's configuration in your app's dashboard:

**slot ID**: `23986555-0ea3-49b4-bcaa-56cfe1ad35bf`

For example:

```json
{
  "hostingPlatform": "BUSINESS_MANAGER",
  "extends": "23986555-0ea3-49b4-bcaa-56cfe1ad35bf",
  "description": "Product Page More Actions Menu Plugin",
  "title": "Sales Overview",
  "iconKey": "Payment",
  "action": {
    "navigateToPage": {
      "pageId": "98052ea0-bfe4-4095-88ba-d5c65c03254b"
    }
  },
  "componentName": "My Sales Overview Menu Plugin"
}
```

<blockquote class="important">

**Important:**

- The hosting platform must be "BUSINESS_MANAGER".
- Each slot must include an [icon](https://www.wix-pages.com/wix-design-system-employees/?path=/story/foundations-icons--icons) to comply with Wix's style requirements. Provide the icon's name as the value for `"iconKey"`.

</blockquote>

#### Interaction between the dashboard page and your plugin

Apps built by Wix can pass data, such as an ID, from the dashboard page to your plugin through a designated slot. Learn how to use the Wix SDK to interact with and retrieve data from the dashboard page. Learn how to use the Wix SDK to [interact with and retrieve data from the dashboard page](https://github.com/wix-private/developer-docs/blob/695f24161f011706921d924d90370daccaba9cb7/build-apps-portal/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions.md#slots-and-plugin-apis*original::../about-dashboard-plugin-extensions.md#slots-and-plugin-apis).

### Multiple dashboard menu plugins in the same slot

These menu plugin slots can host multiple plugins.

The plugins are displayed vertically and ordered by date created, with the most recently created plugin displayed at the top.

## Wix APIs

You can implement logic in your plugin using the Wix Stores APIs:

- [SDK](https://dev.wix.com/docs/sdk/backend-modules/stores/products/introduction)
- [REST](https://dev.wix.com/docs/rest/business-solutions/stores/about-wix-stores)

## Slot IDs

| Slot                                     | ID                                      | Parameters |
| ---------------------------------------- | --------------------------------------- | ---------- |
| Products page                            | `3ca518a6-8ae7-45aa-8cb9-afb3da945081`  |
| Main more actions menu                   | `c87531bd-12df-42f6-bd78-c929ece48be4`  |            |
| Product more actions menu                | `5c6c70b7-5041-404d-81b6-1f7ce19acf0f`  | `id`       |
| Bulk actions toolbar's More Actions menu | ` 23986555-0ea3-49b4-bcaa-56cfe1ad35bf` |            |

## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [Add Self-hosted Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
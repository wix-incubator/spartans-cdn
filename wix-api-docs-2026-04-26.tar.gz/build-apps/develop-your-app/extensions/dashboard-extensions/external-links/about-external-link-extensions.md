---
portal: build-apps
name: "About External Link Extensions"
type: ARTICLE_RESOURCE
resourceId: eda37bd3-d011-419f-aa47-915512b8194d
---

# About External Link Extensions

# About External URL Extensions

The external URL extension allows you to refer users from the dashboard of a Wix site or project to your service outside the Wix platform. The extension adds a link to your service on the Manage Apps page in the site dashboard. When a site admin clicks the link, your external service opens in a new browser tab. Query parameters are passed to your service so it can identify the user.

You can only create one external URL extension per app.

For example, if a user installs the Family Budget app on their site or project, the external URL extension allows them to launch the Family Budget service from the Manage Apps page in their site’s dashboard.

![External URL apps](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-external-link-extensions-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_external-links_assets_externalurl.png)

## When to use the external URL extension

Use the external URL extension when you want to create a connection point between your service and a Wix site or project without embedding your service in a [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions). This can be useful in the following cases:

- Your service is too extensive or complex to render in dashboard pages.
- Your service is part of another service hosted outside the Wix ecosystem.
- Your service is not designed to add new features to the Wix platform or enhance existing ones. Rather, it aims to delegate certain tasks to your platform using user and site information provided by Wix.

## Implementation options
You can add the external URL extension using a [self-hosted solution](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions).

When it comes to designing the UI, consider using the [Wix Design System](https://dev.wix.com/docs/build-apps/develop-your-app/wix-design-system/about-the-wix-design-system), a collection of reusable React components that you can use to make your app appear and feel like a native Wix app.

## See also

- [Add an External URL Extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/external-links/add-external-link-extensions)
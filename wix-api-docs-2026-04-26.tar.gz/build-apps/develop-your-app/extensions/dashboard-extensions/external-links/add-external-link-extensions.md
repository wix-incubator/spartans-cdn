---
portal: build-apps
name: "Add External Link Extensions"
type: ARTICLE_RESOURCE
resourceId: e058d391-eff4-4299-a017-b5d48db94367
---

# Add External Link Extensions

# Add External URL Extensions

This article describes how to add an [external URL extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/external-links/about-external-link-extensions) to your app in the app dashboard.

> **Note**: You can only create one external URL extension per app.

## Add an external URL extension to your app

Do the following to add the extension:

1. Build your app using the technologies of your choice. Make sure your app:
   - Is hosted on a publicly accessible server.
   - Is served on an `https` URL, not an `http` one. For security reasons, the app dashboard does not support making requests to non-`https` servers.
2. Select an app from the [Custom Apps page](https://manage.wix.com/studio/custom-apps) in your Wix Studio workspace. 
3. Go to **Extensions** and click **Create Extension**.
4. In the **Choose the extension you want to create** modal, select **External URL** and click **Create**.
5. On the **External URL** extension configuration page, fill in the following fields:

| Field    | Description        |
| -------- | ------------------------------------------------------------------------------------------------- |
| **Page Info** > **Page URL** | **Required**. Your app server’s address. When a site admin opens your app from the Manage Apps page in their site dashboard, this address is opened in a new browser tab. <br><br> The [app instance data](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances) is attached to the URL of the new browser tab as an encoded query parameter, `instance`, so that you can identify the site owner when they launch your service. <br><br> **Note**: For security reasons, your app must be hosted on an `https` address. |

![External URL extension configuration page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/add-external-link-extensions-md_build-apps-portal_develop-your-app_extensions_dashboard-extensions_external-links_assets_externalurlsettingspage.png)

6. Click **Save** to save your changes.

Once your app is installed on a site, a site admin can access your service by clicking **Apps** > **Manage Apps** in the sidebar menu of their site dashboard, and clicking **Open** next to your app.

## See also

- [About External URL Extensions](https://dev.wix.com/docs/build-apps/developer-tools/extensions/dashboard-extensions/about-external-url-extensions)
---
portal: build-apps
name: "Find a Dashboard Extension ID"
type: ARTICLE_RESOURCE
resourceId: b32f46bd-196c-47ac-95e6-b4ca5bc53979
---

# Find the Dashboard Extension ID

# Find the ID of a Dashboard Extension

When developing your app, you might need to find the unique identifier of a particular extension. Depending on the extension's type and how it was added to your site, this identifier might be called "component ID", "extension ID", or "page ID."

The way to find an extension's ID depends on how it was created. In other words, finding the ID of an extension built with the Wix CLI is different from finding the ID of a [self-hosted extension](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions).

<blockquote classname="caution">

**Caution**: Each dashboard extension ID must be unique across all apps. If 2 different apps installed on the same site use the same ID for their dashboard pages, Wix's dashboard routing may treat them as the same extension. This can cause unexpected behavior, such as clicking on one app's dashboard and being redirected to the other app's dashboard instead.

</blockquote>

## Extension types and their IDs

The following table summarizes how to find a dashboard extension ID based on its type and the way it was added to your app:


| Extension Type  | Deployment Method | Location  |
| --------------- | ----------------- | --------- |
| Dashboard Page  | Self-hosted       | On the **Extensions** page of your app's dashboard, the extension's **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/11e10e4f-b84d-4136-a5a9-6109fab0b7d7/2020/10/25/347cc5c6-bce3-4407-82c3-e211e02cab98/398ced84-9ef5-4f70-87cd-4cb39a66dd65.png) menu includes a **Copy extension ID** action item. <br> The ID also appears on the [Dashboard Page configuration page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-page-extensions) in the `Extension ID` field and as the `component-id` query parameter in the configuration page's URL. |
| Dashboard Modal | Self-hosted       | On the **Extensions** page of your app's dashboard, the extension's **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/11e10e4f-b84d-4136-a5a9-6109fab0b7d7/2020/10/25/347cc5c6-bce3-4407-82c3-e211e02cab98/398ced84-9ef5-4f70-87cd-4cb39a66dd65.png) menu includes a **Copy extension ID** action item. <br> The ID also appears as the `component-id` query parameter in the [Dashboard Modal configuration page's](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-modal-extensions#add-a-dashboard-modal-to-your-app) URL. | 
| Dashboard Page  | Wix CLI           | On the **Extensions** page of your app’s dashboard, the extension’s **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/11e10e4f-b84d-4136-a5a9-6109fab0b7d7/2020/10/25/347cc5c6-bce3-4407-82c3-e211e02cab98/398ced84-9ef5-4f70-87cd-4cb39a66dd65.png) menu includes a **Copy extension ID** action item. The ID also appears in the local extension directory as the `id` property in the page's [`.extension.ts` file](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-pages/dashboard-page-extension-files-and-code#page-builder). |
| Dashboard Modal | Wix CLI           |  On the **Extensions** page of your app’s dashboard, the extension’s **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/11e10e4f-b84d-4136-a5a9-6109fab0b7d7/2020/10/25/347cc5c6-bce3-4407-82c3-e211e02cab98/398ced84-9ef5-4f70-87cd-4cb39a66dd65.png) menu includes a **Copy extension ID** action item. The ID also appears in the local extension directory as the `id` property in the modal's [`.extension.ts` file](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-modals/dashboard-modal-extensions-files-and-code#modal-builder). |

### Extension ID query parameter

When adding a self-hosted extension in your app's dashboard, the extension ID appears in the URL of the extension's configuration page as the `component-id` query parameter.

![query-param-component-id](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a8bf427ce755622ab3329a47c10ab11b.png)
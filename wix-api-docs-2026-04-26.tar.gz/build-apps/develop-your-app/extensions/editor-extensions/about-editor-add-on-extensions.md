---
portal: build-apps
name: "About Editor Add-on Extensions"
type: ARTICLE_RESOURCE
resourceId: 434ec040-172d-44ac-b4d9-59b2f917337f
---

# About Editor Extensions

# About Editor Add-on Extensions

Editor Add-ons extend the functionality of Wix editors by adding a dedicated panel that offers tools to improve the site-building experience. These panels can include features like design guides, accessibility tools, and other enhancements, providing users with additional resources to build and manage their sites more effectively.

Here's an example of an add-on that lets site builders make their own unique color palette from the images on their site:

![add-on-panel](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7f1c51010a7b6d58d4e56eead1ba9cfa.png)

<blockquote class="tip">

**Tip:** When developing an add-on extension, avoid bundling it with other extensions in the same app. This approach allows users to install only the features they require.

</blockquote>

Site owners can install add-ons in two ways:

* **From the Wix App Market**, where they can browse and install apps that include add-on extensions.  
* **From the Tools menu** in the Wix editors, allowing them to directly access and install add-ons as they work on their site. Users can also access the **Editor Add-ons** menu from the [editor’s right-click menu](https://support.wix.com/en/article/wix-editor-using-the-right-click-menu).

<details>
<summary><strong>Add-on menu in Wix Studio</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/9f50a89f7dc1e063c411810253e6af0c.png"/>
</details>

<details><summary><strong>Add-on menu in Wix Editor</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/02f096374f18f28e12d97912cbccbd64.png"/>
</details>

## Add-on panel

Add-ons provide their functionality through a dedicated panel in the editor. This panel is where users access and interact with the features offered by the add-on once it has been installed. Through the panel, site owners can configure settings, customize options, and utilize the tools that come with the add-on.

The add-on panel is rendered as an iframe, giving you the flexibility to build and deploy it using any tools or frameworks you choose. To set up the add-on extension, in the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard), provide a link to your panel’s HTML code, which can be hosted on any platform that exposes public, secure endpoints.

Your add-on can use [Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis) to interact with the editor and the Wix backend, allowing it to access editor elements and manage the site's data.

The [Editor API](https://dev.wix.com/docs/sdk/host-modules/editor/introduction) currently supports the following functionality for interacting with editor elements:

* Get and set a [text element](https://support.wix.com/en/article/wix-editor-adding-and-editing-text) content
* Get and set an [image element](https://support.wix.com/en/article/wix-editor-uploading-your-own-images)'s source

## Implementation options

Currently, editor add-ons can only be built using a self-hosted iframe, with your code deployed on your own server.

Learn how to [create a self-hosted editor add-on extension](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/editor-extensions/add-self-hosted-editor-add-on-extensions).
<!---
## Get an idea for an add-on

Looking for ideas? Discover opportunities for your next app by exploring our [list of top user-requested features](https://dev.wix.com/docs/build-apps/get-started/get-an-idea).
--->
## See also

[Tutorial | Create an Editor Add-on that Imports Icons from a Library](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-an-editor-add-on-that-imports-icons-from-a-library)
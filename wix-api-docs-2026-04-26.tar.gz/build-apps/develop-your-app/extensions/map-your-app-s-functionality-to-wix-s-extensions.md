---
portal: build-apps
name: "Map Your App’s Functionality to Wix’s Extensions"
type: ARTICLE_RESOURCE
resourceId: 9e37507c-09a6-4623-bfe1-eb834955baab
---

# Map Your App’s Functionality to Wix’s Extensions

# Map Your App’s Functionality to Wix’s Extensions

When developing a Wix app, a critical step is understanding which extensions will best deliver your app's functionality to Wix users. Start with what you want to accomplish, then select the appropriate extension types to bring your vision to life.

## Adding content to a site 
These extensions allow you to enhance and extend the front-end experience of Wix sites, giving Wix users more ways to engage their visitors with your app's capabilities.

### Add placeable components
Need to add a component that Wix users can place anywhere on their existing pages? → Use a [site widget extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions). Ideal for interactive elements like advanced forms, product configurators, or social media displays that Wix users can position within their content.

### Create full pages 
Want to create a full, dedicated page for your app's experience? → Choose a [site page extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/about-site-page-extensions) and fill it with a site widget extension. This is perfect for comprehensive experiences like community forums, custom galleries, or specialized landing pages that need their own real estate on a Wix site.

### Implement persistent components
Creating a persistent element that should always be visible? → An [embedded script extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) is your solution. Perfect for chat widgets, notification bars, or feedback buttons that "stick" to specific edges of the page.

### Track visitor behavior and metrics 
Tracking user behavior and page performance metrics across an entire site? → Implement an [embedded script extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) for comprehensive analytics. Perfect for capturing navigation patterns, interaction heatmaps, conversion funnels, and performance benchmarks that work consistently across all pages without requiring manual placement on each one.

### Display custom modals
Building a popup or modal experience that appears conditionally? → Choose an [embedded script extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts). Great for newsletter signups, promotional announcements, or detail views that overlay the main content.

### Integrate with a Wix site element
Want to enhance an existing Wix business solution with an additional UI component? → Develop a [site plugin extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) that users can place inside designated areas (called slots) within the Wix site element, to integrate directly within Wix's business tools. This allows you to add custom components to booking flows, product pages, event registrations, and more.


## Creating site building tools
These extensions enhance the Wix Editor experience, giving site creators powerful new design and content creation capabilities that complement Wix's native toolset.

### Add site design tools
Need to enhance the Wix Editor with custom design tools or specialized content creation capabilities? → An [Editor add-on extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/editor-extensions/about-editor-add-on-extensions) is perfect for advanced typography controls, specialized layout tools, or custom content creation interfaces that empower site creators with features tailored to specific design needs right within the Editor environment.


## Creating site management tools 
These extensions help you build powerful administrative interfaces that let Wix users manage your app's functionality directly from their Wix dashboard.

### Provide management interfaces
Building a management interface for Wix users? → A [dashboard page extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions) provides a dedicated space in the Wix dashboard where Wix users can manage your app's settings and operations. Create campaign management dashboards, inventory management interfaces, and much more.

### Integrate external dashboards
Have functionality that lives on an external platform? → Choose an [external link extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/external-links/about-external-link-extensions) that allows Wix users to access your external tools directly from the Wix dashboard menu. Give Wix users one-click access to powerful tools and advanced capabilities, seamlessly accessible from their Wix environment.

### Integrate with a Wix dashboard
Want to enhance existing Wix business dashboards with your tools? → Use a [dashboard plugin extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions) to integrate your functionality within Wix's business solution dashboards, like adding inventory insights to the Wix Stores inventory dashboard, or adding dynamic pricing tools to the Wix Bookings services dashboard.

### Add your pages and modals to Wix dashboard menus
Want to add your dashboard pages or modals to Wix business solution menus? → Implement a [dashboard menu plugin extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions) to place your functionality directly in relevant menu sections of Wix business solutions. For example, add a "Tax Compliance" option to the Wix Stores product dashboard menu for instant access to sales tax calculation tools and reporting features, or a "Contact Engagement" option to the Contact dashboard menu where Wix users can instantly access engagement history for their contacts.

> **Note**: Learn more about [plugins and menu plugins for dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots).

### Display custom modals
Building a popup or modal experience that appears conditionally? → A [dashboard modal extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals) creates popup interfaces perfect for setup wizards or detailed views within the dashboard environment. Launch a wizard, an optimization flow, and so much more.


## Enhancing backend capabilities
These extensions allow your app to integrate with Wix's backend systems, enabling powerful functionality that works behind the scenes to enhance the site's capabilities.

### Implement custom business logic
Need to inject custom logic or connect to external systems? → [Service plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions) are the answer. These allow your app to integrate with Wix's business logic for capabilities like custom shipping calculations, third-party fulfillment, or specialized payment processing. For example, implement sophisticated tax calculation logic that applies the correct international tax rates based on customer location and product type, or create a custom order fulfillment system that routes orders to the optimal warehouse based on inventory levels, proximity to customer, and shipping cost optimization.

### Extend Wix’s data models
Want to extend Wix's data models with additional information? → Implement [schema plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions) to add custom fields to Wix entities. These are perfect for adding attributes to products, services, or customer profiles that Wix doesn't natively support.

### Send notifications to Wix users
Have alerts for Wix users about important events or updates related to your app? → Use [notification extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions) to send customizable notifications to Wix users through their site dashboard and/or the Wix Owner mobile app. These are ideal for alerts about completed processes or time-sensitive information without requiring them to be actively using your app.

### Enable automations
Want to enable Wix users to automate repetitive tasks related to your app's functionality? → Implement [automation extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/about-automations) to create triggers, actions, or [pre-installed automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations). This allows Wix users to automate processes like sending confirmation emails, updating records, or managing workflows when specific events occur. You can provide just the trigger (event detection), just the action (what happens), or complete pre-installed automations that combine both.


## Mixing and matching for complete solutions
The true power of Wix's extension framework comes from combining different extension types to create comprehensive solutions. Most successful apps utilize multiple extension types to deliver seamless experiences.
For example:
- A customer loyalty app might use a site widget extension to display points on the site, a site plugin extension to integrate with checkout, a dashboard page extension for program management, a service plugin extension for points calculation logic, an automation extension to automatically notify customers of awarded points when purchases are made, and notification extensions to alert Wix users when a customer has reached reward thresholds.
- An inventory management solution could combine a schema plugin extension for product data enhancement, a dashboard plugin extension for inventory controls within the Wix Stores interface, a service plugin extension to connect with external warehouse systems, and an automation extension to trigger reordering when stock levels are low.
- A marketing tool might use embedded scripts for promotional popups, a dashboard page extension for campaign management, notification extensions to alert Wix users about campaign performance, and automation extensions to send targeted emails when visitors take specific actions on the site.

### Extension availability by framework
Keep in mind that extension availability may vary depending on which Wix development framework you're using. Not all extensions are available in every framework.
For a list of supported extensions by framework:
- [Supported extensions in CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions)
- [Supported extensions in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/supported-extensions/about-extensions-in-blocks)
- [Supported extensions for self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)

## See also
- [Choose the Right Wix Framework for Your App Development Needs](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/choose-the-right-wix-framework-for-your-app-development-needs)
- [About development frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks)
- [How apps extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix)
---
portal: build-apps
name: "About MPA Architecture"
type: ARTICLE_RESOURCE
resourceId: 4c97ddab-0beb-436d-92cb-c5a6a89c1c3e
---

# About MPA Architecture

# About MPA Architecture

Wix sites use Multi-Page Application (MPA) architecture to deliver fast, reliable page loading. Understanding how MPA works helps you build [site extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) that perform optimally.

> **Note:** MPA architecture is gradually replacing  Single-Page Application (SPA)  architecture across Wix sites. Build your site extensions for MPA architecture to ensure optimal performance. Extensions optimized for MPA architecture won't affect the performance of sites still using SPA architecture.

## What is MPA?

MPA is a website architecture in which the browser loads a separate HTML document for each page. When site visitors navigate to different pages on a Wix site, the browser loads a new HTML document for each page, similar to traditional websites.

This differs from SPAs, where only the initial page loads HTML, and subsequent navigation triggers API calls to update content dynamically.

## How MPA improves site visitor experience

MPA architecture provides several benefits for Wix sites:

- Faster navigation: Each page loads independently, preventing slow API calls from blocking the entire navigation experience.
- Better performance measurement: Standard web performance metrics measure page navigations and include them in Core Web Vitals ([CrUX](https://developer.chrome.com/docs/crux)) data.
- Improved reliability: Issues with individual pages don't affect a site's navigation performance.

## Building MPA-compatible site extensions

When you develop site extensions, keep in mind that each page loads independently. When site visitors navigate between pages, navigation clears any data you store in memory.

Use the [session storage API](https://dev.wix.com/docs/sdk/frontend-modules/storage/session) instead of [memory storage](https://dev.wix.com/docs/sdk/frontend-modules/storage/memory) to maintain data across page navigations. Session storage persists data throughout site visitors' browser sessions, ensuring your extension works seamlessly as site visitors move between pages on a site.

## Testing your app

To test your site extensions with MPA navigation, add this query parameter to your site’s URL: `?experiments=specs.thunderbolt.forceMpaNavigation`. This forces MPA navigation even on sites that normally use SPA mode. Test page loads, reloads, and back navigation to confirm your extensions reinitialize or persist data as expected.

## See also

- [About Site Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions)
- [Storage SDK](https://dev.wix.com/docs/sdk/frontend-modules/storage/introduction)
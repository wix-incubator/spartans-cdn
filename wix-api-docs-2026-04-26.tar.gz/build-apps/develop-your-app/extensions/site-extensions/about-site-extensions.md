---
portal: build-apps
name: "About Site Extensions"
type: ARTICLE_RESOURCE
resourceId: 603df585-98ab-42f8-9f5b-fb1649167210
---

# About Site Extensions

# About Site Extensions

Site extensions are front-facing interfaces that enhance Wix sites with additional functionality, such as adding site pages, widgets, site plugins, and embedded scripts for custom HTML code.

## Site pages

A site page extension adds a page to the user's site. The page can appear in the site's main navigation menu and behaves just like any other page. Site pages are composed of one or more of your app’s widgets, and can be comprised of elements like buttons, input fields, and images, widgets.

## Site widgets

Site widgets are draggable UI components that Wix site owners can add to pages on their website. They enhance a site's functionality by displaying content or enabling site visitors to perform various tasks. When working in the site editor, site owners can adjust the size of the widget, reposition it, and customize it using its settings panel.

Widgets can be added to your site by using [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/build-a-site-widget-in-blocks), [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/add-a-site-widget-extension) or a [self-hosted custom element](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/site-widgets-and-plugins/add-self-hosted-site-widget-extensions-with-custom-elements).

Site widgets are [sandboxed](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions#sandboxing-in-the-editor) in the editor. Learn more about [handling sandboxing in the editor](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/handle-sandboxing-in-the-editor). 

## Site plugins

With site plugins, you can create interactive and feature-rich widgets that seamlessly integrate into Wix’s [business solutions](https://support.wix.com/en/business-solutions-apps) such as Wix Stores and Wix Bookings, extending their functionality and user experience. Plugins are built using [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks), which offers powerful layout and design tools, and gives you access to Velo's full-stack development platform.

Wix users can easily place plugins into predefined slots (UI placeholders) within Wix apps, using the [plugin explorer](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) available in all Wix editors.

Site plugins are [sandboxed](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions#sandboxing-in-the-editor) in the editor. Learn more about [handling sandboxing in the editor](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/handle-sandboxing-in-the-editor). 

## Embedded scripts

An embedded script is an app extension that injects an HTML code fragment into the DOM of a site. Unlike other extensions, embedded scripts aren't fully configured by default during app installation and have an [additional setup](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) step to embed the code fragment.

For example, an embedded script can be used to listen for predefined Wix events, as well as to report and listen for custom events.

## See also

- [About site pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/about-site-page-extensions)
- [About site widgets](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)
- [About site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions)
- [About embedded scripts](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts)
---
portal: build-apps
name: "Analyze User Behavior Using Embedded Scripts"
type: ARTICLE_RESOURCE
resourceId: b66e39ae-0ad6-4f9a-8334-5d7b94ca8f7a
---

# Analyze User Behavior Using Embedded Scripts

# Analyze User Behavior with Embedded Scripts

Use an [embedded script extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) to track analytics events on a site and send them to [external analytics platforms](https://support.wix.com/en/article/about-marketing-integrations) such as Google Analytics or Facebook Pixel. Call [trackEvent()](https://dev.wix.com/docs/sdk/host-modules/site/analytics/track-event) to report [standard events](https://dev.wix.com/docs/sdk/host-modules/site/events/about-analytics-events) or custom events to connected platforms.

<!-- TODO: Check about script type and placement: must the script be of type Analytics? Must it be placed in the document head? Or do those not matter? -->

> **Notes:**
>
> - You must load the script on a site by calling [Embed Script](https://dev.wix.com/docs/api-reference/app-management/embedded-scripts/embed-script?apiView=SDK) in your code.
> - This article shows how to track events using [an embedded script extension added by the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension). You can also track events using [a self-hosted embedded script extension](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension-to-a-self-hosted-app).

## Listen to standard Wix events

Wix business solutions, such as Wix Stores or Wix Events, trigger [standard analytics events](https://dev.wix.com/docs/sdk/host-modules/site/events/about-analytics-events) when the corresponding visitor actions occur, but these events aren't automatically forwarded to external analytics platforms. To report them, you need to call `trackEvent()` in your embedded script code. 

For example, to report an [`AddToCart` event](https://dev.wix.com/docs/sdk/host-modules/site/events/wix-stores/add-to-cart) when a visitor adds a product to their cart:

1. In the embedded script extension's [`.html` file](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/embedded-script-extension-files-and-code#embeddedhtml), reference a local JavaScript module:

   ```html
   <script type="module" src="./analytics-events.js"></script>
   ```

2. In the module code, import the `analytics` module and call `trackEvent()` with the standard event name and relevant data. For example, to report an `AddToCart` event:

   ```js
   import { analytics } from "@wix/site";

   analytics.trackEvent("AddToCart", {
     id: "product-123",
     name: "Classic Sneakers",
     price: 89.99,
     currency: "USD",
     quantity: 1,
   });
   ```

The event is reported to all analytics platforms connected to the site.

## Track custom events

You can define and track custom events for visitor behaviors not covered by standard events, and report them to connected external analytics platforms:

1. In the [embedded script extension's `.html` file](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/embedded-script-extension-files-and-code#embeddedhtml), reference a local JavaScript module:

   ```html
   <script type="module" src="./analytics-events.js"></script>
   ```

2. In the module code, import the `analytics` module and call `trackEvent()` with the event name and any relevant event data:

   ```js
   import { analytics } from "@wix/site";

   analytics.trackEvent("HeroBannerClick", {
     eventCategory: "engagement",
     eventAction: "hero-banner-click",
   });
   ```

The event is reported to all analytics platforms connected to the site.

> **Note:** Some external analytics platforms require that the custom event contains certain properties, such as `eventCategory` and `eventAction`.

## Register event handlers

You can call [registerEventListener()](https://dev.wix.com/docs/sdk/host-modules/site/analytics/register-event-listener) to register an event handler that runs whenever any analytics event occurs, either standard or custom. 

Use this for debugging, logging, or forwarding events to a custom destination. To run handlers for only specific event types, use conditional logic in your code:

```js
import { analytics } from "@wix/site";

analytics.registerEventListener((eventName, eventData) => {
  switch (eventName) {
    case "PageView":
      console.log("Page viewed:", eventData);
      break;
    case "AddToCart":
      console.log("Added to cart:", eventData);
      break;
    case "HeroBannerClick":
      console.log("Hero banner clicked:", eventData);
      break;
  }
});
```

## See also

- [About Marketing Integrations](https://support.wix.com/en/article/about-marketing-integrations)
- [Add an Embedded Script Extension Using the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension)
- [Add an Embedded Script Extension to a Self-Hosted App](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension-to-a-self-hosted-app)
- [About the Analytics API](https://dev.wix.com/docs/sdk/host-modules/site/analytics/introduction)
- [About Analytics Events](https://dev.wix.com/docs/sdk/host-modules/site/events/about-analytics-events)
- [About Embedded Scripts](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts)
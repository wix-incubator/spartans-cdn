---
portal: build-apps
name: "About Site Page Extensions"
type: ARTICLE_RESOURCE
resourceId: e8f9c8a5-ca96-4b32-908b-1f1df1be3097
---

# About Site Page Extensions

# About Site Page Extensions

A site page extension adds a full page to the user's site. The page can appear in the site's main navigation menu and behaves just like any other page. Learn more about [how site owners manage pages](https://support.wix.com/en/article/wix-editor-managing-your-sites-pages).

Your app's site pages are structured as a series of [sections](https://support.wix.com/en/article/wix-editor-adding-and-setting-up-sections), each containing a [site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions). A page can contain as many widgets as you like. This means that before setting up a  page, your app must have at least one widget.

![site page app](https://wixmp-833713b177cebf373f611808.wixmp.com/images/63788024676d56b25d96513bea0e5d01.png)

You can add multiple pages to your app. You must assign a unique ID to each page you add, which is used when referring to the page in code. When your app is installed on a site, the ID is also used as the page's default [URL slug](https://support.wix.com/en/article/wix-editor-changing-your-page-url).

When setting up the page extension, you can determine whether site owners are able to duplicate the page and whether to add it automatically to the site menu after installation.

> **Note**: Your app can automatically add a page only to a [regular site menu](https://support.wix.com/en/article/wix-editor-adding-a-site-menu) in the Wix Editor. It cannot add  a page to [advanced menus](https://support.wix.com/en/article/wix-editor-adding-and-setting-up-advanced-menus) or to [menus in Wix Studio](https://support.wix.com/en/article/studio-editor-designing-menus).

## Implementation options

Once you've created your [site widgets](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions), setting up a site page extension only requires configuration in your app's dashboard, with no coding involved.

Add a site page extension to your app by [setting it up in your app's dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/add-a-site-page-extension).
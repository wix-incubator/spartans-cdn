---
portal: build-apps
name: "Add a Site Page Extension"
type: ARTICLE_RESOURCE
resourceId: 287a3e40-efdd-4e28-b0b3-87b1e89ac663
---

# Add a Site Page Extension

# Add a Site Page Extension

A [site page extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/about-site-page-extensions) adds a full page to the user's site.

<blockquote class="important">

__Important:__
A site page is structured as a series of [sections](https://support.wix.com/en/article/wix-editor-adding-and-setting-up-sections), each containing a [site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions). This means that before setting up a  page, your app must already have at least one widget.

</blockquote>

To create a site page extension:

1. In the [Custom Apps page](https://manage.wix.com/account/custom-apps), select an existing app that contains site widgets.
2. In the left menu, select **Develop > Extensions**.
3. Click **Create Extension** and select **Site Page**.
4. Configure the page’s settings:
   * **Page name**: This name will appear in the site's Pages panel.
   * **Page ID**: The ID will be used to refer to the page in code, and will also become the default URL slug.
   * Select whether to prevent users from duplicating the page.
   * Select whether to add the page automatically to the site menu after installation.
   > **Note**: Your app can automatically add a page only to a [regular site menu](https://support.wix.com/en/article/wix-editor-adding-a-site-menu) in the Wix Editor. It cannot add  a page to [advanced menus](https://support.wix.com/en/article/wix-editor-adding-and-setting-up-advanced-menus) or to [menus in Wix Studio](https://support.wix.com/en/article/studio-editor-designing-menus).
5. To define which widgets to include in the page, click **+ Add Widgets** and select any of your app’s widgets. Each widget will be added to the page in its own section in the order that you defined.
   > **Note**: If you include a widget that is set as [essential to your app's functionality](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions#essential-widgets), deleting the page from a site will delete the entire app.
6. Click **Save**.
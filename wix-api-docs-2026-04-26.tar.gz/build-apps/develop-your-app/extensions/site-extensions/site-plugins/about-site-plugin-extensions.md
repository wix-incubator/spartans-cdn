---
portal: build-apps
name: "About Site Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 99bdc6e6-edea-48e5-bc0c-478022ba8b2b
---

# About Site Plugin Extensions

# About Site Plugin Extensions

With site plugins, you can create interactive and feature-rich components that seamlessly [integrate into Wix’s business solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions), such as Wix Stores and Wix Bookings, extending their functionality and user experience.

Wix users can easily place site plugins into predefined **slots** (UI placeholders) within Wix apps, using the plugin explorer available in all Wix editors.

![plugin-flow](https://wixmp-833713b177cebf373f611808.wixmp.com/images/54e05c27b1fbbf6dfd6835138b7e8f51.gif)

## Terminology

The following are key terms related to site plugins:

| Term | Definition |
|-----|----|
| Host widget | A widget belonging to a Wix business solution, which contains one or more slots. |
| Slot | A placeholder within a host widget in which users can add a plugin. |
| Site plugin | A component that can be added inside a slot, extending the host widget's functionality. |
| Plugin API | An API contract between a site plugin and a slot that both must implement to communicate. |

## How site plugins work

A site plugin integrates with its host widget in two ways:

* **Visually**, by embedding its UI inside one of the host's slots
* **Logically**, by implementing a communication interface with the host

To enable site plugins to communicate with their hosts, each slot supports an API that provides data about the plugin's context (for example the `productId` of the current product on the Product page).

## Slots and plugin APIs

Wix offers a range of placeholders, called [slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots), across app pages, for which you can build plugins.

When developing a plugin, you need to explicitly declare the specific slots in which users are allowed to add it.

Explore the slots available on each host widget, as well as the APIs they support:

| Wix app | Host widget |
|---|---|
| Wix eComm | [Checkout page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-checkout-page) |
| Wix eComm | [Side cart](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-side-cart) |
| Wix Stores | [Product page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-product-page) |
| Wix Stores | [Category page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-category-page) |
| Wix Stores | [Shop page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-shop-page) |
| Wix Stores | [Gallery widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-gallery-widget) |
| Wix Bookings| [Service page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-bookings/wix-bookings-service-page) |
| Wix Events | [Event Details page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-events/wix-events-event-details-page) |
| Wix Blog | [Post page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-blog/wix-blog-post-page) |

![slot-wireframe](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5e913647b7c4f03b442b445bf40fde82.png)

## Implementation options

You can add a site plugin extension using:

* [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/add-a-site-plugin-extension-in-the-cli): Create a site plugin using the CLI and custom element technology, with your code by default deployed on our servers. The creation and setup process of your widget takes place in the terminal. Then, to edit your plugin, you write code directly in your CLI app project's files.
* [Self-hosted custom element](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/site-widgets-and-plugins/add-self-hosted-site-plugin-extensions-with-custom-elements): Create a site plugin using custom element technology, with your code deployed on your own server. The custom element is essentially a new HTML tag that you define, which is made available in the Wix editors as a widget.
* [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-plugins/build-a-site-plugin-in-blocks): Create a site widget in Wix's native app editor. Design your site plugin using visual layout and design tools, and code your business logic using Velo, Wix’s native coding solution.

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

## Sandboxing in the editor

Site plugins are sandboxed when rendered in the editor to enhance security. This means they're treated as if they come from a different domain, which impacts access to browser storage APIs and other same-origin resources.

<blockquote class="important">

__Important:__ The format of the Wix editor URL is changing due to new cookies introduced for authorization. The new URL format is `{username}-{sitename}.{editor|studio|harmony}.wix.com`. If your app uses CORS and whitelists specific origins, update your allowed origins to match the new format to avoid blocked requests.

</blockquote>

Learn more about [handling sandboxing in the editor](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/handle-sandboxing-in-the-editor).
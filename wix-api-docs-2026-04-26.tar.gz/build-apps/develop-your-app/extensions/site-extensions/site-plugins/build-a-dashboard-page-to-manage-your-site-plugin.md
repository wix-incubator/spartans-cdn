---
portal: build-apps
name: "Build a Dashboard Page to Manage Your Site Plugin"
type: ARTICLE_RESOURCE
resourceId: 9a509117-c660-4696-bb50-2ca3db94cd55
---

# Build a Dashboard Page to Manage Your Site Plugin

# Build a Dashboard Page to Manage Your Site Plugin

When building a [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions), you may want  to provide users with a back office management interface for the plugin. You can create one either within the Wix dashboard, or as an external dashboard on a third-party platform. [Learn about building a dashboard page extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions)

## Add your plugin to a slot from a dashboard page

To let users add your plugin to their site through your app's [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions), create a user interface that triggers the Wix Dashboard API's `addSitePlugin()` function. Specify the desired slot when calling this function. This initiates a user flow where Wix requests the user's consent to add the plugin. If the selected slot is already occupied, the user can choose to replace the existing plugin with your plugin. Plugins for the checkout page must implement this functionality to enable users to add the plugin to their site.

Depending on the framework you're using to develop your dashboard page, use one of the following APIs:

* [Velo in Blocks: `addSitePlugin()`](https://dev.wix.com/docs/velo/api-reference/wix-dashboard/add-site-plugin).
* [Wix SDK: `addSitePlugin()`](https://dev.wix.com/docs/sdk/host-modules/dashboard/add-site-plugin).

The `addSitePlugin()` function takes the following parameters:

* `pluginId`: ID of your site plugin, which you can find in your app's site plugin extension. To view the extension, go to your app's dashboard in the [Wix Studio workspace](https://manage.wix.com/studio/custom-apps).
* `placement`: Details of the slot in which you want to add the plugin, including the hosting app's `appDefinitionId`, and the relevant `widgetId` and `slotId`. Learn more about the locations and identifiers of [slots that are available on Wix app pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots).

The following example shows how to use Velo in Blocks to add a site plugin to the checkout page when a user clicks an **Add Plugin** button in the dashboard:

```js
import { addSitePlugin } from 'wix-dashboard';

$w.onReady(function() {
  $w('#addPluginBtn').onClick(() => {
    const pluginId = '9fbd5efb-1b58-489e-b896-47f6851603f0';
    const pluginPlacement = {
      appDefinitionId: "1380b703-ce81-ff05-f115-39571d94dfcd",
      widgetId: "14fd5970-8072-c276-1246-058b79e70c1a",
      slotId: "checkout:summary:before"
    }

    addSitePlugin(pluginId, {
        placement: pluginPlacement
      })
      .then(() => {
        console.log('Plugin added successfully');
      })
      .catch(error => {
        console.error('Error adding plugin:', error);
      });
  })
});
```

## Check your plugin's placement status

You can check whether your plugin is currently placed in a slot on a specific site. Depending on the framework you're using to develop your dashboard page, use one of the following APIs:

* [REST: Get Placement Status](https://dev.wix.com/docs/rest/app-management/site-plugins/placement-status-v1/get-placement-status)
* [Velo in Blocks: `getPlacementStatus()`](https://dev.wix.com/docs/velo/api-reference/wix-site-plugins-v1/plugins/get-placement-status)

Both APIs return an array of objects indicating whether each of your app's site plugins is currently placed in a slot on the user's site.

For example:

```js
import { plugins } from "wix-site-plugins.v1";

...

const { placementStatuses } = await plugins.getPlacementStatus();
const myPluginPlacementStatus = placementStatuses[0];

if (myPluginPlacementStatus.placedInSlot) {
  onPluginPlacedSuccessfully();
}
```
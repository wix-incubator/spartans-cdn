---
portal: build-apps
name: "About Slots"
type: ARTICLE_RESOURCE
resourceId: 8b780014-e938-4425-88aa-638d22da5f75
---

# About Slots

# About Slots

Wix offers a range of slots across Wix app pages where you can build [site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions).

When developing a plugin, you need to declare the specific slots in which users are able to place it. If you set your plugin to be automatically placed in a slot on installation, it will be placed in the first available slot according to the order you defined. If that slot is occupied, it will be placed in the next available slot, and so on. If there are no available slots, it will not be placed.

To enable plugins to communicate with their hosts, each slot supports an API that provides data about the plugin's context (for example the `productId` of the current product on the Product page). Use this API when you code your plugin's logic.

For details about the slots available on each app page, as well as the API they support, see:

* Wix Stores:
  * [Product page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-product-page)
  * [Category page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-category-page)
  * [Shop page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-shop-page)
  * [Gallery widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-gallery-widget)
* [Wix Bookings: Service page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-bookings/wix-bookings-service-page)
* [Wix Events: Event Details page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-events/wix-events-event-details-page)
* Wix eCommerce (Checkout & Orders): 
  * [Checkout page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-checkout-page)
  * [Side cart](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-side-cart)
* [Wix Blog: Post page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-blog/wix-blog-post-page)
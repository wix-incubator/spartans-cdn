---
portal: build-apps
name: "Wix Blog: Post Page"
type: ARTICLE_RESOURCE
resourceId: 4b529149-7979-4df4-adee-4cf9881458a9
---

# Wix Blog: Post Page

# Wix Blog: Post Page

The following slots are available when building a [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) for the Post page.

## Slots

The following image shows slots in the Post page, into which users can add plugins.


![post-slots](https://wixmp-833713b177cebf373f611808.wixmp.com/images/29722d7432e7f5c13c415900eb3cbc5c.png)


The slots are represented by the following `placement` object:

```json
[
  {
    "appDefinitionId": "<WIX_BLOG_APP_ID>",
    "widgetId": "<POST_PAGE_ID>",
    "slotId": "<SELECTED_SLOT_ID>"
  }
]
```

Provide the following values for each property:

| Key                | Value |
| ------------------ | ------- |
| `appDefinitionId`  | "14bcded7-0066-7c35-14d7-466cb3f09103" |
| `widgetId`         | "211b5287-14e2-4690-bb71-525908938c81" |
| `slotId`           | ID of the slot you want [as displayed in the image above](#slots). </br> Supported values: <br /> <ul><li>`"above-header"`</li><li>`"above-content-1"`</li><li>`"above-content-2"`</li><li>`"below-content-1"`</li><li>`"below-content-2"`</li><li>`"page-bottom-1"`</li><li>`"page-bottom-2"`</li><li>`"page-bottom-3"`</li></ul> |


For example:

```json
{
  "appDefinitionId": "14bcded7-0066-7c35-14d7-466cb3f09103",
  "widgetId": "211b5287-14e2-4690-bb71-525908938c81",
  "slotId": "above-content-1"
}
```

Learn more about how to [add your plugin to a slot from the dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/build-a-dashboard-page-to-manage-your-site-plugin).


## Post plugin API

Use the Post plugin API to integrate with the plugin's host.

The API provides data about the current post.

### Properties

| Name | Type | Description |
| -------- | ---- | ----------- |
| `postId` | String | The ID of the current post. |

### Code example
```js
const { postId } = $widget.props;
```

## Related Wix backend APIs

Post plugins usually need to integrate with Wix Blog Post APIs, as well as other backend APIs.

In your site plugin or in your app's server code, you may want to perform actions or implement logic that is dependent on the current post or related data.

You can do this using the Wix Blog APIs ([Velo](https://dev.wix.com/docs/velo/api-reference/wix-blog-backend/introduction), [REST](https://dev.wix.com/docs/rest/business-solutions/blog/introduction), [JavaScript SDK](https://dev.wix.com/docs/sdk/backend-modules/blog/introduction)).
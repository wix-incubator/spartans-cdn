---
portal: build-apps
name: "Wix Bookings: Service Page"
type: ARTICLE_RESOURCE
resourceId: 8685d69e-37a5-4ae8-bb7f-9e8f2a016f6b
---

# Wix Bookings: Service Page

# Wix Bookings: Service Page

Following are the slots and APIs that are available when building a [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) for Wix Bookings' Service page.

## Slots

The Service Page can host a single plugin that users are free to reposition within the page by [reordering the Service Page sections](https://support.wix.com/en/article/wix-bookings-customizing-your-service-pages):

![service-page-slots](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4117b92be9b9cfc8cfe4330a5e9af2ab.png)

The slot is represented by the following `placement` object:

```json
{
  "appDefinitionId": "13d21c63-b5ec-5912-8397-c3a5ddb27a97",
  "widgetId": "a91a0543-d4bd-4e6b-b315-9410aa27bcde",
  "slotId": "slot1"
}
```

## Bookings Service plugin API

Use the Booking Service plugin API to integrate with the plugin's host.

The API provides data about the current booking service.

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `bookingsServiceId` | String | ID of the Wix Bookings service that is currently applied on the plugin's host. |

### Code example

```javascript
const {bookingsServiceId} = $widget.props;
```

## Related Wix backend APIs

In your site plugin or in your app's server code, you may want to perform actions or implement logic that is dependent on the current booking or related data.

You can do this using the Wix Bookings APIs ([Velo](https://www.wix.com/velo/reference/wix-bookings-v2/introduction) and [REST](https://dev.wix.com/docs/rest/business-solutions/bookings/about-wix-bookings)).
---
portal: build-apps
name: "Wix Events: Event Details Page"
type: ARTICLE_RESOURCE
resourceId: 517dd4a2-6595-4497-a877-4b69cf66be00
---

# Wix Events: Event Details Page

# Wix Events: Event Details Page

Following are the slots and APIs that are available when building a [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) for the Event Details Page.

## Slots

The following image shows slots in the Event Details page, into which users can add plugins.

![events-slots](https://wixmp-833713b177cebf373f611808.wixmp.com/images/8d4c4197e9e852d402ec74c4585f4893.png)

The slots are represented by the following `placement` objects:

```json
{
  "appDefinitionId": "140603ad-af8d-84a5-2c80-a0f60cb47351",
  "widgetId": "14d2abc2-5350-6322-487d-8c16ff833c8a",
  "slotId": "header"
}
```

```json
{
  "appDefinitionId": "140603ad-af8d-84a5-2c80-a0f60cb47351",
  "widgetId": "14d2abc2-5350-6322-487d-8c16ff833c8a",
  "slotId": "details"
}
```

## Event plugin API

Use the Event plugin API to integrate with the plugin's host.

The API provides data about the current event.

| Property | Type | Description |
| -------- | ---- | ----------- |
| `eventId` | String | The ID of the event that is currently applied on the plugin's host. |

### Code example

```javascript
const {eventId} = $widget.props;
```

## Related Wix backend APIs

In your site plugin or in your app's server code, you may want to perform actions or implement logic that is dependent on the current event or related data.

You can do this using the Wix Events APIs ([Velo](https://www.wix.com/velo/reference/wix-events-v2/introduction) and [REST](https://dev.wix.com/docs/rest/business-solutions/events/introduction)).
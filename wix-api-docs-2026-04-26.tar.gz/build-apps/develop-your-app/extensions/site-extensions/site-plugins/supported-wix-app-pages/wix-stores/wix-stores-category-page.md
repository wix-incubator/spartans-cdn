---
portal: build-apps
name: "Wix Stores: Category Page"
type: ARTICLE_RESOURCE
resourceId: 696c245c-6b60-4bf3-93a8-a67b3b9a12cc
---

# Wix Stores: Category Page

# Wix Stores: Category Page

The following slots and APIs are available when building a [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) for the Category page.  

> **Note:**
> When selecting a slot for your plugin in the Category page, you should select the same slot for the [Shop page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-shop-page) and the [Gallery widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-gallery-widget). Different Wix sites may use any of these and making these slots available for your plugin allows users to add it to their site regardless of their setup.

## Slots

The following images show the slots available in the Category page, into which users can add plugins.

<details>
<summary><strong>Mobile</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/6b5a12db3e11d3da7b778aea4d26a6ab.png"/>
</details>

<details>
<summary><strong>Mobile Popup</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/0c034fb7bd33c7c46883c49731b0f46c.png"/>
</details>  
  
<details>
<summary><strong>Desktop</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/75eb67da0a0c8bcba8639432d705c9da.png"/>
</details>

The slots are represented by the following `placement` object:

```json
{
  "appDefinitionId": "<WIX_STORES_APP_ID>",
  "widgetId": "<CATEGORY_PAGE_ID>",
  "slotId": "<SELECTED_SLOT_ID>"
}
```

Provide the following values for each property:

| Key                | Value |
| ------------------ | ------- |
| `appDefinitionId`  | "1380b703-ce81-ff05-f115-39571d94dfcd" |
| `widgetId`         | "bda15dc1-816d-4ff3-8dcb-1172d5343cce" |
| `slotId`           | ID of the slot you want [as displayed in the image above](#slots). |

For example:

```json
{
  "appDefinitionId": "1380b703-ce81-ff05-f115-39571d94dfcd",
  "widgetId": "bda15dc1-816d-4ff3-8dcb-1172d5343cce",
  "slotId": "category-page-hero-top"
}
```

### Category plugin API

Use the Category plugin API to integrate with the plugin's host.

The API provides data about the current category.

| Property | Type | Description |
| -------- | ---- | ----------- |
| `categoryId` | String | The ID of the category that is currently applied on the plugin's host. |

## Related Wix APIs

In your site plugin or in your app's server code, you may want to perform actions or implement logic that is dependent on the current category or related data.

You can do this using the Wix Stores APIs ([Velo](https://dev.wix.com/docs/velo/apis/wix-stores-v2/products/introduction), [REST](https://dev.wix.com/docs/rest/business-solutions/stores/about-wix-stores), [JavaScript SDK](https://dev.wix.com/docs/sdk/backend-modules/stores/products/introduction)).
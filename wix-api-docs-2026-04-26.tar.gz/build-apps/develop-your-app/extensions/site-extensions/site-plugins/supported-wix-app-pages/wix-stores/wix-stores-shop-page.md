---
portal: build-apps
name: "Wix Stores: Shop Page"
type: ARTICLE_RESOURCE
resourceId: f46ee513-7b8e-4684-afd6-f348adbe37f3
---

# Wix Stores: Shop Page

# Wix Stores: Shop Page

The following slots and APIs are available when building a [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) for the Shop page.  

> **Note:**
> When selecting a slot for your plugin in the Shop page, you should select the same slot for the [Gallery widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-gallery-widget) and the [Category page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-stores/wix-stores-category-page). Different Wix sites may use any of these and making these slots available for your plugin allows users to add it to their site regardless of their setup.

## Slots

The following images show the slots available in the Shop page, into which users can add plugins.

<details>
<summary><strong>Mobile</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/2702505363ef88bda2366efa8011d253.png"/>
</details>

<details>
<summary><strong>Mobile Popup</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/0c034fb7bd33c7c46883c49731b0f46c.png"/>
</details>

<details>
<summary><strong>Desktop</strong></summary>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/3abcc5c351e8330a8dfb3bae647dc596.png"/>
</details>

The slots are represented by the following `placement` object:

```json
{
  "appDefinitionId": "<WIX_STORES_APP_ID>",
  "widgetId": "<SHOP_PAGE_ID>",
  "slotId": "<SELECTED_SLOT_ID>"
}
```

Provide the following values for each property:

| Key                | Value |
| ------------------ | ------- |
| `appDefinitionId`  | "1380b703-ce81-ff05-f115-39571d94dfcd" |
| `widgetId`         | "1380bba0-253e-a800-a235-88821cf3f8a4" |
| `slotId`           | ID of the slot you want [as displayed in the image above](#slots). |

For example:

```json
{
  "appDefinitionId": "1380b703-ce81-ff05-f115-39571d94dfcd",
  "widgetId": "13afb094-84f9-739f-44fd-78d036adb028",
  "slotId": "gallery-products-top"
}
```

### Category plugin API

Use the Category plugin API to integrate with the plugin's host.

The API provides data about the current category.

| Property | Type | Description |
| -------- | ---- | ----------- |
| `categoryId` | String | The ID of the category that is currently applied on the plugin's host. |

## Related Wix APIs

In your site plugin or in your app's server code, you may want to perform actions or implement logic that is dependent on the current category or related data.

You can do this using the Wix Stores APIs ([Velo](https://dev.wix.com/docs/velo/apis/wix-stores-v2/products/introduction), [REST](https://dev.wix.com/docs/rest/business-solutions/stores/about-wix-stores), [JavaScript SDK](https://dev.wix.com/docs/sdk/backend-modules/stores/products/introduction)).
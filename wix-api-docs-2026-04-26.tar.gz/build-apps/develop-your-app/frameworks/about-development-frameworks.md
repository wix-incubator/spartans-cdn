---
portal: build-apps
name: "About Development Frameworks"
type: ARTICLE_RESOURCE
resourceId: 2edba636-3ec1-402a-9da4-e920c8aeb5b9
---

# About Development Frameworks

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# About Development Frameworks

Wix offers 3 development frameworks for building apps, each providing a comprehensive development model. Each framework offers various tools and technologies on different platforms. The 3 frameworks are: 

- [Wix Blocks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks#wix-blocks): Design, code, and deploy on Wix’s native app editor.
- [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli):  Code and deploy with Wix’s React/[Node.js stack](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks#wix-cli).
- [Self-hosting](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks#self-hosting): Use your own tech stack.

[<button class="wix-button">Start Developing
</button>](https://manage.wix.com/account/custom-apps)

To make an informed choice about which framework to use, follow the path below.

## Get acclimated

First, we recommend you review the [Development Frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) article, which guides you through the process of choosing the framework that’s right for you. 

No matter which framework you start with, you can always continue developing your app using any of the other frameworks. 

## Get started

A great way to learn about the frameworks is to try them out. Check out our [Quick Start tutorials](https://dev.wix.com/docs/build-apps/get-started/quick-start/about-the-quick-starts) for each of the frameworks. 

## Get integrated

Now that you know which frameworks are right for you, you can extend Wix functionality by adding [extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions) and integrating with Wix's [business solutions](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/about-wix-business-solutions). Learn more about the [frameworks you can use to build each type of extension](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#extension-catalog).

## See also

- [Tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials)
- [App templates](https://dev.wix.com/docs/build-apps/get-started/templates/get-started-from-an-app-template)
---
portal: build-apps
name: "About Self-hosting for Wix Apps"
type: ARTICLE_RESOURCE
resourceId: 849dd1f5-e113-4f36-83d0-d4d00fcc7bdc
---

# About Self-hosting for Wix Apps

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# About Self-hosting for Wix Apps

Wix supports several [development frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) you can use to build your app. You can use Wix's [native frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks), such as [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) and the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). You can also build and host your app's features yourself outside the Wix ecosystem, and integrate them with Wix using the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).

With the self-hosting framework, your app can provide entirely new functionality, or integrate an existing service with the Wix ecosystem. By integrating an existing service with Wix, you can make it available to a large number of Wix site owners, easily integrate it with [Wix's business solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions), and maintain the ability to manage it across multiple platforms.

Self-hosting enables you to use the tech stack of your choice. However, to benefit from a native Wix development environment, consider using [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) or the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli).

> **Note:**
> No matter which development framework you start with, you can always continue developing your app using any of the other supported frameworks.

[<button class="wix-button">Start Developing
</button>](https://manage.wix.com/account/custom-apps)

## Building and deploying your Wix app

To start building a Wix app with the self-hosted framework, [create a new app with the app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard) and provide the links to your app's assets. These can be hosted on any platform that exposes public, secure endpoints.

Once your app is installed on a site, it can communicate with it using Wix APIs. Wix APIs allow your app to access and manage the site's data, extend the [Wix business solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions) it has installed, and customize interactions with site visitors. Wix offers multiple [API technologies](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis), including REST, JavaScript SDK, GraphQL, and Velo with Blocks. Each API technology offers a similar set of APIs.

Learn more about [Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis) and the [JavaScript SDK](https://dev.wix.com/docs/sdk/articles/get-started/about-the-wix-java-script-sdk).

### Functionality as extensions

On Wix, each specific type of functionality that an app can provide is called an [extension](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix). Wix offers [many types of extensions](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#extension-catalog) that allow your app to extend both your site's frontend interfaces and its backend capabilities.

Your app can contain multiple extensions across different interfaces and services to provide a more comprehensive solution. Since each extension is configured separately in an app's dashboard, build your app in such a way that each of its deployable self-hosted assets is accessible to Wix via a separate URL.

Learn more about [how apps extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).

Make sure your app includes at least one extension. You can build most extensions using one of Wix’s development frameworks, though some extensions can be added simply by [configuring them in your app's dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).

Learn more about [self-hosted app extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions).

## See also

* [About the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard)
* [About Self-hosting for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps)
* [Tutorial | Create a Self-Hosted App](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-a-self-hosted-app)
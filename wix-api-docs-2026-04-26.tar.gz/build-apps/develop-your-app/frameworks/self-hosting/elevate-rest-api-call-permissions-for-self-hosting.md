---
portal: build-apps
name: "Elevate REST API Call Permissions for Self-hosting"
type: ARTICLE_RESOURCE
resourceId: dc9622bf-5727-4eb6-9b67-6c5127799337
---

# Elevate REST API Call Permissions for Self-hosting

# Elevate REST API Call Permissions with Self-Hosting

In workflows that use mostly [site visitor](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#site-visitors), [site member](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#site-members), or [Wix user](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#wix-users) authentication, you may occasionally need to call APIs that require the elevated level of a [Wix app](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#wix-apps) identity for authentication. This can happen when coding in a frontend environment such as a [site extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) or a [dashboard extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions).

The process involves two steps: 
1. Setting up your app's backend code to handle requests that require Wix app permissions.
1. Sending an authenticated call from your frontend code to your app's backend.

<blockquote class="important">

**Important:** Exposed elevated function calls create a security risk for [privilege escalation attacks](https://en.wikipedia.org/wiki/Privilege_escalation). Make sure to protect your exposed function calls with the appropriate logic.

</blockquote>

To elevate permissions for API calls:

## Step 1 | Set up your app's backend

The first step is to set up your app's backend to handle requests for API calls from your frontend.

To set up your backend:

1. Set up an endpoint to receive HTTP requests. In your endpoint's code, extract the `authorization` header from incoming requests. When you send requests to the endpoint from your frontend code, this header's value will be an access token that includes authentication data for the site visitor or member.

1. Retrieve the [app `instanceId`](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances) from the access token. In your endpoint code, call Wix's [Token Info](https://dev.wix.com/docs/rest/app-management/oauth-2/token-info) endpoint. The response includes the `instanceId`.

    ```curl
    curl -X POST ֿ
      'https://www.wixapis.com/oauth2/token-info' 
      --d '{
        "token": "<token>"
      }'
    ```

1. Create an access token with a Wix app identity. In your endpoint code, call Wix's [Create Access Token](https://dev.wix.com/docs/rest/app-management/oauth-2/create-access-token) endpoint and include your `instanceId` in the request body. The response includes an `accessToken` with a Wix app identity.

    ```curl
    curl -X POST ֿ
      'https://www.wixapis.com/oauth2/token' 
      -H 'Content-Type: application/json'
      --d '{
         "instance_id": "<instanceId>"
         "grant_type": "client_credentials",
         "client_id": "<app_id>",
         "client_secret": "<app_secret_key>",
       }'
    ```

1. In your endpoint code, use the access token to authorize calls to endpoints that require a Wix app identity for authentication.


## Step 2 | Send authenticated requests from your frontend

Next, use the Wix [JavaScript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk) to send authenticated requests from your site's frontend code to your backend endpoint.

To send requests:

1. In your app's frontend code, import `createClient()` from the `@wix/sdk` package as well as the relevant [host module](https://dev.wix.com/docs/sdk/host-modules/about-host-modules).
   ```js
   import { createClient} from '@wix/sdk';
   // Include one of the following:
   import { dashboard } from "@wix/dashboard";
   import { editor } from "@wix/editor";
   import { site } from "@wix/site";
   ```
1. Create an SDK client using the `auth()` and `host()` functions from the appropriate host module.
   ```js
   const wixClient = createClient({
     auth: < dashboard.auth() | editor.auth() >,
     host: < dashboard.host() | editor.host() | site.host() >
   });
   ```
1. Use the client's [`fetchWithAuth`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client#fetchwithauth) function to make calls to your app's backend endpoint. This function automatically signs API calls with an authorization header that identifies the current site visitor or member. 
   ```js
   const response = await wixClient.fetchWithAuth(`https://my-backend.com/apis/func`);
   ```

## See also
+ [About Elevated Permissions](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-elevated-permissions)<!-- + [Elevate API Call Permissions with the CLI](https://dev.wix.com/docs/wix-cli/guides/development/elevate-api-call-permissions) -->
+ [Elevate SDK Call Permissions with Self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/elevate-sdk-call-permissions-with-self-hosting)
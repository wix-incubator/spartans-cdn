---
portal: build-apps
name: "Elevate SDK Call Permissions with Self-hosting"
type: ARTICLE_RESOURCE
resourceId: 3bc802db-7784-4fdf-bead-3b2e861457b0
---

# Elevate API Call Permissions with Self-hosting

# Elevate SDK Call Permissions with Self-Hosting

In workflows that use mostly [site visitor](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#site-visitors), [site member](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#site-members), or [Wix user](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#wix-users) authentication, you may occasionally need to make calls with [elevated permissions](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-elevated-permissions). You can use the [JavaScript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk) to provide specific calls with [Wix app](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#wix-apps) authentication.

The process involves two steps: 
1. Setting up your app's backend code to handle elevated requests.
1. Sending an authenticated call from your frontend code to your app's backend. Frontend code includes [site extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) and [dashboard extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions) code.

<blockquote class="important">

**Important:** Exposed elevated function calls create a security risk for [privilege escalation attacks](https://en.wikipedia.org/wiki/Privilege_escalation). Make sure to protect your exposed function calls with the appropriate logic.

</blockquote>

To elevate permissions for API calls:

## Step 1 | Set up your app's backend

The first step is to set up your app's backend to handle requests for elevated function calls from your frontend.

To set up your backend:

1. In your code file, import the following:
    + `createClient` and `AppStrategy` from the Wix SDK module. 
    + The SDK module containing the function that you want to make elevated calls to. 
    + Express
    ```js
    import { createClient, AppStrategy } from '@wix/sdk';
    import { <module> } from '@wix/<package>';
    import express from "express";
    ```
    > **Note:** You can use your preferred method to expose HTTP functions from your self-hosted backend. For this example, we used the [express](https://www.npmjs.com/package/express) NPM package.
1. Set up an endpoint. In your endpoint's code, extract the `authorization` header from incoming requests. When you send requests to the endpoint from your frontend code, this header's value will be an access token that includes authentication data for the site visitor or member.
   ```js
   const app = express ();
   
   app.get('/func', (req, res) => {
     const accessToken = req.headers['Authorization'];
   });
   ```
1. In your endpoint code, use [`createClient()`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client#createclient) to create a client that can make authenticated SDK calls. Use [`AppStrategy`](https://dev.wix.com/docs/sdk/core-modules/sdk/app-strategy) to construct the `auth` value for your `createClient()` call. Chain a call to `elevated()` to your call to the `AppStrategy` constructor. Your `createClient()` call should include your app ID, app secret key, access token, and SDK module. You can find your app ID and app secret key in your [app's dashboard](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Foauth). 
   ```js
    const elevatedClient = createClient({
      auth: await AppStrategy({
        appId: "YOUR_APP_ID",
        appSecret: "YOUR_APP_SECRET",
        accessToken: accessToken
      }).elevated(),
      modules: {
        <module>
      }
    });
   ```
   This call to `createClient()` returns a client that can make API calls with Wix app authentication. To make calls with site visitor or site member authentication, create a second client without using `elevated()`.
1. Use the client to make elevated calls to the functions of the SDK module.
   ```js
   elevatedClient.<module>.<function>()
   ```

## Step 2 | Send authenticated requests from your frontend

Next, send authenticated requests from your site's frontend code to your backend endpoint.

To send requests:

1. In your app's frontend code, import `createClient()` as well as the relevant [host module](https://dev.wix.com/docs/sdk/host-modules/about-host-modules).
   ```js
   import { createClient} from '@wix/sdk';
   // Include one of the following:
   import { dashboard } from "@wix/dashboard";
   import { editor } from "@wix/editor";
   import { site } from "@wix/site";
   ```
1. Create an SDK client using the `auth()` and `host()` functions from the appropriate host module.
   ```js
   const wixClient = createClient({
     auth: < dashboard.auth() | editor.auth() >,
     host: < dashboard.host() | editor.host() | site.host() >
   });
   ```
1. Use the client's [`fetchWithAuth`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client#fetchwithauth) function to make calls to your app's backend endpoint. This function automatically signs API calls with an authorization header that identifies the current site visitor or member. 
   ```js
   const response = await wixClient.fetchWithAuth(`https://my-backend.com/apis/func`);
   ```


## See also
+ [About Elevated Permissions](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-elevated-permissions)<!-- + [Elevate API Call Permissions with the CLI](https://dev.wix.com/docs/wix-cli/guides/development/elevate-api-call-permissions) -->
+ [Elevate REST API Call Permissions with Self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/elevate-rest-api-call-permissions-for-self-hosting)
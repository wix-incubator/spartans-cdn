---
portal: build-apps
name: "About Self-Hosted App Extensions"
type: ARTICLE_RESOURCE
resourceId: f3a493a7-9f04-4462-bdc5-d3266868346e
---

# About Self-Hosted App Extensions

# About Self-Hosted App Extensions
  
Self-hosted extensions are app features that are hosted on an external platform and integrated with the Wix ecosystem using the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard). Your app can combine multiple extensions to provide a comprehensive service that spans across several user interfaces and backend capabilities. Browse the [extensions catalog](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#extension-catalog) to explore available extensions.

Learn more about [How Apps Extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).

## Building and adding self-hosted extensions

Use your preferred development environment and tools to build your extension. Once it's ready, host it on any platform that exposes public, secure endpoints. Finally, add it to your app by configuring it in your [app's dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard).

Learn more about [self-hosting for Wix apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps).

## Supported extension types

Self-hosted apps currently support the following extensions:

### Site extensions

+ [Embedded scripts](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension-to-a-self-hosted-app)
+ [Site widgets with custom elements](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/site-widgets-and-plugins/add-self-hosted-site-widget-extensions-with-custom-elements)
+ [Site plugins with custom elements](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/site-extensions/site-widgets-and-plugins/add-self-hosted-site-plugin-extensions-with-custom-elements)

### Dashboard extensions

+ [Dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-page-extensions)
+ [Dashboard modals](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-modal-extensions)
+ [Dashboard plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/add-self-hosted-dashboard-plugin-extensions)

### Backend extensions

+ [Service plugins with the JavaScript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/backend-extensions/add-self-hosted-service-plugin-extensions-with-the-sdk)
+ [Service plugins with REST](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/backend-extensions/add-self-hosted-service-plugin-extensions-with-rest)

## See also

* [How Apps Extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix)
* [About the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard)
* [About Self-hosting for Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps)
* [Mapping your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
---
portal: build-apps
name: "Add Self-hosted Dashboard Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 3c6016cd-50c3-4dba-972b-21ecd3cb8023
---

# Add Self-hosted Dashboard Plugin Extensions

# Add Self-hosted Dashboard Plugin Extensions

This article describes how to add a [dashboard plugin extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions) using the [app dashboard](https://dev.wix.com) and how to connect the extension to your plugin.

> **Note:** For a more streamlined approach to developing your dashboard plugin, try out the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extensions) instead of self-hosting.


The end result will look like this:

![Dashboard plugin extension](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7793e5d7e5c4d594f7d08802aab6ee9b.png)


## Before you begin 

- Instruct your users to install the app built by Wix on their site before installing your app.
- Use an existing app or create a new one in the app dashboard. 

## Add a dashboard plugin

1. Select an app from the [Custom Apps page](https://manage.wix.com/account/custom-apps) in your Wix Studio workspace. 

1. Go to [**Extensions**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions) and click **+Create Extensions**.

1. Search for the **Dashboard Plugin** extension, and click **+ Create**.

1. Fill in the JSON editor with your plugin’s details. This configuration is how you integrate your plugin with Wix’s dashboard pages. Details include the name of the plugin, the size of the plugin, the slot ID of the dashboard page to place your plugin, and the URL that hosts your plugin. Use the following properties, also listed in the ** Documentation** tab on the right of the JSON editor, to fill in the JSON. 
 
      <!-- https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots -->

    | Field | Description |
    | ----- | ----------- |
    | `hostingPlatform`  | **Required.** Wix platform that hosts the plugin extension.     |
    | `extends`	         | **Required.** [Slot ID](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) for the slot your extension plugs in to.	            	                                        |
    | `description`	     | Description of the plugin.                                       | 
    | `title`		         | Title of the plugin.	  				    	                            |
    | `width` 	         | Initial width of the plugin in pixels while loading. Width may be adjusted dynamically based on the content of the plugin and/or limited by the size of the slot container.    |
    | `height` 	         | Initial height of the plugin in pixels while loading. Height may be adjusted dynamically based on the content of the plugin and/or limited by the size of the slot container.    |
    | `iframeUrl`	       | **Required.** The URL of the iframe that renders the plugin.	    |
    | `componentName`    | Name for the plugin extension that appears in the app dashboard.	 	  | 
    
    &nbsp;
  
    <blockquote class="important">
       
    __Important:__
    The hosting platform must always be "BUSINESS_MANAGER".
       
    </blockquote>
    
    Below is an example of how your plugin configuration could appear in the JSON editor.
    ```json
    {
      "hostingPlatform": "BUSINESS_MANAGER",
      "iframeUrl": "https://example.com/plugin",
      "title": "Example Plugin",
      "width": 600,
      "height": 400,
      "componentName": "My Dashboard Plugin"
    }
    ```

1. Click Save. 

## Interacting with the dashboard page

Now that your dashboard plugin is set up, you can write code that allows your plugin to interact with the dashboard page. This can be done with the `observeState()` function from the [dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/observe-state).

The `observeState()` function allows you to retrieve contextual data from the dashboard page hosting your plugin:

1.  Make sure the `@wix/dashboard`, package is installed in your app. 

1. Add the following import statements to your code: 
    ```js
    import { dashboard } from '@wix/dashboard';
    import { createClient } from '@wix/sdk';
    ```

1. Create a client constant using the dashboard module. This allows you to interact with the dashboard page.  

    ```js
    const client = createClient({
      host: dashboard.host(),
      auth: dashboard.auth(),
      modules: {
        dashboard,
      },
    });
    ```

1. To retrieve the data from the dashboard page, use the `observeState()` function. 

    ```js
    client.dashboard.observeState((componentParams) => {
      console.log("componentParams:", componentParams);
    });
    ```


## See also

- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
- [About Dashboard Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [Add Dashboard Menu Plugin Extensions in the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions)
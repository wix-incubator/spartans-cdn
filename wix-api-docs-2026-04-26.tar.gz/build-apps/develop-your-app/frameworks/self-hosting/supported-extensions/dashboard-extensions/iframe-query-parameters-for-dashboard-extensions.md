---
portal: build-apps
name: "iframe Query Parameters for Dashboard Extensions"
type: ARTICLE_RESOURCE
resourceId: 4bbb9114-8bdf-455e-8347-61add5421b7f
---

# iframe Query Parameters for Dashboard Extensions

# iframe Query Parameters for Dashboard Extensions

When a user accesses your self-hosted iframe dashboard extension through a client-side action, Wix provides you with the following query parameters:

```bash
[endpoint]?instance=[signed-instance-data]&locale=[locale]&cacheKiller=[cacheKiller]&viewMode=dashboard&isPublish=[isPublish]&containerProtocol=[httpProtocol]&siteUrl=[site-url]
```

| Name | Value | Comments |
|--|--|--|
| ```endpoint``` | The [Dashboard URL](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions), as provided in your app's dashboard. |
| ```instance``` | The [signed app instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances). | The app instance ID (```instanceId```) is the unique identifier of your app within a specific user's website. |
| `locale` | Current local value. | This is the browser's language identified with two characters. For example, English = `en`. |
| ```cacheKiller``` | Ensures no caching of the iframe content by the host browser. | This is a randomly generated number to ensure the browser hasn't seen this URL before. |
| ```viewMode``` | Will only get 'dashboard' as it's an iframe dashboard extension. |
| ```isPublish``` | Boolean indicating if the site is published. |
| ```containerProtocol``` | Indicates if it's HTTP or HTTPS. |
| ```siteUrl``` | The address of the site to which the app belongs. | Relevant only if the site has already been published. |
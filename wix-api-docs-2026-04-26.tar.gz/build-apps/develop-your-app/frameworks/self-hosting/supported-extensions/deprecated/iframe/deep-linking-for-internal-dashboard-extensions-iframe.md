---
portal: build-apps
name: "Deep Linking for Internal Dashboard Extensions (iframe)"
type: ARTICLE_RESOURCE
resourceId: 4dab0dcf-1510-440a-8d23-cf6f788b6d39
---

# Deep Linking for Internal Dashboard Extensions (iframe)

# Deep Linking for Internal Dashboard Extensions (iframe)

> **Note:** If you experience problems with deep linking, [contact us](https://www.wix.com/support-chatbot?nodeId=25a57397-ccf7-4376-8b74-48d51edf7159&referral=devRels).

An internal dashboard extension supports deep linking for its internal pages. Deep linking enables your app to update the content of your iframe without refreshing the whole iframe.

Your dashboard extension changes its state using JavaScript and AJAX methods. After the dashboard extension changes its state, it notifies the host website using the `relativeUrl` parameter of JavaScript Dashboard SDK's [`navigate()`](https://dev.wix.com/docs/sdk/host-modules/dashboard/navigate) function. This call will not reload your iframe. Wix will update the top window App-state part of the URL.

## Example

If the browser is showing this URL: ```http://www.wix.com/my-account/site/<metaSite>/app/<appID>?queryParams``` when you call the method: ```Dashboard.pushState(“AppState”)``` the browser URL will change to ```http://www.wix.com/my-account/site/<metaSiteId>/app/<appID>?queryParams&appState=<appState>``` but your Dashboard iframe will not reload.

When there is a request to render your Dashboard iframe with an internal state, Wix will call your Dashboard endpoint with the internal state as part of the iframe’s URL in the app-state path variable. You should load your dashboard extension at the intended internal state.

## Example

When a user clicks on a link with a URL such as: ```http://www.wix.com/my-account/app/<appID>/<AppInstanceID>/<appState>``` we will load your Dashboard iframe using the URL: ```http://www.yourApp.com/<appState>```

> **Note:** If you want to notify a user about something that happened in your app or an action they should take, you can direct them to your app in a specific Wix site. Use the following URL: ```https://www.wix.com/my-account/app/<appID>/<appInstanceID>/<appState>```.
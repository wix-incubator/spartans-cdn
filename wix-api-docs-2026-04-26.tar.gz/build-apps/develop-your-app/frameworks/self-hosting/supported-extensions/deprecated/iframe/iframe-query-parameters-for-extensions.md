---
portal: build-apps
name: "iframe Query Parameters for Extensions"
type: ARTICLE_RESOURCE
resourceId: e127b938-450d-4fe3-bed8-873542a290e9
---

# iframe Query Parameters for Extensions

# iframe Query Parameters for Extensions

<blockquote class="warning">

**Warning:** The features discussed in this article are deprecated. If you're looking for information related to dashboard extensions, see [iframe Query Parameters for Dashboard Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/dashboard-extensions/iframe-query-parameters-for-dashboard-extensions). If you have questions or concerns, [contact us](https://www.wix.com/support-chatbot?nodeId=25a57397-ccf7-4376-8b74-48d51edf7159&referral=devRels).

</blockquote>

## Widget extension

```bash
[endpoint]?compId[compId]&viewMode=[viewMode]deviceType=[device]&locale=[locale]&originCompId[originCompId]&width=[width]?instance=[signed-instance-data]
```

|Name |Value |Comments |
|---|---|---|
|```endpoint```|The Widget URL as supplied during the app registration in your app's dashboard|
|```compId```|The ID of the Widget extension|While the instanceId remain constant within the scope of the site, each iframe will have a unique and persistent compId
|```viewMode```|Current view mode|"editor" or "site". "editor" is valid inside the Wix editor, while "site" is available only in a published website
|```deviceType```|Current device type|"desktop" or "mobile"
|```locale```|Current locale value|
|```originCompId```|ID of the original widget that the user copied (or cut)|When a user copies (or cuts) a widget, this query parameter appears in the pasted widget. Use it to retrieve the original widget’s design, layout, and other settings
|```width```|The width of the iframe in pixels|
|```instance```|The [signed instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances#app-instance-id)|The App Instance ID (```instanceId```) is the unique identifier of your app within a specific user's website.

## Widget app settings panel

```bash
[endpoint]?instance=[signed-instance-data]&width=[width]&compId=tpaSettings&origCompId=[origCompId]&locale=[locale]
```

|Name |Value |Comments |
|---|---|---|
|```endpoint```|The App Settings URL as supplied during the app registration in your app's dashboard|
|```compId```|The compId value for the app settings is always **tpaSettings**|
|```instance```|The [signed instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances#app-instance-id)|The App Instance ID (```instanceId```) is the unique identifier of your app within a specific user's website.
|```locale```|Current locale value|
|```originCompId```|The ID of the extension which associated with the App Settings|The origCompId identifies the current extension that the user is editing
|```width```|The width of the iframe in pixels|

## Page extension

```bash
[endpoint]/[app-state]?&compId=[compId]viewMode=[viewMode]&deviceType[device]&locale=[locale]&width=[width]&instance=[signed-instance-data]&target=[target]&section-url=[section-url][endpoint]/[app-state]?instance=[signed-instance-data]&section-url=[section-url]&target=[target]&width=[width]&cacheKiller=[cacheKiller]&compId=[compId]&viewMode=[viewMode]&locale=[locale]&deviceType[device]
```

|Name |Value |Comments |
|---|---|---|
|```endpoint```|The Widget URL as supplied during the app registration in your app's dashboard|
|viewMode|Current view mode|"editor" or "site". "editor" is valid inside the Wix editor, while "site" is available only in a published website
|```deviceType```|Current device type|"desktop" or "mobile"
|```locale```|Current locale value|This is the browser's language identified with two characters. E.g., English = en
|```width```|The width of the iframe in pixels|The frame height will auto-adjust depending on the frame content
|```instance``|The [signed instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances#app-instance-id)|The App Instance ID (```instanceId```) is the unique identifier of your app within a specific user's website.
|```target```|Attribute that must be added to all href anchors within the Page iframe|
|```sectionUrl```|The base URL of the page extension|
|```app-state```|The inner state of the page extension|The app-state part of the URL may include a query string, but must not include a #
|```compId```|The ID of the extension|While the instanceId remain constant within the scope of the site, each iframe will have a unique and persistent compId

## Page app settings panel

```bash
[endpoint]?compId=tpaSettings&instance=[signed-instance-data]&locale=[locale]&origCompId=[origCompId]&width=[width]
```

|Name |Value |Comments |
|---|---|---|
|```endpoint```|The App Settings URL as supplied during the app registration in your app's dashboard|
|```compId```|The compId value for the app settings is always **tpaSettings**|
|```instance```|The [signed instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances#app-instance-id)|The App Instance ID (```instanceId```) is the unique identifier of your app within a specific user's website.
|```locale```|Current locale value|This is the browser's language identified with two characters. E.g., English = en
|```origCompId```|The ID of the extension which associated with the App Settings|The origCompId identifies the current extension that the user is editing
|width|The width of the iframe in pixels|

## Worker extension

```bash
[endpoint]?compId=[compId]&viewMode=[viewMode]&deviceType=[device]&locale=[locale]&endpointType=worker
&instance=[signed-instance-data]
[endpoint]?compId=[compId]&viewMode=[viewMode]&deviceType=[device]&locale=[locale]&endpointType=worker
&instance=[signed-instance-data]

```

|Name |Value |Comments |
|---|---|---|
|```compId```|The ID of the Worker extension|While the instanceId remain constant within the scope of the site, each iframe will have a unique and persistent compId
|```viewMode```|Current view mode|"editor" or "site". "editor" is valid inside the Wix editor, while "site" is available only in a published website
|```deviceType```|Current device type|"desktop" or "mobile"
|```locale```|Current locale value|
|```endpointType```|The Worker URL as supplied during the app registration in your app's dashboard|
|```instance```|The [signed instance](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances#app-instance-id)|The App Instance ID (```instanceId```) is the unique identifier of your app within a specific user's website.
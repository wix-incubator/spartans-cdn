---
portal: build-apps
name: "Set Your iframe Dimensions"
type: ARTICLE_RESOURCE
resourceId: 5c49c573-fe9e-44af-b4a2-e6146c68e1f8
---

# Set Your iframe Dimensions

# Set Your iframe Dimensions

You set the default size of the iframe extension in the [app dashboard](https://dev.wix.com/apps). Users can change the size of the extension by resizing the iframe inside the editor, just like other Wix elements.

To detect the size of the iframe, use the window resize event. Make your app responsive and change the layout of the extension according to the new size.
---
portal: build-apps
name: "Test a Webhook Locally for Self-hosting"
type: ARTICLE_RESOURCE
resourceId: 74b024d9-77ec-4d0d-9db5-3d6eb8425005
---

# Test a Webhook Locally

# Test a Webhook Locally for Self-hosting

To test a webhook locally, you need to use a network tunneling solution to redirect external traffic to a locally hosted endpoint. This article explains how to test your webhook handler using [ngrok](https://ngrok.com/), a widely adopted networking tunneling tool. However, you can use any tunneling solution of your choice.

In the Webhooks page of the app dashboard, each webhook includes a code sample to assist you in developing your webhook handler. These samples are configured to handle webhook events using an Express server. If you already have this sample, skip to [test your handler](#step-2--test-your-handler). Otherwise, [get a code sample](#step-1--get-a-code-sample).

## Step 1 | Get a code sample

To get a code sample for an existing webhook:

1. Select your app from the [Custom Apps page](https://manage.wix.com/studio/custom-apps) in your Wix Studio workspace. 
1. From the side menu, click **Webhooks**.
1. Next to the relevant webhook, click on the menu icon, and select **View code sample**. 

    ![View code sample](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ffdd6202e5c99c0324d4633ecaee69cb.png)

## Step 2 | Test your handler

To locally test your webhook handler without deploying your server:

1. Install and configure ngrok on your local machine. For guidance, see the [ngrok quickstart](https://ngrok.com/docs/getting-started/).

1. Start your webhook handler. To start the handler from the code sample, run the following command:

    ```bash
    node server.js
    ```

    This action starts the webhook handler on the local port 3000.

1. Start ngrok and expose the same port as your handler. For example:

    ```bash
    ngrok http http://localhost:3000
    ```

    If your handler isn't listening on port 3000, substitute `3000` with the relevant port number.

1. Once ngrok is running, copy the **Forwarding** URL provided in the terminal output.

1. In the Webhooks page of your app's dashboard, click on the menu icon next to the relevant webhook and select **Edit callback URL**. 

1. In the **Callback URL** field, paste the ngrok **Forwarding** URL followed by the endpoint of your handler. In the provided code sample, the endpoint is `/webhook`.
    
    > **Note:** Restarting ngrok generates a new **Forwarding** URL. In such instances, ensure to update the **Callback URL** accordingly.

1. Click **Trigger a test**.
 
If using the code sample provided with the webhook, the handler should output the payload of the received webhook call.
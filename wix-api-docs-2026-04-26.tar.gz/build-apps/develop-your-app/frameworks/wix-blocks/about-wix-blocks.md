---
portal: build-apps
name: "About Wix Blocks"
type: ARTICLE_RESOURCE
resourceId: 20c11ca2-7505-4d2d-b393-a271d509363e
---

# About Wix Blocks

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# About Wix Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Wix Blocks is an editor for designing, coding and deploying native Wix apps. It lets you build site and dashboard extensions using Wix’s drag-and-drop editor, with its powerful layout and design tools, and [add logic and APIs](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-coding-in-blocks). Your code is deployed and hosted on the Wix cloud, with no additional costs or setup by you.

[<button class="wix-button">Start Creating
</button>](https://manage.wix.com/account/custom-apps)

![Blocks gif](https://wixmp-833713b177cebf373f611808.wixmp.com/images/90727235007485ba800d68c90d3a5779.gif)

## Extend Wix using Blocks

Blocks apps can add functionality to various parts of the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem), such as adding a page to a site’s dashboard or a widget to a site page. Each specific type of functionality that an app can provide is called an extension.  
Learn more about the types of [extensions that are supported on Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/supported-extensions/about-extensions-in-blocks).

## When you need custom UI

Blocks is a composition tool that lets you rapidly create drag and drop UI from native Wix elements. If you are looking to create a rich custom visual representation, that dynamically adds elements to a widget in flexible locations, you can use one of the following options:
* Create a [Custom Element](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-custom-elements-in-blocks) to embed in Blocks
* Or, use the [Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) to write your UI code

Learn more about [Choosing your framework](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks). 

## Access Blocks from anywhere

There are several entry points across Wix's user interfaces for creating and opening Blocks app, including your Wix Studio workspace, the Wix apps templates page and the Wix Editor. 
Learn more about [how to access Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/create-a-blocks-app-and-open-it).

## Make your app public

You can build Blocks apps [for your own use or for sharing](https://dev.wix.com/docs/build-apps/get-started/overview/exposing-apps-publicly-and-privately). If you’re building an app for the Wix App Market, you'll have to set up your App Market listing, create promotional assets to showcase your app, and set up your app’s pricing plans to start making money. Finally, you'll need to submit your app for review so Wix’s team can check that everything’s working as it should.   
Learn more about [publishing a Blocks app to the App Market](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/publish-a-blocks-app-to-the-app-market).

## Get started with Blocks

Master Blocks quickly with the help of these articles and resources:

* [Blocks Unboxed](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/blocks-unboxed-a-quick-tour): A quick tour of the Blocks editor and what it can do.
* [Blocks app workflow](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/a-blocks-app-workflow): An overview of the stages involved in building a Blocks app from start to finish.
* [Blocks app tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials#blocks-app-tutorials): Gain practical experience by building a working Blocks app through our detailed tutorials.
* [Blocks templates](https://dev.wix.com/apps-templates?filter=blocks): Jumpstart your app with ready-made Blocks templates.
* [Blocks Glossary](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/wix-blocks-glossary): Learn about the different terms you'll encounter when using Blocks.
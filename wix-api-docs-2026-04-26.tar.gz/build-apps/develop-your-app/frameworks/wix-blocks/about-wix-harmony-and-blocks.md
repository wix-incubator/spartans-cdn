---
portal: build-apps
name: "About Wix Harmony and Blocks"
type: ARTICLE_RESOURCE
resourceId: ade634f1-f973-4da0-b153-a690eae19e8f
---

# Wix Harmony and Blocks

# About Wix Harmony and Blocks

Wix Harmony is Wix's new AI-powered site editor, built on a technical architecture that's different from previous editors. While Harmony introduces powerful new AI-driven features for site creation, its new foundation also changes how apps and extensions work.

Wix Blocks apps aren't compatible with sites built on Wix Harmony. Your existing Blocks apps will continue to work and remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites.

This article explains what Harmony means for Blocks developers and walks you through your options for building and supporting apps across the different Wix editors.

> **Note:** If you're developing Wix sites with Velo or the JavaScript SDK, see [About Wix Harmony](https://dev.wix.com/docs/develop-websites-sdk/get-started/overview/about-wix-harmony).

## App compatibility at a glance

The following table shows which Blocks extensions work in each editor.

> **Note:** App discovery in Harmony works differently than in other editors.

| Extension type    | Wix Harmony | Wix Editor & Wix Studio |
| ----------------- | :---------: | :---------------------: |
| Dashboard pages   | ✓           | ✓                       |
| Dashboard plugins | ✓           | ✓                       |
| Dashboard modals  | ✓           | ✓                       |
| Site widgets      | —           | ✓                       |
| Site plugins      | —           | ✓                       |

## What this means for existing apps

Your app's availability in Harmony depends on the types of extensions it includes:

- **Dashboard extensions only:** Your app works in Harmony with no changes required. However, for new apps, we recommend using the [Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) or [self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting) to build apps that work across all Wix editors.
- **Site widgets or site plugins:** Your app works on Wix Editor and Wix Studio but not in Harmony. To support Harmony users, rebuild these extensions with the [Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) or [self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting).

## Build site extensions for Wix Harmony

To create site extensions that work across all Wix editors, including Harmony, use one of these approaches:

- **Wix CLI:** Build app extensions using your preferred IDE, local development, and full control over your code. For site extensions, use [embedded scripts](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/about-embedded-scripts) or [site widgets](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/add-a-site-widget-extension). Learn more in the [Wix CLI documentation](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli).
- **Self-hosting:** Deploy your app on your own infrastructure and tech stack. Learn more about [self-hosted extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions).

## For private app developers

If you've built a [private app](https://dev.wix.com/docs/build-apps/get-started/overview/exposing-apps-publicly-and-privately) with Blocks for specific Wix sites, the same compatibility rules apply. Your app continues to work on sites built with Wix Editor and Wix Studio. However, if your client creates a new site using Harmony, your app won't be available on that site.

To ensure your app works across all editors, consider rebuilding site extensions with the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) or [self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting).

## Get support

Our support team is here to answer your questions and concerns. Feel free to [reach out to us directly](https://www.wix.com/support-chatbot?nodeId=25a57397-ccf7-4376-8b74-48d51edf7159&referral=devRels) or in our [Discord community](https://discord.gg/wixdevs).

## See also

- [About Wix Harmony and Apps](https://dev.wix.com/docs/build-apps/get-started/overview/wix-harmony-and-apps)
- [About Wix Harmony](https://dev.wix.com/docs/develop-websites-sdk/get-started/overview/about-wix-harmony)
- [Choose the Right Wix Framework](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/choose-the-right-wix-framework-for-your-app-development-needs)
---
portal: build-apps
name: "About CMS Collections in Blocks"
type: ARTICLE_RESOURCE
resourceId: 2492ee95-7d97-4f81-9741-c59b14f045b6
---

# About Collections

# About CMS Collections in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Wix Blocks lets you integrate CMS database collections into your app seamlessly. While managing collections in Blocks shares similarities with [managing collections in Wix sites](https://support.wix.com/en/article/cms-content-management-system-an-overview), there are a few key differences. Explore these distinctions in detail in this article.

<blockquote class="tip">
  <strong>Examples:</strong>
  
  To see examples of collections in Blocks, open the following templates and go to the **Databases**  ![databases icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/06/15/929245d2-3a89-445f-996b-623326b4b81f/1a31bddc-febf-451e-a716-773572239804.png)  tab. 

  - [Repeater](https://dev.wix.com/apps-templates/template?id=a4a7246f-4644-48ce-81e7-2a86aa74d9e5&http_referrer=documentation)
  - [Recipe list](https://dev.wix.com/apps-templates/template?id=512a7d8a-1666-40c2-9586-25874d2f69b4&http_referrer=documentation)
</blockquote>

<blockquote class="important">

<strong>Important:</strong>

- Be mindful of [collection permissions](#permissions) and follow their [security guidelines](https://dev.wix.com/docs/develop-websites/articles/best-practices/security-best-practices).  
- How Blocks collections affect a [site's collection item limit](https://support.wix.com/en/article/wix-studio-cms-limits-on-free-sites) depends on whether the app is private or public:
  - **Private Blocks apps**: Items in collections from private Blocks apps count towards the site's collection item quota.
  - **Public Blocks apps**: Items in collections from public Blocks apps, installed from the Wix App Market, don't count towards the site's collection item quota.
- When a Blocks app is installed on a site, whether a private or a public app, data requests made by the app are subject to the site's requests per minute (RPM) limits, not the app's limits. 
- You can also ask the [Blocks AI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/about-the-blocks-ai) to add and edit collections in your app. 

</blockquote>

## A Blocks collection is a placeholder

The most important thing to understand about a Blocks collection is that it is a placeholder for the data of any site it's installed on. This is because a Blocks collection can be used on multiple sites. These sites can be very different from each other and have their own databases. Think about a collection that holds customer information. Every site can have a list of their own customers, and your widget can apply to all of them.

When you create a collection in Blocks, you define the fields of the collection, and make it possible to refer to it in the app's code. You can also add default data in Blocks, but you don’t have to. If you do add default data, it is automatically installed on the site together with the app, and can later be replaced by data from any site the app is installed on. 

If you change the structure of a collection in Blocks in a future version of your app, it impacts any site it's installed on. So work with caution and don't make changes that can break sites.  

## About the default data

Data that you add to your  Blocks collections will be imported to the site in which your app is installed, providing your site creators with default data for your app. If you choose to add default data, note that:

* The site your app is installed on can change that data later.
* The default data will only be imported in the first installation. If you release a new version of your app and change the data in the collection, it will not override the data that already exists in any site your app is installed on.

## Add a collection to your app

To add a collection to your app:

1.  Click the **CMS**  ![databases icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/06/15/929245d2-3a89-445f-996b-623326b4b81f/1a31bddc-febf-451e-a716-773572239804.png)  icon in your app's left menu. 
2.  Click **Create Collection**.
3.  Create a unique [namespace](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/creating-a-namespace-for-your-app) for you app, if you haven't already done it. Make the namespace meaningful and clear (if you haven't named your app yet, you will be triggered to name it now). 
4.  Name your collection.
5.  Define the structure of your collection in the **CMS**. 
6.  Optional - add default data to your collection. 

## See your collection in the editor

When you import a Blocks app that has a collection to your site, the collection will appear in the **Content Collections** section in the **CMS**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/06/16/58327a82-cb4e-4e52-8d36-fe45ba37926c/afb48575-c883-4145-94b8-8b95d0b2327f.png)  panel. Your app namespace will appear next to this collection, to indicate that it's from Blocks. From now on you can [handle your collection](https://support.wix.com/en/content-manager/content-collections) like in any other Wix site. 

<blockquote class="important">

<strong>Important:</strong>
If you delete the app from the site, the collection will be deleted as well.

</blockquote>

## Reference collection data in code

To access your collection and perform various actions, query, insert, etc, use the following syntax with the [`items`](https://dev.wix.com/docs/sdk/backend-modules/data/items/introduction) submodule in the `data` SDK module. For example, this is how you query a collection (note that `@wix/data` cannot be tested in Blocks Preview and must be tested on a site):

```js
import { items } from "@wix/data";

$w.onReady(async function() {
  try {
    const results = await items
      .query("@username/my-app/MyCollection")
      .find();
    // your code using the "results"
  } catch (err) {
    console.log(err);
  }
});
```

<details>
<summary>See deprecated wix-data code example</summary>

You can also use the deprecated [wix-data Velo API](https://dev.wix.com/docs/develop-websites/articles/databases/wix-data/data-api/working-with-the-data-api) for this purpose:

```js
import wixData from 'wix-data';

$w.onReady(async function() {
  try {
    const results = await wixData
      .query("@username/my-app/MyCollection")
      .find();
    //your code using the "results";
  } catch (err) {
    console.log(err);
  }
});
```
</details>

## Use collection data with data-binding

Use data-binding to connect an element to a collection field, or let site-builders connect it themselves. This can be done easily [without code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-elements-to-collection-fields-with-no-code).

## Reference a site collection through the app code

You might want to reference a collection on your site directly from your widget code without adding it to Blocks. There are two ways to do this: 

* If you know the name and structure of the collection, you can use it in your widget code. For example, if Wix Stores is installed on the site, you can use the `Stores/Products` collection. Note that if the site is not under your account, you will need to add [app permissions](#app-permissions).

* You can pass the name of the collection or other information about the collection as properties in the [Widget API](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-properties).

## Permissions

There are two types of permissions to consider when building apps that handle collections. 

### Collection permissions
Collection permissions determine what users can do in a collection you created in Blocks, when your app is installed on their site. This means whether users can view, add, update or delete items in your collection.

To configure collection permissions, click the three dots next to the collection name and select **Permissions & privacy**.  

### App permissions
[App permissions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/add-app-permissions-in-blocks) determine what your app can do on a site collection that **does not belong to your app**. The specific permissions you need to add depends on the function you are using. For example, [query()](https://dev.wix.com/docs/sdk/backend-modules/data/items/query) requires the `READ DATA ITEMS` permission.

To configure app permissions, click on the **Wix Blocks** icon. Then click **App** > **App Permissions**.
---
portal: build-apps
name: "Connect Elements to Collection Fields With No Code"
type: ARTICLE_RESOURCE
resourceId: 3703a750-fa5a-45a4-9f85-c836ad381881
---

# Connect Elements to Collection Fields With No Code

# Connect Elements to Collection Fields With No Code (Data-Binding)

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

If you want to connect an element to a collection field, you must choose whether you want to connect it yourself from the app, or allow site-builders to connect this element on their own. For example if you build an app with complex logic that you need to control, you would probably use the first option. If you build a more design-oriented widget and want to give site-builders the freedom to connect any field they want to the design, your would use the second. 

Here are some details about these two options:

## Option 1: Connect an element to a collection in Blocks

You can connect an element to a collection field in Blocks, through adding a dataset. If you do this, note that: 

*   An outer widget cannot connect an [inner-widget’s](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Widgets%20Within%20Widgets.md*original::../Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Widgets%20Within%20Widgets.md) element to a dataset. You must go into the inner widget and connect the element from there.
*   If you connect an app’s element to a dataset, you cannot allow a site builder to connect this element to a collection on their site. Therefore, you will also not be able to add the **Connect to CMS**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/27/0529fe32-8e09-4f9b-be94-38010664296d/82eea2f5-fe57-423a-a0e3-78bfc698c647.png)  [action button](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/Configuring%20Action%20Bars.md*original::../Blocks:%20Configuration%20and%20Panels/Configuring%20Action%20Bars.md) to this element’s action bar. Note that the action button will be disabled and appear gray. 

<blockquote class="tip">
  <strong>Example:</strong>

Go to the [Repeater template](https://dev.wix.com/apps-templates/template?id=a4a7246f-4644-48ce-81e7-2a86aa74d9e5&http_referrer=documentation) to see an example of connecting elements to collection fields. The elements in this repeater are connected to the collection with no code. 
</blockquote>

### To connect an element to a field in Blocks:

1.  Go to the **Design** tab. 
2.  Click on the element.
3.  Click on the **Connect to CMS**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/28/35acad32-03ed-4ea0-a201-df5ebcc37ceb/eb371f17-e215-41bc-9260-64ac656eade4.png)  icon in the action bar. 
4.  Select a dataset, or add one if you haven't.
5.  Select the field to connect to your element. 

You can also [connect the elements through code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-a-dynamic-repeater-to-a-collection).

## Option 2: Allow site builder to connect the element on a site

You can also allow site builders to connect app elements to their site’s CMS through the **Connect to CMS**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/27/6486ca16-9aa9-4cde-940e-079b07b7a136/eaf5b199-e1ad-43ef-9119-5b83c274ff9d.png)  action button. If you choose to do this, note that:

*   Once the app is installed on user sites and they connect the element to their collections, if you connect the same element to your collection in Blocks, it will break the app’s functionality on their site. 
*   If you connected an element to your own collection in Blocks, you will not be able to add this action button to the element's action bar. 

### To allow site builders to connect the element on their site:

1.  Go to the **Editor Experience** tab. 
2.  Click on the element. 
3.  Click **Edit Action Bar**. 
4.  Click **\+ Add**.
5.  Add the **Connect to CMS**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/28/18d9df96-eb85-4a98-9de8-8d4e0669f9c1/a56d3008-5703-4034-9e50-bc22323f949f.png)  button and accept the notification. 

<blockquote class="standard">
  <strong>Note:</strong>

If your widget has [properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-properties), adding this button to the action bar of entire widget, allows site builders to connect the widget properties to their data. 

</blockquote>
---
portal: build-apps
name: "Dynamic Repeaters in Blocks"
type: ARTICLE_RESOURCE
resourceId: 81342578-ec70-4dab-842c-48e9e4a54acf
---

# Dynamic Repeaters in Blocks

# Dynamic Repeaters in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Dynamic repeaters are designed specifically for app building. Unlike standard repeaters used in site building, where you can edit each item individually directly on the canvas, dynamic repeaters require code or a connection to a CMS collection for content management. In dynamic repeaters, if you try to edit one item directly on the canvas, all items will be edited simultaneously. Dynamic repeaters also support advanced features like adding widgets or [nesting them](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/nest-dynamic-repeaters).


## Connect dynamic repeaters to collections without code

You can connect a dynamic repeater to a CMS collection using data binding without writing code. However, for nested repeaters, this method is only applicable to the outer repeater.

To connect a dynamic repeater to a collection without code:  
1. Select the repeater in your widget.  
2. Click the **Connect to CMS** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/28/35acad32-03ed-4ea0-a201-df5ebcc37ceb/eb371f17-e215-41bc-9260-64ac656eade4.png) icon.

Learn more about [connecting elements to collections without code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-elements-to-collection-fields-with-no-code).

> **Note:** If a connected dynamic repeater is nested inside another repeater, its data connection will be removed. In this case, reconnect the nested repeater using code.

## Connect dynamic repeaters to collections using code

Dynamic repeaters can also be connected to CMS collections programmatically using code. This gives you more control over the content being displayed. For example:

```javascript
import { items } from '@wix/data';

$w.onReady(async function() {
  try {
    const results = await items
      .query("@myuser/my-app-name/CollectionName")
      .find();
    $w("#repeater1").data = results.items;
  } catch (err) {
    console.log(err);
  }
});
```

<details>
<summary>See deprecated wix-data Velo example</summary>

```javascript
import wixData from "wix-data";

$w.onReady(async function() {
  try {
    const results = await wixData
      .query("@myuser/my-app-name/CollectionName")
      .find();
    $w("#repeater1").data = results.items;
  } catch (err) {
    console.log(err);
  }
});
```
</details>

This allows you to manipulate and update the data in the repeater based on the query results from your collection.

Learn more about [connecting dynamic repeaters to collections using code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-a-dynamic-repeater-to-a-collection).

## Add widgets to dynamic repeaters

To add a widget to a dynamic repeater:

1. Add a repeater to your widget.
2. Create another widget in your app.
3. Open the **Add +** panel and select **My Widgets**.
4. Drag the second widget into the repeater in the first widget until the Attach indication appears.
5. The second widget will now act as a [nested widget](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/add-nested-widgets-in-blocks) and will appear in all repeater cells.

If the nested widget contains its own repeater, refer to [nesting repeaters](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/nest-dynamic-repeaters) for additional guidance.

## Reference dynamic repeaters in code

Dynamic repeaters are referenced in code using the `$w` API, similar to standard repeaters. You can manipulate their data and appearance programmatically with the [`$w.Repeater`](https://dev.wix.com/docs/velo/velo-only-apis/$w/repeater/introduction) methods, which provide access to all repeater-specific functionality. This allows you to update and customize dynamic repeaters directly through your app's code.

## Nest dynamic repeaters

Dynamic repeaters support nesting, which can be done in two ways:

1. **Direct Nesting**: Drag one repeater directly into another. In this setup, the inner repeater can only connect to a collection through code.
2. **Nesting a Widget with a Repeater**: Create a widget that contains a repeater, then nest this widget inside another repeater.

<blockquote class="tip">
  <strong>Notes:</strong>

- Learn more about [Nesting dynamic repeaters](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/nest-dynamic-repeaters).
- Try out the [Coffee catalog tutorial](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-coffee-catalog-with-blocks), which uses nested dynamic repeaters.

</blockquote>

## Does Blocks also have standard repeaters?

You can no longer add standard repeaters in Blocks, as they are not available in the Add Panel. However, if you have older apps that include standard repeaters, they will continue to function as expected.

Keep in mind that standard repeaters have limitations: they cannot be nested or hold widgets. If you attempt to use any new features, such as nesting or adding widgets, a migration process will be triggered. This process converts all standard repeaters in your app into dynamic repeaters, enabling them to support these features.
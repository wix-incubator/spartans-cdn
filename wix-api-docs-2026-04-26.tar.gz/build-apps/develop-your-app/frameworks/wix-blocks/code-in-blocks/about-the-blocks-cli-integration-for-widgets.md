---
portal: build-apps
name: "About the Blocks-CLI Integration for Widgets"
type: ARTICLE_RESOURCE
resourceId: 3c24c90b-3d2e-4a75-9cc4-c59e362ab349
---

# About the Blocks-CLI Integration

# About the Blocks-CLI Integration for Widgets

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

<blockquote class="important">

**Important:** The Blocks-CLI integration only works with the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps). The new [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), which is the recommended tool for new app projects, doesn't support this integration.

</blockquote>

The Blocks-CLI integration offers a hybrid workflow that combines the **Blocks visual design** capabilities with the **CLI development** environment.

This integration currently supports only [widgets](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions). It does not support Blocks dashboard pages, plugins or collections.  

## Where to do what

Each framework serves a specific purpose in the workflow:

| In the CLI | In Blocks |
|--------|-----------|
| <ul> <li>Create an app and integrate it with Blocks</li> <li>Code widget logic</li> <li>Code custom panel logic</li> <li>Define widget API properties, functions, and events</li> <li>Test your app in the editor and on a site</li> <li>Release an app version</li> </ul> | <ul> <li>Add and design widgets</li> <li>Configure a widget’s editor experience</li> <li>Add and design custom panels</li> <li>Configure installation settings</li> <li>Preview a widget’s design</li> </ul> |

## Get started

First, make sure to set up your app and add a widget:

1. Create a new CLI app or use an existing CLI app project. [See guide](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/quick-start) 

2. Add a Blocks widget to your CLI app. [See guide](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/add-a-blocks-site-widget-extension-in-the-cli)


## Design and sync the UI in Blocks

When you've integrated your CLI project with Blocks, a **CLI Active** indication appears in the Blocks editor.

![blocks-cli](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b8d93224f12c69b8d64e6a5ffdc7ffff.png)

In the Blocks editor, you design your UI and configure your widgets' editor experience and installation settings:

* [Design your widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/blocks-widget-design-guidelines)  
* [Create custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks)  
* [Configure the editor experience](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/about-configuration-in-blocks)
* [Configure installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings)

Click **Sync** in Blocks to update the CLI environment with your latest UI changes. This does the following:

* Adds or deletes files for any widgets you added or removed.  
* Updates code-completion suggestions for newly-added UI elements.

You can sync as often as needed, as long as the local development environment is running in the CLI.

<blockquote class="tip">
<strong>Tip:</strong>

To define element IDs for selecting elements in your code, use the **Layers** ![layers](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/10/04/f7b41afc-940b-4dad-8570-be5a7c71ae97/38653f43-8499-4015-8f3f-37e02e5c3ec2.png) panel, as the **Properties and Events**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/07/26/b734f951-abe5-4735-b65f-76cf788f13d3/26127617-e23d-47ba-b183-225adc5775a2.jpg) panel isn't available in the Blocks-CLI integration.
 
</blockquote>

## Code and preview the app in the CLI

When using the CLI, you write your code in TypeScript and work with the Wix JavaScript SDK. The CLI does not support Velo APIs, and its code structure differs from widget and panel code in the Blocks editor.

From the CLI, you can preview and test your app in both the editor and the live site. The local development environment supports hot code reloading, so changes appear instantly in the browser.

For detailed instructions on coding and previewing your app in the CLI, see the [CLI documentation](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/add-a-blocks-site-widget-extension-in-the-cli).

## Release an app version

When your app is ready for production, you can [release an app version in the CLI](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli#build-and-deploy-an-app-with-the-cli). This  allows you to publish it to the Wix App Market or install it on a site with a direct install link or [through the editor](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/install-a-blocks-app-on-a-site).
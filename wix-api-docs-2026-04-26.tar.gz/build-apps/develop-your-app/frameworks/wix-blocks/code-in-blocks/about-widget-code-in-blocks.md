---
portal: build-apps
name: "About Widget Code in Blocks"
type: ARTICLE_RESOURCE
resourceId: 95221b0b-d215-48b6-a85a-9f75d1f2eb68
---

# About the Widget Code

# About Widget Code in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Widget code lets you add custom functionality to your widget and expose an external API. 

## What widget code is used for

Add code to your widget to provide the following:

* **Custom functionality and interactions**. Select widget elements using their IDs and bind them to code, work with Wix's frontend and backend APIs, and more.
* **Widget API**. Your [widget API](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/about-the-widget-api) lets you add properties, functions and events to the entire widget. These are exposed in the editor when your widget is installed on a site, or when it's nested inside another widget.

## Where to write widget code

Where you add your widget code varies according to the tools you are using. 

### Add widget code in the Blocks Editor

If you are working directly in the Blocks editor: 

- Make sure you selected the correct widget in the **App Interface** > **Widgets** panel. 
- Write your widget logic in the code panel in the bottom part of your screen.
- Click the **Widget API** ![widget API](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/9aa25a00-57bb-465d-b443-4e14a5478da3/67b8bc89-773d-4775-a0d5-b1585843da7b.jpg) icon to add API properties, functions and events.
- You can also ask the [Blocks AI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/about-the-blocks-ai) to generate the widget code for you. 

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3c16762ee98b0291e998dce9874181c5.png)

### Add widget code in the Wix IDE for Blocks

If you are using the [Wix IDE for Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-the-wix-ide-for-blocks), add your widget code in the following locations: 

- Write the widget code in the `site` folder in the auto-generated file that has your widget's name.
- Click the **Widget API** ![widget API](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/9aa25a00-57bb-465d-b443-4e14a5478da3/67b8bc89-773d-4775-a0d5-b1585843da7b.jpg) icon to add API properties, functions and events. 

### Add widget code in the Blocks-CLI integration

<blockquote class="important">

**Important:** The Blocks-CLI integration only works with the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps). The new [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), which is the recommended tool for new app projects, doesn’t support this integration.

</blockquote>
  
If you are using the [Blocks-CLI integration](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-the-blocks-cli-integration), add your widget code in the following files:

- Write widget logic in the [`widget.ts`](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/widget-files-and-code#widgetts) file.
- Write widget API properties, events and functions in the [`api.ts`](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/widget-files-and-code#apits) file.
---
portal: build-apps
name: "Add App Permissions in Blocks"
type: ARTICLE_RESOURCE
resourceId: 9b2f2f13-ac57-4b1e-aa50-f36c230f28a8
---

# Add Permissions to Your App

# Add App Permissions in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When an app is installed on a Wix site, the app may need to access and manage some of the site's data. To enable this, the site builder must grant the required permission scopes to the app when installing it. The app permissions are specific to the APIs that you use in your app.

<blockquote class="important">
  <strong>Important:</strong>

If your app is already installed on user sites, add permissions with caution. First, [test your app on your own site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site). Then release a major version for user sites.
</blockquote>

## Code that requires permissions

Adding permissions **is required** in the following cases:

* **If you added dependencies to Wix apps:** If you added [dependencies](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/set-wix-app-dependencies-in-blocks) to Wix's business-solutions apps (such as Stores or Bookings), you are probably using their APIs. You *must* add permissions, or else these APIs will cause your code to fail. 
* **If you need to access site data:** If your app needs to [access data from a site it's installed on](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/about-cms-collections-in-blocks#reference-a-site-collection-through-the-app-code), you'll need permissions to use the specific APIs required for this data. This **does not** apply to data from the app collection itself. 
* **If you used other APIs:** Even if you didn't add permissions and don't need to access site data, there are other APIs that require permissions. 

You do **not need** permissions in the following cases: 
* For your app's internal business logic. 
* For your custom panel code, including the `widget` module in `@wix/editor` SDK, `wix-widget` and `wix-editor` Velo modules.
* To use the `wix-dashboard` module.
* To access data from a collection that belongs to your app. 

## When permissions are missing
  
If your app requires permissions, but you haven't added them, site builders won't be able to provide consent, causing your code to fail. 

While everything might seem fine in Blocks (the release process won't fail), once the app is installed on a site, the site will show an error and the console will say that an API failed.

![permissions failed](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3076aaa1bed1263a5d9006affc4d30ec.png)

## Finding the required permissions

Follow these steps to make sure you have added the required permissions. Each step is only needed if the previous one wasn't successful. 

1. **Check the reference:** In most cases, if an API requires permissions, you will see it in the reference, under the `Permissions` section.

    For example, the `bulkCreateBooking()` function requires the following permissions:
     * `MANAGE BOOKINGS`
     * `MANAGE BOOKINGS - ALL PERMISSIONS` 

    You can click the permission to add it to your app. 

    ![Permissions scope](https://wixmp-833713b177cebf373f611808.wixmp.com/images/61a0854f7383a5ca3b2eced3544c763a.png)

1. **Check the legacy list:** If no permissions are specified in the API reference,  check if it's included in the Velo [legacy APIs permissions list](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/legacy-velo-api-permissions).

1. **No permissions needed:** Only if the API you are using has no permissions specified in the reference *and* doesn't appear in the legacy list, you can assume that no permissions are needed. 

## Ways to add permissions

You can add permissions in several ways: 

- In Blocks, click **WixBlocks** > **App** > **App Permissions**. This takes you to your app dashboard **Permissions** section. 
- Go directly to your app **Permissions** section in the [app dashboard](https://manage.wix.com/account/custom-apps).
- Click a specific permission from the API reference and then select your app.

## See also

*  [About Permissions in Wix Apps](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions)
* [Legacy Velo API Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/legacy-velo-api-permissions)
---
portal: build-apps
name: "Call Backend Code from the Frontend in Blocks"
type: ARTICLE_RESOURCE
resourceId: 2dff6517-59f6-43b3-a88c-60c26c8f9a70
---

# Call Backend Code from the Frontend in Blocks

# Call Backend Code from the Frontend in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Web modules allow you to write backend functions that you can easily call from the frontend. The following describes how to create, export, and call web module functions, also known as web methods.

## Step 1 | Add a web module

The way you add a web module file depends on which IDE you're using.

### From Blocks

1. Navigate to the **Code {}** section in the left menu. 
1. Go to the **Backend** section and click **+ Add web module**. 
This action creates a web module file with a `.web.js` extension.

### From Wix IDE or your local IDE

1. Create a new file in the `backend` directory and name it with the `.web.js` extension. 


## Step 2 | Define a web method in the backend

Add an exported web method in the file you created above. The web method wraps an inner function that contains the logic you want to call from the frontend.
To create a web method, call the `webMethod()` function and define the web method's permissions and its inner function:
1. Add the necessary imports:
    ```ts
    import { Permissions, webMethod } from "wix-web-module";
    ```
1. Call the `webMethod()` function and store its returned value in an exported variable.
    ```ts
    export const myFunction = webMethod();
    ```
3. Pass the `webMethod()` function a permissions value as the first argument:

    ```ts
    export const myFunction = webMethod(Permissions.SiteMember);
    ```
1. Pass the `webMethod()` function an inner function as the second argument:
    ```ts
    export const myFunction = webMethod(Permissions.SiteMember, (someParam) => {
    // Some functionality for site members to call from the frontend
      return `You passed me ${someParam}`;
    });
    ```
## Step 3 | Call the function from the frontend

To call a web method from the frontend:
1. Import the exported web method from the web module you created above:
    ```ts
    import { myFunction } from "backend/weather.web";
    ```
1. Call the imported function:
    ```ts
    const fromBackend = await myFunction(someValue);
    ```

Remember, web module functions are always asynchronous.
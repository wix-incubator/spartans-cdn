---
portal: build-apps
name: "Code in Blocks with the SDK"
type: ARTICLE_RESOURCE
resourceId: dc9b2a90-e736-4e53-95c5-5bcc217042a1
---

# Code in Blocks with the SDK

# Code in Blocks with the SDK

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

You can now use the [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) instead of Velo APIs for most functionality when building apps with Blocks. This marks the beginning of a gradual transition from using Velo APIs to using the next generation SDK.

The Wix JavaScript SDK follows industry standards, using npm modules to make development more accessible for professional web developers. It offers greater stability and aligns with the tools used across Wix CLI and self-hosted apps.

You are encouraged to start using the SDK in all new and ongoing development projects. You may also want to [migrate existing code](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/develop-with-the-sdk/migrate-from-velo-to-the-sdk) written using Velo APIs to the SDK.

## Install the npm package
Before you can import an SDK module in your code, you must install the corresponding npm package to your app.
- To install the packages in Blocks, go to **Code {}** > **npm** > **Install packages from npm**. 
- To install the package in the [Blocks CLI integration](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-the-blocks-cli-integration), use the command line.

<blockquote class="important">

**Important:** The Blocks-CLI integration only works with the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps). The new [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), which is the recommended tool for new app projects, doesn’t support this integration.

</blockquote> 

## See also

Learn more about the [transition from Velo APIs to the SDK](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/develop-with-the-sdk/develop-websites-with-the-sdk).
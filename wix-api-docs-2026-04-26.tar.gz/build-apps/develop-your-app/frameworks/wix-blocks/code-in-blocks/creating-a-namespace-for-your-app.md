---
portal: build-apps
name: "Creating a Namespace for Your App"
type: ARTICLE_RESOURCE
resourceId: 728b5889-90c6-4048-a0aa-609f359fd7f5
---

# Creating a Namespace for Your App

# Create a Namespace for Your Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

A namespace is a unique indicator of your app, in the format of:

    @prefix/suffix
    

The prefix is either your account name or your company name. The suffix usually indicates your app name.

**You need a namespace to:**

*   Import the app's [backend and public functions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/add-code-files-to-your-app) in the editor. 
*   Reference your app's [collections](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/about-cms-collections-in-blocks) both in the editor and in the app code in Blocks.

**You don't need a namespace to:**

*    Create widget-only apps with no backend or public code files, or collections.

<blockquote class="important">
<strong>Important:</strong>

Once you create a namespace you cannot change it.

</blockquote>

* * *

## Namespace prefix

There are two options for the prefix of your namespace. It can either start with your account name or with your company name. 

### Account name

Your account name is your Wix user name. If you are a [Wix Partner](https://www.wix.com/studio/partner-program), it's your Wix Partner account name. For this option, your namespace format is:

    @your-account-name/your-app-name

### Company name

Your company name is defined in your [Company Info](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/add-your-company-info) in your app dashboard. Use this option if you plan to publish your app in the Wix App Market. For this option, your namespace format is:

    @your-company-name/your-app-name

>**Company name requirements for namespace** 
> *   A company name that you put in your namespace **must be unique** in Wix. If someone used your company name and you think it might involve trademark infringement, please [let us know](https://support.wix.com/en/article/reporting-trademark-infringement).
> *   Your namespace can only include latin letters and numbers. If your company name includes non-latin letters, you'll need to change it in the app dashboard to use it as the prefix of a namespace. 
> *   If you change your company name in the app dashboard, it will change the namespace of **all future applications** in your account.

## Namespace suffix

You can change the suffix of your namespace as you wish. Just follow these requirements:

*   Use only lower-case letters, and numbers.
*   No special characters or spaces.
*   Must be unique within your account.

## Using your namespace for collections

To use your namespace for a collection, add the collection name after the namespace. The path created is your collection ID.  

```js
@yourAccountName/yourApp/yourCollection
```

To see your collection ID and copy it, click the three dots next to your collection name and then click **Edit Settings**. 

Here is a code example that uses a collection ID. If you want to try out this example, note that the [`insert`](https://dev.wix.com/docs/sdk/backend-modules/data/items/insert) function requires allowing users to write to your collection. Go to your collection's **Permissions & privacy** to configure this.  

```javascript
import { items } from "@wix/data";

async function insertItem() {
  const toInsert = {
    "name":        "Bella",
    "breed":   "Poodle",
    "age":    3
  };
  
  try {
    const inserted = await items.insert("@daphnet/adoption-app/DogsForAdoption", toInsert);
    console.log(inserted);
  } catch (err) {
    console.error(err);
  }
}
```

<details>
<summary>See deprecated wix-data Velo example</summary>

```javascript
import wixData from 'wix-data';

// ...

let toInsert = {
  "name":        "Bella",
  "breed":   "Poodle",
  "age":    3
};

wixData.insert("@daphnet/adoption-app/DogsForAdoption", toInsert)
  .then( (results) => {
  let item = results; //see item below
 } )
 .catch( (err) => {
  let errorMsg = err;
 } );
```
</details>

## Using your namespace to import functions in the editor

To import a public function from your app's code files in the editor, use this syntax:

```js
import {yourFunctionName} from '@yourAccountName/yourAppName'
```

For example:

```javascript
import {getStock} from '@nathanb257/stockquotesfromapi';

$w.onReady(function (){
  getStock()
});
```

To import from backend files, use this syntax:

```js
import {yourFunctionName} from '@yourAccountName/yourAppName-backend'
```

For example:

```javascript
import { getStock } from '@nathanb257/add1-backend';
```
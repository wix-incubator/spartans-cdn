---
portal: build-apps
name: "Debugging Your Blocks Code"
type: ARTICLE_RESOURCE
resourceId: 9d697dc1-0384-460e-8323-d9739334a187
---

# Debugging Your Code

# Debug Your Blocks Code

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

This article explains how to debug your code in Blocks or on a site where your app is installed.

## Debugging with the Developer Console

The Wix Developer Console appears at the bottom of the page when previewing your site and in Blocks. The console displays useful debugging information, such as errors, warnings, and other messages.

The console also displays debug messages that you added to the code using any [console method](https://developer.mozilla.org/en-US/docs/Web/API/console). If you are new to debugging code, learn more [further in this article](#logging-messages-to-the-console). 

**In Blocks:** Each message displays the widget where the relevant code can be found and a clickable link to the specific line of code that triggered the message.

**In Preview mode in the site editor:** You see only the message.

To view the Developer Console in Blocks or in the editor, click **Preview**. The Developer Console appears at the bottom of the page.

![developer console](https://wixmp-833713b177cebf373f611808.wixmp.com/images/951c0aa7a919f1c1fb3f6c6c77808c6d.png)


### Filtering console messages

Click **Log levels** on the console menu bar, and then choose which kinds of messages you want to see.


*   **Verbose**: System log messages that can help you debug low-level code problems.
*   **Debug**: Messages you have logged to the console.
*   **Info**: Informational messages that require no action.
*   **Warning**: Messages about potential problems in your code. These are highlighted in yellow.
*   **Error**: Messages about actual errors in your code. These are highlighted in red.

## Functional Testing for Backend Functions

Backend code debugging is challenging because you need to trigger and test the code, often by calling functions from the client side on a test site. To simplify this process, Wix enables [quick testing of backend functions](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/testing-monitoring/functional-testing/test-backend-functions-with-functional-testing) directly from the code panel. The test tab output matches what you would see in the Developer Console when previewing your app and triggering the function.

### HTTP Functions

You can debug HTTP functions by adding `console.log()` calls to them. The information you log appears in the function output when using [functional testing](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/testing-monitoring/functional-testing/test-backend-functions-with-functional-testing).

## Debugging with Your Browser's Developer Tools

<blockquote class="tip">
<strong>Tip:</strong>

Use these debugging methods to debug your code on a site where your app is installed. You can also debug directly in Blocks, but debugging from the site shows more complete behavior.

</blockquote>

Wix allows you to [debug](https://developer.chrome.com/docs/devtools/javascript/) your app's code like any modern JavaScript web application using browser [developer tools](https://developer.mozilla.org/en-US/docs/Learn/Common_questions/What_are_browser_developer_tools) to set breakpoints, log to the console, and more. These tools come with your browser, not Wix. If you're new to debugging, learn how to [log messages to the console](https://support.wix.com/en/article/wix-blocks-debug-your-code#logging-messages-to-the-console). You can debug your published site's code directly or use a [test site](https://support.wix.com/en/article/about-test-sites).

Here are a few things you need to know before you start debugging:

### Accessing Client-Side Source Files

You can open a copy of your app's client-side code files in the browser's developer tools.

**There are two easy ways** to locate your code:

#### Method 1: Search for your file by name

1.  Identify the names of your app's client-side code files. These file names appear in the Developer Console when you preview your site.


    ![developer console](https://wixmp-833713b177cebf373f611808.wixmp.com/images/119daefd6e44950dea18b303e4bf56a0.png)

1.  Browse to your published site and open your browser's developer tools.
2.  Open the file search bar. In Chrome, press **command/Ctrl+O**. In Firefox, open the **Debugger** panel and press **command/Ctrl+P**.
3.  Type the name of your code file and select it from the search results to open it.

    ![open file](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/20/31bb80b1-9492-4311-98e2-e2998be874a1/53305ee0-b48d-4cbb-8830-6bf69ee28128.png)


#### Method 2: Use the debugger

Adding the [debugger](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/debugger) statement to your code halts execution at that point and displays the code file in developer tools.

1.  Add debugger; at the point in your code where you want the debugger to run.
2.  Open your browser's developer tools and browse to your published site. The **Sources** panel opens to your code file and points to the line where you added debugger.

    ![debugging file](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/20/a0b22809-2cb8-4146-b4d2-3598e68c51bb/88f71d63-ccda-4a25-a5ac-7a7f5bacc209.png)


### Backend Code and HTTP Functions

For security reasons, messages in backend code are not logged to the browser's console on your published site.

HTTP functions are not browser based, so their messages are not logged to the console when viewing your published site.

Use [Logs](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/logs/about-logs) to view console messages from backend code and HTTP functions on your published site.

<details>
<summary>Note: source maps</summary>

When debugging in the browser, your code appears just like your original source code. In reality, the browser runs a different version of your code. Source maps handle this translation behind the scenes.

Wix supports the ES2017 standard, but for browser compatibility, your code is transformed to ES5. It's also minified and combined with other files for efficiency.

The code running on your site is transformed, minified, and combined. Source maps let you debug your original code by mapping between the running code and your source code. When you debug, the source map finds your original code while the debugger runs the corresponding generated code.

This process happens automatically. If you encounter issues, check your browser's developer tools settings to ensure source maps are enabled.

</details>

## Debugging with Logs

Wix's [Logs](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/logs/about-logs) tool helps you debug your installed app by generating and tracking logs. To view the logs: 

1. Go to your site's dashboard. 
1. Click **Developer Tools** > **Logging tools**. 
1. Or, access the Logs tool in the code sidebar under **Developer Tools** > **Logging tools**. 

<blockquote class="standard">
  <strong>Notes:</strong>

*   You can generate logs from any code in your site: client-side, backend, public, HTTP functions, or elsewhere.
*   You can monitor logs in both Preview mode and on your published site.

</blockquote>

![logging tools](https://wixmp-833713b177cebf373f611808.wixmp.com/images/d9e0a17c9bbd5b90554686dd59474118.png)

### Wix Logs

View logs in real-time on the Wix Logs page. Add a [console message](https://support.wix.com/en/article/wix-blocks-debug-your-code#logging-messages-to-the-console) to any code, trigger the code in Preview mode or on your published site, and the log appears in your Wix Logs page.

### Google Cloud Logs

For more robust log analysis, connect your Wix logs to Google Cloud Logs, an external monitoring tool.

Learn more about:


*   [Viewing logs using Wix Logs](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/logs/view-logs-using-wix-logs)
*   [Connecting to Google Cloud Logs](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/logs/view-logs-using-google-cloud-logs)
*   [How to generate logs to debug your site](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/logs/generate-logs-to-debug-your-site)
*   [Log object structure](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/logs/log-object-structure)

## Logging Messages to the Console

1.  Add any [console message](https://developer.mozilla.org/en-US/docs/Web/API/console) to the code you want to debug.
    
    For example, let's say you have a function called `myFunc()` that operates on a variable called `myVar`. To check if the function is called and if the operation works as expected, add this code:
    
    ```js
    console.log("Inside myFunc(). Value of myVar is: ", myVar);
    ```
3.  In Preview mode or on your published site, perform the action that triggers `myFunc()`.
4.  View the message in your chosen tool (Developer Console, Developer Tools, or Logs) to see how your code behaves.

<blockquote class="standard">
<strong>Note:</strong>

When logging nested data, only the first 5 levels appear in detail. For deeper nested items, log them directly.
</blockquote>

## Bypassing permissions with `elevate()`

Some functions require specific permissions to run. If you are receiving a 403 or FORBIDDEN error when you run a function, try using [elevate()](https://dev.wix.com/docs/velo/apis/wix-auth/elevate). This creates a copy of your function that includes the elevated permissions required by the original function. Exercise caution when using `elevate()`, to prevent security vulnerabilities.
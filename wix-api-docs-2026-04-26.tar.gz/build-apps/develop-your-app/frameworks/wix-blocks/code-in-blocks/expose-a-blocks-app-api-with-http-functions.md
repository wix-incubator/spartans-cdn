---
portal: build-apps
name: "Expose a Blocks App API with HTTP Functions"
type: ARTICLE_RESOURCE
resourceId: c947db18-4983-4732-894d-fc167309b641
---

# Exposing an App API with HTTP Functions

# Expose a Blocks App API with HTTP Functions

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Blocks allows you to create functions to expose the functionality of your app as a service.  
You can use it in sites where your app is installed by calling your app's APIs, as defined by the functions you create in the `http-functions.js` file.

This feature is very similar to [exposing site APIs through HTTP functions](https://support.wix.com/en/article/velo-exposing-a-site-api-with-http-functions), but with a slightly different syntax. 

**To create HTTP functions:**

1.  Click the **Public and Backend** icon  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/09/14/106ac6e3-d0ba-4030-82af-632453420d8b/9aefd48b-5126-46ea-8e33-d7bc0eadbd87.png)  in the Blocks left menu. 
2.  Hover over the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/09/14/90d60fd6-e7bb-4021-a33b-4f356fb8b086/bf3b7952-ef83-4c33-ae29-a14aeb5e76a3.png)  icon in the Backend section. 
3.  Click **Expose site API**. 

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/09/14/3078d29c-90dc-41fc-bdab-8c86381fc506/a3c01460-32cf-4ba3-9a59-135c51ce50f3.jpg)

</div>

## Endpoints

Each function you define in `http-functions.js` is accessible through a unique endpoint, allowing external requests to interact with your app’s features and allowing you to test them.

### API Callers
Clients consume your HTTP functions by reaching endpoints using the following pattern:

*   **Premium sites:** `https:/{user_domain}/_functions/<app_namespace>-backend/<function_name>?<optional_parameter>`
    
    For example: 
    ```js
    https://mysite.com/_functions/@johndoe/exampleapp-backend/multiply?leftOperand=3&rightOperand=4
    ```
*   **Free sites:** `https://{user_name}.wixsite.com/{site_name}/_functions/<app_namespace>-backend/<function_name>?<optional_parameter>`
    
    For example:
    ```js
    https://johendoe.wixsite.com/mysite/_functions/@johndoe/exampleapp-backend/multiply?leftOperand=3&rightOperand=4
    ```

### Testing
You can test your HTTP functions by reaching endpoints using the following pattern:

*   **Premium sites:** `https://www.{user_domain}/_functions-dev/<app_namespace>-backend/<functionName>?<optional_parameter>`
    
    For example:
    ```js
    https://mysite.com/_functions-dev/@johndoe/exampleapp-backend/multiply?leftOperand=3&rightOperand=4
    ```
*   **Free sites:** `https://{user_name}.wixsite.com/{site_name}/_functions-dev/<app_namespace>-backend/<function_name>?<optional_parameter>`
    
    For example:
    ```js
    https://johndoe.wixsite.com/mysite/_functions-dev/@johndoe/exampleapp-backend/multiply?leftOperand=3&rightOperand=4
    ```
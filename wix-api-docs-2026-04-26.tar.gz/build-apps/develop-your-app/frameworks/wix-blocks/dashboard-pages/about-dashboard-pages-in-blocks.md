---
portal: build-apps
name: "About Dashboard Pages in Blocks"
type: ARTICLE_RESOURCE
resourceId: 53076e2e-2365-4ffb-80e3-5fde2e122320
---

# About Dashboard Pages in Blocks

# About Dashboard Pages in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Dashboard pages are administrative pages you can add to the dashboard of a Wix site. They do not appear on the live site, so site visitors never see them. However, dashboard pages are visible to site admins with the required permissions. [Learn more about dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions)

Blocks enables you to add dashboard pages to your app. Dashboard pages are the back office of your app, allowing site builders to manage the app's data and settings. When a site builder installs your Blocks app on a site, the dashboard pages appear on their site's Dashboard, under **Apps** and the app name. 

![see the dashboard in the editor](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e67085e2194aec6c1a1494928bf8b414.png)

Use the following resources to get started with dashboard pages on Blocks:

* [Developer guide](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/build-a-dashboard-page-in-blocks): Learn how to build a Dashboard page from scratch with our comprehensive guide.
* [App templates](https://dev.wix.com/apps-templates?filter=blocks): Explore Blocks templates that demonstrate how to build dashboard pages.
* [UX guidelines](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/ux-guidelines-for-dashboard-pages-in-blocks): Learn how to build beautiful dashboard pages that serve your goals.
---
portal: build-apps
name: "Open a Blocks Dashboard Page from a Custom Panel"
type: ARTICLE_RESOURCE
resourceId: 85241d6e-a52d-4861-8d62-50c141cdd5f0
---

# Using a Blocks Dashboard Page URL in a Blocks Custom Panel

# Open a Dashboard Page in Blocks Using Code

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Use code to navigate to a dashboard page from a [custom panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks) or from another dashboard page in your app.

First, copy the dashboard URL (for panels) or ID (for other dashboards). Then, use it in your panel or dashboard code.

> **Note:** Panel buttons can also open a dashboard page [with no code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-button-rules-to-open-pages).
 

## Copy the Dashboard URL or ID: 

1. Go to the app dashboard ![app dashboard](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a12d944122f56ade6769357d7b7a9026.png) menu.
1. Hover over the dashboard page's name and click the More Actions ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/e9f11af0-679c-4bf1-8b76-e50e26ec98f6/27128ae4-51ef-4cdd-b679-854d2e85973b.jpg) icon.
1. Click **Dashboard Page Settings**.
1. Copy the following:
    - For dashboard, copy the **Page ID**
    - For panel, copy the **Page URL**

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/169e084ac242b8bcd73007bfb3f7e4d5.png)

## In Dashboards: Use the Dashboard ID 
1. Go to the code section of the dashboard page.
2. Import the `dashboard` SDK (remember to install the corresponding npm package). 
3. Call the `navigate()` function with the dashboard ID. For example:
```js
import {dashboard} from "@wix/dashboard"
dashboard.navigate({ pageId: "2e96bad1-df32-47b6-942f-e3ecabd74e57" });
 ```

<details>
<summary>See deprecated wix-dashboard example</summary>

```js
import wixDashboard from `wix-dashboard`;
wixDashboard.navigate({ pageId: "2e96bad1-df32-47b6-942f-e3ecabd74e57" });
```
</details>

## In Panels: Use the Dashboard URL
Opening a dashboard from a custom panel is slightly different: 
1. Open your panel from the **Editor Experience > Panels** tab. 
1. Go to your panel's code section. 
2. Import the `wix-editor` module. 
3. Use the `openDashboardPanel()` function with the correct URL. For example:

```js
import wixEditor from 'wix-editor';
wixEditor.openDashboardPanel({url: '771680a8-ad76-4a3c-8bfc-4e2873de96c9/dashboard-page-2'});
```
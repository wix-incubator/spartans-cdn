---
portal: build-apps
name: "UX Guidelines for Dashboard Pages in Blocks"
type: ARTICLE_RESOURCE
resourceId: 2ba3bcf3-16e2-40b5-82d1-bdafb2230e77
---

# UX Guidelines for Dashboard Pages in Blocks

## UX Guidelines for Designing Dashboard Pages in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Dashboard pages are the backoffice of your app, allowing site builders to manage the app's data and settings.

When your app is installed on a site, the Dashboard page for your app will be part of the site Dashboard, alongside other apps from Wix. To make it easier for people to use your app, we recommend that you follow our suggested patterns when designing Dashboard pages. 

## Screen sizes
Dashboard pages in the Business Manager are viewed on a variety of desktop screen sizes, so aim to design layouts and content that work well on various screen sizes.
Users should understand the purpose of a Dashboard page right away. The primary content should be revealed at the top area of the page, without asking users to scroll down. 
Content displayed in the **top 600** pixels of the page will be visible for the majority of our users.

The dashboard page takes up the whole content area, with a width that's adaptable to screen size.

![screen size](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b2ebc1bdaa5230f864b9204e52b61cd6.png)

## Elements
Dashboard pages are designed with their own visual language and a dedicated design system. 

When designing your app’s Dashboard page, use elements from the **Dashboard Elements** section of the **Add Elements** panel, which contains a set of recommended elements. 

Note that Dashboard pages can’t contain widgets, so you will not see them in the **Add Elements** panel.

![dashboard elements](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b7a3cf48bbe993406b8dec27ad764ba4.png)

The **Design Patterns** section of the **Add Elements +** panel contains several basic recommended layouts for you to start designing your app’s Dashboard page. 

![design patterns](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b83ad47193dd861117f815a802078096.png)

## Layout
The page layout defines the page structure, hierarchy, and rhythm. Choose a layout that decreases the amount of time a user needs to invest in  a complex task.

![layout](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ebf3cdd60e4a9a26db13be2f89d06957.png)

In order to design a page with a great layout, it’s important to understand what the page content will be, how it will be segmented on the page, and how each segment will use the grid.

## Layout grids
When designing your Dashboard page content, we recommend using a fluid grid layout with a fixed maximum width of 1248px. Such a grid should use columns that scale and resize the content that's placed on the grid accordingly. This means that content placement on a screen is always consistent.

### Columns
For maximum flexibility, use a 12-column grid as a base when planning your page layout. Each column width is fluid and changes according to the page width. 

![colunmns](https://wixmp-833713b177cebf373f611808.wixmp.com/images/34b948d03d7dfc393ed32492a62af74b.png)

Such a 12-column grid will allow you to use column spans to construct layout regions of your page. Regions will be separated by a grid gutter.

![colunmns and rows](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4d2695ebea5c1d2edc8c75caf2103add.png)

### Gutters
Gutters are the gaps between the columns. Gutter width should have a fixed value of 24 px.

![images/gutters.png](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e8aa25c1e2978ac277f272550c9d9c84.png)

### Using the grid on a page
The page's content area should have 48px side margins and a 48px bottom margin. To arrange content inside of a page, use a 12-column grid.

![grid](https://wixmp-833713b177cebf373f611808.wixmp.com/images/fd2b9bdc0ad89f37e3eda8d7bc3f686f.png)

A page's content area has a minimum width of 864 pixels (each grid column should be 50px wide).

![area size](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e02144fe94868d45cb8d758a8deba93c.png)

The maximum width of a page's content area should be 1248px (each column is 82px wide). Wider screen sizes should maintain a 1248px content area width. Side margins should automatically stretch to maintain content in a centered position.

![widget](https://wixmp-833713b177cebf373f611808.wixmp.com/images/d9f231e2adab7fa38b793998456f4b8c.png)

A page can contain multiple layout regions of content (cards). Use a 24px gap between such cards both vertically and horizontally:

![cards](https://wixmp-833713b177cebf373f611808.wixmp.com/images/15a86cf3232cb3a3edeed4f1c4cf44a8.png)

## Layout intents
Page layouts can be divided by intention into the following types:
* Form
* Display
* Marketing
* Wizard

Let's describe these layouts. 

## Form layout
Forms allow users to fill-in data or edit existing data. Depending on the content, the form layout type can appear in two different ways:

* 2/3 layout with an optional sidebar (8/4 column split)
* Full width (12 columns)

Both form page layouts include **Save** and **Cancel** actions in the header and footer areas.

### The 2/3 form layout

![2-3 layout](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3078f47db561a6ca2136ecd85b7ba55f.png)
The 2/3 layout provides the flexibility to expose a variety of content at the same time.

Use this layout to:
* Expose primary and secondary content at the same time
* Keep the form easy to scan and understand

The page content is easier to scan when text and data inputs have a set maximum width. Shorter lines are more pleasant to read and allow users to understand the content faster.

When working on a form design, be thoughtful of the white space you use. Just like content, white space should have a purpose and intention. 

Use white space to:
* Emphasize content
* Highlight hierarchy
* Group related content together

![form](https://wixmp-833713b177cebf373f611808.wixmp.com/images/947b48a32eead509afb41986eeb404cb.png)


### The full width form layout

The full width form layout supports advanced needs. Use it when a form includes complex structures, such as a data table with inline editing.

![full widget layout](https://wixmp-833713b177cebf373f611808.wixmp.com/images/dbf68b35ab444b3d14f6cfca64041abe.png)

Use the full width layout for forms that include complex structures such as tables:

![complete form](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5706b883b3d25147b2f75ae5fa0efafb.png)

## The display layout
Display pages showcase data or content in a corresponding layout. These pages do not accept input from the user side. They can contain minor actions such as data filtering.

Here are some of use cases for display layout:

* List or table
* Grid
* Dashboard
* Empty state

## List or table display

Lists or tables, display large databases and provide users with a quick overview. They allow users to manipulate and act on a database. Use a 12-column layout for lists and tables.

Depending on the loading type, pagination may or may not be displayed at the end of the list.

![table](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a4806a14c71f2781044ff6724dbcedf2.png)

![list](https://wixmp-833713b177cebf373f611808.wixmp.com/images/97c725062800682379feb473b17ddceb.png)

## Grid display

Grids can display lists of different items: features, tools, photos, audio files, etc. There are multiple variations of grids available to use:
* 2 columns
* 3 columns
* 4 columns
* Custom

![grid 2 column](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5ae2a7c72de1b51a7a757d285c6a1178.png)

![grid 3 column](https://wixmp-833713b177cebf373f611808.wixmp.com/images/79f558ec032756840a7d10a37556f6a2.png)

![grid 4 column](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4b7c588fa06ca11297103f276c3c9de4.png)

![grid not even](https://wixmp-833713b177cebf373f611808.wixmp.com/images/576ee0a39b431f1873df9b8298cc1082.png)


Selecting the right grid depends on the content you want to display. Before picking a type, you should think about:

* The total amount of items that you want to show
* The content that you need to display in each list item
* What objects the list  of items reflect. Sometimes lists reflect physical objects, such as photo albums. Photo albums tend to have a square shape most of the time in the physical world. You should stick to that shape in digital space as well to make it easily recognisable.

Use a 6/6 column split to list features or tools with lengthy descriptions:

![marketing integrations](https://wixmp-833713b177cebf373f611808.wixmp.com/images/8f9d29efe500b10ef35162ffd9e7907d.png)

Keep in mind that a layout that works in one case might not be the best option in another. If the list item has a number of text lines of different types, a 3/3/3/3 column split reveals more items above the fold than a 6/6 layout:

![layout 3-3-3-3](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2be844fda553f1652e560b49ce329535.png)

## Dashboard
Dashboards display different types of data on a specific topic. Feel free to use a combination of grid segments to display all the different types of information.

![dashboard](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0e4703987c49abccd9b8671b7f976964.png)

The number of columns to span the layout region across depends on the content. Use:
* 3 or 4 columns: for lists of items, previews, marketing, statistics, and charts
* 12 columns (full width): for tables and marketing content
* 8 columns: for lists, tables with a few data columns, setup wizards, and charts
* 6 columns: for lists, tables with a few data columns, and statistics

Use 12 columns for marketing content to draw attention to it:

![split to categories](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2876fcad7c49cdbd62532970bd5d18ae.png)

Use a 6/6 column split to categorize features under the same section:

![list options](https://wixmp-833713b177cebf373f611808.wixmp.com/images/957abbfb5c5984f2ce88c46c45404202.png)

Use a 3/3/3/3 layout to list the options of a feature that user can choose from:

![layout 3-3-3-3](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2be844fda553f1652e560b49ce329535.png)


Feel free to combine different grid for mixed data displays:

![mixed](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6bd11dfbaaed7547cf15d5ec25b848e3.png)

### Empty state
Use the full width layout for the empty state of a page to indicate that a feature or product:

* Has no data yet
* Has all data cleared
* Is not set up yet (first time experience)

![empty](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4f82a1f9c31ced6e0cd42150351d7876.png)

Use the full width layout to clearly communicate that a page is empty, and add a clear CTA indicating what to do to fill the page with relevant content:

![CTA](https://wixmp-833713b177cebf373f611808.wixmp.com/images/55c75742370b287d067e5c26cebdf040.png)

It's OK to combine the empty state with other layout elements such as marketing widgets or navigation elements:

![empty combined](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5e8be7bebcd5d95e83f744e093cdcac2.png)

### Marketing
A marketing layout can promote your app or products that site owners are not aware of yet. 

![marketing](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7b7144d2895dacd04b4e68e47a478be7.png)

Marketing pages should be built using the dedicated Marketing Layouts compositions which you can find in the **Add Elements** panel.

![marketing pages](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e39d863b077be54a66377c6ac38f5ab2.png)

### Wizard
Wizard pages guide users through setting up a product or feature. They also split complex forms into steps so that they're easier for users to complete.

![wizard](https://wixmp-833713b177cebf373f611808.wixmp.com/images/53cad9d5d524544199ac8c0afae2b9b7.png)

Create multiple Dashboard pages or use a Multi-State Box to split up complex forms or product setup into smaller steps of a wizard:

![wizard with multi-state](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0fd1aaa4d8b9fd0a4348f185dd0e08b9.png)

Remember that wizards need to have an explicit entry point and a final destination. After a user completes all the steps, they should end up on a relevant page: a dashboard, a details page, or any other relevant location.
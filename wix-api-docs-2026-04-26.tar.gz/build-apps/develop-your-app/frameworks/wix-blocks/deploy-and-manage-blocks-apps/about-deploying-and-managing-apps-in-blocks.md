---
portal: build-apps
name: "About Deploying and Managing Apps in Blocks"
type: ARTICLE_RESOURCE
resourceId: 610c74d5-9d50-450e-86aa-b435f64d203c
---

# Deploy and Manage Blocks Apps

# About Deploying and Managing Apps in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Wix Blocks offers several features for deploying and managing your app, including:

* **Version management**: Create a [test](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site), major or minor version of your app. [Manage](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-blocks-app-versions) how versions are handled for your sites, or for other site creators.

* **Installation settings**: Define [how your app is installed](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings) on a site. For example, what widgets and what presets are installed by default.

* **Work with your team**: [Share your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-collaborators-in-blocks) with team members, work on it [concurrently](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/work-on-a-blocks-app-concurrently), [translate ](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/translate-a-blocks-app) it or [duplicate](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/duplicate-a-blocks-app) it.

* **Publish your app**: Blocks apps can be [private or public](https://dev.wix.com/docs/build-apps/get-started/overview/exposing-apps-publicly-and-privately), meaning that you can use them on your own sites or [publish them to the Wix App Market](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/publish-a-blocks-app-to-the-app-market) and reach millions of site creators.  
After you decide on your business model and pricing plans in the Wix Dev Center, make sure to  [adjust your UI and code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans) to these pricing plans.
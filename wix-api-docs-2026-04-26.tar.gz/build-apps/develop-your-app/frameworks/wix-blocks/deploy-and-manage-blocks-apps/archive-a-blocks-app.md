---
portal: build-apps
name: "Archive a Blocks App"
type: ARTICLE_RESOURCE
resourceId: 6eb1c56b-f417-42cd-b027-9eb6e582dc72
---

# Archiving Your App

# Archive a Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Archiving your app allows you to get rid of apps that you no longer need. When you archive an app, you will not see it in your list of apps in the Blocks Editor. You will also not see it in your list of apps when importing Blocks apps to a site. You will no longer be able to edit it in Blocks, or install it on any site. 

<blockquote class="important">

**No unarchive** 
Note that once you archived an app, you cannot unarchive it.

</blockquote>

### To archive your app

1.  Click **App** in the top menu.
2.  Click **Archive App**. 

<div style="text-align:center">

![archive app](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/12/21bd5a7c-2677-4047-97f9-6bdd045f0f72/8a994a49-5d41-4e14-8714-821e4cf9bc19.png)

</div>

1.  A message pops up, asking you if you want to archive that specific app. Take a good look at the name of the app and click **Archive**.

<div style="text-align:center">

![archive button](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/12/b3a98515-5554-46dd-a456-7f035dfa71a1/3a90f5d0-545f-4446-9e08-be3c47fd2af4.png)

</div>

### How an archived app behaves on a site

If you archived an app that is already installed on a site, it will continue to appear and function in the site. The site behavior will not be broken.  However, you will not be able to maintain the app that is installed. If you hover over the app in the **Wix Blocks >** **My Apps** menu, you'll see that you cannot open it in Blocks to edit it. 

<div style="text-align:center">

![archived app](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/12/a477bcfa-7e92-4a19-a3bb-037ac6129b81/5dfc98a5-e153-473d-a806-426a3a7c1b10.png)

</div>
---
portal: build-apps
name: "Configure Blocks Installation Settings"
type: ARTICLE_RESOURCE
resourceId: 2c09fd52-b596-4a22-8e37-8d8e88984f3c
---

# Widget Installation Settings

# Configure Blocks Installation Settings

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

The widget installation settings let you configure what happens when a site builder installs your app. For example, should all widgets be visible in a site's Add panel? Should any of them be added automatically to a site? What will be the default preset?

<blockquote class="important">
  <strong>Important:</strong>
  
*   Installation settings apply only **for the first install** on a site. This means that in any further update, the settings won't be updated unless the user removes and reinstalls the app. 
*   The installation settings you apply for your Wix Blocks App are specific to a [version of the app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-blocks-app-versions). The best practice is to [test your app on a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site), before releasing a new version.

</blockquote>

## Access Installation Settings

There are two ways to access your widget's installation settings. First, make sure your widget is selected in the **App Interface** in Blocks. 

### Method 1: From the WixBlocks Menu
1. Click the **WixBlocks** menu.
1. Click **Dashboard** to open the app dashboard.
1. In the app dashboard, click **Installation Settings** and then select **Manage Settings**.
1. To switch to another widget, return to the **Extensions** page in the app dashboard and select the widget you wish to manage.

### Method 2: From the Editor Experience
1. Hover over the widget name in the **App Interface**. 
1. Click the three dots and select **Editor Experience** > **Edit Installation Settings**.
1. Hover over the widget name.
1. To switch to another widget, select a different widget and repeat the process. 


## Configure how your widget is added

There are several options for adding each of your widgets to a Wix site.

*   [Not added automatically](#not-added-automatically)
*   [Added to homepage](#added-to-the-site-homepage)
*   [Added to a site page](#added-to-a-site-page)
*   [Added to a site page as a popup](#added-to-a-site-page-as-a-popup)

### Not added automatically

This is the default setting for Installation Settings. With this option, your widget is:

*   Not added to a page automatically.
*   Shown in the **Add +** panel as available to install on a site. If you do not want your widget to appear in the **Add +** panel (for example, if it is an [nested widget](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/add-nested-widgets-in-blocks)), deselect this option in the **Preset Images in Add Panel** section.

In this example, the app has two widgets, both are defined as **Not added automatically**, and therefore seen in the **Add+** panel. 

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/02/2127b66a-dada-4531-a90e-e17a04fd03c4/c577b46e-ffbf-4487-8104-d2c4cfdbb1ca.png)

</div>

### Added to the site homepage

This option means that your widget is automatically added to the homepage of a site, without having to drag and drop it from the **Add +** panel.

You can also set the default [preset](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md) for your widget and define a different default preset for mobile. 

### Added to a site page

Use this option when you want your widget to appear on a different [Site Page Extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/add-a-site-page-extension) of your app. A site page extension means that whenever your app is installed of a site, another page comes with it.

**To add the widget to a page extension:**

1.  Select the site page extension to add your widget to.
2.  If you want to add the widget to a new site page extension, (meaning that you want to create this extension now), provide the following information: 
    *   **Page Name:** Create a name to appear in the site menu.
    *   **Page ID:** This will be used to refer to this page in code, and will also become the default page URL slug. The Page ID is filled in automatically based on the page name, but you can edit it. It cannot be changed once it has been saved.
3.  Set the default [preset](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md) for your widget. If you want a different preset for mobile, select it.  
4.  Set how the widget appears on the page:
    *   **Original size:** This option is selected by default. Your widget appears at the size it was created.
    *   **Stretched:** Select this option to stretch the widget to fill the page.

>**Note:** 
> The Page ID value becomes part of the URL for the new page that this widget is installed on. This is so it can be used in code as a unique URL. You'll use this if you want to navigate to the page from your app.

### Added to a site page as a popup

Use this option when you want your widget to appear as a popup. 

> **Note:** The terms popup and lightbox refer to the same element. While the editor and dashboard now refer to it as a [popup](https://support.wix.com/en/article/studio-editor-using-popups), the API methods continue to use the term lightbox for backward compatibility. The documentation uses both terms accordingly.

**To add the widget as a popup:**

1. Click **Added to site page**.  
2. Click **\+ Select popup extension**.
3. If you want to add the widget to an existing popup extension, select the name of your popup. 
4.  Or, if you want to create a new popup, provide the following information:
    *   **Popup name:** This will appear in the site menu.
    *   **Popup ID:** This is used to refer to this popup in code, and also becomes the default page URL slug. It is filled in automatically based on the popup name, but you can edit it. It cannot be changed once it has been saved (see note below).
5.  Set the default [preset](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md) for your widget. If you want a different preset for mobile, select it.

> **Note:** 
> The Page ID value becomes part of the URL for the popup this widget is installed on. This is so it can be used in code as a unique URL. You'll use this if you want to navigate to the popup from your app.

<blockquote class="tip">

**openLightbox()** 
To open the popup from the app code, use the [wix-application openLightbox()](https://www.wix.com/velo/reference/wix-application/openapplightbox) function.

</blockquote>

***

## Configure preset images and visibility

The preset images section lets you define what widgets and presets appear in a user's **Add +**   and **Preset** panels.

### Shown in Add Panel

Control the widgets users see in their **App Widgets** list in the **Add +** panel. For example, if you have [inner widgets](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Widgets%20Within%20Widgets.md*original::../Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Widgets%20Within%20Widgets.md) that are already included within another widget, you'll need to hide them from the Add panel. You can define Add panel visibility for each [design preset](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Design%20Presets.md) separately.  

<details>
<summary>See an Add panel with two widgets</summary> 

![Add panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/08/e7335270-e324-4a4c-ad83-d6450ec5b9eb/efc69fd0-e95c-4951-94fe-07a328ea76f5.png)

</details>

<details>
<summary>See an Add panel with one widget and three presets</summary>

  

![add panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/08/f764f8d5-1fd5-4c9f-8324-7d876dd94391/b88b0d45-2393-490f-ae16-67e22a23b1a6.png)

</details>

### Shown in Preset Panel

The **Preset** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/27/2907ce70-8afe-48d0-a3b7-65097674f11c/19742c50-14ba-48de-a648-f09689a259cf.png) panel is where users can choose between the various presets of a widget. This option lets you determine which presets should appear in the Change Preset panel. 

<details>
<summary>See a Preset panel</summary>

  

![Change Preset panel](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7564b0c12f84c9bae7bad5765a0227f9.png)

</details>

### Choose image

When users browse through the design presets of your widget in their Add or Preset panels, they see a thumbnail image of the presets. We recommend that you upload your own images, to make sure that they represent the design and functionality of your widgets. If you started building from a [Blocks template](https://dev.wix.com/apps-templates?filter=blocks), this is crucial, or else your thumbnail images will be the template's images. 

Click **Choose Image** to upload your images. Make sure to follow our [UX guidelines](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/create-thumbnail-images-for-your-presets) for these images. 

Select **Use a different preset for mobile** if you want a different preset to show on users' mobile view. 

***

## Configure widget as essential to your app

Set a widget as essential to your app if it is a main widget and your app has no meaning without it. 

Note that you can set a widget as essential only if you add it to a page or a page as a popup. You cannot set it as essential if you add it automatically or to your homepage. 

With this toggle on:

*   Your widget **cannot be deleted**. Deleting the widget will un-install the app from your site. 
*   Your widget **cannot be duplicated**. A user can't add it twice from the Add + panel, and cannot copy and paste it. 

<blockquote class="important">

**Reminder** 
Installation settings **only apply for the first install** on a site. This means that if your app is already installed on a site, the settings won't be updated unless the user removes and reinstalls the app.

</blockquote>
---
portal: build-apps
name: "Duplicate a Blocks App"
type: ARTICLE_RESOURCE
resourceId: a409aa72-686c-41b5-9338-4022ea272e5d
---

# Duplicating a Wix Blocks App

# Duplicate a Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Blocks enables you to duplicate an app. This is useful especially if you want to share an app with someone else, but don't want them to change the original one. 

## Duplicate Your App

1.  Make sure that you are logged in to the app owner user.
2.  Open the app that you want to duplicate in Blocks.
3.  Click the **App** tab in the top bar. 
4.  Click **Duplicate**.
5.  The duplicated app opens in a new tab. 

>**Note:** 
> If you don't see the new app in your [app dashboard](https://manage.wix.com/account/custom-apps), click **Build** to create a version of the app.

> **Note:** [Self hosted extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions) and [installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings) aren't duplicated in this process. Add them again to the new app. 

## Share Your App

Now that you duplicated your app, you can share it with more people. 

1.  Click the **App** tab in the top bar.
2.  Click **Collaborators** to [share this app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-collaborators-in-blocks) with your colleagues. They will get an email inviting them to edit the app.
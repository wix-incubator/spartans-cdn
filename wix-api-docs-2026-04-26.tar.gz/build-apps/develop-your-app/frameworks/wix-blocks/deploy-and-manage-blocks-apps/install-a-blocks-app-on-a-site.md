---
portal: build-apps
name: "Install a Blocks App on a Site"
type: ARTICLE_RESOURCE
resourceId: 490c25a4-8351-4598-947b-e284b7273bda
---

# Installing a Blocks App on a Site

# Install a Blocks App on a Site

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Install and reuse any Blocks app you created or collaborate with, as many times as you want. You can install the app on any site you own or collaborate with. 

Before you install the app, make sure to configure its [Installation Settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings) in Blocks.

## Install your app

1. Open the Wix or Studio editor. 
1.  Click the **Add Apps**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/08/10/adccdd51-7025-46e0-8b79-1a17f8978719/245b3a47-f76b-4c7c-a6f8-c8eeb247d67e.png)  icon in your Editor.
1.  Click **Custom Apps**.
1.  Click **Available Apps** and select the app you want to install. 
1.  Click **Install App**. 
1.  Wait for the success message. You'll get the most updated version release. 

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/71d20af0-560e-44a5-bb38-bf3f513b58fa/2023/07/26/f69bb290-976f-4088-b66b-14a52555aa66/432f70cf-0730-41b6-95aa-eba4fde0a232.jpg)

## Change the installed app version

To move between app versions, hover over the More Actions icon  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/09/12/f94cd9bd-9b3c-4755-bf6a-306f288dda27/4d380f0b-a5f4-4d75-8349-705d334e608a.jpg)  next to your app's name. If you released a new major version, you'll see an indication next to the app name.

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2022/09/12/ca250c45-dc40-45e4-bf05-7a1a6a5c60c1/c0b7c82c-9ca7-4248-8d45-5c109b12d1ac.png)

If you want to install your app just for testing purposes without releasing a version, go back to Blocks and [test your app in the editor](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-blocks-app-versions).

## Add widgets to a site page

If your app has widgets that are not automatically added to the page, you can add them to any page on your site:  

1.  Click **Add Elements**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/8696077d-830a-4b1e-bd86-9df98f89994a/2023/06/14/cef22a14-dfc9-43c7-a54f-72ed83266050/741248d2-4240-497e-a282-2a7d15d8afac.png)  on the left side of the Editor.
2.  Click **App Widgets**.
3.  Select your widget and drag it onto the page. You may have the option to choose between several design presets.

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/71d20af0-560e-44a5-bb38-bf3f513b58fa/2023/08/01/5f91cff2-cbec-42d2-80b0-ad6536654d92/6bc32444-d081-4571-a1bd-ebd544e0cf57.jpg)

<blockquote class="tip">
  <strong>Tip:</strong>
  
In the Studio Editor, your app widgets are at the top of the elements list. In the Wix Editor, they appear in the middle.
</blockquote>

## Access your app's code files

If your app has public or backend code files, you can now import functions from these files. 

To import **public** functions, use this syntax: 

```javascript
import { <functionName> } from '@<myAccountName>/<my-app-name>';
```

To import **backend** functions, use this syntax:

```javascript
import { <functionName> } from '@<myAccountName>/<my-app-name>-backend';
```

## Manage your app's dashboard extensions

If you added [dashboard extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks) to you app, you'll see them in the site's dashboard. 

![dashboard](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e67085e2194aec6c1a1494928bf8b414.png)

## Manage your app's collections

If your app has a [CMS collection](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/about-cms-collections-in-blocks), you'll see it under your site's CMS collections, with the default data that you added in Blocks.

## Add your app's plugins

If your app has a plugin extension, add it to the relevant page, depending on the plugin type. [See full guide](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-plugins/build-a-site-plugin-in-blocks#step-6--test-and-preview).
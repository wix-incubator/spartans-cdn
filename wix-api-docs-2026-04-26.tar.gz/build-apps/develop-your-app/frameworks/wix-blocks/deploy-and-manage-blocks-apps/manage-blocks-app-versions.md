---
portal: build-apps
name: "Manage Blocks App Versions"
type: ARTICLE_RESOURCE
resourceId: 36ad44f8-674b-4b63-9ab0-a8a9fb69e561
---

# Managing App Versions

# Manage Blocks App Versions

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Release a version of your app whenever you want to distribute a new feature to your users or sites. To release a version, click **Release** in Blocks. Before releasing a version, make sure to [test your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site). 

## Version types

Choose one of two versions:

*   **Major version.** Release a major version when you've made changes that break compatibility. Your first release must be a major one. Changes come into effect after users manually update the app and publish their site. 
*   **Minor version.** Release a minor version when you've made small changes that don't break compatibility. A minor version will automatically change on any site the app is installed on. It takes 5-15 minutes to update in the live site.  

## Changes that require a major version

Some changes are substantial changes that cannot allow a minor version. 

If you added the following items in Blocks, your next build must be major or test:

*   Wix app [dependencies](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/set-wix-app-dependencies-in-blocks)
*   Add [Code files](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/add-code-files-to-your-app) for the first time, or
*   Add a CMS [collection](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/about-cms-collections-in-blocks) for the first time


If you made the following changes in your app dashboard, your next version will be a major version:  

*   Added or removed [Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions)
*   Added an [Embedded Script](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) extension
*   Changed [Dynamic Key Parameters](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts#dynamic-parameters) of an Embedded Script

## Version numbering

Wix Blocks automatically updates the version number. For example, if your previous release was 1.0, and you release a minor version, Blocks assigns it the version number 1.1. If your previous release was 2.2, and you release a major version, Blocks assigns it the version number 3.0. 

## Apps published in the App Market

If you've [published your app in the App Market](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/publish-a-blocks-app-to-the-app-market) and want to update it to the latest version you've released, there’s no need to resubmit it for review. Minor changes will be automatically received by users, while major updates will be available if they choose to update. 

However, certain changes are not included in your Blocks version release and are managed directly through your app dashboard:

* **Market listing:** Updates to [your app’s public information](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/about-market-listings), including media, contact details, etc.
* **Pricing:** Changes to your [pricing plans](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/change-app-pricing). These also require you to resubmit your app for review.
 
## Apps that weren't created in Blocks

If you added a Blocks extension to an already existing app that wasn't created in Blocks, make sure to release a **minor version** in Blocks. A **major** version will require a manual update of the application in all the sites it's installed on.
---
portal: build-apps
name: "Manage Collaborators in Blocks"
type: ARTICLE_RESOURCE
resourceId: 5ad319fa-fa3e-4c94-a5ce-5c3daebb5c86
---

# Managing Collaborators in Blocks

# Manage Collaborators in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Wix Blocks enables you to invite other Wix users to work on your app. Blocks provides these roles:

*   **Owner:** The owner is the creator of the app and has full control over it. They can manage, edit and install the project, invite collaborators and duplicate the app.  
*   **App Co-Owner:** The app co-owner can manage, edit and install the project, including inviting collaborators. There is no limit on the number of co-owners. They cannot duplicate the app. 

## Add a Collaborator

1. Click the **WixBlocks** icon.
1. Click **App** > **Collaborators**. 

![collaborators](https://wixmp-833713b177cebf373f611808.wixmp.com/images/35862349845c1a49e5e20abb8bd51672.png)

1.  Click **Invite Collaborators**.
2.  Provide the email address(es) of the person or people whom you want to add as collaborators. Separate each address with a comma.
3.  Check the **App Co-owner** box.
4.  Click **Send Invite**. 

Your collaborator gets the invitation by email must accept it before they can work on your project. 

## Resend the invite 
You can resend the invite or get the invite link by clicking the **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/57e9f77c-6d15-498d-ac4e-c4d09bf3a490/2021/06/01/63380403-960e-4a4c-9908-8f9ac9178675/35752514-6aff-4c4f-9075-9d70082fc269.png) icon next to your collaborator.


## Remove a Collaborator

1.  Click the  **More Actions**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/57e9f77c-6d15-498d-ac4e-c4d09bf3a490/2021/06/01/63380403-960e-4a4c-9908-8f9ac9178675/35752514-6aff-4c4f-9075-9d70082fc269.png)  icon and then click **Remove** next to the collaborator you want to remove.
1.  Confirm that you want to remove that collaborator.

Your collaborator receives a removal message by email.
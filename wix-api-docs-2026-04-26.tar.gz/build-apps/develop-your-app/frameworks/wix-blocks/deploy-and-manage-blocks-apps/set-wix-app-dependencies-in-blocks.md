---
portal: build-apps
name: "Set Wix App Dependencies in Blocks"
type: ARTICLE_RESOURCE
resourceId: c710743f-5ed3-46ec-90ce-ba3daa5efa98
---

# Setting Wix App Dependencies

# Integrate with Wix Apps in Blocks  

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

[Wix Apps](https://dev.wix.com/docs/develop-websites/articles/wix-apps/about-apps-made-by-wix) are business solution apps created by Wix, enabling users to sell products and services, run events, write blogs, manage restaurants and more. To integrate with Wix Apps in your Blocks app, you must first add them as dependencies. You can then use their collections or utilize their APIs.

## Add Wix App Dependencies   

To add a or remove a dependency:    

1. Click **WixBlocks** > **App** > **App Dependencies**.  
2. Click **+ Add Dependencies** and select the App that you want to add (or remove).   

When a user installs your app, they'll receive a notification that they need to install the Wix apps you defined in order for your app to work. 

## Using Wix App Collections  

[Wix App collections](https://dev.wix.com/docs/develop-websites/articles/databases/wix-data/collections/working-with-wix-app-collections-and-code) are special collections that come from the Wix Apps that you integrate in your app. These collection appear automatically when you add a dependency to these apps. They'll also appear in any site that will use your app. 

<blockquote class="important">
  <strong>Important:</strong>
  
Currently, you can only access the collections of Wix Stores and Wix Bookings. For other Wix Apps, use their APIs to access data. 
</blockquote>


To use Wix App collections:  

1. Navigate to the **Collections** ![collections](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b7ec373cdde0ab59576a1a36fcc0705f.png) tab.  
1. Click **Wix App Collections** and view the available collections.  

You can use these collections with [data-binding](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-elements-to-collection-fields-with-no-code) or [code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-a-dynamic-repeater-to-a-collection) to populate Repeaters or display the data in other ways.  

In Preview mode, your app shows how it interacts with the default data from these collections.  

## Utilizing Wix App APIs  

Wix App APIs are documented in the [API reference](https://dev.wix.com/docs/velo) and can be implemented in your app's code.  

To test them, go to **Test** and [run them on a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site). You cannot test these APIs in the Blocks preview.
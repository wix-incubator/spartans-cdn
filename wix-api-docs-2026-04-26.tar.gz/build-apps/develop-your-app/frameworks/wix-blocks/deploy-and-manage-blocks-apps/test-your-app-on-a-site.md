---
portal: build-apps
name: "Test Your App on a Site"
type: ARTICLE_RESOURCE
resourceId: c35676c7-5cfa-48ad-aaea-87df8f789c13
---

# Creating and Managing a Test Version

# Test Your Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Before launching your Blocks app, thorough testing is key to ensuring everything runs smoothly. Here's how to test your app in the Blocks preview, or on a site. 

Use our checklist of [what to check when testing your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/what-to-check-when-testing), to make sure you don't miss any part of your app.

## Where to test what

Some parts of your app can be checked in Preview in Blocks, whereas others can only be tested in the editor of a site. Here is a list to help you understand what goes where. However, it's always good practice to also check everything in the editor.

**What you can check in Preview**
- Responsive behavior
- How your widget elements are connected to site themes
- Widget API properties
- Logs (learn more about [debugging your code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/debugging-your-code))

**What you must test in the Editor**
- Custom panels
- Wix business solution apps [APIs](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions#apis)
- Wix business solution apps [Database collections](https://dev.wix.com/docs/develop-websites/articles/databases/wix-data/collections/working-with-wix-app-collections-and-code) 
</details>

## How to test your app in the editor

1. Click **Test**. This creates a testing version of your app, updated with the latest changes. 
1. Select a site to install your app on. This will be a [premium development site](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/test-your-app-on-a-premium-site), allowing you to test your full app functionality. 
1. Test your app as if you were a user. Make sure to follow our [checklist](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/what-to-check-when-testing), so you don't miss any testing steps. If you plan to publish your app on the Wix App Market, also see the [top ways to speed up your app approval](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/top-ways-to-speed-up-approval-in-blocks). 

## Continuous testing

 When you make more changes in your app and want to test them, there is no need to install it again. Just click **Test** again, or use the keyboard shortcuts. This creates a new testing version of the app, which updates automatically on the site you installed it on. Even if you build a [minor or major version](https://github.com/wix-private/developer-docs/blob/master/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Deploying%20and%20managing%20apps/Managing%20App%20Versions.md*original::Managing%20App%20Versions.md) in Blocks, the development site with the testing version of your app will always show the latest changes.

## Keyboard shortcuts

- The keyboard shortcut for Preview is **Cmd+Option+P** on macOS, **Ctrl+Alt+P** on Windows. 
-  The keyboard shortcut for Test in Editor is **Cmd+Option+T** for macOS and **Ctrl+Alt+T** for Windows.

<blockquote class="caution">
  <strong>Caution:</strong>
  
Blocks database collections are editable in Preview mode. Make sure not to edit them by mistake.</blockquote>
---
portal: build-apps
name: "What to Check When Testing"
type: ARTICLE_RESOURCE
resourceId: f7662917-2867-4888-91db-0c2ee469d4e8
---

# Testing a Blocks App on a Site

# What to Check for When Testing a Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Here is a list of things to check when you're testing your app on a site. Make sure to go over all the items. 

## Design

Remember that users can configure your app elements and try to imagine all the different ways they can do it. Here are some things to check: 

- For each element in your app that includes configurable content, check different types of content. For example, use short and long texts, or big and small images. 


    ![long text](https://wixmp-833713b177cebf373f611808.wixmp.com/images/45f9832e8b0593b70292b3bba5dea074.gif)
- Remove elements from your widgets and make sure that the layout stays consistent.


    ![remove elements](https://wixmp-833713b177cebf373f611808.wixmp.com/images/1c76e3d01536515e33d6f6735503172d.gif)
- Check that elements are connected to site themes. Begin with the **Test theme** option in the Blocks Preview. 

    ![connect to theme](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ca8f1f8ecd8b0253697763da5a6c68bb.gif)


- Change the theme in the site and see that all elements change together.

    ![connect to theme](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a5890d5deb49b2ef7ada88d92a2396a7.gif)
- Check the responsiveness of your widgets. Drag the handles and see that the layout rearranges well. 

    ![responsiveness](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e5c603f0966c31fd59a24c5a16526fae.gif)
- Check your app on several screensizes, including mobile view. 

    ![screen size](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2c88f3fd319bda04de698cd484cd9b13.gif)
- Check the widget's various design presets. 
     
    ![presets](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5eb561d865665671195b6abbb4907611.gif)

## Editor Experience
* Make sure that your action buttons go to the correct panels. Check this in Blocks and then in the site. 
    ![buttons to panels](https://wixmp-833713b177cebf373f611808.wixmp.com/images/88636770cb96af0f6369fde0fd3e0623.gif)
* If an element has dynamic content, make sure you remembered to remove the **Edit** action button. Check this in Blocks and then in the site.

    ![edit text](https://wixmp-833713b177cebf373f611808.wixmp.com/images/99a5413d95e4edb985a06d63996d5b93.gif)
* Make sure you have defined any element that’s essential as “non-removable” or “non-selectable”. The go to the site and check that it cannot be selected or deleted. 

    ![selectable](https://wixmp-833713b177cebf373f611808.wixmp.com/images/339d955e094684ce102fbf166e21e093.gif)
 
- Check the logic of all of your [custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks), and make sure they are working as expected. This cannot be checked in the Blocks Preview, only in a site. 


* Make sure that the [Installation Settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings) are configured correctly for each widget.

## Code

* Make sure that Wix [business solutions APIs](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions#apis) are working.
* [Debug your code](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/blocks-code/blocks-debug-code.md*original::../blocks-code/blocks-debug-code.md).


## Dashboard Page
- Make sure that the [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks) backend logic is working. 
- Make sure third party APIs are retrieving data.
- Connect your Dashboard to an [action button](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-action-bars-in-blocks). This is not mandatory, but is a good practice. 

## Pricing 
Check that you configured the plans as you expected and your logic is working according to the plans. [Learn more](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans)

## Public apps requirements
If you are planning to publish your app in the Wix App Market, make sure to go over the [top ways to speed up your app approval](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/top-ways-to-speed-up-approval-in-blocks).
---
portal: build-apps
name: "Work on a Blocks App Concurrently"
type: ARTICLE_RESOURCE
resourceId: f21641fe-79a0-4a19-841b-4c8bb6581271
---

# Working on an App Concurrently

# Work on a Blocks App Concurrently

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Blocks allows you to collaborate with other users, on the same app, in real time. More than one person can edit content and change design elements and layout.

Collaborating with others is fast and effective. Changes made by other users appear on your screen within seconds.

Learn how to [invite people to work on your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-collaborators-in-blocks)



>**Note:** 
>When you invite someone to collaborate they need to have a Wix account, or to sign up for one.



### Concurrent Editing in Blocks

As soon as someone accepts your invitation they can begin editing your app. You can see who is working on your app by checking whose avatar appears in the top right of the top bar.

  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/26/d659b7fe-813e-4d6f-ab8f-216a5479a375/687435e0-c1de-4cae-899f-b744bafac633.png) 

The person who is able to edit code has brackets **{ }** next to their avatar.

<blockquote class="important">

**Important:** 
*   Blocks does not allow two people to work on the code at the same time. The first person to open the app can edit code. Other users can read the code but not edit it. 
*   Two people cannot build the app at the same time.
*   When you are working on the app at the same time as someone else, you can undo your changes but you can't undo anyone else's changes.

</blockquote>
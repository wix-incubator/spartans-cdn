---
portal: build-apps
name: "About Configuration in Blocks"
type: ARTICLE_RESOURCE
resourceId: da3524c2-119f-407d-aca8-69b50e44feae
---

# About Configuration

# About Configuration in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Blocks allows site builders to customize your widget when they install it on a site. The site builder can change the look and feel of your widget and remove or change elements, so that it integrates with their site.

You can decide how much freedom to give site builders by configuring these different options in Blocks. With the Blocks **Configuration** tab, which is in the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/d885478b-0fa3-46d0-950a-801399d94383/8dc747a0-244b-4714-bd4c-7a71986a8394.png)  panel, you can determine how your widget and its elements look and behave when they're installed on a site. 

<blockquote class="tip">

**Configurations in the editors** 
These configurations refer to how the widget behaves in the editors and not on the live site.

</blockquote>

**Learn more about**

[Display names](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/About%20Configuration.md#display-names*original::../Blocks:%20Configuration%20and%20Panels/About%20Configuration.md#display-names)

[Widget Behavior](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/About%20Configuration.md#widget-behavior*original::../Blocks:%20Configuration%20and%20Panels/About%20Configuration.md#widget-behavior)

[Action Bars](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/About%20Configuration.md#action-bars*original::../Blocks:%20Configuration%20and%20Panels/About%20Configuration.md#action-bars)

### Display Names

Your widget can have many different elements, such as buttons, text boxes and shapes. When you insert these elements in your widget, Blocks gives them default names. In the **Configuration** tab you can give these elements display names so the site builders can easily understand what they do.

<details>
<summary>See how it looks in Blocks</summary>

![display name in configuration tab](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/22/8b3484ad-4d43-454c-acd2-315edfd71366/3f8f8b69-5d1d-4df9-bd1c-d3b8fc39a18b.png)

</details>

<details>
<summary>See how it looks in the Wix Editor</summary>

![add to cart display name in the editor](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/22/e8028bb8-4f20-43de-ab12-fc613edc6bd9/e87e7e72-e891-499f-9b11-a68bfb7efe83.png)

</details>

Learn more about [configuring display names](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/Configuring%20Widget%20and%20Elements%20Display%20Names%20and%20Behavior.md#setting-a-display-name-for-a-widget-or-element*original::../Blocks:%20Configuration%20and%20Panels/Configuring%20Widget%20and%20Elements%20Display%20Names%20and%20Behavior.md#setting-a-display-name-for-a-widget-or-element)

### Widget Behavior

The Wix Editors offer site builders a lot of freedom when they customize your widget. You can decide to limit some of these options by using the **Configuration** tab. You can define whether or not elements can be selected or removed, duplicated or resized.

There may be elements in your widget that are essential to its function, an **Add to Cart** button for example. You can configure your widget so that a site builder cannot remove this element from your widget.

Or, you might want to limit some options for design purposes, because you want the design to stay as it is. You can define any element as non-selectable or non-removable. 

 ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/22/8e662834-1248-4d93-b97c-b5084977fd6c/72b13493-e3ff-480f-af28-ceb859abd61a.png) 

You also might want to prevent your widget from being duplicated (for example, if it's connected to dynamic pages and duplication might trigger conflicts or break code) or from being resized (for design reasons).   

 ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/22/31775b6c-5021-45ad-ab79-7792c419c244/dcabcc43-2578-4ab5-b30a-13ce95a68d8e.png) 

Learn more about [widget behavior](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/Configuring%20Widget%20and%20Elements%20Display%20Names%20and%20Behavior.md#configuring-widget-or-element-behavior-selectable-removable-duplication-and-resize*original::../Blocks:%20Configuration%20and%20Panels/Configuring%20Widget%20and%20Elements%20Display%20Names%20and%20Behavior.md#configuring-widget-or-element-behavior-selectable-removable-duplication-and-resize)

### Action Bars

Each element of your widget has an action bar which the site builder uses to customize it. You can modify the action bars in the **Configuration** tab. You can add, remove or reorder buttons. You can determine which panel opens when a button is clicked, and more. The modification options vary, depending on whether you select a widget, or one of its elements, and which element you select.

<details>
<summary>See how it looks in Blocks</summary>

![action bar settings in configuration tab](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/22/f46d9ae7-32d4-4808-ace5-e1bbd0ce89da/58175ce2-4678-4d5b-850a-a8451a03de64.png)

</details>

<details>
<summary>See how it looks in the Wix Editor</summary>

![action bar example in the editor](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/22/7c1afb25-1709-44d0-9b81-1bba8c06ef57/dc47f88e-5ffd-4718-bbc7-2ca367131ccc.png)

</details>

Learn more about [configuring action bars](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/Configuring%20Action%20Bars.md*original::../Blocks:%20Configuration%20and%20Panels/Configuring%20Action%20Bars.md)

<blockquote class="tip">

**Action button panels** 
When you add an action button you can add a custom panel to it in the **Panels** tab. 

Learn more [about panels](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/About%20Panels.md*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md)

</blockquote>
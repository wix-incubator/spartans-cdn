---
portal: build-apps
name: "About the Editor Experience in Blocks"
type: ARTICLE_RESOURCE
resourceId: 0e197953-5d2e-4e02-9064-5f8e76d33921
---

# About Configuration and Panels

# About the Editor Experience in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

<blockquote class="important">


Wix Blocks is open to all Wix Studio users. To get access to Blocks, [join Wix Studio](https://support.wix.com/en/article/wix-studio-switching-to-wix-studio).

</blockquote>

Blocks allows Wix users who install your widget to customize it in their editor. Users can change the settings of your widget and its elements, add or remove elements, see the IDs that you give to elements, and more. 

![configuration GIF](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e25c2a545876e4bc4f18793ec11f237b.gif)

### Configuration

Go to the Blocks [Configuration](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/about-configuration-in-blocks) tab, to determine how your widget and its elements look and behave when they're installed on a site. You can configure:
* Display names of widgets and their elements
* Widget behavior (for example, whether or not site creators can select)
* Action bars of widgets and their elements

### Panels

Every Blocks widget comes with several default [panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/about-panels-in-blocks) for design, presets, settings and adding or removing elements.

You can also go to the [Panels tab](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/about-panels-in-blocks) to create custom panels. Creating custom panels has three steps: 
* [Design your panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks): plan the panel, add elements and text.
* [Code your panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks): add the code that connects between the panel elements and the widget's behavior.
* [Connect your panel to an action button](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks), so that when a site-creator clicks the button, the panel opens.
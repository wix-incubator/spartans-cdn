---
portal: build-apps
name: "Configure Action Bars in Blocks"
type: ARTICLE_RESOURCE
resourceId: 4906ec90-7216-43d3-b7ac-470a7b899a19
---

# Configuring Action Bars

# Configure Action Bars in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

The Configuration tab in the Editor Experience panel enables you to determine the way your widget and its elements look and behave in the editor when they're installed on a site. 

### About Action Bars

When a site builder installs your widget on a site and opens the editor, the widget and its elements have floating action bars, just like any other Wix site element. For example, this is the action bar of the widget's button, which allows the site builder to perform various actions on the button:

<div style="text-align:center">

![button action bar](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/09/45198d44-4dea-4982-b938-1455af3b9119/a57e6d79-599d-4cef-bbb0-58684a31209b.png)

</div>

Blocks lets you modify these action bars. You can add, remove or reorder buttons. You can determine which panel opens when a button is clicked, and more. The modification options vary, depending on whether you select a widget, or one of its elements, and which element you select.

By modifying the action bars you can give site builders more options for customizing your app when they install it on their site. You can also decide that you want to limit what they can change in your widget. 

<blockquote class="tip">

**UX guidelines** 
Read our [UX guidelines](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/ux-guidelines-for-editor-experience-in-blocks) for clear and effective action bars

</blockquote>

### Modify Action Bars

**To modify action bars:** 

1.  Click the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/5ad6e6ae-179c-4b7f-bb4e-ef9a1ad955fe/5c5b01ad-59b6-4913-aaeb-83dc7c46e8c1.png)  panel.
2.  Click the **Configuration** tab.  
3.  Select the correct element in your widget, or select the entire widget from the **Widgets** panel.

**Now, you can modify action bars in two ways:**

*   From the **Edit Action Bar** that appears:

<div style="text-align:center">

![edit widget action bar](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/19/e3859b34-c6e9-44fd-8e6b-46972d5073e2/490b8070-b9c5-4a7f-895b-293cc931785b.png)

</div>

*   Or from the **Action Bar** section in the **Inspector** panel on the right (if you can't see the panel, click on the **Inspector**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/47a1ea96-8804-4a32-8959-9f910d42272f/4eb3ddd8-023e-4ce9-aa05-f8eec5a3737e.png)  icon to expand it). 

<div style="text-align:center">

![modify action bar in inspector](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/02/fd63b906-45cb-4345-ab57-4262013b13b9/c785f150-0d7b-44c6-8247-51aa65758e3c.png)

</div>

### Removing and Adding Action Buttons

*   Hover over the action bar buttons to see which of them can be removed, and click **Remove** to remove that button.

<div style="text-align:center">

![edit action bar remove button](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/02/098555df-3dc4-4d55-8e08-c8d2bb1343ce/b0fbdfae-3390-4329-9f26-cf0608720032.png)

</div>

*   Add any buttons you removed by choosing **+** **Add** in the **Edit Action Bar** panel, or **Add Action Button** in the **Action Bar** section in the **Inspector** panel on the right (if you can't see the panel, click on the **Inspector**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/c4aa336d-9974-45c2-bb61-8ea1936b2255/5e9c4e05-8b3b-47bc-b10c-d5892483df0c.png)  icon to expand it).

### Changing Action Button Settings

1.  Hover over the action bar buttons to see which of them have settings that can be changed.
2.  Click the **Action Button Settings** button. 
3.  At this point, you can also change the text of the action button. 

<div style="text-align:center">

![Action Button Settings](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/02/d912043c-d0b3-4ff9-9f96-776fcd78f3f7/da563aa0-6887-4dcf-911c-0ef2933a4483.png)

</div>

1.  Select the [panel](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/About%20Panels.md*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md) or [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks) that you want to open for the action button settings. You can also [create a new custom panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) and then assign it to the action button. Clicking **Create Custom Panel** will take you to the **Panels** tab.

<div style="text-align:center">

![action button settings](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/11/02/3347368a-a71f-4aea-b761-d7e404fbb8c9/92c6feb2-3e05-4f53-b2f2-f399e513fd5a.png)

</div>

>**Notes** 
> *   When you add an action button you need to make sure that you assign a [panel](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Configuration%20and%20Panels/About%20Panels.md*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md) or a [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks). If you don't you will see a warning in the **Inspector** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/81622adc-781e-47ea-85f8-aff67ac13734/b496597f-6d7b-4332-9f94-41a28b1f9d71.png). 
> *   The changes you make when you are in the Configuration tab impact all [design presets](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md).
> *   Make sure to read our [UX guidelines](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/Design%20Guidelines%20for%20Applications.md*original::../Blocks:%20Design%20widgets%20and%20apps/Design%20Guidelines%20for%20Applications.md) for clear and effective action buttons
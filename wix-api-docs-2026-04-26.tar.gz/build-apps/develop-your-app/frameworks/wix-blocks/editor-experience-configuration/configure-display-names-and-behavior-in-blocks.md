---
portal: build-apps
name: "Configure Display Names and Behavior in Blocks"
type: ARTICLE_RESOURCE
resourceId: 8803f7e8-9483-44ff-9a18-76618d7e0848
---

# Configuring Widget and Elements Display Names and Behavior

# Configure Display Names and Behavior in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

The Configuration tab in the Editor Experience panel enables you to decide how your widget and its elements look and behave when they're installed on a site. Make sure to check out our [UX guidelines](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/blocks-widget-design-guidelines) for Configuration.

### Widget and Elements Display Names

There are lots of ways you can help site builders get the most out of your app. Giving the elements in your app a display name makes it clear to site builders what each element does. You can also decide how they use different elements, and give them design options. 

If you don't define these display names, your widget and its elements will have default display names like "widget" and "button". They will also have default Velo IDs, such as "#widget1" in the Properties and Events panel.

#### Setting a display name for a widget or element

When you design a widget, you want the site builders who install it on their site to understand what it does. You also want them to be sure about what each of the widget's elements does. 

For example, you can make sure that your widget is called "Single Product" and that one of its buttons is "Add to Cart". 

**To set the display name:**

1.  Click the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/ed55de36-fcb5-40d4-b738-c9abaf7f2e23/117b4ba6-5023-4a05-93bf-e770a46a4451.png)  panel.
2.  Click the **Configuration** tab.  
3.  Select the correct widget from the **Widgets** panel on the left (if you want to name a specific element inside the widget, select it).
4.  Click the **Inspector**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/18a45da9-babb-42b0-a0e1-d37bb5eeb4a2/f2c501cf-565d-4b87-b1fd-8b075523f424.png)  icon in the top right corner to expand the **Inspector** panel, if it isn't expanded yet. 
5.  Insert the new display name under **Component Name**. 

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/1a050513-6de9-4500-9371-fbb118b2c46f/48e5001a-5abd-49a0-b05a-e335bbe1f518.png)

</div>

<details>
<summary>See how it looks on a site</summary>

![how widget display names work on a site](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/16/2f718975-5561-4ec0-9422-9d21553f11b7/b05d4a29-add7-4ea7-aac6-745f380c7192.gif)

</details>

### Configuring widget or element behavior (selectable, removable, duplication and resize)

In some cases you might want to control the way the widget or its elements behave: 

**Widget behavior:**  

*   **Can be duplicated:** You might want to prevent your widget from being duplicated by copy and pasting, (for example, if it's connected to dynamic pages and duplication might trigger conflicts or break code). In this case, uncheck this box.
*   **Can be resized:** You might want to prevent a widget from being resized, for design reasons. 

**Element behavior:** 

*   **Can be selected:** You might have organized all of your widget elements in a flexbox element, for design purposes. But when someone installs your widget on a site, you don't want them to touch the flexbox - because you want the design to stay as it is. In this case, uncheck this box.
*   **Can be removed:** Some elements might be crucial for your app logic. For example, an **Add to Cart** button. You would probably not want a site builder to remove it from the widget. In this case, uncheck this box.

#### Configuring a widget's behavior

1.  Click the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/ed55de36-fcb5-40d4-b738-c9abaf7f2e23/117b4ba6-5023-4a05-93bf-e770a46a4451.png)  panel.
2.  Click the **Configuration** tab.  
3.  Select the widget from the **Widgets** panel. 
4.  Select or un-select the checkboxes **Widget can be duplicated** and **Allow widget to be resized** in the **Behavior** section of the Inspector  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/97f05949-d871-42b9-9ba2-97334fff21c2/fe416f77-abe9-44ab-b597-8a8df8581d04.png)  panel (if you can't see the Inspector, click on the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/77104546-76a7-4bc9-8eee-cd779dbd2376/31b8bb93-a61d-4034-a397-04c30263ada9.png)  icon to expand it).

<div style="text-align:center">

![widget behavior](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/16/e4b9de6a-c42f-4c7f-8c05-e1f0785c33f4/39c62fbf-42b1-44ba-a038-ab40b3f8b261.png)

</div>

#### Configuring an element's behavior

1.  Click the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/ed55de36-fcb5-40d4-b738-c9abaf7f2e23/117b4ba6-5023-4a05-93bf-e770a46a4451.png)  panel.
2.  Click the **Configuration** tab.  
3.  Select the element you want to configure. 
4.  Select or un-select the checkboxes **Can be selected** and **Can be removed** in the **Behavior** section of the **Inspector** panel (if you can't see the Inspector, click on the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/97f05949-d871-42b9-9ba2-97334fff21c2/fe416f77-abe9-44ab-b597-8a8df8581d04.png)  icon to expand it:

<div style="text-align:center">

![layouter behavior](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/16/baabfc9e-6c86-4316-932c-8c716a8f0130/6a75676c-4dba-4bb2-be67-aa5611b01f63.png)

</div>

>**Notes:** 
>*   The changes you make when you are in the Configuration tab impact all [design presets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/create-and-manage-design-presets). 
>*   In the Configuration tab, you can also modify the action bars connected to each element when your widget is installed on a site. Learn more [about modifying action bars](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-action-bars-in-blocks)
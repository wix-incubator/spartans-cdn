---
portal: build-apps
name: "UX Guidelines for Editor Experience in Blocks"
type: ARTICLE_RESOURCE
resourceId: f20b9d58-9592-4360-83fc-4c7199c59b7c
---

# UX Guidelines for Configuration and Panels

# UX Guidelines for Editor Experience

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

A Blocks widget blends  seamlessly, both with the site-builder's editing environment, and the experience of the site visitor. Following these guidelines will help make the experience of whoever installs your app as easy and intuitive as possible. Whenever in doubt, use this rule of thumb: their experience should be similar to what you see in the Wix site editor. All guidelines refer to the [**Configuration**](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/about-configuration-in-blocks) and [**Panels**](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) tabs in the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/d885478b-0fa3-46d0-950a-801399d94383/8dc747a0-244b-4714-bd4c-7a71986a8394.png)  panel in Blocks. 

### Selecting Elements

You can define whether your widget elements [can be selected](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-display-names-and-behavior-in-blocks) by a site builder who installed your app, in the **Configuration** tab in the **Editor Experience** panel. In general, invisible elements, such as layout tools (for example, a stack), should be defined as non-selectable. This makes the experience of the site builder who installs the widget easier and clearer.

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/ae08b76a-80da-4753-946c-33fc544b6bc7/6a5243b8-7438-4aed-871a-8cb8d11e2187.png)

</div>

For example, take the following widget. You can see in the **Layers** tab in Blocks that it has a layouter, an image, a stack, two texts and a button. 

<details>
<summary>See example</summary>

  

![all elements in Blocks](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/09/27/eb755545-3427-4c53-972a-2ab9b3c85009/4fefb0ab-09aa-43bd-8318-7f04fae31e11.png)

</details>

We defined all the non-visible elements of this widget as non-selectable. When it is installed in the editor, only the image, texts and button can be selected. 

<details>
<summary>See example</summary>

  

![in the editor](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/09/27/6810ff22-9d83-4af2-a66a-873d6c64ff35/379baf30-f443-404b-a9ed-e2a5b75dbabf.gif)

</details>

#### Exceptions

In some cases, en element is not a layout tool and still you will want it to be non-selectable: 

*   When your widget is a [custom element.](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-custom-elements-in-blocks) 
*   When an element is essential for the widget and therefore cannot be removed. If you uncheck the "Can be removed" checkbox, the "Can be selected" checkbox will automatically be unchecked. 
*   When the entire widget is **treated as a single element**. For example, a social bar, a small rating widget, or a calendar. Here is an example of a social bar, that does not allow selecting inner elements. We defined the repeater, its items and the button non-selectable. Everything you need to configure is done through the widget's Settings panel. 

<details>
<summary>See example</summary>

  

![social bar exmaple](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/09/27/c68fbca0-0c7c-4b7c-b9ff-0d41dc54259c/53f36310-fb0e-4060-b37b-8984865ac334.png)

</details>

* * *

### Display Names

You can set display names for your widgets and their elements. The display name appears in a site builder's site-editor. For example, the button in this widget was given a meaningful display name: "Add to Cart". 

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/fe11addc-0847-40aa-ae3f-2ce85ab5ebb7/10093252-8c10-4e6b-9269-d2d052950971.png)

</div>

*   Don't use the word "Widget" in your widget's display name (you also shouldn't use it in the widget name itself). 
*   Give the widget elements a meaningful display name. For example, if your widget has an input element for a site-visitor to write their email address, call it "Email" and not "Input". 
*   Use **title case** to capitalize the display name. 

* * *

### Configuring Action Bars

Widgets and their elements come with default action bars (floating menus). The buttons on the action bars are called action buttons . 

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/5cd88a25-5ddc-4e14-98e6-e9b64352d1f8/84c5f692-2fc8-47e1-9c13-8a767c20b72b.png)

</div>

#### Action Bar Design

*   You can remove and add action buttons. Note that the main action (the left one, which has a word on it and not only an image), can't be removed. 
*   If a text field has dynamic text, which the site-builder should not edit, make sure to change the main action from "Edit Text" to "Design Text". This sort of text can be changed from the [Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/build-a-dashboard-page-in-blocks).
*   We recommend not to connect a design panel to the paintbrush action button, since it will work only in the Wix editor and not in the Studio editor. 

#### Action Bar Text

*   Make sure that the name or icon of the action button matches the goal of the panel that opens. For example, a design icon will open a design panel. 
*   Make sure that the name is short and clear. For example: "Settings". It can also be a call to action (CTA), such as "Manage App". 
*   Use **title case** for the button names. 

* * *

### Custom Panels

You can [create custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) and connect them to the widget or element action bars. Before creating a custom panel, make sure to understand the [different types of panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/about-panels-in-blocks) in Blocks. 

#### Panel Design

*   **Hiding elements:** only show panel elements that are needed. You can use the panel code to hide unnecessary elements. 

<details>
<summary>See example</summary>

  

![show and hide panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/09/21/362873db-4caf-4ad1-bf1f-f62a41edb10d/5e22c9a1-43e3-4fd5-8ad4-c12ddc22ce4e.gif)

</details>

*   **Disabling elements:** If you choose to show a disabled element instead of hiding it, use a tooltip to say why it's disabled. Every panel element has a _tooltip_ and _enabled_ property that can be changed with code (for example, see the API reference for a [Panel Button](https://dev.wix.com/docs/velo/velo-only-apis/$w/panel-button/introduction)). 

<details>
<summary>See example</summary>

  

![disable panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/09/21/0c04b79f-6e98-43ea-9a70-88eb2405c598/eab8052c-f929-4464-b78e-0418bc053e9f.gif)

</details>

*   **Autosave:** Confirmation buttons such as “OK” and “Cancel” are usually not used in panels, since the changes are applied immediately. 
*   **Tooltips:** Do not overload panels with text paragraphs. If you need to add more information, expose it  with a tooltip. 

<details>
<summary>See example</summary>

  

![section and tooltip](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/09/21/4b6638c3-fdfa-4992-a232-7ebdd779aaf7/d03815e8-51be-4038-992c-500c503e03ed.gif)

</details>

#### Panel texts

Panel text should e clear, concise and useful, to ease user decision making. Be consistent, use the same terminology, structure and tone of voice everywhere. 

*   **Capitalization:** Use title case for the panel title, and sentence case for other panel texts.
*   **Title length**: Approximately 20 characters. 
*   **Title wording**: First state the name of your widget / element and then the name of the action . For example, if your widget is a product and the button is **Settings**, name your panel: **Product Settings**. 
*   **Labels:** Labels should be short and clear as possible. They can be questions, but not necessarily. For example, "Choose what displays" could also be "What's displayed?" 

<details>
<summary>See example</summary>

  

![button settings](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/11/15/7a5fa759-6821-4284-a820-3185ced8b048/857c8c7e-a2e2-45ca-8939-40d2f333f43f.png)

</details>

*   **Section divider headings:** Section dividers should separate between different topics in a panel. They should not be written as a question. 
*   Avoid using Parentheses unless absolutely necessary.
*   Avoid the word "Click". Instead of **Click to Update**, just say: **Update**.
---
portal: build-apps
name: "About Panels in Blocks"
type: ARTICLE_RESOURCE
resourceId: 1c4dfa8e-b156-4d1f-93a9-35a60492b25c
---

# About Panels

# About Panels in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Blocks allows site builders to customize your widget when they install it. A large part of this customization takes place through the widget's action bars. The site builder adapts the widget to their site through using the action buttons. Learn more about [action bars](https://github.com/wix-private/developer-docs/blob/2567c110b82a827a18cdd8e0cc655963dbb25c52/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Configuration%20and%20Panels/Configuring%20Action%20Bars.md*original::../Blocks:%20Configuration%20and%20Panels/Configuring%20Action%20Bars.md).

Panels are a key part of the customization process. When your widget is installed on a site, the site builder clicks on the widget, or its elements, and an action bar appears. When you click on an action button, for example, the **Design**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/21/c89fa121-9d61-4379-aa2a-929f125bd4ea/e94ac900-234d-4d7b-88b1-39fc882c19d8.png)  button, a panel appears. You use the options available in this panel to customize your widget.



>**Note:** 
>Panels are available for site builders in the Wix Editors, not on the live site.


**Learn more about**

[Blocks default panels](https://github.com/wix-private/developer-docs/blob/2567c110b82a827a18cdd8e0cc655963dbb25c52/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Configuration%20and%20Panels/About%20Panels.md#default-panels*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md#default-panels)

[Blocks custom panels](https://github.com/wix-private/developer-docs/blob/2567c110b82a827a18cdd8e0cc655963dbb25c52/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Configuration%20and%20Panels/About%20Panels.md#custom-panels*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md#custom-panels)

[Panel examples](https://github.com/wix-private/developer-docs/blob/2567c110b82a827a18cdd8e0cc655963dbb25c52/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Configuration%20and%20Panels/About%20Panels.md#custom-panel-design-examples*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md#custom-panel-design-examples)

### Default Panels

Blocks uses default panels which give site builders a range of customization options. The default panels are generated automatically by the Blocks product.

Available default panels:

<details>
<summary>Design presets panel (see more)</summary>

The **Design** button ![editor design button](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/17/b54f9864-02c1-4db3-a43f-4a90e0738ec8/bbbf5bbc-192e-463a-aaad-40e11bb8d0fd.png) opens a presets panels so that you can switch between design presets.

  

![default design presets panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/17/ae5c801a-278c-4c4b-bfd7-045d7ba7c995/b269f49f-e527-43a5-9737-9b32c94de99c.png)

</details>

<details>
<summary>Add Elements panel (see more)</summary>

If the site builder has hidden one of the elements of your widget the **Elements** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/17/c42bd1dd-83eb-4ac5-a9dd-c80f50aab89b/32dafadd-7bcc-4529-ab89-21dc3a3338b3.jpg) button opens a panel with all the hidden elements so that they can be restored. In the following example a widget button has been hidden but can be restored using the default panel. 

  

![default elements panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/17/ca17a8cf-7555-4d60-aa1a-fc31fd26ae80/07da5151-648e-406e-9037-ab743fa5e785.png)

</details>

<details>
<summary>Settings panel (see more)</summary>

Site builders can access your widget's API through the default settings panel.

  

![default settings panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/17/fb76e02b-8bef-466c-a1b4-ba62221e8832/a5e33ab9-9e6f-459b-ba1b-6b030f1dbf5b.png)

</details>

<details>
<summary>Editor elements default panels (see more)</summary>

Site builders have access to all the regular editor default panels such as design, layout and settings for every element in your widget's UI.

The following screenshot shows the default design panel in the Change Design button.

  

![change design panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/20/771d75d1-7c9a-43fa-9871-af4bceed73b5/34935fff-708a-4a4c-9b09-9bcb4161eb9a.png)

</details>

### Custom Panels

<blockquote class="tip">

**API reference for panel elements** 
See all available panel elements and [their API reference](https://www.wix.com/velo/reference/$w/panelbutton).

</blockquote>

The user interface of the default panels cannot be changed. By using custom panels, you can change the user interface and create panels that are unique to your widget, which direct the flow and how it's used.

You can create unique [designs](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) for your panel by using sliders, section dividers, toggles and multiple choice elements. Adding these elements makes your widget easier to customize and more functional. 

After designing your panel, you need to write [code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks) to make it work.

### Custom Panel Design Examples

**Pay Button Settings Panel**

If you have a shopping widget, with a pay button, for example, you can create a custom panel which allows the site builder to choose which information is displayed. The site builder can customize the widget so that on different sites it can display different information. On one site it might be important to display the price in another currency, or to show the terms and conditions. 

This Pay Button Settings panel includes rich text (text with links), text input fields, dividers and a toggle, which enables the site create to decide whether or not to show the Terms & Conditions.

This is how it looks when the toggle is on:

![pay button custom panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/30/426c12ee-efbe-4061-93e9-824424d059a6/210582fe-d588-4149-a592-e1f43f9ffc4c.png)


#### Login Bar Settings Panel

If your widget is a login button, you can design a panel which gives the site builder the option to decide whether to display a greeting or not, or if they want to display a profile pic or name. By using a custom panel the site builder can change this on different sites. They can use the same widget on one site which displays a profile pic, and on another site the same widget displays a name only.

This panel for the Login Bar Settings button has a radio button, text inputs, a divider and a toggle, which determines whether or not to show a greeting before the user's name.

![login bar custom panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/30/b868f63d-87e7-43c9-96c5-a4a63a4c1351/dd01e8e0-2b80-4432-94cf-61b168161732.png)
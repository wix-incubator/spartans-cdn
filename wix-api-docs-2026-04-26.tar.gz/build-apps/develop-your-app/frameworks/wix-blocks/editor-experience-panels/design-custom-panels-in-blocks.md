---
portal: build-apps
name: "Design Custom Panels in Blocks"
type: ARTICLE_RESOURCE
resourceId: c5dba51c-1f6c-4b4a-ba16-811f4009f0f5
---

# Designing Custom Panels for Your Widget Action Bar Buttons

# Design Custom Panels in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Create custom panels for action buttons in your widget and its elements. When a Wix user clicks an action button (for example, the Settings button), the custom panel opens. 

You can create as many panels as you need, to provide users with various options to customize widgets.

Creating your panel has **three main stages:**

1. Design your panel, as described in this article. Use [our UX guidelines](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/ux-guidelines-for-editor-experience-in-blocks#custom-panels) to make your panels clear and effective.

2. Connect your panel to an action button.

3. Add logic to your panel to make it work.  

<blockquote class="important">
  <strong>Important:</strong>
  
You cannot test panels in the Blocks preview. To see your panel in action, [test it on a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site). 
</blockquote>


<blockquote class="tip">
  <strong>Examples:</strong>
  
To see examples of custom panels, open the following app templates and go to the **Editor Experience** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/d885478b-0fa3-46d0-950a-801399d94383/8dc747a0-244b-4714-bd4c-7a71986a8394.png) tab. 
- [Repeater app](https://dev.wix.com/apps-templates/template?id=a4a7246f-4644-48ce-81e7-2a86aa74d9e5&http_referrer=documentation): Panel for changing the widget layout.
- [Events Map app](https://dev.wix.com/apps-templates/template?id=f086effa-64b8-4c8b-a5c8-61c3a7548af7&http_referrer=documentation): Settings panel. 
- [Recipe List app](https://dev.wix.com/apps-templates/template?id=512a7d8a-1666-40c2-9586-25874d2f69b4&http_referrer=documentation): Setting panel that also links to a dashboard page. 
- [Banner app](https://dev.wix.com/apps-templates/template?id=1b7db962-6230-46bf-b908-d988ef640238&http_referrer=documentation): Panel for adding and removing elements. 
- [Pie Chart app](https://dev.wix.com/apps-templates/template?id=9a55382c-c755-4f01-bda2-80b85630acdd&http_referrer=documentation&http_referrer=documentation): Settings panel for custom element in Blocks.
</blockquote>

## Create your panel

First, go to the Editor Experience panel to create a panel.

1. Click the **Editor Experience** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/d885478b-0fa3-46d0-950a-801399d94383/8dc747a0-244b-4714-bd4c-7a71986a8394.png) icon.
2. Click the **Custom Panels** tab.
3. Click **Create New Panel**. 

## Add elements to your panel

Your panel is built of [panel elements](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-elements-in-blocks), such as buttons, dividers, input fields and more. Before designing your panel, read our [UX guidelines for custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/ux-guidelines-for-editor-experience-in-blocks#custom-panels). 

Click **\+ Add Element** and select which elements you want to add to your panel. You can add the same element as many times as you need. Then, you can customize the label text and style, and set defaults and values. 

## Customize your panel

You have several customization options for the elements in your panel. You can change label text, add tool tips, set defaults and values. You do this by using the action bar connected to each element.

### Settings options

Click on an element. Select **Settings** or the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/22/2ebb7ba4-f134-4791-96d5-df1a71214876/f01c7af3-5437-472a-b98f-c5f6d1b79996.png)  icon to customize your panel. Here are some of the options:

<details>
<summary>Add field titles (see more)</summary>

Fill in the **Field Title** field provide a label for your element (for example, in the following image, **Fill Color & Opacity** and **Border** are labels). To remove the label, delete the text.

![label](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/23/c358ba23-3d56-4e03-bb5a-ff3cc6df1c15/a46f5126-d17e-4f8f-863b-5d22ca829fe3.png)

</details>

<details>
<summary>Add tooltips (see more)</summary>

Write some text in the **Tooltip Info** box to add an info icon with a tooltip containing additional information for site builders who install the widget. To remove the info tooltip, delete the text in the field.

</details>

<details>
<summary>Define element as "read only" (see more)</summary>

Toggle on **Read only** so that the user can only see and copy the text inside, but cannot type in it.

</details>

<details>
<summary>Set initial text options (see more)</summary>

An input field in a panel may appear empty, or may contain initial text in several forms:

*   **Default text:** The input field appears with default text.
*   **Placeholder:** The input field appears with a message in a light shade (usually gray), which says what the user should type there and disappears once they start typing.
*   **Both:** The input field appears with default text, but if the user deletes it, they will see the light placeholder text.

</details>

<details>
<summary>Add pattern validation (see more)</summary>

Toggle to enable [regex](http://www.codemag.com/article/0305041) (regular expression) to apply additional criteria whenever the field is validated. Use the edit box to enter and edit your regular expression.

</details>

### Multiple choice elements

If you choose to add an element that has multiple options, like check boxes, radio buttons or dropdown lists, you can configure them by using the manage choices button in the action bar that appears when you select the element.

<details>
<summary>Rename choices (see more)</summary>

Click **Manage Choices** to open a pop-up with the list of the choices in your element. Double click the choice you want to rename and enter the new name in the field box. You can reorder your choices using drag and drop.

![managing choices renaming a choice](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/26/17dda8e0-04be-421e-acd5-5fad40bd7875/69945bb7-760a-41ea-a7b0-e06f6e1c7e3f.png)

</details>

<details>
<summary>More Actions (see more)</summary>

Click **Manage Choices**, hover over the choice you want to edit and click the **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/22/418cb81e-65bc-4ccd-af0a-b4a46cc9f32e/db459a87-d0cd-415b-b0d9-b66fcdfebdae.png) icon, to set defaults, edit values, and move or duplicate elements.

  

![more actions menu in manage choices](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/26/8d817f81-ecaa-400a-9de9-778414d0c7dc/1a6a1b86-dbea-4bff-9126-dd8487f45bae.png)

</details>


## Name your panel

1.  Hover over your panel name in the **Custom Panels** section . 
2.  Click the **More Actions**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/10/18/1fa8a888-57fa-46af-86cd-fff5380ef88c/67e8b665-5252-4ad7-ae7e-160dd07bbb6f.jpg)  icon when it appears. 
3.  Select **Rename**.

4. When naming your panel, note that this name is visible to users. See our [UX guidelines for panel texts](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/ux-guidelines-for-editor-experience-in-blocks). 

5. You can also duplicate or delete your panel if needed. 

<div style="text-align:center">

![rename duplicate delete panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/28/5d046cbe-fa14-46f8-9a53-f32be7be4013/c64c1485-d841-4b54-90fb-ca3627641d7b.png)

</div>

## Connect your panel to an action button

After creating your panel, you must connect it to a button in the action bar of a widget or an element.  

1.  Click the **Editor Experience**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/04/24/d885478b-0fa3-46d0-950a-801399d94383/8dc747a0-244b-4714-bd4c-7a71986a8394.png)  icon.
2.  Click the **Configuration** tab.
3.  Select the desired widget from the **Widgets** panel. 
4.  Hover over the button to which you want to connect your panel, in the **Edit Action Bar** menu that appears. For example, if it is a settings panel, select the settings button. If it's a design panel, select the design button. You can also add a new button, name it and connect it to a panel.
5.  Click  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/09/09/83e2f61d-0005-4613-871b-24b5b264b268/874431bc-fb51-471d-a779-889744b04245.png)  **Action Button Settings**. 

<div style="text-align:center">

![select your panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/28/5032a2a0-0f85-4c3e-92c6-593b65daee66/30bb54ac-663d-4263-b0f7-e1a6f5ce47a7.png)

</div>

<div style="text-align:center">

![action button settings](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/06/28/425f2f9f-3111-46e7-ada5-6ea92c16e256/862a1c3b-5da9-416f-8e99-12477b962c9b.png)

</div>

5\.  Select your panel from the **Custom Panels** section. 

 
## What's next
Now that you have designed your panel you need to add its logic. This can include: 
- [Connecting widget properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/connect-panel-elements-to-props)  to panel elements, so users can change the properties. 
- [Creating button rules](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-button-rules-to-open-pages) to open a pricing page, dashboard page or an external URL. 
- [Adding code to your custom panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks) for any other logic you need.
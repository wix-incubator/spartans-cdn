---
portal: build-apps
name: "Panel Button Rules to Open Pages"
type: ARTICLE_RESOURCE
resourceId: d73171b1-542e-4ccb-bb7a-80933877f8bd
---

# Panel Button Rules

# Add Panel Button Rules to Open Pages

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Panel button rules determine which page opens when Wix users click the button in their editor. These rules can lead to one of three pages:
* One of your app's [dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks)
* Your app's [pricing page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans)
* Any external URL

To add a rule to a panel button:

1. Click the button. 
1. Click **Rules** -> **Open a page** in the Inspector.
1. Click **+ Add Rule**.
1. Select one of the three options: dashboard page, pricing page or an external URL. 

![button rule](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2543182e670ef555e34cd9d0227b4b06.png)
## Open a dashboard page

[Dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks) are administrative pages that allow Wix users to manage the app's data and settings. 
 
Creating a panel button that leads to a dashboard page is a good way to increase the page's visibility. 

Note that you can also define a button to navigate to a dashboard page [using code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/open-a-blocks-dashboard-page-from-a-custom-panel). 

## Open your app's pricing page

When you [add pricing plans to your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans), it gets a pricing page where users can choose their plan and upgrade their app. 

Providing a button that leads to that page is a good way to let users upgrade your app (you can also use [more entry points](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/provide-entry-points-to-upgrade-your-app#provide-entry-points-to-upgrade-a-blocks-app) for this). 

If you are creating an Upgrade button and connecting it to your pricing page, consider changing the button type to **Premium** to get the purple color. 

![premium style](https://wixmp-833713b177cebf373f611808.wixmp.com/images/08df1aabcdab0360d05c46b71319696a.png) 

## Open an external URL 

Add the full URL of the site you'd like to open. Use this option, for example, to provide support or documentation.
---
portal: build-apps
name: "Panel Elements in Blocks"
type: ARTICLE_RESOURCE
resourceId: ce2f11d9-8551-426e-932c-9cbb194d1cff
---

# Panel Elements

# Panel Elements in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Blocks [custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) are made of unique panel elements.

To reference the panel elements in your widget's code, go to the [code section of the Panels tab](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks).

Use the [$w()](https://www.wix.com/velo/reference/$w/$w) [function](https://www.wix.com/velo/reference/$w/$w) to select elements by ID, for example:

```javascript
let label = $w("#myPanelElement").label;
```

## Panel element APIs

The following panel elements are available to use in your panels. Click each element to see how to reference it in your panel code: 

*   [Panel Slider](https://www.wix.com/velo/reference/$w/panelslider)
*   [Panel Thumbnails](https://www.wix.com/velo/reference/$w/panelthumbnails)
*   [Panel Button](https://www.wix.com/velo/reference/$w/panelbutton)
*   [Panel Checkbox Group](https://www.wix.com/velo/reference/$w/panelcheckboxgroup)
*   [Panel Dropdown](https://www.wix.com/velo/reference/$w/paneldropdown)
*   [Panel Radio Button Group](https://www.wix.com/velo/reference/$w/panelradiobuttongroup)
*   [Panel Rich Text](https://www.wix.com/velo/reference/$w/panelrichtext)
*   [Panel Text Input](https://www.wix.com/velo/reference/$w/paneltextinput)
*   [Panel Toggle Switch](https://dev.wix.com/docs/velo/velo-only-apis/$w/panel-toggle-switch/introduction)
*   [Panel Section Divider](https://www.wix.com/velo/reference/$w/panelsectiondivider)
*   [Panel Color Picker](https://www.wix.com/velo/reference/$w/panelcolorpicker)
*   [Panel Font and ColorPicker](https://www.wix.com/velo/reference/$w/panelfontandcolorpicker)

##  Helpful SDK and Velo modules

Import the following modules to interact with the panel elements in your panel code: 
 
* The [widget SDK module](https://dev.wix.com/docs/sdk/host-modules/editor/widget/introduction) lets you interact with your widget's properties and design presets from a panel.

* The [wix-editor Velo module](https://dev.wix.com/docs/velo/apis/wix-editor/introduction) lets you open Dashboard pages from a panel, and remove or restore elements.  

## Know the panel elements

Here is a short description of each element and anything special you should know about it. 

### Panel Slider

Panel sliders allow users to select a number from a given range. 

![slider](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/12/5f168858-237d-4786-882d-7789c4bb6f99/808cfd0f-c395-4b98-87ae-1234ec772e1b.png)

### Panel Thumbnails

Thumbnails allow users to select an item from a set of thumbnail images.

![thumbnails](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/13/b986ab71-3ed6-45d9-989a-15eb03f135e6/27d3f321-9b1a-4022-a871-404f45897668.png)

### Panel Button

A button on your panel. Add the button logic through code or [button rules](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-button-rules-to-open-pages).

![button](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/13/49f8e404-c024-48ca-a7d8-fbdc03b2e5b0/8b1dc8f1-fe45-4823-9bc3-c72ebb44c62a.png)

### Panel Checkbox Group

Checkbox groups are used for selecting any number of the given options.

![checkbox](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/14/00eaf2c4-c5cc-425b-bce1-43e4e240ec2a/c95fdb7c-8194-4345-98b4-b2abfaf1e387.png)

### Panel Dropdown

Drop-downs are used for selecting one of a number of options.

![drop-down](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/14/e891744e-6b72-4b0f-88f6-4426b7399706/f805fe93-3d10-4dba-8c3a-e788b7e1beef.png)

### Panel Radio Button Group

Radio button groups are used for selecting one of a number of options.

![radio button group](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/14/87ebda86-e661-4500-b751-a7861c0ad103/e2733ef0-a50f-4046-98b9-881bdcf3bb35.png)

### Panel Text

A text element (also called "rich text") is used to display text followed by a link.

![text](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/14/e7ee263c-2297-4c27-b114-6d565b58f56b/8f16680e-37f8-4d95-ac63-ef9b3127c46a.png)

### Panel Text Input

An input element that lets users enter small amounts of text.

### Panel Toggle Switch

Toggle switches are used for a single binary choice.

![toggle](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/14/ca97049a-35dc-4a2f-a413-42dee1208178/673f68e2-4077-4423-b2b0-469450179371.png)

### Panel Section Divider

 Section dividers display a section heading in the panel.

![section divider](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/08/14/7b41f7a3-989b-49fd-9ef3-c1d3b8f44b0d/bb9e72ac-86c6-481e-b4b5-603636fdcb29.png)

### Panel Color Input

Color pickers allow a site builder to select a color for one or multiple elements.

![color picker](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/19/8ab275e9-57e4-4195-94e3-3b6e79867d94/5385ae86-8f18-4fda-84f8-85f363af1537.png)

<blockquote class="standard">
  <strong>Notes:</strong>

*   You cannot test the color in the Blocks **Preview**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/20/1614c776-069b-4a91-bfd9-567f352a84d1/fba47dd3-3bdc-4e2e-b987-370820aa54f3.png)  mode. To test the color, install the app on a site. 
* You must add at least one line of code to see how the element works in the editor. For example: `$w('#panelColorPicker1');`
*   A color picker can be a good way to give site builders a possibility to customize a [custom element](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-custom-elements-in-blocks).
*   We recommend not to connect a custom panel to the **Design**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/19/f3e5c98a-9577-4283-a037-d4b504eb4968/98df67ef-1832-45a0-aef8-39e0f74ee8e1.png)  action button, since it will not work well in the Wix Studio editor. Instead, you can create a main action named **Change Design** (learn more about [connecting action bars](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-action-bars-in-blocks)). 
</blockquote>

### Panel Font and Color Input

Font and color pickers allow site builders to select a font and its color. 

> **Note:** You must add at least one line of code to see how the element works in the editor. For example: `$w(panelFontAndColorPicker1);` 

![Font and color picker](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/19/d618f5b2-f059-4a59-bd80-5694c7252e44/88516c26-2630-455a-b67d-8f29d510debf.png)
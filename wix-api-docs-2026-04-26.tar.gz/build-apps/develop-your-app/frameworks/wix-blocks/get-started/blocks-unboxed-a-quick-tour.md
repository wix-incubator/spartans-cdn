---
portal: build-apps
name: "Blocks Unboxed: A Quick Tour"
type: ARTICLE_RESOURCE
resourceId: 27ca5b36-9d2c-4dee-a4a8-7774e4bece24
---

# A Quick Tour

# Blocks Unboxed: A Quick Tour

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

<blockquote class="important">


Wix Blocks is open to all Wix Studio users. To access Blocks, go to [Custom Apps](https://manage.wix.com/account/custom-apps) in your Studio workspace. If you want to create a Blocks app in a Studio workspace where you are not the owner, make sure to get **Co-owner** permissions from the owner. 

</blockquote>

**Welcome aboard – it's great to have you here!**

The Blocks Editor is where you create apps for Wix sites.

Blocks apps can be anything from simple widget layouts to full-fledged interactive web components, complete with APIs and code files – the sky is the limit.

![Gif of what an application includes](https://wixmp-833713b177cebf373f611808.wixmp.com/images/90727235007485ba800d68c90d3a5779.gif)

Let's get started with a quick tour of the basics. You can then dive straight into the [Blocks app workflow](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/a-blocks-app-workflow) and start building apps, or try out our [Blocks tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials#quick-start--create-an-app-in-wix-blocks).

* * *

### Build amazing widgets for Wix sites

Wix Blocks offers you all the tools you need to design professional widgets that Wix site builders (yourself included!) can add to any site. It comes with powerful layout and design tools to help you make your widgets responsive, precise, and beautiful. Build them yourself or ask the Blocks AI to do it for you!

![Widgets](https://wixmp-833713b177cebf373f611808.wixmp.com/images/34d1005620391e2d63e94d65fcd62371.gif)

* * *

### Responsive from the ground up

Blocks widgets are fully responsive when added to any Wix site, adapting elegantly to any viewport or layout.

![How responsive looks](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/07/25/6519e533-9008-49bb-bdcf-93a129bee397/6dd7592e-88bc-483e-9aeb-8a35b8fb0f08.gif)

* * *

### Limitless customization out of the box

In Blocks, you compose your widget out of standard Wix site [elements](https://support.wix.com/en/article/studio-editor-adding-elements-4240855), like text boxes, images and buttons. They all come with tons of built-in customization options. When site creators add your widget to their site, all those options are still available, allowing them to adjust almost anything and make your widget perfect for their needs.

![customization](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/07/25/3022749d-d3a2-496e-80be-90f2bceed286/af9a4084-ec6b-48a6-94f0-dc0e7e44f86b.gif)

* * *

### Give site builders a tailored editing experience

Your widget's [configuration](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/about-configuration-in-blocks) settings control how site builders interact with the widget in the editor, for example, which widget elements can be selected or removed, and the buttons available in each action bar.

You can even build your own [custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/about-panels-in-blocks) for your widgets, to let site builders easily adjust your widget's settings, layout, design, and more. 

![editing experience](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/07/25/3b7583af-b23d-4367-a736-06522139e446/ffa196d4-d03a-4217-a436-78a73e01cff5.gif)

* * *

### Turbocharge your widget with code

The Wix full-stack development platform empowers you to rapidly build, manage, and deploy professional apps. Add custom functionality and interactions, use the [Wix Javascript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk), work with your favorite tools, and enjoy serverless coding in both the frontend and backend—all on an open, extendable platform.



![Velo code](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/07/25/6fc2b9dd-b979-4f5c-9341-9f039bfd4e22/9cc75ffb-562a-4872-98b9-80cc175ed540.gif)

* * *

### Let Wix sites interact with your widget

Exposing your own [API](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/about-the-widget-api) allows site builders to smoothly integrate your widget into their site, by manipulating the widget's props, calling its public functions, and reacting to its events.

![velo code](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/3d78bec4-05f0-4503-9b59-b76c23ec7b86/2022/07/25/d4520255-77bf-4c35-b199-f01768bf9fbf/8b57d5f0-9161-4ffb-be79-05a512199950.gif)
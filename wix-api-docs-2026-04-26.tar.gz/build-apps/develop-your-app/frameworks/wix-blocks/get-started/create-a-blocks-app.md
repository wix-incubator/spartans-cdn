---
portal: build-apps
name: "Create a Blocks App"
type: ARTICLE_RESOURCE
resourceId: e3af8944-4f50-4315-afea-ba8f411b53f8
---

# Creating an App and Opening it

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# Create a Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

<blockquote class="important">

Wix Blocks is open to all Wix Studio users. If you haven't created a Wix Studio account yet, [here's how to join](https://support.wix.com/en/article/wix-studio-switching-to-wix-studio). If you want to create a Blocks app in a Studio workspace where you are not the owner, make sure to get **Co-owner** permissions from the owner. 
</blockquote>  

You can start building an app with a ready-made template or build from scratch, depending on your project's needs.

## Start with a template

1. Open the [Custom Apps](https://manage.wix.com/account/custom-apps) section in your Wix Studio workspace.
2. Click **Create New App**.
3. Click **Start with a template**.
4. On the left side, under **Browse by framework**, select **Wix Blocks**.
5. Select a template that best suits your needs and then click **Use Template**.

Wix Blocks opens with a new app based on the selected template.

[<button class="wix-button">View Wix Blocks templates
</button>](https://dev.wix.com/apps-templates?filter=blocks)

## Build from scratch

1. Open the [Custom Apps](https://manage.wix.com/account/custom-apps) section in your Wix Studio workspace.
2. Click **Create New App**.
3. Click **Build from scratch**.
4. Select **Wix Blocks** and then click **Get Started**.

Wix Blocks opens with a blank canvas.

[<button class="wix-button">Start with a blank canvas
</button>](https://dev.wix.com/apps-templates/open-blocks-template?templateId=b4d78c69-534a-4c87-9b15-656577abacdb&templateName=Blank+Canvas)

## Next steps

Go back to the [Custom Apps](https://manage.wix.com/account/custom-apps) section in your Wix Studio workspace to continue working on your app. From there, you can:
* Edit your app in Blocks
* Manage your app in the app dashboard
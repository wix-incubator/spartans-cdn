---
portal: build-apps
name: "Wix Blocks Glossary"
type: ARTICLE_RESOURCE
resourceId: b96e3e5f-a25a-4e72-9d66-01818132f157
---

# Glossary

# Wix Blocks Glossary

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

In this article, you can find definitions, synonyms, related links, and locations of many terms used within the Wix Blocks environment. Search this page to find the word or phrase you require.

<details>
<summary>Action Bar</summary>

**Definition:** The floating menu that appears in the Wix Editors when a widget or its elements are clicked.

**Related links:** [Configuring Action Bars](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-action-bars-in-blocks)

**Where****:** Editor Experience, Configuration Tab

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/10/8b1d2762-b239-48d3-b84d-506b4620cd80/9df5dc3d-3184-4361-8ec7-9507087e91e2.png)

</details>

<details>
<summary>Action Buttons</summary>

**AKA:** Action bar button, system button

**Definition:** The buttons of an action bar.

**Related links:** [Configuring Action Bars](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-action-bars-in-blocks)

**Where:** Editor Experience, Configuration Tab

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/10/598e9688-d6b4-46e0-88d2-fcd2178ece09/25fc409d-bf92-406d-a385-459e26b54708.png)

</details>

<details>
<summary>App Dependencies</summary>

**Definition:** Other Wix apps that are required for the Blocks app to function on a site.

**Where:** Top Bar Menu

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/5679a14b-469d-4b80-98c1-fe962e677aab/8c6d444b-708f-48c2-a99d-61def2652626.png)

</details>

<details>
<summary>Backend Code</summary>

**Definition:** Create JavaScript files, web modules, and other files for use in the backend, and organize these files in folders.

**Related links:** [Add code files to your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/add-code-files-to-your-app)

**Where:** Code Tab, Public & Backend

  

![code files](https://wixmp-833713b177cebf373f611808.wixmp.com/images/9b6b475d36495166ffad9e323ec3f72c.png)

</details>

<details>
<summary>Blocks</summary>

**Definition:** Blocks is an independent Editor where you can create web applications to use on Wix sites.

**Related links:** [Blocks unboxed: a Quick Tour](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/get-started/blocks-unboxed-a-quick-tour)

</details>

<details>
<summary>Code Files</summary>

**AKA:** Code Packages, Public & Backend Files

**Definition:** Code libraries that you can reuse across multiple sites that allow you to add specific functionality to your site. 

**Related links:** [Add code files to your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/add-code-files-to-your-app)

**Where:** Code Tab, Public & Backend

  

![code files](https://wixmp-833713b177cebf373f611808.wixmp.com/images/9b6b475d36495166ffad9e323ec3f72c.png))

</details>

<details>
<summary>Configuration</summary>

**AKA:** Widget Behavior, Editor Experience

**Definition:** Defining the site builder's experience when interacting with the widget in the Wix Editors. For example, which widget elements can be selected or removed, and what buttons are available in the action bar.

**Related links:** [About Configuration in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/about-configuration-in-blocks)

**Where in product:** Editor Experience, Configuration Tab

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/da8f014b-44b4-4cb0-b7fc-feb5ed5144bf/074b831c-e5b4-4a88-bb21-a2a9ffcb48ea.png)

</details>

<details>
<summary>Configuration File</summary>

**AKA:** config.json

**Definition:** You can add a **config.json** file to define settings that affect how the app works on a specific site. These settings typically vary from site to site, so the file you provide contains default settings that you can edit for each site.

**Related links:** [Add a configuration file](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/add-code-files-to-your-app#add-a-configuration-file)

**Where:** Code Tab, Public & Backend

</details>

<details>
<summary>Connect to theme</summary>

**Definition:** Defining the widget elements so that they connect automatically to the theme of any site the widget is installed on.

**Related links:** [About themes in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/about-themes-in-blocks)

**Where:** Widgets

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/96298292-773b-4832-8102-7ab75763fba1/3e9a5714-781e-4e0a-893f-8f113da9e519.png)

</details>

<details>
<summary>Custom Panels</summary>

**AKA:** Settings Panels

**Definition:** Panels that were built in the Blocks Panels tab (as opposed to default ones).

**Related links:** [Designing custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks)

**Where:** Editor Experience, Custom Panels Tab

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/7242b861-9f29-4d7e-a19c-5a610a4a1ae2/d8a56cd5-6b72-4a1b-92ad-a15a0bf4b8e0.png)

</details>

<details>
<summary>Design Presets</summary>

**Definition:** Different design and layout options for one widget. The functionality remains the same across the different designs.

**Related links:** [About Design Presets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/about-design-presets)

**Where:** Widgets

  

![design presets location](https://wixmp-833713b177cebf373f611808.wixmp.com/images/22ac9981d1c5f8c0f96e9a704e955304.png)

</details>

<details>
<summary>Display name</summary>

**Definition:** The name of the widget and elements that appear when the widget is added to the Wix Editors. Display names can be defined in the Configuration tab. Note that this is not the Velo Element ID.

**Related links:**  [Configuring widget display names and behavior](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-configuration/configure-display-names-and-behavior-in-blocks)

**Where:** Editor Experience, Inspector Panel 

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/296d0958-4baf-45cc-a3c2-34c920b8c5b1/8d526071-2a7b-4fac-b4fc-79b46cfdb7ce.png)

</details>

<details>
<summary>Events</summary>

**Definition:** API events can be fired by the widget when a certain condition is met. They can then be caught by event handlers in the site where the widget is installed.

**Related links:** [Adding a New Event to Your Widget](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-events)

**Where:** Widget code panel

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/14/b45914bc-4ddc-45b7-83a2-59cd4f8b0c67/c8c5a129-a4ac-4d4e-aed8-703625d8d575.png)

</details>

<details>
<summary>Namespace</summary>

**AKA:** Import name

**Definition:** A namespace is required for importing the app’s backend and public functions, as well as content collections in the Editors and in the app’s code in Blocks.

**Related links:** [Creating a namespace for your App](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/creating-a-namespace-for-your-app)

**Where:** Prompted when building an app after adding collections or code files

</details>

<details>
<summary>Nested Widget</summary>

**AKA:** Widget in Widget

**Definition:** Two widgets (from the same app) where one is inserted inside the other. Eg. A button widget inside a form widget.

**Related links:** [Add Nested Widgets in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/add-nested-widgets-in-blocks)

**Where:** Widgets menu 

  
![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/29113606-50f8-494a-bfa5-936b0daade51/95e621da-a9f7-4f1f-afe2-fca5a02da61c.png)

</details>

<details>
<summary>Panel Elements</summary>

**Definition:** The UI elements of a custom panel (buttons, dividers, text inputs, etc) that are used to control a widget's or element's settings. These elements are different from the regular Wix elements used in the Wix Editor.

**Related links:** [Panel Elements in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-elements-in-blocks)

**Where:** Editor Experience, Custom Panels Tab panel 

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/25/6f8620d3-71bc-432c-99a5-80cac2bd6d2c/39d15a93-4567-4199-b871-7154df986dfa.png)

</details>

<details>
<summary>Panels</summary>

**Definition:** The pop-up window that opens when an action bar button is clicked and gives site builders control over a widget or element's settings. For example, when you click **Design** the design panel opens.

**Related links:** [About Panels in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/about-panels-in-blocks)

**Where:** The panels open in the Wix Editors, when a site builder configures the widget

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/14/4005d4ed-9f23-494b-a415-5cfe336bfbf4/e5b361c2-b111-48d5-829b-8c6292299b5e.png)

</details>

<details>
<summary>Plugin</summary>

**AKA:** Site Plugin

**Definition:** The ability for site builders to add a plugin into a dedicated container (or slot). This allows site builders to extend the functionality of their app. Usually used to extend Wix business solution apps. 

**Where:** App Interface

**Related links:** [Build a Site Plugin in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-plugins/build-a-site-plugin-in-blocks)

  

![add plugin](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3c009f4d3bf8a3aff94e8e52a4d88338.png)

</details>

<details>
<summary>Properties</summary>

**AKA:** Widget Properties, Widget API Properties, Props

**Definition:** Certain choices that the app builder gives to the site builder regarding the widget. The properties can be changed from the widget's **Settings** panel, from a custom panel, from a dashboard page or from the site's code.

**Related links:** [Working with Widget API Properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-properties)

**Where:** Widget code

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/14/aa8d8adb-7a9a-4ad5-91e9-0cd7482adf45/c7014ae7-3d62-4e68-aef0-0a25211a11db.png)

</details>

<details>
<summary>Public API Functions</summary>

**Definition:** The widget creator can expose API functions that can be called by the code of the page where the widget is added.

**Related links:** [Widget Functions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-functions)

**Where in product:** Widget code

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/14/31e9f218-3229-49b0-a147-91eb81f0d36b/e9d4adc9-1793-4a4b-9d65-69835623ac39.png)

</details>

<details>
<summary>Site Visitor</summary>

**AKA:** User of user

**Definition:** The person who uses the Blocks app that's installed on a Wix site. Since your user as an app builder is the site builder, the site visitor is your "user of user". 

</details>

<details>
<summary>Widget</summary>

**AKA:** Site Widget, App UI

**Definition:** Widgets build your app's User Interface (UI). They are the part of the app the site visitor interacts with. Widgets are usually composed of elements like buttons and input fields, as well as settings panels and action bars. Every app can have several widgets. For example, a booking form widget, countdown timer or a customized menu.

**Related links:** [Blocks widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/build-a-site-widget-in-blocks)

**Where:** App Interface

</details>

<details>
<summary>Widget API</summary>

**Definition:** The widget's properties, functions and events, exposed by the app creator and enabling site builders to interact with the widget.

**Related links:** [About the Widget API](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/about-the-widget-api)

**Where:** Widget code

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/f0656688-8ed1-488a-888d-62373b7c3a3c/2023/03/15/5e5e6bd7-b111-46ca-ad32-3edace406847/6ee129e3-16f6-4a6d-bb9d-858f2ea23d4c.png)

</details>
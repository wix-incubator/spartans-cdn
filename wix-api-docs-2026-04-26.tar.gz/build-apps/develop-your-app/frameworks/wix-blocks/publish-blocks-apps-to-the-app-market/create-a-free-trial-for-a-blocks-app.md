---
portal: build-apps
name: "Create a Free Trial for a Blocks App"
type: ARTICLE_RESOURCE
resourceId: 8f50033b-2d50-4c6c-b670-cdb531ca82f0
---

# Creating a free trial for your app

# Create a Free Trial for a Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When you [set up your app's pricing](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/set-up-and-manage-free-trials) in the app dashboard, you can choose to provide users with a free trial. This is recommended especially if you don't provide a free version of your app, so you can let users experience your app's value before they decide whether to upgrade.

![free trial in the dev center](https://wixmp-833713b177cebf373f611808.wixmp.com/images/bb51c8fc5a9bfec8a93f6ce905cd5505.png)

Once you choose to add a free trial, your app market listing will show how many days of free trial the app offers.  

![app listings in the app market](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/01/17/65dd33bb-218a-4604-84ae-bc42f346b992/67388481-d02f-454e-aeb8-f47eb98c17d1.png)


When users are in the free trial period, their app works as if it's upgraded. When the free trial is over, Wix will automatically move them to the plan they selected. You can see information about the app's billing and the free trial in the [app instance](https://dev.wix.com/docs/sdk/backend-modules/app-management/app-instances/get-app-instance).


<details>
<summary>See deprecated Velo function</summary>

You can also see the app's current pricing plan in the `vendorProductId` object of the Velo [`decodedAppInstance`](https://dev.wix.com/docs/velo/apis/wix-application/get-decoded-app-instance) object, from the moment the user began the free trial. 
</details>

## See Also

Learn how to [set up and manage free trials](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/set-up-and-manage-free-trials).
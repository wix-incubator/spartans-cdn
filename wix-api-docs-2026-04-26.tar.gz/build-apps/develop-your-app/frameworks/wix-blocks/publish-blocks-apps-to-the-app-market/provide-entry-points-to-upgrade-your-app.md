---
portal: build-apps
name: "Provide entry points to upgrade your app"
type: ARTICLE_RESOURCE
resourceId: 9499dd17-c54b-45c3-bd08-2d03e1e7020d
---

# Provide entry points to upgrade your app

# Provide Entry Points to Upgrade a Blocks App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

If you [published your Blocks App](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/publish-a-blocks-app-to-the-app-market) in the Wix App Market and [adapted it to a pricing plan](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans), there are a few ways to allow site builders to upgrade their app to another plan. All these ways lead site builders to your app's pricing page. 

<details>
<summary>See example pricing page</summary> 

![example pricing page](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/18/3e33e3b2-ba7f-4873-94ca-7c672c2c227b/b54b13a1-69a3-4fbf-80b0-3b8b59945592.png)

</details>

## A default Upgrade action button

Blocks automatically adds an upgrade  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/18/8b0167ef-5780-4e93-9f19-51ef65433e86/aa7e9f4d-2450-4ef7-8b0d-25ab9dccab45.png)  icon to the widget's action bar, once you set up a pricing plan for it. Note that this button cannot be removed.

To see how this button works, [test you app in the editor](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/test-your-app-on-a-site). You'll be able to see it on a live site once the app is published in the App Market. 

<div style="text-align:center">

![Default premium action button](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/27/380f9a9a-a961-4fcc-abc3-fbb15e418bb9/fc7cda6b-7b83-409e-8e59-ad0b848265f2.png)

</div>

## Add an Upgrade button from a panel

Add a button to a custom panel and connect it to your pricing page [with no code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-button-rules-to-open-pages). 

![upgrade button](https://wixmp-833713b177cebf373f611808.wixmp.com/images/9ed9ccffa5064353c4dde631014e3b5e.png)

**To add an upgrade button:**

1. Click the button.
1. Click **+ Add rule** in the inspector. 
1. Select your pricing page. 
1. Click **Settings** and set the button type to premium, to get the purple color. 


## Add an Upgrade link from a panel

Add text and a link from a [custom panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks), to enable site builders to upgrade the app from a panel.

![Settings panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/27/4165b682-b94f-4656-9e1e-566ed7480f66/9b24ccde-31b0-4dcc-a733-f667c2539d65.png)

**To add a text and link to your panel:** 

1.  Go to the **Panels** tab. 
2.  Add a **Text** element to the panel.
3.  Click the element's **Settings**. 
4.  Insert a short call to action in the **Text** field.
5.  Set the code to the **Link** field through Velo. The link uses your App ID and Instance ID: 

```javascript
import wixApplication from 'wix-application';

const appInstance = await wixApplication.getDecodedAppInstance();
const upgradeUrl = `https://www.wix.com/apps/upgrade/${appInstance.appDefId}?appInstanceId=${appInstance.instanceId}`;
$w('#<panelRighTextComponent>').link = upgradeUrl; 
```

## Add an Upgrade link or button from a Dashboard page

Add a link or a button to your Dashboard page, to enable site builders to upgrade from their Dashboard. 

<div style="text-align:center">

![Dashboard with upgrade](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/27/8ae3669c-c7fe-4116-9bb7-9b86e25fc5ea/e4e27b41-5045-4530-9363-b901c7f3ce56.png)

</div>

**To add an upgrade button or link to your Dashboard:**

1.  Go to your App's Dashboard  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/18/ced5ed2f-65fd-4db5-995c-2a09d7028447/307693ce-7e82-49ba-997f-ce17ccced1fd.png)  page. 
2.  Add a button or text element through the Add  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/12/18/26427f79-9d3d-4ab1-803b-2b13a95229f6/e3c73c8d-871d-4ed0-b376-5b283f2c20da.png)  panel. 
3.  In the Dashboard code, set the link to use your App ID and Instance ID. 
4.  Specify that the link should open in a new tab. 

For example, if it's button:

```javascript
import wixApplication from 'wix-application';

const appInstance = await wixApplication.getDecodedAppInstance();
const upgradeUrl = `https://www.wix.com/apps/upgrade/${appInstance.appDefId}?appInstanceId=${appInstance.instanceId}`;
$w('#<yourButton>').link = upgradeUrl; 
$w('#<yourButton>').target = "_blank" //opens in a new tab
```
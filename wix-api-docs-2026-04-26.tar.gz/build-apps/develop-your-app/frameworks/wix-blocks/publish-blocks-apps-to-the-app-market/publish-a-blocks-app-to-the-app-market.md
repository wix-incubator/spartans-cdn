---
portal: build-apps
name: "Publish a Blocks App to the App Market"
type: ARTICLE_RESOURCE
resourceId: 8e00747e-6f66-4bbb-aefe-af28479ce5d0
---

# Publishing Your App to the App Market

# Publish Your Blocks App to the App Market

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

As a Blocks app builder, you can publish your app to the [Wix App Market](https://www.wix.com/app-market) to allow Wix site builders to install and use your app. Follow this article to submit your app for review by Wix and then have it published.  

## Before you begin

Here are some preliminary things to check out before publishing your app: 

<details>
<summary>Get to know the app dashboard</summary>

Any Blocks app that you create is added to the [Custom Apps](https://manage.wix.com/account/custom-apps) section in the in your Wix Studio workspace. You can select one of your apps to manage it in the app dashboard or edit it in Blocks. Most of the steps in this guide take place in the app dashboard. 
</details> 

<details>
<summary>Set up your app's pricing</summary>

To monetize your app, you need to select a business model and adjust your app's UI and code to various pricing plans. Learn more about [pricing your Blocks app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans) and make sure everything works before proceeding.

</details>

<details>
<summary>Prepare your app for review</summary>

Go over [our checklist](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/top-ways-to-speed-up-approval-in-blocks) to make sure you didn't miss any Blocks-specific requirements, such as installation settings, custom panels, and more. All items are mandatory. 
</details>


When you're ready, follow the next steps to publish your Blocks app to the App Market. 

## Step 1 | Duplicate your app in Blocks

If your app is already installed on any Wix site, you should duplicate it before publishing it to the App Market. This will prevent any changes that you don't want to happen to your installed app. If your app was never installed on a user's site, you can skip this step. 

## Step 2 | Click Publish App in Blocks

Click **Wix Blocks** > **App** > **Publish App**. A new tab opens with your app dashboard in the Custom Apps section of your Wix Studio workspace. 

## Step 3 | Add your app's Market Listing

Provide all the information needed to publish your app. This includes:

*   App contact info
*   App icon
*   App teaser (one-line description) 
*   Three app features
*   App full description
*   App images
*   App search words
*   Privacy and security info

Every time you fill in one of these topics, the count of your **Blockers** will go down by one. 

## Step 4 | Submit your app for review

Once you click **Submit App**, the team reviews your app. Since every app is reviewed manually, this takes some time. Note that during the review, you cannot build, duplicate or share your app in Blocks. 

Learn more about the [review process](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/submit-your-first-app-version). 

## Step 5 | Your App is in the App Market!

When your app is approved, you can find it in the [Wix App Market](https://www.wix.com/app-market). Install it both on the Studio editor and Wix editor to see that it works. 

## Step 6 | Release more versions

After you made changes to your app, [release it again in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/manage-blocks-app-versions) to create another version. Minor changes will be automatically received by users, while major updates will be available if they choose to update. 

However, certain changes are not included in your Blocks version release and are managed directly through your app dashboard:

* **Market listing:** Updates to your app’s public information, including media, contact details, etc.
* **Pricing:** Changes to your pricing plans, which will require you to [resubmit your app](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/about-app-distribution) for review.
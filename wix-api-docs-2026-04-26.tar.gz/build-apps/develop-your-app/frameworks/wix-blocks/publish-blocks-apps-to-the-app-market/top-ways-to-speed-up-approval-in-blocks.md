---
portal: build-apps
name: "Top Ways to Speed Up Approval in Blocks"
type: ARTICLE_RESOURCE
resourceId: e756310f-b2b2-4a62-9679-690d0d8df970
---

# Top Ways to Speed Up Your Apps Approval

# Top Ways to Speed Up App Approval in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Before you [submit your app to the Wix App Market](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/about-app-distribution), there are a few things you should check. Make sure to go over these items, as they are all mandatory. If your app was rejected for any reason, don't worry - you can fix it and resubmit. 

## 1 | Handle pricing plans
Your app logic should identify paid and free users and [create different experiences](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/adjust-a-blocks-app-to-different-pricing-plans) for them. Make sure to:
* Check if a user is paying for a plan, and then hide or disable non-paid features on the live site, while ensuring that they work in the site editor.
* Provide [entry points](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/provide-entry-points-to-upgrade-your-app) that lead users to upgrade when needed.
* [Handle free trials](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/create-a-free-trial-for-a-blocks-app).

    ![upgrade app](https://wixmp-833713b177cebf373f611808.wixmp.com/images/c4c8f5b3f00fe3f79fed350c3612f4aa.png)


## 2 | Follow media guidelines
Follow the App Market [media guidelines](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/add-your-media) and provide good and sufficient marketing photos and texts.

## 3 | Use custom panels
Create [custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) to allow users to adjust app elements, if relevant. Some app-builders are used to provide one large settings panel. With Blocks, you can add as many panels as you want, for the different widgets and app elements. Don’t forget to [connect your panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/design-custom-panels-in-blocks) to the relevant action buttons. 

![custom-panel](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a61e2585a29ace4ca7edeb51d8838b4a.png)

## 4 | Use a dashboard page when needed
Use a [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/about-dashboard-pages-in-blocks) when applicable, and create a clear experience to lead users to the dashboard. For example, to connect an account, or configure things that would affect multiple widgets at the same time, see statistics or other information on the admin side that is too long for a settings panel. 

## 5 | Name your widgets and presets 
This step is important since users will see these names in their site editor.

<details>
<summary>To name your widgets</summary>

1. Go to the **Configuration** tab.  
2. Give your widget a display name.   

![widget display name](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a238abc57a838fa13ce3d1415c5ee70f.png)

</details>

<details>
<summary>To name your presets</summary>

1. Go to the **Design** tab.
1. Click on the three dots next to the preset name. 
1. Rename the preset. 

![rename preset](https://wixmp-833713b177cebf373f611808.wixmp.com/images/1f75898b14f21a372b4be35033f1cdee.png)

</details>

## 6 | Add thumbnail images to your presets
Provide good [thumbnail images](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/create-thumbnail-images-for-your-presets) for every preset. This is done in your app's [installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings), in the **Preset Visibility** section. 

![Preset thumbnail](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4c865df5fd230d5d51320086b7cab82c.png)

## 7 | Provide a user guide
Provide a good explanation of how to install, configure and use your app. Some apps can get pretty complex, and without a tutorial, users will never understand how to use the apps. For example, If your app uses database collections, explain to users how to get to their CMS to update. A user guide is usually done through:

* Text in the settings panel
* A link to an external documentation site
* Text in a dashboard page

## 8 | Test your app on a site
Make sure that all areas of your app work as planned. Here is a checklist we prepared of [what to check when testing your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/what-to-check-when-testing) on a site.
---
portal: build-apps
name: "About Site Plugins in Blocks"
type: ARTICLE_RESOURCE
resourceId: 4ccbb3da-bb1b-4678-bae9-d1661e83347c
---

# About Site Plugins in Blocks

# About Site Plugins in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

With site plugins, you can create interactive and feature-rich components that seamlessly integrate into Wix's business solutions (such as Wix Stores and Wix Bookings), extending their functionality and user experience. [Learn more about site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions)

Use the following resources to get started with site plugins on Blocks:

* [Developer guide](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-plugins/build-a-site-plugin-in-blocks): Learn how to build a site plugin from scratch with our comprehensive guide.

* [Tutorial](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-site-plugin-for-the-wix-bookings-service-page): Gain practical experience by building a working site plugin through our detailed tutorial.

* [App template](https://dev.wix.com/apps-templates/template?id=086a1107-3d84-43cc-992e-738055e01547): Kickstart your plugin development with a template that demonstrates how to build a site plugin for the Wix Stores product page.
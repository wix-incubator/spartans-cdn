---
portal: build-apps
name: "About Site Widgets in Blocks"
type: ARTICLE_RESOURCE
resourceId: 9836f84c-d22e-4f9b-a15b-3e6c1676a2c1
---

# About Site Widgets in Blocks

# About Site Widgets in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Site widgets are draggable UI components that Wix site owners can add to pages on their website. They enhance a site's functionality by displaying content or enabling site visitors to perform various tasks. [Learn more about site widgets](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)

Wix Blocks offers you powerful layout, design, and coding tools, enabling you to build professional widgets that site builders can add to any site.

Use the following resources to get started with site widgets on Blocks:

* [Build a site widget](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/build-a-site-widget-in-blocks): Learn how to build a site widget from scratch with our comprehensive guide.
* [Tutorial](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-counter-widget-with-blocks): Gain practical experience by building a widget through our detailed tutorial.
* [App templates](https://dev.wix.com/apps-templates?filter=blocks&http_referrer=documentation): Explore Blocks templates that demonstrate how to build site widgets.
* [Design guidelines](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/blocks-widget-design-guidelines): Learn how to make your widgets behave responsively and adapt to any screen size, blend beautifully with Wix sites, and offer as many design styles and layouts as you want.
---
portal: build-apps
name: "Copy Widgets from App to App"
type: ARTICLE_RESOURCE
resourceId: 8478cd9e-3a64-486b-b8ef-30b1e95a65e4
---

# Copy Widgets from App to App

# Copy Widgets from App to App

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When copying and pasting a widget between apps, all widget elements and code are transferred to the new app. However, any resources external to the widget, such as database collections, code files, or dashboard pages, are not included. After pasting a widget, review the settings and code to ensure everything works as expected in the new app.


**To copy and paste a widget:** 

1. Click the ![more-actions](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/2136be44-e369-4942-b48e-e5af43b32124/a6be021c-326d-40ee-bfdd-1ceb207c6077.jpg) icon next to the widget name. 
1. Click **Copy**. 
1. Go to the app where you want to paste the widget.
1. Click the ![more-actions](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/2136be44-e369-4942-b48e-e5af43b32124/a6be021c-326d-40ee-bfdd-1ceb207c6077.jpg) icon next to any widget name.
1. Click **Paste**. 

![Copy paste widget](https://wixmp-833713b177cebf373f611808.wixmp.com/images/514ac3886bd34c9adabcd8d98cffc7b0.png)

> **Note:** If your browser is blocking the copy-paste action, set it to allow copying to the clipboard. Look for the definition in your browser's privacy or security settings. 

## Adjust Widget Settings Not Copied

The following widget settings are not copied automatically and must be updated manually:

- [Data-binding](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/connect-elements-to-collection-fields-with-no-code): Elements connected to a collection using no-code data-binding will lose their connection. Reconnect these elements to collections in the new app.  
- Animations: Animations applied to widget elements will not transfer. Reapply them in the new app.  
- [Installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings): Installation settings configured for the widget must be set up again in the new app.  
- [Nested widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/add-nested-widgets-in-blocks): Nested widgets are not copied automatically. Copy each nested widget separately and add them back to the parent widget in the new app.  


## Update the namespace
If your widget code references the app [namespace](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/creating-a-namespace-for-your-app), it will retain the namespace of the original app. Update all instances of the namespace in the widget's code to match the namespace of the new app.
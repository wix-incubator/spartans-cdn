---
portal: build-apps
name: "Manage Accessibility in Blocks"
type: ARTICLE_RESOURCE
resourceId: 336c8f04-e6e4-45e3-8bad-94b6490091bd
---

# Managing Accessibility in Blocks

# Manage Accessibility in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Most of the elements that you add to your Blocks app are ARIA (Accessible Rich Internet Applications Suite) -compliant. You can use the accessibility panel in Blocks to improve the accessibility of elements and widgets that are not ARIA-compliant.

[Learn more about ARIA](https://www.w3.org/WAI/standards-guidelines/aria/).

<blockquote class="important">

**Important note about compliance:** 
*   At Wix, we are committed to ensuring everyone, regardless of ability, can use our products and services. We are continually working on improving them, in line with accessibility standards.
*   Wix cannot guarantee or ensure that the use of our services is compliant with all accessibility laws and worldwide regulations. 
*   You are responsible for reviewing and complying with local legislation applicable to you or to your site visitors.
*   Note that a [custom element](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-custom-elements-in-blocks) is not accessibility friendly. 

</blockquote>

## Add accessibility attributes

You can add accessibility attributes to an element or a widget. 

1.  Right-click the element or the widget and click **Accessibility**.

<div style="text-align:center">

![Click on Accessibility](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/57e9f77c-6d15-498d-ac4e-c4d09bf3a490/2021/09/19/6d8cd0ee-3071-4394-ae17-1f06d6e7799f/242111f7-42a5-48a6-9690-18d45fe39c3e.png)

</div>

2.  Click **Add Attribute**.

<div style="text-align:center">

![Click on Add Attribute](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/57e9f77c-6d15-498d-ac4e-c4d09bf3a490/2021/09/19/0a07222d-8403-4eaa-87da-3b434bb3a45a/a12e7711-b4f2-459e-bc89-a8339364918c.png)

</div>

3.  Choose the attribute you want to add from the drop-down menu, and then choose its value.

<div style="text-align:center">

![Select an attribute](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/57e9f77c-6d15-498d-ac4e-c4d09bf3a490/2021/09/19/350b3313-aa8c-486e-8caa-8071be777158/7f8e8980-75f8-4e5a-908f-8a3f723f2ef0.png)

</div>

4.  Repeat steps 2 and 3 to add more attributes.

## Reorganize elements by DOM (tabs) order

DOM order is used by assistive technologies to help some visitors find the information they need ([Learn more](https://support.wix.com/en/article/studio-editor-reorganizing-elements-by-dom-order)).

When a site visitor clicks "Tab" in your Blocks widget, it goes through your elements in the same order that they appear in the **Layers** panel (from bottom to top). You can edit this order as you wish, by dragging the elements in the layers panel.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2da241b79fc5ea0d22220568463cc70b.png)

Go to **Preview** to see how it works.
---
portal: build-apps
name: "About Extensions in Blocks"
type: ARTICLE_RESOURCE
resourceId: d1414214-5a65-449e-a2a2-43c1557df93f
---

# About Wix Blocks extensions

# About Extensions in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Your app can add functionality to various parts of the Wix ecosystem, such as adding a page to a site's dashboard or a widget to a site page. Each specific type of functionality that an app can provide is called an extension. For general information about Wix app extensions, read [How apps extend Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).

Wix Blocks is a [development framework](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks#wixs-development-frameworks) for developing Wix apps, supporting the integration of extensions. It allows for the addition of extensions such as site widgets, dashboard pages and more to your app.

You can easily add the following extensions from the **App Interface** and **Dashboard Interface** in Blocks.

![app interface image](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f2809eea83ba4cd5dbadbe9ad982b62c.png)



## Site widgets

Widgets build your app's user interface. They are the part of the app the user interacts with. Usually composed of elements like buttons and input fields, as well as settings panels and action bars. An app can have several widgets.

Learn how to [build a site widget](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-widgets/build-a-site-widget-in-blocks) using Blocks.

## Site plugins

With site plugins, you can create interactive and feature-rich widgets that seamlessly integrate into Wix’s business solutions (such as Wix Stores and Wix Bookings), extending their functionality and user experience. Site plugins are built using Wix Blocks, which offers powerful layout and design tools, and give you access to Velo's full-stack development platform.

Learn how to [build a site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/site-plugins/build-a-site-plugin-in-blocks) using Blocks.

## Site pages

A page extension adds a full page to the user's site, when your app is installed on it. The page can appear in the site's main navigation menu and behaves just like any other page. 

[Learn more](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/add-a-site-page-extension).


## Dashboard pages

Dashboard pages are administrative pages you can add to the dashboard of a Wix site or project. They do not appear on the live site, so site visitors never see them. However, dashboard pages are visible to site admins with the required permissions.

Learn how to [build a dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/dashboard-pages/build-a-dashboard-page-in-blocks) using Blocks.

## Self Hosted Extensions

Blocks also allows you to add any **site** or **dashboard** self-hosted extensions that Wix provides. [Learn more](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions)

## See also
- [Map your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
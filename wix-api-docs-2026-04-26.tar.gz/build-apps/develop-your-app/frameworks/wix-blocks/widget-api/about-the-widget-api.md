---
portal: build-apps
name: "About the Widget API"
type: ARTICLE_RESOURCE
resourceId: 7d981bf2-4e7e-448d-ad90-0fb6beb7c6fb
---

# About the Widget API

# About the Widget API in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

The Widget API lets you create interactive, customizable widgets for Wix users. It serves as the bridge between your widget's internal functionality and the external interface that Wix users interact with, allowing them to customize your widget's behavior to match their specific needs.

You can add properties, events, and functions to your widget API.

## Widget API properties

Properties allow the Wix user get and set information to your widget. For example, in a product widget, you can add a property to represent whether the product is on sale, the number of items in stock, etc.  

Learn more about [widget API properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-properties).


## Widget API Events

Add an event when you want to provide information about actions that happen in the widget to the Wix user. For example, when a customer adds a product to the cart.

Fire your event in the widget's code in Blocks and Wix users can see it and register it in the editor. 

Learn more about [widget API events](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-events)

## Widget API Functions

Add a new function to enable Wix users to perform actions related to the widgets on their websites. For example, allow a Wix user to  get the address of a certain customer through a function and set the address through another function.

Learn more about [widget API functions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-functions)

## Using the Widget API on a Site

When a Wix user installs your widget on a site they can control it through the API.

Learn more about [using your Widget API when editing a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/use-the-widget-api-when-editing-a-site).

## The `$widget` module

The [`$widget`](https://dev.wix.com/docs/velo/velo-only-apis/$widget/introduction) module provides functionality for working with to your widget's API from within the widget code. The `$widget` module includes:

* A `props` object, which contains the properties that you defined, with the values that were set to them by the user of your widget (or the default value that you've set in case they were untouched).
* An `onPropsChanged()` event registrar, which allows you to register a callback that will be fired when a property value was changed, for example, when the user changes the title:  
  `$w('#myWidget').title = 'new title'`
* A `fireEvent()` method, which triggers an event that you define in the Widget API.

>**Note:**
>Make sure to document your widget API by describing any property, event or function you add to it. These descriptions >are available to Wix users who install your widget.
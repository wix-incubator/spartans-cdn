---
portal: build-apps
name: "Blocks Widget Functions"
type: ARTICLE_RESOURCE
resourceId: 245dc99b-49d2-40cd-8703-390d4745aa4b
---

# Widget API Functions

# Blocks Widget Functions

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Add a new function to enable Wix users to perform actions related to the widgets on their websites. For example, a user who has a shopping widget would like to be able to get the address of a certain customer through the function `getAddress(customerId)` and set the address through the function `setAddress(customerId)`.

**To add a new public function to your widget:**

1.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/9aa25a00-57bb-465d-b443-4e14a5478da3/67b8bc89-773d-4775-a0d5-b1585843da7b.jpg)  icon.

2.  Click **Add New Public Function** or hover over **Functions** and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/be929c05-3c41-452d-ae3a-1503546f8883/b6abb229-8c19-4d2b-9522-d42d125dcc76.png)  icon. 

    ![add new public function](https://wixmp-833713b177cebf373f611808.wixmp.com/images/af05e4d06b7671ebb6180322718352b5.png)



3.  Add the code for your function in the code editor, where a new function "foo" appears. 

4.  Change the new default name to a meaningful name and edit the function. For example, in the [counter tutorial](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-counter-widget-with-blocks#add-a-public-function-to-your-widget-api), there is a function that resets the counter and renders it. This is the code in Blocks: 

```js
    export function reset() {
  //This function is part of my public API
  count = 0;
  render();
    }      
```

5. You, or users, can then call the function from the editor. For example, this could be the code in the editor:  

    ```js
    export function counter1_change({ data: count }) {
        if (count > 30) {
            $w("#counter1").reset();
        }
    }
    ```
Learn more about [using your Widget API when editing a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/use-the-widget-api-when-editing-a-site).

<blockquote class="tip">
<strong>Don't forget to document</strong>

When you write your function, make sure to replace the default `jsdoc` that appears above it with your own one. The user of the widget will see the `jsdoc` when using the function in a site.

</blockquote>
---
portal: build-apps
name: "Blocks Widget Properties"
type: ARTICLE_RESOURCE
resourceId: d144886c-cc16-4815-b4db-1dca1cba410a
---

# Widget API Properties

# Blocks Widget Properties

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Properties allow site builders to pass information to the widget and get information from it. For example, in a shopping widget, you can add properties that represent  information about the product. 

Wix users can set property values through the default Settings panel, or by a custom panel that you create. Learn more about [using your widget API when editing a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/use-the-widget-api-when-editing-a-site). 

## To add a new property to your widget:

1.  Open your app in Wix Blocks.
2.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/9aa25a00-57bb-465d-b443-4e14a5478da3/67b8bc89-773d-4775-a0d5-b1585843da7b.jpg)  icon on the bottom right.
3.  Click **Add New Property** or hover over **Properties** and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/be929c05-3c41-452d-ae3a-1503546f8883/b6abb229-8c19-4d2b-9522-d42d125dcc76.png)  icon. 

<div style="text-align:center">

![add new API property](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/17/cc1172d6-1213-4b69-bf62-d26541a4500b/d2c98d39-ce8e-4c11-a6d9-113dbfd8d15d.png)

</div>

4\.  Name your property, select its [type](#property-types) and default values, add a description and click **Create.**  Make sure to fill in these fields with care. The Display Name will be visible to users.

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/17/cb3c5506-94a8-495b-bfed-e31ae5c066cd/4b8f23f0-a243-445f-bd2c-e2c4a8f473d4.png)

</div>

## Property types

These are the types of properties you can add to your Widget API:

*   **Text:** String values.
*   **Number:** Number values, without spaces or special characters except for a minus sign "-", to indicate a negative value.
*   **Boolean:** Either true or false.
*   **Image:** The URL for the source of the image. The format for the URL is described [here](https://www.wix.com/code/reference/$w.Image.html#src).
*   **Date and Time:** See [Date and Time Conventions](https://support.wix.com/en/article/date-and-time-conventions).
*   **URL:** In the format `http(s)://www.<domainname>.<topleveldomain>`, such as [www.wix.com](http://www.wix.com/)
*   **Custom:** A highly-flexible property type that you design around the needs of your app. Learn more about [creating custom type properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/custom-type-properties-blocks).
*   **List:** An array of any single type listed above. Learn more about [creating list type properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/list-type-properties-in-blocks).


To change the property type, hover over the property in the **Widget API** ![API icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/31/aff3d193-fc53-4df2-9d2a-3f16bdc11810/b8765d68-4150-4299-9191-9ffc55a107d2.jpg) panel and click the **Edit** ![edit icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/31/86efdcac-bb43-4738-bd3d-34cc6d1e5d4a/028a41b9-f00f-4167-9d4b-a28ef11fdfbe.png) icon.

## Interact with properties in your widget code

Interact with properties in your widget code through the [`$widget`](https://dev.wix.com/docs/velo/velo-only-apis/$widget/introduction) module, using the following syntax. Internal properties are optional - they're needed only if you're using [a custom type property](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/list-type-properties-in-blocks):

```javascript
$widget.props.<property>.<internal properties>
```

For example, let's say that you want to present the size of a shoe in a text element in your widget. The property is "shoe". Shoe is a custom type that has an internal property named "size". So the statement will look like this: 

```javascript
$w('#text1').text = $widget.props.shoe.size;
```

## Interact with properties in panels

You can get or set properties in custom panels through your [panel code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks#interact-with-widget-properties), or through [connecting properties to panel elements](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/connect-panel-elements-to-props) with no code. 

Note that Blocks also creates a default Settings panel for any widget that has properties.

## Define `onPropsChanged()`

The `onPropsChanged()` event is fired when there is a change in your widget's properties.

It receives `oldProps` and `newProps` as its parameters. Here is the syntax to use in the widget code:

```javascript
$widget.onPropsChanged((oldProps, newProps) =>  {
  <whatever you want to happen, code here >
})
```

The initial code for `onPropsChanged()` is created automatically in every new Blocks widget. You can define what happens in this event through adding code.

<div style="text-align:center">

![onPropsChanged code](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/21/5ba32ce1-cbbe-43d5-94ab-4af7be13660e/a8816d4f-e491-42fc-ac1c-92e10fda8e3b.png)

</div>

For example, in a shopping widget, if the product id is changed - load the data for the new product and customer:

```javascript
$widget.onPropsChanged((oldProps, newProps) => {
  loadProductData(newProps.productId);
  loadCustomerData(newProps.customerId);
});
```

## Testing your widget's API properties

When your widget is installed on a site, it comes with a default **Settings** panel, which includes any properties that you defined in your API (Learn more about [using your Widget API when editing a site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/use-the-widget-api-when-editing-a-site)). You can also use a custom **Settings** panel by using the [panel builder](https://support.wix.com/en/article/wix-blocks-about-custom-panels) in Blocks. Use Blocks's **Test API Properties** to see how these properties look on a site: 

**To test your widget's API properties:**

1.  Click **Preview**.
2.  Click **Test API Properties** when you are in preview mode.

<div style="text-align:center">

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/21/61a88f6e-9840-4c86-80eb-83ca554efc7c/901706b5-af5d-4a25-9bd5-ba375a8db519.png)

</div> 

<blockquote class="tip">
<strong>Don't forget to document</strong>

Make sure to document your widget API by describing any property, event or function you add to it. These descriptions are available to site creators who install your widget.

</blockquote>
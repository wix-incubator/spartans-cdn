---
portal: build-apps
name: "Custom Type Properties Blocks"
type: ARTICLE_RESOURCE
resourceId: b09e359b-41de-41cf-a0b1-e830f3e4035d
---

# Creating and Managing Custom Type Properties in the Widget API

# Custom Type Properties in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

In your Widget API, you can create custom property types that fit the requirements of your app.

For example, if you have a shopping widget, you may want to create a type that represents a customer, or a product, such as a shoe. 

The Customer type could include the following properties: _name_ (text), _address_ (text), _age_ (number) and _customerI__d_ (number).

The Shoe type could include the following properties: _model_ (text or number, depending on your catalog), _size_ (number), _color_ (text) and _productId_(number).

A custom type property (such as Customer or Shoe) also has properties, which are the fields of this new datatype that you created. However, these inner properties can only have simple types: text, number, boolean, image and URL. They cannot break down into more custom type properties.

## Create a Property with a Custom Type

1.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/22/9adacb68-b183-41d9-ac02-a237db2d7c6f/b1ebd5e2-ecd8-469c-be02-cdd966d0e285.jpg)  icon.
2.  Click **Add New Property** or hover over **Properties** and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/22/56440d76-fbfe-417e-be2d-996b8f2b50a0/3cc1493b-5fcb-45c2-a5f0-cc803b3283c5.png)  icon.
3.  Give your property a significant name and a display name.
4.  Expand the **Property Type** menu. 
5.  Click **Create New Custom** **Type**.

    ![new custom property type](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/25/d690731c-a65f-41e6-9b83-34a346c0910d/95bc6f33-797e-4953-87a3-2fab58b2e952.png)

1.  Name the custom type.
2.  Click **Add Property** to add properties (fields) to the type.
3.  Repeat the process until you've added all the properties of the type. 
4.  Click **Save**. 

    ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/07/21/81df923c-eeaa-4f11-8d09-cb1c20822b76/deb9ec78-55e5-456e-981c-cbdf9e070c19.jpg)

5.  Add a description to your new property. 

6.  Add default values to the type's fields if you want (such as a default age for the customer). 

7. Click **Create**.

    ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/07/21/25ab37e1-42e9-496e-b5f3-0d3c72419c3c/5f901e89-00fa-4838-96de-17475905172d.jpg)

<blockquote class="tip">
<strong>Tip:</strong>

In the above example, the Customer type can be used for various properties in the Widget API, such as ExsitingCustomer, FirstTimeCustomer, PotentialCustomer.

</blockquote>

### Edit a Custom Property Type

Edit a custom type by hovering over the type and clicking the **Edit**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/30/6e5bfca9-25d6-437e-ad46-308f11dae23a/b27efe36-c2d2-4c32-9df7-6ad334d21e18.png)  icon. You can then edit or remove any of the properties in that type.

If you **remove** a property from your custom type, it is removed from the Widget API properties of the custom type. If you add a property to your custom type, it is automatically added to the existing Widget API properties of that custom type. 

If you **change the name** of the custom type it is automatically changed in each Widget API property that is of that type.

</blockquote>

### Delete a Custom Property Type

Delete a custom type by hovering over the type and clicking the **Delete**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/30/41f84058-7343-45df-ad31-37d9509179a3/77daacee-70d7-48d5-bef7-97dbbc5e2605.png)  icon. You can only delete a custom type if no Widget API properties are of that type.
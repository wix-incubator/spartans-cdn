---
portal: build-apps
name: "List Type Properties in Blocks"
type: ARTICLE_RESOURCE
resourceId: c3e23761-7f89-4245-b10b-68b783c42e24
---

# Creating and Managing List Type Properties in Widget API

# List Type Properties in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Sometimes you need a property that can contain a list of items, for example, colors, sizes or locations. The list type can contain a list of items of a single type, such as text strings, numbers, or values of a custom type.

### Create a List Type Property

1.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/22/9adacb68-b183-41d9-ac02-a237db2d7c6f/b1ebd5e2-ecd8-469c-be02-cdd966d0e285.jpg)  icon.
2.  Click **Add New Property** or hover over **Properties** and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/22/56440d76-fbfe-417e-be2d-996b8f2b50a0/3cc1493b-5fcb-45c2-a5f0-cc803b3283c5.png)  icon.
3.  Give your property a significant name and a display name.
4.  Select **List** in the **Property type** menu. 
5.  Select the type of items on the list (or create a new custom type for them).  
6.  Describe your list. 
7.  Click **Add items...** to add items to your list. 
8.  Click **Create**. 

    ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/07/21/2086baf1-48ef-4c05-a997-96828ef18b45/c33791aa-a487-48aa-a970-8db4546b9478.jpg)

### Set List Type Properties from a Website

1.  Open the site in the Wix Editor or Wix Studio. 

2.  Select the widget ([learn more about installing a widget](https://support.wix.com/en/article/installing-a-blocks-app-in-your-site-ga)).

3.  Click **Settings** in the widget's action bar to see the list. 

    ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/25/bf7b1141-6086-43ce-a5f7-94df449caa46/3842f357-dca1-4db1-98e4-3d34f06f2cc6.png)

<blockquote class="tip">

**Edit List in Blocks Versus in a Site:** 
*   **If you edit list items in Blocks:** Changes will come into effect wherever the widget is installed, as long as you make sure to build the app again in Blocks, and refresh the Wix Editor or Wix Studio.
*   **If you edit list items in the Editor:** Changes will impact only that specific instance of the widget, which is installed in your site.

</blockquote>
---
portal: build-apps
name: "Use the Widget API When Editing a Site"
type: ARTICLE_RESOURCE
resourceId: e5ce4282-601c-4444-ae87-654f9e9ca9b6
---

# Using Your Widget API When Editing a Site

# Use the Widget API When Editing a Site

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

After a [Widget API was defined in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/about-the-widget-api) and the widget is now [installed on a site](https://support.wix.com/en/article/installing-a-blocks-app-in-your-site-ga), you can easily access the Widget API from the Wix Editor or Wix Studio. 

<blockquote class="standard">
<strong>Note:</strong>

Any changes that you make to the API while editing a site, only impact this specific site. The original widget is not impacted. If this isn't your intention and you want to edit the Widget API so that it updates on all sites using the widget, edit it in Blocks.

</blockquote>

## Set property values

There are a few ways for users to set the widget API properties. 

### Set property values through the Settings panel

Any widget that has properties, gets a default Settings panel. A widget with no properties will not have this panel. 

1.  Select the widget in Wix Studio or Wix Editor.  
2.  Click **Settings** in the widget's action bar to access its properties. 
3.  Edit the properties in the **Settings** panel. Note: Your changes will only apply to the site you're editing.
4.  Click **Preview** to see how your widget works on this site. 

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/07/21/78369f9e-9583-4fac-92d9-23867288e096/353dd159-8fa7-452a-b2ed-fb8ff9d9a138.jpg)

### Set property values through a custom panel

You can also let users [set the properties through a custom panel](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/connect-panel-elements-to-props) that you created. Note that if you connect your custom panel to the widget's **Settings** button, the default Settings panel will not be available. 

### Set property values through code

1.  Select the widget in Wix Studio or Wix Editor.
2.  Click the **Properties and Events**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/07/26/b734f951-abe5-4735-b65f-76cf788f13d3/26127617-e23d-47ba-b183-225adc5775a2.jpg)  icon to view the widget's ID. 

    ![widget api properties in editor x](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/24/c1615408-4f63-4d0d-803f-65d7e00c92af/1d643714-fa62-48a5-a38c-03280d122536.png)

3.  Use the following syntax to set or get a property value. 

    ```js
    $w("#<widgetId>").<propertyName> 
    ```

    Use extra dots if the property is an object and you want to access its inner properties. For example, let's log the name of our customer from the shopping widget to the console. 

    ```javascript
    let name = $w("#widget11").existingCustomer.name;
    console.log(name);
    ```

## Handle widget API events 

When your widget is installed on a site, site creators can see the event name in their **Properties and Events**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/08/25/2c401013-69e3-46d6-970b-3b53b4551600/68340d03-582d-405e-b6f2-74beb867fbfb.jpg)  panel, in the format of `on<EventName>`, for example, `onAddedToCart`. There are a few things they can do with this event name: 

###  Create a function to handle the event

1. Select the widget in the site editor. 
1. Click on the name of the event in the Properties and Events panel.
1. Write the code to handle it in the empty function that appears in your code editor. 

    ![onAddedtocart](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/07/24/0ebbf546-8bbc-458b-b8cc-fe9d1ba7b099/bb91af0f-4fa8-4aaf-96af-81774eed6531.png)

### Get data from the event

If you want to handle data from this event, you must add it as an argument (it's not added automatically). For example: 

```js
export function widget11_addToCart(event){
  const { productId, customerId } = event.data;
  console.log('Product added to cart', { productId, customerId });  
}
```

### Handle the event in the `onReady()` function

You can handle the event directly from the `onReady()` function of your site. For example:  

```js
    $w.onReady( function() {
            $w('#widget1').onAddedToCart((event) => {
            const { productId, customerId } = event.data;
            console.log('Product added to cart', { productId, customerId });
          });
    } );
  ```


<blockquote class="standard">

<strong>Note:</strong> 

The condition for firing the event [was defined in Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-events), while the actions to take when handling the event are defined in the site that installed the widget. 

</blockquote>

## Call widget API functions

Call your Widget API functions in your site's code easily, with auto-complete. 

For example, when an item was successfully added to the cart - you can all a function that notifies the user. 

Once you begin to write the function's name (such as "add"), you get auto-completes so you can see what functions are available:  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/09/13/2bda87ae-6649-4841-a640-b2ad36aff38b/c993b8da-6006-4003-ad37-1d0edf45588b.jpg)

Then you can use the function in your code, for example: 

```javascript
let productAddedToCart = $w('#widget11').addItemToCart(productID, quantity));
```
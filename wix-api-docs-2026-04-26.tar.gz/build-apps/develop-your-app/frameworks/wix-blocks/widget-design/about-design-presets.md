---
portal: build-apps
name: "About Design Presets"
type: ARTICLE_RESOURCE
resourceId: 7f52f503-408b-4eec-a90c-eada0d054cc5
---

# About Design Presets

# About Design Presets in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Design presets allow you to create various designs for the same widget. When you create design presets for a widget, its functionality, elements, code, APIs and data remain the same, while the way it looks can vary. 

With design presets, you can easily reuse your code and functionality across different designs, without the need to copy and paste them. You can also control how your widget looks across various viewports, through creating different presets for desktop and mobile. When site builders install the app, they can easily move between your ready-made presets. 

## Example
This [Banner Widget](https://dev.wix.com/apps-templates/template?id=1b7db962-6230-46bf-b908-d988ef640238&http_referrer=documentation) has four design presets. The first two presets are similar, but have a different layout. One has the text beside the image and the second one has the text over the image. 

Text beside image: 

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4ae14ad49ea1c939435f6042f415fe3d.png)

Text over image: 

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a2a9f460861cf6024f5cabfd9818030f.png)

The third preset has a different style - an inverted colors preset: 

 ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/56e3ede4cf0af625a998408ddd16aa8e.png)
 
 The fourth preset is built vertically, so it can look great on mobile devices: 
 
 ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4942aba8b985b07acbd0727f7e1308c7.png)


Ready to use presets? Learn more about [creating and managing design presets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/create-and-manage-design-presets).
---
portal: build-apps
name: "About Themes in Blocks"
type: ARTICLE_RESOURCE
resourceId: 130918ca-3948-4ef5-ae73-62bc58be7623
---

# About Themes

# About Themes in Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When you design a Wix site and you want to keep a neat and consistent design, it's best to have your site's elements connected to a **Theme**. A **color theme** includes combinations of colors that look great together, and a **typography theme** defines the looks of your site texts (learn more about using [Wix Studio site themes](https://support.wix.com/en/article/studio-editor-managing-your-site-styles)). 

When you create a widget, connecting it to a theme becomes essential. You never know where your widget or app might end up - it can be installed on an unlimited number of Wix sites. Think about a widget with a black background, designed  to stand out on a site's white background. If the widget colors are not connected to site color themes, it will be hard to spot on a site with a black background. Or, think about setting all your buttons to be pink and then importing the app to a website with a pink background - no one would be able to see the buttons. This goes for fonts too - your widget's fonts can be very different from the site's fonts.

Blocks automatically connects your widget's colors and texts to any site theme - adapting the widget to the site's look and feel. You can test how your widget looks across various themes in the **Test Theme** option in **Preview** mode. 

Here is an example of a simple widget. Look what happens when it is connected to a theme and when it is not.

<div style="text-align:center">

![simple widget](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/18/bc301c00-f33c-44ec-9265-4d648a4e9e9e/dbf92ed7-15d0-4895-a4b2-0d3a1a0150bb.jpg)

</div>

When the widget colors are not connect to the site's theme, it looks like this: 

<div style="text-align:center">

![widget not connected](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/18/c720e19e-1a00-4e48-b78c-4aed1986ad22/25fb4098-1993-4d9e-abe8-0885ed9f171b.jpg)

</div>

When the widget colors are connected properly to the theme, the widget blends in the site's look and feel. It looks like this: 

<div style="text-align:center">

![widget connected](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/18/dd4ad591-8243-46f7-b3c4-9b3a8d03f7fd/08e16c4d-2d29-47ea-a03a-39149eca2b0a.jpg)

</div>

## See Also
* [Connect your Blocks widget colors to site themes](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/connect-your-blocks-widget-colors-to-site-themes)
* [Connect your Blocks widget text styles to site themes](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/connect-your-widget-text-styles-to-site-typography-themes)
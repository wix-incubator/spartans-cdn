---
portal: build-apps
name: "Connect Your Blocks Widget Colors to Site Themes"
type: ARTICLE_RESOURCE
resourceId: 964ba708-3258-41a3-97b9-d15eea485818
---

# Connecting Your Widget Colors to Site Themes

# Connect Your Blocks Widget Colors to Site Themes

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When you create a widget with Blocks, it can be installed on many different Wix sites. To ensure that your widget's colors look great on all of these sites, Blocks automatically connects it to a theme. When you change colors in your widget, we recommend keeping them connected to the theme. 

### Select colors that are connected to a theme

1.  Open your widget in Blocks. 
2.  Select a widget element (such as a container or a text input). 
3.  Click the **Design** icon  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/04/bcdca632-813c-49d2-a35e-921fdfac0a70/08d98167-9b06-49fc-b55f-2be6d1bdab47.png)  in the **Inspector** menu  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/1ebf50de-b376-4460-8500-69273929a835/75d3a097-ae27-46ba-8eea-e935c6e476a0.png)  on the right.
4. Click the color options related to your elements, to change its colors. A box, for example, has colors for **Fill Color & Opacity**, **Border**, **Corners** or **Text**.
5. Select a color from the **Theme Palette**. 


Blocks uses a default palette that cannot be changed - this represents the Wix site themes. If you want to change the color, we recommend that you select the appropriate color from the five default colors presented. 

<div style="text-align:center">

![open theme palette](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/19/a5789ad7-5a7b-4c70-b134-3c415a1d03f9/ab64c9d5-def3-4b54-9753-5267614143d9.png)

</div>

When a color is connected to a theme, it shows the link ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/17/66d824bf-7821-40a1-b14f-9ed8afb59ff9/78f0b717-78bc-406a-bd35-efafab6c3952.png) indication in the color picker. . 

<div style="text-align:center">

![linked element](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/17/c1cb7aff-0487-4840-b6c9-5a3c3e730a04/03d5e0a0-63a3-4a2e-a8ea-b49088398da0.png)

</div>

If you choose a color from the **Add a Custom Color** section of the color picker and not from the Theme Palette, the color remains fixed and disconnects from site themes. You might choose to use this option in special cases, such as success and error buttons that you want to keep green and red. 


> **Note:** If you a user selects a color through a [custom panel color input](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-elements-in-blocks), the color won't connect to a site theme, even if they select one of the 5 recommended colors. This is because panel elements behave differently.

## Test your colors

Click **Test Theme** in **Preview** ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/903729a30d93ce91cf06fde181bbba46.png) mode to see how your widget looks across various sites with different themes. This helps you check that all your elements are connected correctly and your widget looks great with different themes. 

<div style="text-align:center">

![Test Theme in Preview Mode](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/02/7540ac98-1b42-4740-b272-839f767d84fb/c5f54f69-feee-4840-affa-dd9d6c2ec7fd.gif)

</div>
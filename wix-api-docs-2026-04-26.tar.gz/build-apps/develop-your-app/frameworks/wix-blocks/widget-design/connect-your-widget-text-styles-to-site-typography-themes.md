---
portal: build-apps
name: "Connect Your Widget Text Styles to Site Typography Themes"
type: ARTICLE_RESOURCE
resourceId: 2382eddb-27c3-46e5-8f8d-e3449f2eca58
---

# Connecting Your Widgets Text Styles to Site Typography Themes

# Connect Your Blocks Widget Text Styles to Site Typography Themes

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When you design a widget, you want it to look great on any site it's installed on. That's why connecting your widget's texts to a theme is so important. Styled texts, such as Heading 2 or Paragraph 2, are connected to a theme that defines their properties.

### Connect a text element to site typography themes:

To look best on Wix sites, your paragraphs should be connected to **Paragraph 2** and your headings to **Heading 2**. 

## Check that your texts are connected: 

1.  Select a text element on your widget.
1.  Look at the text theme under the **Design** section in the **Inspector** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/1ebf50de-b376-4460-8500-69273929a835/75d3a097-ae27-46ba-8eea-e935c6e476a0.png) menu.

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/bd8149afcabdfbf519566ad4ca91fd4a.png)  

### Override specific typography properties

You can choose to override each one of the typography properties (such as font, size, bold, etc.). Your text will stay connected to the site theme, except for the overridden properties. Your text will disconnect from the theme only if you override **all** properties.

Currently, all text elements in Blocks appear with a size override, so you'll see the asterisk (*) sign next to the text Theme. 

### Test your theme

Click **Test Theme** in Preview ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/903729a30d93ce91cf06fde181bbba46.png) mode to see how your widget looks across various sites with different themes. This helps you check that all your elements are connected correctly and your widget looks great with different themes. 

<div style="text-align:center">

![Test Theme in Preview Mode](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/02/7540ac98-1b42-4740-b272-839f767d84fb/c5f54f69-feee-4840-affa-dd9d6c2ec7fd.gif)

</div>
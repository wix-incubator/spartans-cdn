---
portal: build-apps
name: "Create and Manage Design Presets"
type: ARTICLE_RESOURCE
resourceId: 83f78cad-fe1e-457b-8fd2-724e3ca54c84
---

# Creating and Managing Design Presets

# Create and Manage Design Presets

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

Create multiple designs for the same widget. When you create design presets for a widget, its functionality and data remain the same, while the way it looks can change a lot. You can also use presets to create different designs for different viewports, like desktop and mobile. Learn more [about design presets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-design/about-design-presets) in Blocks.

<blockquote class="tip">
  <strong>Examples:</strong>
  
  To see examples of design presets, open the following templates and browse through the app widgets. Also, take a look at the widgets' [installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings#preset-visibility-and-images).

  - [Banner](https://dev.wix.com/apps-templates/template?id=1b7db962-6230-46bf-b908-d988ef640238&http_referrer=documentation)
  - [Repeater](https://dev.wix.com/apps-templates/template?id=a4a7246f-4644-48ce-81e7-2a86aa74d9e5&http_referrer=documentation)
  - [Events Map](https://dev.wix.com/apps-templates/template?id=f086effa-64b8-4c8b-a5c8-61c3a7548af7&http_referrer=documentation)
  - [Calculator Form](https://dev.wix.com/apps-templates/template?id=3ccb81da-dff8-43fd-95c8-620563624e2b&http_referrer=documentation)
  - [Recipe list](https://dev.wix.com/apps-templates/template?id=512a7d8a-1666-40c2-9586-25874d2f69b4&http_referrer=documentation)
</blockquote>

**To create and manage design presets in Blocks:**

1.  Open the widget you want to design. 
2.  Click **\+ Add** in the **Design Presets** panel. 
3.  Click the **ֿMore Actions** icon  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/e9f11af0-679c-4bf1-8b76-e50e26ec98f6/27128ae4-51ef-4cdd-b679-854d2e85973b.jpg)   to rename, duplicate or delete a preset. Note that if you only have one preset, you cannot delete it.


    <div style="text-align:center">

    ![add preset](https://wixmp-833713b177cebf373f611808.wixmp.com/images/52ba67f56b238638e97ce5797da16bd5.png)

    </div>

4. To preview your design presets, click **Preview** > **Test Design Presets**.

## Make Changes Per Preset Versus Global Changes

Some changes you make in one preset impact only the current one, while others impact all of them. As a rule of thumb, design changes are per-preset, while structure or data changes are global. Here's a guide to help you track what happens when. 

<details>
<summary>Changes that impact all presets</summary>

*   Add an element from the add panel.
*   Duplicate, copy, cut and paste an element.
*   Delete an element.
*   Hide an element on all other presets (click the **More Actions** icon ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/2136be44-e369-4942-b48e-e5af43b32124/a6be021c-326d-40ee-bfdd-1ceb207c6077.jpg) in the element's action bar and then click **Display** -> **Hide on all other Presets**). 
*   Reparent an element.
*   Group and ungroup elements.
*   Manage the items in a repeater (reorder).
*   Stack, unstack, add to stack and detach from stack (however, changing the order of stack items impacts current preset only).
*   Text: change text content.
*   Text - structural changes: theme (such as Heading 1 or Paragraph 2), a link, bullets, numbering, indentation, text direction and heading tag.
*   Replace a decorative shape (icon).

</details>

<details>
<summary>Changes that impact only your current preset</summary>

*   Resize a widget.
*   Set widget overflow content options, position, design and adjust options.
*   Hide an element in this preset (click the **More Actions** icon ![more actions icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/2136be44-e369-4942-b48e-e5af43b32124/a6be021c-326d-40ee-bfdd-1ceb207c6077.jpg) in the element's action bar and then click **Display** -> **Hide on this Preset**). 
*   Change an element's design and layout.
*   Change an image's focal point.
*   Hide, show and reorder widget layers.
*   Grids: change the number of rows or columns, define row and column size, set gaps, move elements between cells (change grid areas). 
*   Flexboxes: set display type, item properties, auto-wrap, margins, direction and proportions.
*   Reorder stack layers.
*   Text - design changes: font, scaling, size, bold, italic, underline, color, highlight, alignment, line spacing and character spacing.

</details>


## Define Preset Visibility in the Widget Installation Settings

When users install your widget, you can allow them to select a preset from the **Add to Site** panel and later switch between presets using the **Presets** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/27/2907ce70-8afe-48d0-a3b7-65097674f11c/19742c50-14ba-48de-a648-f09689a259cf.png) button in the widget’s action bar. You can control which presets appear by configuring their visibility in the [installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings#preset-visibility-and-images).

<details>
<summary>The Add to Site Panel</summary>

  

![add widget](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2023/10/04/e1502cb1-4742-4936-b314-8282c9194b53/fe2cbb6b-746d-434b-b335-d25cd8af5eb2.png)

</details>

<details>
<summary>The Presets Panel</summary>

  

![action bar icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/27/85bf68a7-7595-4d25-8b1a-b49962bd2b5c/1183b330-403e-48da-82c9-ce4511745056.png)

  

![new presets panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/27/a551024a-0acf-4fe1-804a-29817512fc20/fc29ac78-4902-4b79-a58a-725734d35caf.png)

</details>

## Change Presets According to Viewport  

You can create different presets for different viewports, such as vertical layouts for mobile. Wix Studio users can switch between desktop, tablet, and mobile views, while Wix Editor users can switch between desktop and mobile. When users select a viewport, they can change the preset using the **Presets** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/27/2907ce70-8afe-48d0-a3b7-65097674f11c/19742c50-14ba-48de-a648-f09689a259cf.png) button, but presets for other viewports remain unchanged. You can also set a default preset for mobile in the [installation settings](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/configure-blocks-installation-settings#preset-visibility-and-images).  

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/49515e78384a0586c2268ccb6e9f0bf7.png)
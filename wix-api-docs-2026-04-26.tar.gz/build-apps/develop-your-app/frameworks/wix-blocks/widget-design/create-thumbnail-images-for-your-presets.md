---
portal: build-apps
name: "Create Thumbnail Images for Your Presets"
type: ARTICLE_RESOURCE
resourceId: ad32f6b4-da8e-4387-9fa8-abcf78328090
---

# Create Thumbnail Images for Your Presets

# Create Thumbnail Images for Your Presets

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

When site builders browse through the design presets of your widget in their **Add** or **Presets** panels, they see a thumbnail image of the widget. You can use the auto-generated image, or create your own.  When creating your own image, please consider the following guidelines.

### Content guidelines

*   The image should be a visual representation of the preset. It's not a banner or an ad. 
*   If your widget has dynamic content, use dummy content to prepare your image. However, don't use Lorem Ipsum. 

### Technical guidelines

*   Compression: do not compress, use best quality
*   File type: JPG or PNG
*   File size limit: 25 MB
*   Image size minimum: 304X188 px

### See how it looks

You must go to the Wix Editor and Wix Studio to see how your images appear in the actual panels. Here are some examples: 

<details>
<summary>The Add Panel</summary>

  

![add widget](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2231128d2638eb6d3b73117802825d07.png)

</details>

<details>
<summary>The Presets Panel</summary>

  

![action bar icon](https://wixmp-833713b177cebf373f611808.wixmp.com/images/14acd9346f9a4fe7ebfb879e410714cc.png)

  

![new presets panel](https://wixmp-833713b177cebf373f611808.wixmp.com/images/83eb7287ffbd31cd98c60a68d8082997.png)

</details>
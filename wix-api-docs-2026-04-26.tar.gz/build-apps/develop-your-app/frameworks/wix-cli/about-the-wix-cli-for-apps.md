---
portal: build-apps
name: "About the Wix CLI for Apps"
type: ARTICLE_RESOURCE
resourceId: 8837c2c5-20d5-4802-b2f3-cc12f034e874
---

# About the Wix CLI for Apps

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# About the Wix CLI

Wix is unifying app and headless project workflows in the [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). All new features will appear only in the new CLI.

The Wix CLI is a unified command-line tool for creating, developing, and deploying Wix apps and headless projects.

The Wix CLI:

- Provides a modern, streamlined development experience.
- Makes it easy to develop, test, and manage your projects.
- Provides a fully managed hosting solution on Wix’s servers.

[<button class="wix-button">Learn More
</button>](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)

### The Wix CLI for Apps

The previous tool, Wix CLI for Apps, remains available for existing projects but will no longer receive updates or new features. For the best developer experience and the latest features, start new projects with the new Wix CLI.

Documentation for the previous CLI is avaliable in the [legacy reference](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/about-the-wix-cli-for-apps) to support those maintaining existing projects.
---
portal: build-apps
name: "About Wix Business Solutions"
type: ARTICLE_RESOURCE
resourceId: 82a13f48-8f3f-411c-a8aa-011ade674e81
---

# About Wix Business Solutions

# About Wix Business Solutions 

Wix offers a range of [business solutions](https://support.wix.com/en/business-solutions-apps), enabling users to sell products and services, run events, write blogs, manage restaurants, and more. Users add Wix business solutions to their sites by installing [apps created by Wix](https://www.wix.com/app-market/collection/made-by-wix).

To make an informed choice about how to work with business solutions, follow the path below.

## Get acclimated

First, we recommend you review the [Integrating with Wix's Business Solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions) article, which lists the business solutions available for integration in your app. 

Wix also offers other solutions you can integrate with, such as media support, form submission, location management, loyalty programs, and more. 

## Get started

A great way to learn about business solutions and resources is to try out [tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials) related to the business solutions relevant to you. 

## Get integrated

Your app can integrate with Wix’s business solutions and resources in the following ways:

* **Plugins** for injecting your own functionality directly into a business solution’s [user interfaces](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) and [backend capabilities](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/about-backend-extensions).

* **APIs** for connecting your services to Wix sites by gaining access to a business solution’s [data](https://dev.wix.com/docs/rest/business-solutions/cms/introduction) and [schema functionality](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions). We use the term *API* here broadly to include [REST APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/rest), [Velo APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/velo-for-blocks), [SDKs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk) and [GraphQL](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/graph-ql).

## See also

- [Tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials)
- [App templates](https://dev.wix.com/docs/build-apps/get-started/templates/get-started-from-an-app-template)
---
portal: build-apps
name: "Extensions and APIs for Dropshipping Apps"
type: ARTICLE_RESOURCE
resourceId: bfede395-b773-4ee1-913e-6fc10fa2983f
---

# Extensions and APIs for Dropshipping Apps

# Extensions and APIs for Dropshipping Apps

Dropshipping apps allow Wix users to sell products without maintaining inventory. The app connects a Wix site to an external supplier who handles product sourcing and fulfillment.

This article lists the APIs, events, and service plugins you need to use to build a dropshipping app.

When developing your app, make sure to create a [dashboard extension](#extensions) to provide Wix users with an interface to connect their supplier account, browse products to import, and manage orders.

## Permissions

Your app needs the following permission scopes:

- **Manage Products** (`SCOPE.DC-STORES.MANAGE-PRODUCTS`): Required for creating and updating products.
- **Manage Orders** (`SCOPE.DC-STORES.MANAGE-ORDERS`): Required for reading orders and creating fulfillments.

## APIs and events

Use these APIs, events, and service plugins to build your dropshipping integration.

> **Note:** This reference is intended as a helpful starting point. Your app may require additional resources. Explore the full [API Reference](https://dev.wix.com/docs/api-reference) for more options.

### Products

Import products from your supplier into the Wix Stores catalog.

- [Create Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/create-product) / [Bulk Create Products](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/bulk-create-products): Add new products to the Wix Stores catalog.
- [Update Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/update-product) / [Bulk Update Products](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/bulk-update-products): Update product details such as price, stock, or description.
- [Query Products](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/query-products): Retrieve products from the catalog.

### Product restrictions

Restrict Wix users from editing specific product fields, such as price or inventory, to keep product data consistent with your supplier.

- [Product Restrictions service plugin](https://dev.wix.com/docs/api-reference/business-solutions/stores/service-plugins/product-restrictions-v3/introduction): Define which product fields Wix users can edit for products your app manages.

### Orders

Receive and process orders to forward to your supplier.

- [Order Approved event](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-approved): Triggers when an order is ready for fulfillment.
- [Order Paid event](https://dev.wix.com/docs/api-reference/business-solutions/events/registration/ticketing/orders/order-paid): Triggers when payment is confirmed.
- [Order Updated event](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-updated): Triggers when order details change, such as shipping address updates.
- [Get Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/orders/get-order): Retrieve order details to send to your supplier.

### Fulfillment

Create and manage order fulfillments to track which items have been shipped and their delivery status.

- [Create Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/create-fulfillment) / [Bulk Create Fulfillments](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/bulk-create-fulfillments): Creates an order fulfillment.
- [Update Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/update-fulfillment): Update a fulfillment's tracking info or status as it progresses through delivery.
- [Delete Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/delete-fulfillment): Deletes an existing order fulfillment.
- [List Fulfillments For Single Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/list-fulfillments-for-single-order): Retrieve all fulfillments for an order to check which items have already been shipped.

## Extensions

Extensions add functionality to your app and integrate it with the Wix platform.

### Dashboard extension (required)

[Dashboard extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions) add customizable features like a page or plugin to the Wix Dashboard. Use a dashboard extension to let Wix users connect their supplier account, browse products to import, and manage orders.

### Checkout extensions (optional)

Extend the checkout experience with your supplier's data.

- [Shipping Rates service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/shipping-rates/introduction): Provide custom shipping rates at checkout.
- [Validations service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/validations/validations-integration-service-plugin/introduction): Check stock availability or shipping restrictions before purchase.
- [Additional Fees service plugin](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/additional-fees/introduction): Add handling charges, customs duties, or insurance.

## See also

- [About Launching Apps](https://dev.wix.com/docs/build-apps/launch-your-app/about-launching-apps)
- [Stores Catalog API](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/introduction)
- [eCommerce Orders API](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/introduction)
- [Order Fulfillments API](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/introduction)
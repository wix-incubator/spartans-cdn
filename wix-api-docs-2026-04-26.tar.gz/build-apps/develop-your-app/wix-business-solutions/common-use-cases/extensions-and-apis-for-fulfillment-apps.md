---
portal: build-apps
name: "Extensions and APIs for Fulfillment Apps"
type: ARTICLE_RESOURCE
resourceId: af4278ad-7390-4a65-b1e0-2cef05c896f4
---

# Extensions and APIs for Fulfillment Apps

# Extensions and APIs for Fulfillment Apps

Fulfillment apps help Wix users manage the process of preparing and delivering orders to customers. These apps typically integrate with shipping carriers, warehouses, or 3rd-party logistics providers.

This article lists the APIs and events you need to use to build a fulfillment app.

When developing your app, make sure to create a [dashboard extension](#extensions) to provide Wix users with an interface to connect their shipping accounts, configure fulfillment settings, and manage shipments.

## Permissions

Your app needs the following permission scopes:

- **Read Orders** (`SCOPE.DC-STORES.READ-ORDERS`): Required for retrieving order details.
- **Manage Orders** (`SCOPE.DC-STORES.MANAGE-ORDERS`): Required for creating and updating fulfillments.
- **Manage Products** (`SCOPE.DC-STORES.MANAGE-PRODUCTS`): Required for updating product inventory.

## APIs and events

Use these APIs and events to build your fulfillment integration.

> **Note:** This reference is intended as a helpful starting point. Your app may require additional resources. Explore the full [API Reference](https://dev.wix.com/docs/api-reference) for more options.

### Orders

Receive and retrieve orders that need fulfillment.

- [Order Approved event](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-approved): Triggers when an order is ready for fulfillment.
- [Order Paid event](https://dev.wix.com/docs/api-reference/business-solutions/events/registration/ticketing/orders/order-paid): Triggers when payment is confirmed.
- [Order Updated event](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-updated): Triggers when order details change.
- [Get Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/orders/get-order): Retrieve order details.

### Fulfillment

Create and manage order fulfillments to track which items have been shipped and their delivery status.

- [Create Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/create-fulfillment) / [Bulk Create Fulfillments](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/bulk-create-fulfillments): Creates an order fulfillment.
- [Update Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/update-fulfillment): Updates an existing order fulfillment.
- [Delete Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/delete-fulfillment): Deletes an existing order fulfillment.
- [List Fulfillments For Single Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-fulfillments/list-fulfillments-for-single-order): Retrieves fulfillments for an order.

### Fulfillment events

Listen for changes to fulfillments.

- [Order With Fulfillments Updated event](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/order-fulfillments/order-with-fulfillments-updated): Triggers when an order's fulfillments are created, updated, or deleted.

## Extensions

Extensions add functionality to your app and integrate it with the Wix platform.

### Dashboard extension (required)

[Dashboard extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions) add customizable features like a page or plugin to the Wix Dashboard. Use a dashboard extension to let Wix users connect their shipping accounts, configure fulfillment settings, and manage shipments.

### Checkout extensions (optional)

Extend the checkout experience with your shipping data.

- [Shipping Rates service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/shipping-rates/introduction): Provide custom shipping rates at checkout.
- [Validations service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/validations/validations-integration-service-plugin/introduction): Validate carts and checkouts with custom logic.
- [Additional Fees service plugin](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/additional-fees/introduction): Add custom fees to carts and checkouts.

## See also

- [About Launching Apps](https://dev.wix.com/docs/build-apps/launch-your-app/about-launching-apps)
- [Order Fulfillments API](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/order-fulfillments/introduction)
- [Order Fulfillments Sample Flow](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/order-fulfillments/sample-flow)
- [eCommerce Orders API](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/introduction)
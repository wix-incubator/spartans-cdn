---
portal: build-apps
name: "Extensions and APIs for Invoicing Apps"
type: ARTICLE_RESOURCE
resourceId: 5a5738a5-331a-46be-a12f-8ff42cc3bed3
---

# Extensions and APIs for Invoicing Apps

# Extensions and APIs for Invoicing Apps

Invoicing apps generate invoices, receipts, and manage billing for orders placed on Wix sites. This article lists the APIs and events you need to use to build an invoicing app.

When developing your app, make sure to create a [dashboard extension](#extensions) to provide Wix users with an interface to view invoices, configure invoice templates, and manage billing settings.

## Permissions

Your app needs the following permission scopes:

- **Read Orders** (`SCOPE.DC-STORES.READ-ORDERS`): Required for retrieving order details.
- **Read Bookings - Including Participants** (`SCOPE.DC-BOOKINGS.READ-BOOKINGS-SENSITIVE`): Required for retrieving booking details.
- **Read Payments** (`SCOPE.DC-CASHIER.READ-PAYMENTS`): Required for retrieving payment details.

## APIs and events

Use these APIs and events to build your invoicing integration.

> **Note:** This reference is intended as a helpful starting point. Your app may require additional resources. Explore the full [API Reference](https://dev.wix.com/docs/api-reference) for more options.

### Orders

Receive order notifications and retrieve order details for invoicing.

- [Order Approved event](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-approved): Triggers when an order is approved.
- [Order Paid event](https://dev.wix.com/docs/api-reference/business-solutions/events/registration/ticketing/orders/order-paid): Triggers when payment is confirmed.
- [Order Updated event](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-updated): Triggers when order details change.
- [Get Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/orders/get-order): Retrieve order details.
- [List Invoices For Multiple Orders](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-invoices/list-invoices-for-multiple-orders): Check if invoices exist for orders.

### Billing

Handle payment authorization, capture, and refunds.

- [Authorize Charge With Saved Payment Method](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-billing/authorize-charge-with-saved-payment-method): Authorizes a charge for an order.
- [Capture Authorized Payments](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-billing/capture-authorized-payments): Captures previously authorized payments.
- [Void Authorized Payments](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-billing/void-authorized-payments): Voids previously authorized payments.
- [Get Order Refundability](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-billing/get-order-refundability) / [Calculate Refund](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-billing/calculate-refund): Check refund eligibility and calculate amounts.
- [Refund Payments](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-billing/refund-payments): Refunds order payments.
- [Purchased Item Invoice Status Updated event](https://dev.wix.com/docs/rest/app-management/app-billing/billing/purchased-item-invoice-status-updated): Triggers when invoice status changes.

### Receipts

Generate and manage receipts for completed transactions.

- [Create Receipt](https://dev.wix.com/docs/rest/business-management/get-paid/receipts/receipts/create-receipt): Creates a receipt.
- [Get Receipt](https://dev.wix.com/docs/rest/business-management/get-paid/receipts/receipts/get-receipt) / [Query Receipts](https://dev.wix.com/docs/rest/business-management/get-paid/receipts/receipts/query-receipts): Retrieve receipts.

### Billable items

Manage custom products or services for invoicing.

- [Create Billable Item](https://dev.wix.com/docs/rest/business-management/get-paid/billable-items/create-billable-item) / [Update Billable Item](https://dev.wix.com/docs/rest/business-management/get-paid/billable-items/update-billable-item): Create or update billable items.
- [Query Billable Items](https://dev.wix.com/docs/rest/business-management/get-paid/billable-items/query-billable-items): Retrieve billable items.

## Extensions

Extensions add functionality to your app and integrate it with the Wix platform.

### Dashboard extension (required)

[Dashboard extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions) add customizable features like a page or plugin to the Wix Dashboard. Use a dashboard extension to let Wix users view invoices, configure invoice templates, and manage billing settings.

## See also

- [About Launching Apps](https://dev.wix.com/docs/build-apps/launch-your-app/about-launching-apps)
- [eCommerce Orders API](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/introduction)
- [Order Billing API](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/order-billing/introduction)
- [Receipts API](https://dev.wix.com/docs/api-reference/business-management/get-paid/receipts/receipts/introduction)
- [Billable Items API](https://dev.wix.com/docs/api-reference/business-management/get-paid/billable-items/introduction)
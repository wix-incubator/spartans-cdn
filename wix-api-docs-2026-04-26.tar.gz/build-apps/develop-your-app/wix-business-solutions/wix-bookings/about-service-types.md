---
portal: build-apps
name: "About Service Types"
type: ARTICLE_RESOURCE
resourceId: 81d2ab19-afd1-47fb-b5b4-dcf1f4902c3c
---

# About Service Types

# About Service Types: Appointments, Classes and Courses

Wix Bookings supports 3 types of services for businesses: appointments, classes and courses. Each individual appointment, class, or course meeting is commonly referred to as a session. 
Business owners can use any or all of these service types to run their businesses.

## Appointments
[Appointments](https://support.wix.com/en/article/wix-bookings-creating-an-appointment) are intended for one-on-one bookings, and exist only as available time slots until they are booked. For example, a salon might offer various hair cutting and styling services 
of varying lengths of time, and none of them are listed in the business’s booking calendar until they are booked by a customer.

Unique settings for appointments include:  
- Allowing multiple duration times per service type. For example, offering 15-minute, 30-minute, and 45-minute massages within one service. Currently supported only via API.
Managed through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `schedule.availabilityConstraints.sessionDurations`.
- Allowing customers to filter by their preferred staff member. In the UI, a dropdown is displayed with a list of all staff members available to provide the selected service.
Managed through the [Resources API](https://dev.wix.com/docs/rest/business-solutions/bookings/staff-members-and-resources/about-staff-members-and-resources) and calculated via the [Availability calendar API](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings-and-time-slots/time-slots/availability-calendar/introduction) during booking.
- Allowing customers to define the location for an appointment, for example in their home or office. 
Managed through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `locations.type` = “customer”.
- Scheduling buffer times between booked sessions. For example, adding a 10-minute buffer between hair coloring appointments. 
Managed through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `schedule.availabilityConstraints.timeBetweenSessions`.
- Offering available time slots **for all services** more often than the length of the appointment itself, enabling maximum flexibility for customers. This [“every ___ minutes” feature](https://support.wix.com/en/article/wix-bookings-changing-time-slots-for-appointments) dictates when time slots will be generated for a given service. For example, enabling display of available time slots every 15 minutes for an hour-long appointment, so long as there are no other bookings in that time period. Currently supported only in the site dashboard.

Specialized policy settings for appointments include: 
- Allowing customers to reschedule their appointments. 
Accessible through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `bookingPolicy.reschedulePolicy` and currently managed only in the site dashboard. 
- Allowing customers to cancel their appointments and/or limit the timeframe available for cancellation. 
Accessible through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `bookingPolicy.cancellationPolicy` and currently managed only in the site dashboard..

## Classes
[Classes](https://support.wix.com/en/article/setting-availability-for-classes-in-wix-bookings) are intended for one time or recurring events that customers can book individually. 
For recurring classes, customers can sign up to one, some, or all of the available classes, separately. These classes are listed in the business’s booking calendar immediately when they are created, 
and customers will see each session they’ve signed up for in their calendar after they book. For example, a yoga studio might offer a weekly vinyasa flow class, 
and customers can sign up to as many as they like based on their availability, interest, and/or membership coverage. 

Specialized policy settings for classes include:  
- Allowing customers to sign up to a waiting list when a class is fully booked. Accessible through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `bookingPolicy.waitlistPolicy` and currently managed only in the site dashboard.

## Courses
[Courses](https://support.wix.com/en/article/wix-bookings-creating-a-course) are intended for recurring events that customers must book as a set. 
These courses are listed in the business’s booking calendar immediately when they are created, and customers will see all the individual sessions in their calendar once they’ve booked. 
For example, a 5-session yoga teacher training course. API responses for course entities will include the read-only fields `schedule.firstSessionStart` and `schedule.lastSessionEnd`.

Specialized policy settings for courses include: 
- Allowing customers to sign up to a course after the first session has begun. Accessible through the [Services v2 API](https://dev.wix.com/docs/rest/business-solutions/bookings/services/services-v2/introduction) `bookingPolicy.bookAfterStart` and currently managed only in the site dashboard.


## Updating a service’s type

A service’s type can technically be changed after creation, assuming there aren’t any scheduled upcoming events with participants. 
However, Wix highly recommends creating a completely new service of the preferred type, rather than changing an existing service’s type. Changing a service’s type field deletes the service’s existing schedule and creates a new one, and re-triggers all validations based on the new type (availability, locations, policies, etc.)
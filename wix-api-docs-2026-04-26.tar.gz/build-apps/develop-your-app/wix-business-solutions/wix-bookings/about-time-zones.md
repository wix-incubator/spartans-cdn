---
portal: build-apps
name: "About Time Zones"
type: ARTICLE_RESOURCE
resourceId: 701f1f84-9c1e-4c5f-921f-2bd64a3731f5
---

# About Time Zones

# About Time Zones

Wix Bookings acts as the single source of truth for all time zone calculations (for example, Daylight Savings Time) for all types of Bookings services, based on the [IANA](https://www.iana.org/time-zones) Time Zone Database. 

If your code relies on an external database, it may receive updates about a change to the time zone earlier or later than Wix’s database update. Wix acts as the single source of truth for all time zone calculations, and does not take other databases into account.

## Time zone settings
A Wix site’s time zone is determined by the `timezone` field as set in [Get Site Properties](https://dev.wix.com/docs/rest/business-management/site-properties/properties/get-site-properties), which is set according to the time zone of the primary address as set in the site dashboard. Site owners and collaborators always create new sessions and view the Bookings calendar in the time zone of the associated primary address. 

Only one time zone is supported per site. In cases where a site has multiple addresses across multiple time zones (as defined in the Locations API), Wix Bookings always defaults to the time zone for the site’s primary address, as returned in Get Site Properties.

Sites can enable customers from around the world to view available booking slots in their own time zone. In these instances, the client calls Query Availability with the customer’s time zone in the `timeZone` field in the body of the call.

### Changes to a site’s time zone
When a site’s primary address is changed to an address in another time zone, the following changes are made:
- All schedules that are linked to the business are automatically updated to the new time zone.
- All future sessions for classes and courses are moved so that they retain the same time for the business within the new time zone. For example, if a business moves from New York to Seattle, the future class scheduled for 8am in New York is now at 8am in Seattle, and the UTC time is updated. A notification is sent to all booked customers about the time change.
- Appointment times are not changed to the site’s new time, so the customer won’t be affected.

## Calculate display times for customers in other time zones
When a customer requests that session times display in their own time zone, which is different from the business’ time zone, the client calls [Query Availability](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings-and-time-slots/time-slots/availability-calendar/query-availability) with the relevant start and end dates and time zone for the customer’s needs. 

For example, a client call made on behalf of a customer from New York on a site based in Frankfurt, Germany, might look like this:

```
curl -X POST 'https://www.wixapis.com/availability-calendar/v1/availability/query' \
-H 'Authorization: <AUTH>' \
-d '{
      "query": {  "filter": {
          "serviceId": ["832adc1f-d6cc-412d-894d-f04455baec68"],
          "startDate": "2023-05-20T12:17:08.912Z",
          "endDate": "2023-05-25T10:13:49.549Z" }
         }
      “timeZone”: “America/New_York”,
    }'
```
The returned response is appropriate for the customer’s time zone.

## Daylight savings time calculations

[Query Availability](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings-and-time-slots/time-slots/availability-calendar/query-availability) mediates any time gaps caused by daylight savings time automatically, based on the [IANA TZDB](https://www.iana.org/time-zones). For example, any call requesting availability for 00:05 on September 5th 2021 in Santiago, Chile, will not exist, because at 00:00 the clock moved 1 hour forward to 01:00. In this case, Wix’s service automatically moves the non-existent local time forward 1 hour to match the local DST. So if [Query Availability](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings-and-time-slots/time-slots/availability-calendar/query-availability) is called with a `startDate` of 2021-09-05T00:00:01.000 and an `endDate` of 2021-09-06T00:00:02.000, the start time is shifted one hour forward, to 2021-09-05T01:00:01.000, and the end time remains the same.
---
portal: build-apps
name: "About Wix Bookings"
type: ARTICLE_RESOURCE
resourceId: f38238af-9d98-403b-bb1b-6c227c41e260
---

# About Wix Bookings

# About Wix Bookings 

Wix Bookings is a comprehensive suite of services tailored to address standard and specialized needs in the online booking of services, 
including availability, calendar, and resource management. At its core, Wix Bookings is a robust set of interconnected [components](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/wix-bookings/architecture-and-data-flow), which work together to enable a seamless 
and efficient online booking experience for end-users and a streamlined management process for businesses.

The Wix Bookings product/platform works seamlessly with the Wix eCommerce platform, Wix Automations, Wix Pricing Plans (memberships and packages), 
Wix Automations, Wix Loyalty, and more. The product/platform can also be extended by external business solutions, enabling exceptional customization and flexibility.

<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/c864a8cb4c4f206ddb265954d441a1ec.png" style="max-width: 8vw" />

With the Wix Bookings product/platform, site contributors can manage the following: 
- **Service catalog** with multiple service types such as appointments, classes, and courses, across multiple business locations. Each service can have complex pricing systems and schedule availability.
- **Staff management** including working hours, staff calendars, syncing to personal calendars, and payroll. 
- **Calendars** for the business, services, staff, and resources (such as rooms and equipment), including both working hours, hours of specific events, and availability.
- **Bookings system** that is fully-customizable and manages complex calculations for availability and working hours to offer the best available offerings to customers based on their needs/selections, and waitlist functionality.
- **Customer checkout flow and payments**, including creating and selling membership plans and packages, coupons, and refunds (with the Wix eCommerce platform and Wix Pricing Plans).
- **Customer relationships**, with customizable forms, automated reminder messages, attendance tracking, cancellation and reschedule policies, and business email (with Wix Automations and Wix Inbox).

Wix Bookings' power lies in its modularity. The product’s composable architecture provides you with the autonomy to customize, extend, or replace functionalities to meet your requirements. 
This is made possible through various extension points such as APIs, service plugins, schema plugins, and site plugins to a site’s 
Bookings [service pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-bookings-services-page),
and Bookings dashboard [staff pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-bookings-staff-page),
including [menu plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-bookings-staff-page#dashboard-menu-plugin-slots).
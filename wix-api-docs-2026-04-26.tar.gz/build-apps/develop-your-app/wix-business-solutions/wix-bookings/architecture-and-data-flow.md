---
portal: build-apps
name: "Architecture and Data Flow"
type: ARTICLE_RESOURCE
resourceId: 206c15f1-dd6f-4be1-bc55-277dc6c05d53
---

# Architecture and Data Flow

# About Wix Bookings Architecture

Wix Bookings comprises multiple interconnected components that enable booking flows for customers and management capabilities for business owners.
This architecture is flexible: you can extend, customize, or replace elements of the business solution to meet your needs.

This article describes the main components of the Wix Bookings architecture, available customizations, and the standard single-service booking flow.

<!-- HIDE_FROM_PUBLICATION_START
The following diagram shows how the main Wix Bookings components interact with each other and with other Wix business solutions throughout the booking lifecycle.

<p align="center"><img src="images/build-apps-portal_develop-your-app_business-solutions_images_architecture.png" alt="Bookings architecture diagram" title="Bookings architecture diagram" /></p>
HIDE_FROM_PUBLICATION_END -->

## Services

The [Services V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/introduction) manages each business's offerings and all the information that customers need when deciding whether to book.

Wix Bookings supports 3 service types:
- **Appointments:** 1-on-1 or group sessions scheduled at available time slots based on staff and resource availability.
- **Classes:** Recurring group sessions with a set schedule and capacity. Customers book individual class sessions.
- **Courses:** Multi-session programs with a fixed schedule. Customers book the entire course as a single unit.

Booking policies control when customers can book, limit the maximum number of participants, and manage cancellation and rescheduling rules.
You can create and manage these policies using the [Booking Policies API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/policies/booking-policies/introduction).
Services are associated with [booking forms](https://support.wix.com/en/article/wix-bookings-creating-and-setting-up-your-booking-forms) that customers fill out when making a booking.
Learn about [how Wix Bookings integrates with Wix Forms](https://dev.wix.com/docs/api-reference/business-solutions/bookings/wix-forms-integration).

### Customizations

You can extend and customize services in the following ways:

- Offer different pricing options for a service based on customer selections, such as size or duration, with the [Service Options and Variants API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/service-options-and-variants/introduction).
- Create [add-ons](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/add-ons/introduction) that customers can select during booking and organize them into [add-on groups](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/about-add-on-groups).
- Add:
  - Site plugins to [service pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-bookings/wix-bookings-service-page).  
  - Dashboard plugins to [staff pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-bookings/wix-bookings-staff-page).
  - Dashboard plugins to [booking list pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-bookings/wix-bookings-booking-list-page).

## Staff and resources

The [Staff Members API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/staff-members/introduction) manages staff members who provide services and their working hour schedules.
Staff availability is a key factor in determining which time slots are available for appointment bookings.

The [Resources V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/resources/resources-v2/introduction) manages physical assets like meeting rooms or equipment that services require.
You must link resources to [resource types](https://dev.wix.com/docs/api-reference/business-solutions/bookings/resources/resource-types-v2/introduction) to make them bookable and prevent double bookings.
Customers can book a service only if all required resources are available during the selected time.

<blockquote class="important">

__Important:__
Wix Bookings automatically creates and manages a resource for each staff member.
Use the Staff Members API to manage staff because using the Resources V2 API for staff can lead to data conflicts.

</blockquote>

### Customizations

You can extend and customize staff and resource management in the following ways:

- Assign custom [working hour schedules](https://dev.wix.com/docs/api-reference/business-solutions/bookings/staff-members/assign-working-hours-schedule) to staff members.
- [Connect Wix users to staff members](https://dev.wix.com/docs/api-reference/business-solutions/bookings/staff-members/sample-flows#connect-a-staff-member-to-a-wix-user) to allow staff to manage their own schedules through the dashboard.
- Create custom [resource types](https://dev.wix.com/docs/api-reference/business-solutions/bookings/resources/resource-types-v2/introduction) to classify and organize the business's physical assets.
- [Create bookable resources](https://dev.wix.com/docs/api-reference/business-solutions/bookings/resources/resources-v2/sample-flows#create-a-bookable-resource) like meeting rooms or equipment that customers need when booking services.

## Time slots

The [Time Slots V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/time-slots/time-slots-v2/introduction) determines which time slots are available for booking based on service type and relevant constraints:
- For appointments, Wix Bookings determines available time slots based on:
  - Session duration.
  - Staff member working hours and blocked time.
  - Resource blocked time.
  - Time buffer between sessions.
  - Service policies.
- For classes, Wix Bookings determines available time slots based on the class schedule, capacity, and service policies, including waitlist functionality.
- For courses, Wix Bookings determines availability based on the course's capacity and service policies.

Wix Bookings validates all these factors at multiple points in the booking flow:
- When displaying a service's available time slots to customers.
- Before creating the booking (before payment is made).
- Before confirming the booking (after payment is made).

## Bookings

The [Bookings Writer V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/introduction) handles the creation and management of both single-service and multi-service bookings.

After the session takes place, you can track and manage customer attendance using the [Attendance API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/attendance/introduction).

### Forms integration

Wix Bookings integrates with [Wix Forms](https://dev.wix.com/docs/rest/crm/forms/introduction) to collect customer information during the booking process.
Each service has an associated [booking form](https://support.wix.com/en/article/wix-bookings-creating-and-setting-up-your-booking-forms) that customers complete when making a booking.

When a customer completes a booking form, Wix Forms creates a form submission that contains the customer's responses.
The system automatically links this submission data to the booking, and you can access it through the [Form Submissions API](https://dev.wix.com/docs/rest/crm/forms/form-submissions/introduction).
Learn more about [how Wix Bookings integrates with Wix Forms](https://dev.wix.com/docs/api-reference/business-solutions/bookings/wix-forms-integration).

### Booking creation

The system creates a booking once the customer selects 1 or more services with specific time slots and completes the booking form.
The booking then moves through the [payment and checkout flow](#checkout-and-payments).
After payment completes, the system either confirms the booking automatically or sends it to the business for manual approval, depending on the service configuration.

### Customizations

You can extend and customize the booking experience in the following ways:

- **Customize booking forms:** By default, all services use a standard booking form, but you can create custom forms by adding fields, removing fields, or marking fields as required.
- **Build custom booking flows:** Use the [Bookings Writer V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/introduction) to create bookings programmatically from your own interfaces, 3-party platforms, or automated systems.
- **React to booking events:** Listen to booking lifecycle events to trigger custom workflows when bookings are created, confirmed, canceled, or rescheduled.

## Checkout and payments

Wix Bookings integrates with the [Wix eCommerce platform](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/what-is-the-wix-e-commerce-platform) to handle payments and order management.

The Wix eCommerce system automatically uses the booking ID as a catalog item reference and handles pricing calculations, tax, and payment processing.
Add-ons appear as additional fees in the eCommerce checkout.

By default, the system creates a checkout using the [Checkout API](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/checkout/introduction) and redirects customers to complete payment.
Once payment processes, Wix eCommerce creates an [order](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/orders/introduction) and updates the booking status based on the service configuration (for example, `CONFIRMED` for automatic approval or `PENDING` for manual approval).

Learn more about [payment handling with a custom checkout](https://dev.wix.com/docs/api-reference/business-solutions/bookings/handle-payments-with-a-custom-checkout).

### Customizations

You can customize the checkout and payment experience in the following ways:

- **Implement your own checkout:**
  For custom payment flows, you can implement your own checkout experience to collect payment.
  After the customer completes your custom checkout, call [Confirm Or Decline Booking](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/confirm-or-decline-booking) with `options.paymentStatus` set to `PAID` to update the booking status to `CONFIRMED`.
  Then, create an order using the [Orders API](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/orders/introduction) to record the transaction with your custom payment details.
  This ensures the booking is properly tracked in both the Bookings and eCommerce systems.
- **Customize pricing calculations:**
  Use the [Pricing Integration service plugin](https://dev.wix.com/docs/api-reference/business-solutions/bookings/pricing/pricing-integration-service-plugin/calculate-price) to manage the price of a booking externally.
  Wix Bookings calls the integration whenever a customer enters the booking flow to get the price to charge.

## Calendar

Wix Bookings integrates with [Wix Calendar](https://dev.wix.com/docs/api-reference/business-management/calendar/introduction) to manage schedules and events.
Once the booking is confirmed, Wix Bookings adds the session to the business's [booking calendar](https://support.wix.com/en/article/wix-bookings-about-the-wix-booking-calendar) and to the schedules of the relevant staff members, rooms, and other resources.
The booking calendar displays all scheduled sessions and can be filtered by service, staff, and other criteria to help manage daily operations.
Learn more about [how Wix Bookings integrates with Wix Calendar](https://dev.wix.com/docs/api-reference/business-solutions/bookings/calendar/how-wix-bookings-uses-the-calendar-apis).

### Customizations

You can connect and sync external calendars with Wix Bookings using the [External Calendars API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/calendar/external-calendar-v2/introduction).
This allows staff members to sync their Wix Bookings calendar with Google Calendar, Microsoft Outlook, or Apple Calendar for bidirectional synchronization.

<blockquote class="important">

__Important:__
The Calendar V3 APIs are standalone services and aren't part of the Bookings APIs. However, the External Calendars API is part of Bookings.

</blockquote>

## Notifications

Wix Bookings automatically sends notifications to keep Wix users and customers informed about booking events.

Wix users receive notifications for events such as:
- New bookings.
- Rescheduling requests.
- Cancellations.

Customers receive notifications for events such as:
- Booking confirmations.
- Automatic reminders before a booking begins.
- Changes to their bookings.

### Customizations

You can extend the notification system by providing [pre-installed automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations) that trigger custom notifications (or other actions) when specific conditions are met.

## See also

- [Flow: Single-Service Booking](https://dev.wix.com/docs/api-reference/business-solutions/bookings/flow-single-service-booking)
- [Services V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/introduction)
- [Time Slots V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/time-slots/time-slots-v2/introduction)
- [Bookings Writer V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/introduction)
- [Calendar V3 APIs](https://dev.wix.com/docs/api-reference/business-management/calendar/introduction)
- [How Wix Bookings Uses the Calendar APIs](https://dev.wix.com/docs/api-reference/business-solutions/bookings/calendar/how-wix-bookings-uses-the-calendar-apis)
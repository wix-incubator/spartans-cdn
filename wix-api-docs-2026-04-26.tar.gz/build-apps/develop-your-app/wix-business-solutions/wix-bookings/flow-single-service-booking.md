---
portal: build-apps
name: "Flow: Single-Service Booking"
type: ARTICLE_RESOURCE
resourceId: 9fb560d1-c9e7-450a-beb5-70f6c13cd295
---

# Standard Booking Flow

# Flow: Single-Service Booking

This article describes how Wix Bookings handles single-service bookings, from service selection through booking confirmation.
The flow shows what happens automatically when using the Wix Bookings app, and which API methods are involved at each step for developers implementing custom booking experiences.

**Note:** On Wix sites, bookings can be managed by the [Wix Bookings app](https://www.wix.com/app-market/bookings).

## Before you begin

- Create and configure a service with the [Services V2 API](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/introduction).
- Set up [staff members](https://dev.wix.com/docs/api-reference/business-solutions/bookings/staff-members/introduction) and [resources](https://dev.wix.com/docs/api-reference/business-solutions/bookings/resources/introduction) if required for the services.
- The Wix site must [accept payments](https://support.wix.com/en/article/accepting-payments-an-overview) if services require payment.

## Single-service booking flow

The following diagram shows the full single-service booking flow.

![Standard Booking Flow](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a659d28dbb94fd2b3f647613cc5c489d.png)

The following steps describe the complete single-service booking flow from service discovery through booking confirmation and calendar integration.

### Step 1 | Display service list

Display available services to the customer for selection.

**Action:** Call [Query Services](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/query-services) to retrieve available services and display them to the customer.

**Result:** The customer selects a service. Save relevant service details including `id`, `type`, `form.id`, `payment` configuration, `staffMemberIds`, `schedule.id`, `bookingPolicy.id`, and `locations`.

### Step 2 | Display service variants

Retrieve available service variants and display them to the customer for selection.

**Action:** Call [Get Service Options And Variants By Service Id](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/service-options-and-variants/get-service-options-and-variants-by-service-id) to retrieve variants for the service. If the service has variants, display them to the customer.

**Result:** The customer selects variants and the number of participants per variant.

Learn more about [service variants and options](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/service-options-and-variants/introduction).

### Step 3 | Display available add-ons

Retrieve available service add-ons and display them to the customer for selection.

**Action:** Call [List Add On Groups by Service ID](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/list-add-on-groups-by-service-id) to retrieve all `addOns` available for the service. If the service has add-ons, display them to the customer.

**Result:** The customer selects add-ons.

Learn more about [add-ons](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/add-ons/introduction).

### Step 4 | Display available slots

Display available time slots to the customer for selection.

**Action:** Check availability depending on the selected service type:

- **For appointments**: Call [List Availability Time Slots](https://dev.wix.com/docs/api-reference/business-solutions/bookings/time-slots/time-slots-v2/list-availability-time-slots), specifying `serviceId`, `"bookable": true`, `fromLocalDate`, `toLocalDate`, and the relevant `timeZone` as filters. If the customer has selected duration-based variants or add-ons, also specify the relevant `customerChoices`. This retrieves available slots based on staff and resource availability. Display the time slots to the customer.
- **For class events**: Call [List Event Time Slots](https://dev.wix.com/docs/api-reference/business-solutions/bookings/time-slots/time-slots-v2/list-event-time-slots), specifying `serviceId`, `timeZone`, `fromLocalDate`, `toLocalDate`, and the number of `openSpots` the customer intends to book as filters to retrieve scheduled class sessions with available capacity.
- **For courses**: Compare the requested number of participants against the service's `defaultCapacity`. Retrieve all bookings for this service with [Query Extended Bookings](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-reader-v2/query-extended-bookings), specifying `bookedEntity.item.schedule.serviceId` as `filter`. Calculate the total number of participants already booked by adding up the `attendance.numberOfAttendees` from all extended bookings. Then, subtract this total from the service's `defaultCapacity` to determine the number of remaining spots. Ensure the intended number of participants doesn't exceed the remaining places.

**Result:** The customer selects their preferred available time slot or course.

### Step 5 | Display booking form

Display the [booking form](https://support.wix.com/en/article/wix-bookings-creating-and-setting-up-your-booking-forms) to the customer and collect their information.

**Action:** Call [Get Form Summary](https://dev.wix.com/docs/rest/crm/forms/form-schemas/get-form-summary) with the booking form ID from the selected service. Display the retrieved booking form to the customer. 

**Result:** The customer enters their contact details, number of participants, and any service-specific requirements into the booking form. Collect form information as a JSON object using the field names from the form schema in preparation for the booking creation. Learn more about [how Wix Bookings integrates with Wix Forms](https://dev.wix.com/docs/api-reference/business-solutions/bookings/wix-forms-integration).

### Step 6 | Validate availability

Validate the selected time slot to ensure it's still available before creating the booking.

**Action:** Revalidate service availability depending on the selected service type:

- **For appointments**: Call [Get Availability Time Slot](https://dev.wix.com/docs/api-reference/business-solutions/bookings/time-slots/time-slots-v2/get-availability-time-slot), specifying the selected slot's `localStartDate` and `localEndDate` to verify the specific slot is still open.
- **For class events**: Call [Get Event Time Slot](https://dev.wix.com/docs/api-reference/business-solutions/bookings/time-slots/time-slots-v2/get-event-time-slot), specifying `eventId` to revalidate availability for the selected class event.
- **For courses**: Recheck the requested number of participants against remaining capacity as described in step 4.

**Possible results:**

- Time slot or course still available. Continue to step 7.
- Time slot or course no longer available. Return to step 4 to select a different appointment slot, class event, or course.

### Step 7 | Create booking

Create a booking with the selected service, time slot, and customer information.

**Action:** Call [Create Booking](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/create-booking) with the selected service and form data. For appointments and class events, also specify the selected slot. If the customer has selected a [variant](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/service-options-and-variants/introduction), specify all selected `participantsChoices.serviceChoices`. If the customer has selected add-ons, specify their IDs in `bookedAddOns.id`. 

**Result:**

- The booking has `"status": "CREATED"` and isn't visible in the booking calendar. Save the booking ID.
- Wix Bookings automatically calls [Create Submission](https://dev.wix.com/docs/api-reference/crm/forms/form-submissions/create-submission) with the form data specified in the Create Booking request and saves the `formSubmissionId` on the booking.

Learn more about how you can [retrieve submitted booking forms](https://dev.wix.com/docs/api-reference/business-solutions/bookings/wix-forms-integration#retrieve-a-submitted-booking-form).

### Step 8 | Optional: Retrieve custom pricing

Wix Bookings automatically checks if the business has set up custom pricing via the [Pricing service plugin](https://dev.wix.com/docs/api-reference/business-solutions/bookings/pricing/pricing-integration-service-plugin/introduction#ways-to-set-up-pricing-for-bookings). 

**Action:** If the business uses custom pricing logic, Wix Bookings calls [Calculate Price](https://dev.wix.com/docs/api-reference/business-solutions/bookings/pricing/pricing-integration-service-plugin/calculate-price) to retrieve the custom pricing from the service plugin implementation.

**Result:** The service plugin implementor returns the custom price for the booking.

### Step 9 | Create an eCommerce checkout

Create a checkout to initiate the [eCommerce purchase flow](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/purchase-flow/introduction) for the booking.

**Action:** Call [Create Checkout](https://dev.wix.com/docs/rest/business-solutions/e-commerce/checkout/create-checkout), specifying the [Wix Bookings business solution app ID](https://dev.wix.com/docs/rest/articles/getting-started/wix-business-solutions) as `catalogReference.appId` and the booking ID as `catalogReference.catalogItemId`. Save the checkout ID.

**Result:** Checkout created.

Alternatively, you can also create a custom checkout.
Learn more about [handling payments with a custom checkout](https://dev.wix.com/docs/api-reference/business-solutions/bookings/handle-payments-with-a-custom-checkout).

### Step 10 | Customer completes purchase

Redirect the customer to the checkout page so they complete the eCommerce purchase flow.

**Action:** Call [Get Checkout URL](https://dev.wix.com/docs/rest/business-solutions/e-commerce/checkout/get-checkout-url) to generate the checkout page URL and redirect the customer.

**Result:** The customer completes the purchase. Wix eCommerce automatically creates an [order](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/orders/introduction) and charges the customer. 

### Step 11 | Handle booking confirmation

After the customer completes their purchase, Wix Bookings finalizes the booking. Once the [Order Approved](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/orders/order-approved) event triggers, Wix Bookings automatically calls [Confirm Or Decline Booking](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/confirm-or-decline-booking). The resulting booking status depends on the service's approval configuration and current availability.

**Action:** Listen to the [Booking Confirmed](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/booking-confirmed), [Booking Declined](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/booking-declined), and [Booking Marked As Pending](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/booking-marked-as-pending) events to get notified when the booking status changes.

**Automatic approval flow:**

Wix Bookings validates availability:
- If the slot is available, booking status updates to `CONFIRMED` and appears in the booking calendar.
- If there's a double booking conflict:
  - **Unpaid bookings:** Status updates to `DECLINED` and the customer is notified.
  - **Paid or partially paid bookings:** Status updates to `CONFIRMED` with `doubleBooked` set to `true`. The business receives a notification to resolve the conflict. Learn more about [handling double booking conflicts](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/sample-flows#handle-double-booking-conflicts).

**Manual approval flow:**

Wix Bookings updates booking status to `PENDING`. The business receives a notification to review the request:
- If the business confirms, status updates to `CONFIRMED` and the booking appears in the calendar.
- If the business declines, status updates to `DECLINED` and the customer is notified.

## Results

After implementing this flow, customers can discover services, select time slots, complete booking forms, and receive confirmation notifications for their bookings.
Wix users can manage bookings through the Booking calendar, while customers can view and manage their bookings through the members area.

## See also

- [About Wix Bookings architecture](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/wix-bookings/architecture-and-data-flow).
- [How Wix Bookings uses the Calendar APIs](https://dev.wix.com/docs/api-reference/business-solutions/bookings/calendar/how-wix-bookings-uses-the-calendar-apis).
- [How Wix Bookings integrates with Wix Forms](https://dev.wix.com/docs/api-reference/business-solutions/bookings/wix-forms-integration).
- [How Wix Bookings handles time zones](https://dev.wix.com/docs/api-reference/business-solutions/bookings/about-time-zones).
- [Wix Bookings sample flows](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/sample-flows).
---
portal: build-apps
name: "Architecture & data flow"
type: ARTICLE_RESOURCE
resourceId: 8295bac6-b3c6-4d94-88ee-0d95224ecb63
---

# Architecture & Data Flow

# Architecture & Data Flow

The Wix eCommerce platform comprises multiple interconnected components. Together, these components enable sophisticated purchase flows for customers, as well as powerful sales and order management capabilities for business owners. This architecture provides flexibility and adaptability, allowing you to extend, customize, or replace elements of the purchase flow in accordance with your specific needs.

![Wix eCommerce Platform Architecture: A Map](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2324608b2193a9b7f15618aa35b4e349.png)

These are the platform’s main components:

### Catalog (service plugin)

Different businesses sell different types of products and services, so Wix provides a flexible interface for connecting externally managed catalogs with the Wix eCommerce platform through the Catalog service plugin ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/catalog-service-plugin/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-v2/service-plugins-spis/ecom-catalog/introduction)). A catalog can contain anything sellable, including physical products, services, gift cards, pricing plans, and singular, custom items created for individual transactions like specialized project work. Business solutions with varied offerings, such as Wix Bookings, Wix Stores, and Wix Restaurants, provide the Wix eCommerce platform with access to their catalogs via the Catalog service plugin. This enables robust integration of the platform’s Cart and Checkout functionalities with diverse business types.

### Cart

Once customers have found catalog items they want to purchase, they can add these items to their cart. A cart holds information about a potential transaction, including details about selected items, prices, and discounts, as well as the potential buyer. Site visitors can see their cart on the cart page. Developers can access and manage customer carts with the Cart API ([REST](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/cart/introduction) | [SDK](https://dev.wix.com/docs/sdk/api-reference/ecom/cart/setup) | [Velo](https://www.wix.com/velo/reference/wix-ecom-backend/cart/introduction)) and the Current Cart API ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/cart/add-to-current-cart) | [SDK](https://dev.wix.com/docs/sdk/api-reference/ecom/current-cart/setup) | [Velo](https://www.wix.com/velo/reference/wix-ecom-backend/currentcart/introduction)). Some purchasing flows bypass the cart entirely and proceed directly to checkout.

### Checkout

Checkout is the page where a buyer finalizes a purchase. A buyer can reach the checkout page from their cart, or directly – for example, by clicking a button on a catalog or product page. Each checkout holds information about the items to be purchased, price and tax summaries, shipping and billing information, any applied discounts, and more. The checkout experience can be customized, extended, and replaced to suit the needs of the business. Out of the box, the checkout page is tailored to the geographical location of the customer. Developers can access and manage checkout details and trigger checkout-related events with the Checkout API ([REST](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/checkout/introduction) | [SDK](https://dev.wix.com/docs/sdk/api-reference/ecom/checkout/setup) | [Velo](https://www.wix.com/velo/reference/wix-ecom-backend/checkout/introduction)).

### Customization service plugins

You might need to integrate additional logic into your cart or checkout functionality. The eCommerce platform provides service plugins that enable you to integrate custom additional fees ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/additional-fees-provider-v1/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/additional-fees/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-v2/service-plugins-spis/ecom-additional-fees/introduction)), external shipping rates ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/shipping-rates-integration-service-plugin/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/shipping-rates/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-v2/service-plugins-spis/ecom-shipping-rates/introduction)), custom cart or checkout validations ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/validations-integration-service-plugin/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/validations/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-v2/service-plugins-spis/ecom-validations/introduction)), and custom discount triggers ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/service-plugins/custom-discount-triggers-integration-service-plugin/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/custom-triggers/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-v2/service-plugins-spis/ecom-custom-discount-triggers/introduction)). Cart and Checkout determine the total cost of a purchase based on these customizations.

![Customization Service Plugins](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3b727e6c2f872fade2d8fd61986c4d53.png)

### Discounts

The Discounts component offers flexibility in pricing strategies. With the Discount Rules API ([REST](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/discount-rules/introduction) | [SDK](https://dev.wix.com/docs/sdk/api-reference/ecom/discount-rules/setup) | [Velo](https://www.wix.com/velo/reference/wix-ecom-backend/discountrules/introduction)), or directly in a site’s [dashboard](https://support.wix.com/en/article/wix-stores-creating-automatic-discounts), you can create and manage complex discount rules that are applied to cart or checkout items automatically. These rules are informed by custom triggers ([REST](https://dev.wix.com/docs/rest/business-solutions/e-commerce/service-plugins/custom-discount-triggers-integration-service-plugin/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/custom-triggers/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-v2/service-plugins-spis/ecom-custom-discount-triggers/introduction)).


### Tax

The Wix eCommerce platform integrates a comprehensive tax calculation system, facilitating accurate tax calculations based on varying geographical regions and product categories. The component includes APIs for categorizing items into tax groups ([REST](https://dev.wix.com/docs/rest/business-management/payments/tax/tax-groups/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/billing/tax-groups/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-billing-v2/tax-groups/introduction)) and mapping regions ([REST](https://dev.wix.com/docs/rest/business-management/payments/tax/tax-regions/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/billing/tax-regions/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-billing-v2/tax-regions/introduction)) to specific tax calculators ([REST](https://dev.wix.com/docs/rest/business-management/payments/tax/tax-calculation/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/billing/tax-calculation/introduction) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-billing-v2/tax-calculation/introduction)). With the Tax Calculation service plugin ([REST](https://dev.wix.com/docs/rest/business-management/payments/tax/tax-calculation-integration-service-plugin/introduction)) you can customize transactional tax calculations to provide precise tax assessments in a variety of cases.


### Payments

The Payments component facilitates payment processing for buyers. It’s integrated into the site’s checkout page for customer-initiated payments, and the dashboard, where business staff can process customer payments. Payments can also be triggered after an order has been made for unpaid, changed, or partially paid orders. Wix offers several options for handling payments, including [Wix Payments](https://www.wix.com/payments) for credit cards and other popular payment methods, [Wix Pricing Plans](https://support.wix.com/en/article/pricing-plans-an-overview) for memberships, and [Rise.ai](https://rise.ai/) for gift cards. Additional payment integration options can be found in the [Wix App Market](https://www.wix.com/app-market/), and developers can create custom payment platform integrations using the Order Transactions API ([REST](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/order-transactions/introduction) | [SDK](https://dev.wix.com/docs/sdk/backend-modules/ecom/order-transactions/setup) | [Velo](https://dev.wix.com/docs/velo/api-reference/wix-ecom-backend/order-transactions/introduction)).

### Thank you page

Once a transaction is completed, the customer is redirected to a thank you page. This page acknowledges the successful payment and thanks the customer for their purchase.

### Orders

Once a customer has committed to a purchase, an order is created. An order holds information about purchased items, price and tax summaries, shipping and billing information, any applied discounts, and the status of payment and fulfillment. In the dashboard, business staff can create new orders, view and edit existing orders, track fulfillment, and manage the payments cycle. The Orders API ([REST](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/orders/introduction) | [SDK](https://dev.wix.com/docs/sdk/api-reference/ecom/orders/setup) | [Velo](https://www.wix.com/velo/reference/wix-ecom-backend/orders/introduction)) enables apps or site owners to customize management of the order lifecycle, including viewing, editing, approving, canceling, and charging.

### Fulfillment

The Fulfillment component is the process's concluding step, ensuring customers receive their purchases. It accommodates all types of goods or services, from physical and digital products to service provisions, ensuring a comprehensive fulfillment solution. A fulfillment object contains information about an order’s shipping provider, tracking details, and line items. Fulfillment details can be accessed and managed using the Order Fulfillments API ([REST](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/order-fulfillments/introduction) | [SDK](https://dev.wix.com/docs/sdk/api-reference/ecom/order-fulfillments/setup) | [Velo](https://www.wix.com/velo/reference/wix-ecom-backend/orderfulfillments/introduction)), allowing a high degree of customization.

### Notifications

The Notifications component plays a vital role in keeping site owners up-to-date with critical events throughout the buying process. This service sends alerts to site owners when specific events take place, such as a successful or failed payment, the creation of an order, or fulfillment events. Notifications keep site owners informed and help them stay on top of orders, ensuring a smooth buying experience for their customers.
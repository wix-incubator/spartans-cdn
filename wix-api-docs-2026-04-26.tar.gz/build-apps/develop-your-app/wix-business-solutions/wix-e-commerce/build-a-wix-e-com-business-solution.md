---
portal: build-apps
name: "Build a Wix eCom business solution"
type: ARTICLE_RESOURCE
resourceId: 56c5fc4e-a12a-42fa-9218-749258ae1d51
---

# Wix App Developers: Build a Wix eCom business solution

# Wix App Developers: Build a New eCommerce Business Solution

If you are developing a full-scale business solution that requires eCommerce capabilities (similar to Wix Stores, Wix Bookings, or Wix Restaurants Orders), you can integrate your app with the Wix eCommerce platform and take advantage of its features. To enable this integration, you need to:

1. [Set up automatic installation of the eCommerce app.](#step-1--set-up-automatic-installation-of-the-ecommerce-app)
1. [Integrate an external catalog with your app.](#step-2--integrate-an-external-catalog-with-your-app)
1. [Integrate with the Inventory service plugin.](#step-3--integrate-with-the-inventory-service-plugin)
1. [Integrate with additional eCommerce services.](#step-4-optional--integrate-with-additional-ecommerce-services) (Optional)

For a comprehensive guide, see our [tutorial on building a business solution integrated with the Wix eCommerce platform](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/overview).

## Step 1 | Set up automatic installation of the eCommerce app

The eCommerce platform’s functionality can be added to a Wix site by installing the Wix Checkout & Orders app. However, the Wix Checkout & Orders app isn’t a standalone app that a site owner can install independently. To integrate eCommerce capabilities into your own business solution app, you need to make sure that your app automatically installs the Wix Checkout & Orders app as a dependency.

Follow these steps to make your app install Wix eCommerce capabilities every time it's installed on a site:

1. Go to your [app's dashboard](https://dev.wix.com/apps/).
2. In the left sidebar, click **App Profile**.
3. In the sidebar submenu, click **App Audience**.
4. Under **Required Wix Products**, select **Yes, additional products are required**.
5. In the **Choose products** list, select **Wix Checkout & Orders**.
    ![Wix Checkout & Orders](https://wixmp-833713b177cebf373f611808.wixmp.com/images/444cfe17d5680683847c9ffc3870665c.png)
6. Click **Save**.

You have now configured your app to frontload the Wix eCommerce platform. Whenever your app is installed on a site, it now automatically installs the Wix Checkout & Orders app which adds standard Wix eCommerce pages and components to the site it’s installed on.

After installing your app, a Wix site will have these features:

**Site pages:**

+ Cart Page
+ Checkout Page (not visible in the editor)
+ Thank You Page

**Dashboard pages:**

+ Orders
+ Gift Cards


## Step 2 | Integrate an external catalog with your app

Any business solution app that integrates with the Wix eCommerce platform needs to connect with an external [catalog](https://github.com/wix-private/developer-docs/blob/32db975cc3e7635a50a48be56165cc017017775b/developer-guides/ecom-handbook/docs/overview/architecture.md#catalog-service-plugin*original::../overview/architecture.md#catalog-service-plugin) containing available products or services.

To get your app set up with an external catalog, follow these steps:

1. Implement the Catalog service plugin to make your external catalog's data available to Wix in the required format and structure. Refer to the [Catalog service plugin documentation](https://dev.wix.com/docs/rest/business-solutions/e-commerce/introduction) for detailed instructions.

1. Create an [item page](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/get-started/apps/develop-a-business-solution-item-page-with-blocks) (a product page, a service page, or equivalent) and/or a gallery page for your app that displays information about individual items for sale. This page should include functionality for adding items to the site visitor's cart, using the [Cart API](https://dev.wix.com/docs/rest/api-reference/wix-e-commerce/cart). For guidance on creating a page for your app, consult [About Site Page Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/about-site-page-extensions).

1. (Optional) To enable Wix users to manage catalog items from their site dashboard, develop a [dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions) for your app.

For detailed instructions on developing Wix apps, consult our comprehensive documentation on [building Wix apps](https://dev.wix.com/docs/build-apps).


## Step 3 | Integrate with the Inventory service plugin

Any business solution app that integrates with the Wix eCommerce platform and manages inventory needs to prevent orders for unavailable items and keep stock levels in sync with order flows.

To get your app set up with inventory management, follow these steps:

1. Implement the Inventory service plugin to integrate with Wix's unified inventory system. This enables your app to automatically decrement availability when items are ordered or paid for, and increment it when orders are canceled or refunded. Refer to the [Inventory service plugin documentation](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/catalogs/inventory-service-plugin/introduction) for detailed instructions.

1. (Optional) Configure multi-location inventory management if your business solution involves tracking stock across multiple physical or virtual locations.

The Inventory service plugin is especially useful for business solutions involving physical products, digital goods with limited availability, or time-based services like appointments or event tickets.


## Step 4 (Optional) | Integrate with additional eCommerce services

You can further customize your app's functionality by integrating with additional services available on the eCommerce platform.

The [Tax Groups service plugin](https://dev.wix.com/docs/rest/business-management/payments/service-plugins/tax-groups-integration-service-plugin/introduction) enables you to create and manage custom tax groups to categorize items from your app's catalog based on distinct tax treatments. This integration is required to charge tax on your external catalog items.

## See also

+ [Tutorial | Build an eCommerce Business Solution](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/overview)
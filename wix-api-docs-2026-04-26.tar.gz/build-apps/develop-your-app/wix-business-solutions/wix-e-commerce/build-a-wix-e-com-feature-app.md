---
portal: build-apps
name: "Build a Wix eCom feature app"
type: ARTICLE_RESOURCE
resourceId: 01ae4479-ef22-4f68-abf6-876b38b6bb93
---

# Wix App Developers: Build a Wix eCom feature app

# Wix App Developers: Build a Feature App That Extends eCommerce Functionality

Many apps in the Wix App market enhance the eCommerce functionality of sites that already integrate with the Wix eCommerce platform.

If you are creating such an app, your app should require that Wix users first install a business solution app that integrates the Wix eCommerce platform, such as Wix Bookings or Wix Stores.

To prevent your app from being installed on sites that don't have an eCommerce business solution app already installed, follow these steps:

1. Go to your [app's dashboard](https://dev.wix.com/apps/).
2. In the left sidebar, click **App Profile**.
3. In the sidebar submenu, click **App Audience**.
4. Under **Required Wix Products**, select **Yes, additional products are required**.
5. In the **Choose products** list, select the required business solutions, such as **Wix Stores**, **Wix Bookings**, and **Wix Restaurants Orders**. If you select more than 1 app, your app will require at least 1 of the selected apps.
6. Click **Save**.

To check whether a business solution is installed on a site, you can also use the [Get App Instance](https://dev.wix.com/docs/rest/api-reference/app-management/apps/app-instance/get-app-instance) method. The response object contains a list of installed Wix apps in `site.installedWixApps`.

To learn more about developing a Wix app that extends eCommerce functionality, read about [integrating with Wix business solutions](https://dev.wix.com/docs/build-apps/overview/introduction/extend-wix-business-solutions).

If you are new to developing apps for installation on Wix sites, learn more about the [app-building journey](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps), or get started from one of our growing selection of [app templates](https://dev.wix.com/docs/build-apps/get-started/templates/get-started-from-an-app-template).
---
portal: build-apps
name: "What is the Wix eCommerce platform?"
type: ARTICLE_RESOURCE
resourceId: 7ad1a335-8241-40de-a872-d76b68666810
---

# What is the Wix eCommerce platform?

# What Is the Wix eCommerce Platform?

The Wix eCommerce platform is a comprehensive suite of services that addresses standard and specialized needs in online selling.

The platform serves as a foundational layer for Wix's own business solutions, such as [Stores](https://support.wix.com/en/article/wix-stores-about-wix-stores), [Bookings](https://support.wix.com/en/article/wix-bookings-about-wix-bookings), and [Restaurants Orders](https://www.wix.com/app-market/wix-restaurants-orders-new). It can also be [integrated with external business solutions](https://github.com/wix-private/developer-docs/blob/29e95b78da07393f162100fbbab378d4bedb777f/developer-guides/ecom-handbook/docs/get-started/get-started-wix-app-business-solution.md*original::../get-started/get-started-wix-app-business-solution.md), enabling customization and flexibility.

![Wix eCommerce Platform & Business Solution Apps](https://wixmp-833713b177cebf373f611808.wixmp.com/images/20d7e7d23435a34e93769a812c35ea75.png)

At the platform’s core lies a robust set of interconnected [components](https://github.com/wix-private/developer-docs/blob/29e95b78da07393f162100fbbab378d4bedb777f/developer-guides/ecom-handbook/docs/overview/architecture.md*original::./architecture.md), which together enable a seamless and efficient online shopping experience for end-users and a streamlined management process for businesses.

The Wix eCommerce platform's power lies in its modularity. The platform’s composable architecture provides you with the autonomy to customize, extend, or replace the platform’s functionalities to meet your requirements. This is made possible through various extension points such as APIs, service plugins, data extensions, and custom extensions to a site’s checkout UI and its dashboard.
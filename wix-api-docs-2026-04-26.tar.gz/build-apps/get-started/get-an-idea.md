---
portal: build-apps
name: "Get an Idea"
type: ARTICLE_RESOURCE
resourceId: 57b03492-3f7b-43e4-8cf6-9e620438b7aa
---

# Get an Idea

<style>
.wix-button-medium {
    background-color: rgb(17, 109, 255);
    color: rgb(255, 255, 255);
    border-radius: 18px;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 6px 24px;
    font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, sans-serif;
    font-size: 16px;
    font-weight: 530;
    height: 36px;
    line-height: 24px;
    cursor: pointer;
    transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
    text-align: center;
    user-select: none;
    white-space: nowrap;
}

.wix-button-medium:hover {
   background-color: rgb(15, 98, 230);
   color: rgb(255, 255, 255);
}

</style>

# Get an Idea for Your Next App

Are you searching for your next app idea? We’ve gathered the top feature requests from Wix users. These are high-demand features that can boost user adoption of your apps. After you build an app based on this list, let us know so we can help promote it.

[<button class="wix-button-medium">See Feature Requests
</button>](#open-feature-requests)

## Monetize your app

When your app is ready, you can add it to the [Wix App Market](https://www.wix.com/app-market) to reach millions of Wix users worldwide—and sell your apps at scale. For more information, see [About Launching Apps](https://dev.wix.com/docs/build-apps/launch-your-app/about-launching-apps).

## Let us know you're supporting a feature

If you're supporting one of these top feature requests, mention it when you [submit your app for review](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/about-app-distribution) or notify us through [WixBot](https://www.wix.com/support-chatbot?nodeId=25a57397-ccf7-4376-8b74-48d51edf7159&referral=devRels). In the message, be sure to include your app ID and app name.

Apps that meet our quality standards will be promoted through internal tools, such as emails and notifications to account managers, helping users discover your feature and increasing adoption.

**Ready to build?** [Get Started](https://manage.wix.com/account/custom-apps)

## Open feature requests

Here's a list of highly requested features from our user community.

| **Feature** | **Description** |
|---|---|
| **Additional fees in Edit Order page (Ecomm, Stores, Bookings)** <br><br> Date Added: November 1, 2024 | **About the request:** Add fees for extra services like fragile packaging, shipping insurance, or gift wrapping at checkout. Providing these optional fees can boost customer satisfaction and generate new revenue streams for merchants by offering value-added services.<br><br> **Resources to help you get started:**<ul><li>[Dashboard plugin on the Order page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-e-commerce/wix-e-commerce-edit-order-page)</li><li>[Additional fees service plugin](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/additional-fees/introduction)</li></ul> |
| **Reputation management (Bookings)** <br><br> Date Added: December 14, 2025 | **About the request:** Prompt users to rank the business on external platforms like Google, Google Maps, Facebook, and Yelp after completing a meeting. <br><br>**Note:** Developers should bring their own existing solution to manage the reviews. You can trigger this flow by sending a post-meeting email to the client.<br><br> **Resources to help you get started:**<ul><li>[About Wix Bookings Architecture](https://dev.wix.com/docs/api-reference/business-solutions/bookings/architecture)</li><li>[Bookings Reader V2: Sample Flows](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-reader-v2/sample-flows#bookings-reader-v2-sample-flows)</li><li>[Query Attendance](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/attendance/query-attendance)</li><li>[Query Extended Bookings](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-reader-v2/query-extended-bookings)</li></ul> |
| **Print Daily schedule (Bookings)** <br><br> Date Added: December 14, 2025 | **About the request:** Enable business owners to generate a printable agenda of the day's appointment directly from the Booking Calendar. <br><br> **Resources to help you get started:**<ul><li>[Dashboard menu plugin slots - More actions menu](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/wix-bookings/wix-bookings-calendar-page#slot-2-more-actions-menu)</li><li>[Query Events](https://dev.wix.com/docs/api-reference/business-management/calendar/events-v3/query-events)</li></ul> |
| **Share Google Drive content on a site** <br><br> Date Added: January 21, 2026 | **About the request:** Let visitors view and collaborate on Google Drive files and folders directly on your site, including Docs, Sheets, Slides, Forms, Microsoft Office files and PDFs. <br><br> **Resources to help you get started:**<ul><li>[Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/create-a-settings-panel-for-a-site-widget-or-plugin-wix-cli-and-self-hosting)</li></ul> |

## Resolved feature requests

The following feature requests have been resolved by at least 1 app, or by Wix.

| **Feature** | **Description** |
|---|---|
| **Verifying Shipping Addresses (eCom/Stores)** <br><br> Date Added: December 14, 2025 | **About the request:** Systematically verifying the shipping location to ensure accurate delivery before processing the order. <br><br> **Resources to help you get started:**<ul><li>[eCommerce validations service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/validations/validations-integration-service-plugin/introduction#about-the-wix-ecommerce-validations-service-plugin)</li><li>[Dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions) to manage the areas which the verifier is working on</li></ul> |
| **Interactive rotatable product image (Stores)** <br><br> Date Added: November 1, 2024 | **About the request:** Integrate rotatable 360-degree images on a Wix product page to enrich customer interaction. This shopping experience enhances understanding and boosts confidence in purchase decisions, potentially increasing sales. <br><br> **Resources to help you get started:**<ul><li>[Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions) in product page</li><li>[Explore a relevant template](https://dev.wix.com/apps-templates/template?id=086a1107-3d84-43cc-992e-738055e01547&http_referrer=custom-apps-studio)</li></ul> |
| **Site Vacation Mode (eCom/Stores)** <br><br> Date Added: December 14, 2025 | **About the request:** A time-based logic that restricts access to the checkout of defined timeframes <br><br> **Resources to help you get started:**<ul><li>An [embedded script](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) using [`openModal()`](https://dev.wix.com/docs/sdk/frontend-modules/window/open-modal) that executes on the checkout page, preventing purchases by displaying a custom "Store Closed" message during the defined timeframe, and preventing the user from completing the checkout</li><li>[Dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions) to manage time of the vacation mode and messaging</li></ul> |
| **Free shipping bar in Side Cart (eCom/Stores)** <br><br> Date Added: December 14, 2025 | **About the request:** Represent the remaining amount (for example, "Missing X$ to get free shipping") based on the configured shipping rate, encouraging shoppers to add more items to their cart. <br><br> **Resources to help you get started:**<ul><li>[Site Plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-e-commerce/wix-e-commerce-side-cart?apiView=SDK)</li></ul> |
| **Location-based service selection (Bookings)** <br><br> Date Added: February 13, 2025 | **About the request:** Add a visual interface for locations synced with Wix Bookings. When a site visitor selects a location, show a list of services specific to that location. This feature enhances user experience by making service discovery easier and more intuitive. <br><br> **Resources to help you get started:**<ul><li>[Bookings Services](https://dev.wix.com/docs/sdk/backend-modules/bookings/services/setup)</li><li>[Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)</li></ul> |
| **Offer extras and add-ons for client services (Bookings)** <br><br> Date Added: November 1, 2024 | **About the request:** Enable customers to add extras during a booking checkout for a personalized experience, which can customize costs and timing, enhance efficiency, and boost user satisfaction. <br><br> **Resources to help you get started:**<ul><li>[Site widget in checkout](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)</li><li>[Bookings APIs](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction)</li><li>[Checkout APIs](https://dev.wix.com/docs/sdk/backend-modules/ecom/checkout/setup)</li><li>[Explore a relevant template](https://dev.wix.com/apps-templates/template?id=b358e3d3-9e4c-4596-bad1-b7415fa37990&http_referrer=custom-apps-studio)</li></ul> |
| **Checkout and product countdown (Ecomm, Stores)** <br><br> Date Added: November 1, 2024 | **About the request:** Implement countdown timers on checkout and product pages to encourage prompt transactions, improving sales conversions by leveraging urgency and limited-time offers. <br><br> **Resources to help you get started:**<ul><li>[Site widget in checkout and product page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)</li><li>[Discount rules API](https://dev.wix.com/docs/rest/business-solutions/e-commerce/discount-rules/introduction)</li><li>[Explore a relevant template](https://dev.wix.com/apps-templates/template?id=086a1107-3d84-43cc-992e-738055e01547&http_referrer=custom-apps-studio)</li></ul> |
| **Shipping address verification (Stores, Restaurants)** <br><br> Date Added: November 1, 2024 | **About the request:** Implement shipping address verification during checkout to ensure accurate deliveries, reduce shipment failures, and enhance customer satisfaction by ensuring orders are delivered to the correct destination. <br><br> **Resources to help you get started:**<ul><li>[eComm validations service plugin](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/validations/introduction)</li></ul> |
| **Size chart (Stores)** <br><br> Date Added: November 1, 2024 | **About the request:** Offer size charts on product pages to help customers select the right size, enhancing their shopping experience, reducing returns, and boosting sales confidence. Merchants desire the flexibility to create these charts using either images or tables.<br><br> **Resources to help you get started:**<ul><li>[Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions) in product page</li><li>[Explore a relevant template](https://dev.wix.com/apps-templates/template?id=086a1107-3d84-43cc-992e-738055e01547&http_referrer=custom-apps-studio)</li></ul> |
| **Add a PDF to a product description (Stores)** <br><br> Date Added: November 1, 2024 | **About the request:** Offer a PDF download option on product pages, providing resources like spec sheets for offline review. This enhances credibility and informs purchase decisions, potentially boosting sale conversions. <br><br> **Resources to help you get started:**<ul><li>[Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions) in product page</li><li>[Explore a relevant template](https://dev.wix.com/apps-templates/template?id=086a1107-3d84-43cc-992e-738055e01547&http_referrer=custom-apps-studio)</li></ul> |
| **Free shipping progress bar (Stores, eComm)** <br><br> Date Added: November 1, 2024 | **About the request:** Add a progress bar in the cart to show customers how close they are to qualifying for free shipping. This feature incentivizes customers to add more items, boosting average order value and increasing store revenue. <br><br> **Resources to help you get started:**<ul><li>[Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions) in checkout</li><li>[Discount service plugin](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#service-plugins)</li><li>[Explore a relevant template](https://dev.wix.com/apps-templates/template?id=b358e3d3-9e4c-4596-bad1-b7415fa37990)</li></ul> |
| **Zip code locator and restriction (Restaurants, Stores)** <br><br> Date Added: November 1, 2024 | **About the request:** Apply zip code restrictions for merchants offering services across multiple locations. Allow merchants to direct users to the nearest service locations, block bookings from unauthorized areas, limit bookings by zip code on specific days, and optimize schedules. The goal of this feature is to enhance efficiency and service delivery within targeted regions. <br><br> **Resources to help you get started:**<ul><li>[eComm validation service plugin](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/validations/introduction)</li></ul> |

## Explore more articles

- [About Developing Apps](https://dev.wix.com/docs/build-apps/develop-your-app/about-developing-apps#about-developing-apps)
- [About Launching Apps](https://dev.wix.com/docs/build-apps/launch-your-app/about-launching-apps)
- [The Wix Choice Program](https://dev.wix.com/docs/build-apps/launch-your-app/app-promotion/wix-choice-program)
---
portal: build-apps
name: "About Wix Apps"
type: ARTICLE_RESOURCE
resourceId: bbd113d0-4d07-4482-b8b0-959a28d1b74d
---

# About Wix Apps

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# About Wix Apps

Wix apps are packages of reusable functionality that Wix users can add to their sites. They can contain anything from a simple site widget to a full-stack business solution, complete with backend logic, user interfaces, and databases.

Whether your app adds a useful widget to a Wix user's site or helps them manage their business through the site's dashboard, Wix's open platform lets you integrate seamlessly, wherever your app fits in.

Once you've built an app, you can make it public and offer it to millions of potential users through the [Wix App Market](https://www.wix.com/app-market) or [keep it private](https://dev.wix.com/docs/build-apps/get-started/overview/exposing-apps-publicly-and-privately) to install on your own sites.

[<button class="wix-button">Start Developing
</button>](https://manage.wix.com/account/custom-apps)

![app-you-need](https://wixmp-833713b177cebf373f611808.wixmp.com/images/c1ec3989e13efd6c87a43648b579429c.gif)

## Your app-building journey

Ready to get started? Build your app by navigating through the following stages:

### Onboard

Start off by learning about the various parts of the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem). This will help you understand where and how you can add your own functionality to a site.
You can then jump right in and [quickly build a simple app](https://dev.wix.com/docs/build-apps/get-started/quick-start/about-the-quick-starts), or try out one of our many [tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials) and [app templates](https://dev.wix.com/docs/build-apps/get-started/templates/get-started-from-an-app-template), covering a wide range of business cases.

### Develop

Wix offers a versatile development platform with a comprehensive suite of tools and technologies. Use one of our [development frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) to build out your app's functionality by creating [extensions](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix) and [integrating with Wix's business solutions](https://dev.wix.com/docs/build-apps/get-started/overview/integrating-with-wix-s-business-solutions).

### Launch

Wix offers several ways to distribute your app. If you're going to distribute your app publicly, set up your [App Market listing](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/about-market-listings) and create promotional assets to showcase your app.

Then decide whether to list your app in the Wix App Market or distribute your app on your own:

- If you're going to list your app in the Wix App Market, set up your app's [pricing plans](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/about-monetizing-your-app) to start making money. You'll also need to [submit your app for review](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/about-app-distribution) so Wix's team can check that everything's working as it should.

  > **Note**: The type of site your app can be installed on depends on the app's extensions:
  >
  > - **Wix sites built with Wix Studio or the Wix Editor**: Full support for all app types and extensions.
  > - **Wix Vibe sites and Headless projects**: Support apps that only have dashboard extensions.
  >
  > To check if your app works with a specific site type, [contact us](https://dev.wix.com/docs/build-apps/manage-your-app/contact-us/contact-us).

- If you'll distribute your app on your own, you can install it directly on your own sites and create an [install link](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/share-an-app-install-link) from the **Distribute** page in your app's dashboard.

### Grow

Once your app goes live, enhance your success by [responding to reviews](https://dev.wix.com/docs/build-apps/manage-your-app/user-support/user-reviews), analyzing [performance metrics](https://dev.wix.com/docs/build-apps/manage-your-app/data-and-analytics/app-stats), [localizing content](https://dev.wix.com/docs/build-apps/launch-your-app/localization/about-app-localization), and refining monetization strategies to achieve optimal growth.

## Looking for ideas?

Discover opportunities for your next app by exploring our [list of top user-requested features](https://dev.wix.com/docs/build-apps/get-started/get-an-idea).

## Use these docs with AI tools

Wix developer documentation is available in machine-readable formats for use with AI coding assistants and LLMs:

- **llms.txt index:** Browse a structured index of all documentation at [dev.wix.com/docs/llms.txt](https://dev.wix.com/docs/llms.txt).
- **Markdown format:** Append `.md` to any documentation page URL to retrieve a Markdown version of that page.
- **Page menu:** Use the "Ask Assistant" dropdown on any documentation page to copy the page as Markdown or get a direct link to the Markdown version.

## Stay updated

[Subscribe to our newsletter](https://www.wixforms.com/f/7394355343209268224) to receive the latest updates, feature announcements, and tips for building successful Wix apps.
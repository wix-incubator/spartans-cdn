---
portal: build-apps
name: "About Wix Harmony and Apps"
type: ARTICLE_RESOURCE
resourceId: 3136c8ba-aa0d-423b-8e7d-df31f9a812fa
---

# Wix Harmony and Apps

# About Wix Harmony and Apps

Wix Harmony is Wix's new AI-powered site editor, built on a technical architecture that's different from previous editors. With Harmony, the way apps and extensions work across Wix is evolving. This overview explains app compatibility in Harmony, what's changing, and your options for supporting users across all Wix editors and frameworks.

> **Note:** For information about site development, see [About Wix Harmony](https://dev.wix.com/docs/develop-websites-sdk/get-started/overview/about-wix-harmony). For Blocks-specific information, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

## App compatibility at a glance

Apps can be installed in Harmony, though the UI and App Market experience differs from other editors. Due to architectural and technology updates, some app types are only available in certain editors.

| Extension type                    | Wix Harmony | Wix Editor & Wix Studio |
| --------------------------------- | :---------: | :---------------------: |
| Dashboard extensions              | ✓           | ✓                       |
| Backend extensions                | ✓           | ✓                       |
| CLI site extensions               | ✓           | ✓                       |
| Self-hosted site extensions       | ✓           | ✓                       |
| Blocks site widgets and plugins   | —           | ✓                       |
| Legacy custom elements            | —           | ✓                       |
| Legacy iFrame widgets and pages   | Partial     | ✓                       |

## What this means for existing apps

Your app's availability in Harmony depends on the types of extensions it includes:

- **Supported extensions:** Your app works in Harmony with no changes required.
- **Unsupported extensions:** Your app works on Wix Editor and Wix Studio, but can't be installed by Harmony users. To reach Harmony users, rebuild unsupported extensions using the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) or [self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting).
- **Partial support (iFrames):** If your app uses legacy iFrame widgets or pages, test your app thoroughly in Harmony. If you encounter issues, [reach out to us](https://dev.wix.com/docs/build-apps/manage-your-app/contact-us/submit-support-requests) for help.

## Recommendations for new apps

When building a new app, use frameworks supported in Harmony:

- **Wix CLI:** Build app extensions using your preferred IDE, with local development, testing tools, and full control over your code. Learn more in the [Wix CLI documentation](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps).
- **Self-hosting:** Use your own infrastructure for backend, site, or dashboard extensions. Learn more about [self-hosted extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/supported-extensions/about-self-hosted-app-extensions).

## Test your app

We recommend testing your app in Harmony to ensure it works as expected. Create a Harmony development site to test your app's functionality and user experience.

To learn more, see [Test Your App on a Free Premium Site](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/test-your-app-on-a-premium-site).

## FAQ

### Migration and compatibility

<details>
<summary>Can Blocks apps be migrated to the CLI or site widgets?</summary>

Currently, there is no automatic migration path to convert Blocks apps directly to the new CLI or site widget tools. To move to the new architecture, you need to build a new extension.

We've created a [step-by-step guide](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/migrate-to-a-new-site-widget-or-plugin-extension) on how to rebuild and update your app using the new tools. We're also exploring solutions to streamline this process in the future.

</details>

<details>
<summary>What happens to existing Blocks apps when customers move from Classic/Studio to Harmony?</summary>

Currently, there is no migration tool from Classic/Studio to Wix Harmony.

</details>

<details>
<summary>Is there a way to move existing users from a Blocks app to a new implementation without losing reviews or installs, or without supporting 2 app versions?</summary>

You can maintain your existing reviews and install base by adding your new implementation as an additional extension within your existing app, rather than creating a new app. We will be releasing a guide to assist you in migrating your active users from the old extension to the new one.

</details>

### Business impact and App Market visibility

<details>
<summary>Why are Blocks apps not discoverable or installable for Harmony users?</summary>

Wix Harmony is built on a completely new technology that doesn't support Blocks apps, which means they aren't available for installation.

</details>

<details>
<summary>How can developers quickly mitigate lost customer acquisition and revenue due to Harmony not supporting Blocks apps?</summary>

The current path to compatibility with Harmony is to build site widgets using Custom Elements, managed via the [Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) or [self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting). We encourage you to adopt this approach now to regain access to that user base. Additionally, we're working on a comprehensive React-based infrastructure that will provide even more robust options for app development in the near future.

</details>

<details>
<summary>What immediate options exist so current and new users can still access these apps?</summary>

Wix Editor and Wix Studio users still have full access to your apps. If you need to support Wix Harmony sites now, you can start building [self-hosted](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting) or [CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps) site widgets.

</details>

### Long-term strategy and timelines

<details>
<summary>What are the timelines for deprecations and continued support for the Classic and Studio editors?</summary>

We aren't breaking any existing capabilities. If at any time we move forward with deprecation, we will make sure there is a clear and concrete plan that addresses all questions and concerns.

</details>

## Get support

If you encounter issues or have questions, feel free to [reach out to us](https://dev.wix.com/docs/build-apps/manage-your-app/contact-us/submit-support-requests) or ask in our [Discord community](https://discord.gg/wixstudio).

## See also

- [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks)
- [About Wix Harmony](https://dev.wix.com/docs/develop-websites-sdk/get-started/overview/about-wix-harmony)
- [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions)
- [About Development Frameworks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/about-development-frameworks)
---
portal: build-apps
name: "Exposing Apps Publicly and Privately"
type: ARTICLE_RESOURCE
resourceId: f1c0b253-2ba9-4e9c-b714-e1c39b2cea4d
---

# App Exposure: Public or Private?

# Exposing Apps Publicly and Privately

When you build an app, you can decide whether you want that app to be: 
- **Public**: Available for general use, whether listed in the Wix App Market or distributed on your own.
  - **Market listed**: Listed in the Wix App Market.
  - **Unlisted**: Available for general use, not listed in the Wix App Market.
- **Private**. Only available on your own sites or your enterprise sites.


## Public apps

Public apps are applications that are available to all Wix users to install. They might be listed in the [Wix App Market](https://www.wix.com/app-market), or they might be available via [install link](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/share-an-app-install-link).

 ### Market listed apps

 Market listed apps are applications that are listed in the [Wix App Market](https://www.wix.com/app-market). In the Wix App Market, your apps are visible to millions of Wix users and can be found through search engines like Google. You can choose to offer your apps for free or sell them.

You can also decide on the size of your app’s audience by limiting it to certain countries or languages. For example, you could build a shipping app just for Indian users.

 Learn more about [listing apps in the App Market](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/app-market-guidelines).
 
 ### Unlisted apps

Unlisted apps are applications that you make available for general use but are not listed in the Wix App Market.

Unlisted apps can be installed through:
- The app dashboard (if you are an owner or contributor to the site), from the **App Distribution** page.
- A [shareable URL](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/share-your-app-with-an-install-link), which you can create in [Custom Apps page](https://manage.wix.com/account/custom-apps), the **App Distribution** page of your app's dashboard for Wix CLI and self-hosted apps, or directly in Wix Blocks through **App** > **Share App**.

## Private apps

Private apps are applications that are used on your own sites, on your enterprise sites, or for other collaborative projects.

You can install these apps on as many Wix sites as you want, as long as you are an owner or contributor to the site. Enjoy the benefits of reusing the app's user-interface, code, collections, and dashboard pages.

Private apps can be installed through:

- The editor (if you’re the app’s creator).
- The Wix Studio dashboard.
- A [shareable URL](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/share-an-app-install-link), which you can create in [Custom Apps page](https://manage.wix.com/account/custom-apps), the **App Distribution** page of your app's dashboard for Wix CLI and self-hosted apps, or directly in Wix Blocks, through **App** > **Share App**.

### Private apps for enterprise use

With a Wix enterprise account, you can build and reuse apps among all of your organization’s accounts and websites. Private apps built by enterprises can be exposed to all enterprise users through the Wix App Market using a ‘private collection’ that can appear in the Wix App Market sidebar.


## See also

- [About the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard)
- [The Wix App Market](https://www.wix.com/app-market)
- [Publishing Your Wix Blocks App to the App Market](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/publish-blocks-apps-to-the-app-market/publish-a-blocks-app-to-the-app-market)
---
portal: build-apps
name: "Glossary"
type: ARTICLE_RESOURCE
resourceId: 197d00c2-13f9-4ac4-8d0d-483cd86e3f00
---

# Glossary

# Developers' Glossary 

## **Access type** 
Authorization profile used to interact with Wix. Every actor who interacts with Wix, whether they log into Wix, visit a Wix site, or make API calls, must authorize their calls using an access type. Access types include visitor, member, user, app and API key.

## **App ID** 
Unique ID that identifies your app in Wix. Find it on your app’s main page and OAuth page in the app dashboard.

## **API key** 
Account-level access token for REST and SDK API calls, that can be used for account-level APIs as well as site-level APIs. Account-level access provides access only to the specific sites that are managed by the relevant account. Only available to select apps after App Market approval. 

## **App instance** 
Properties that describe your app's installation on a specific site. These properties include the app instance ID, user ID, premium flag and more.  

## **App instance ID** 
Unique ID that identifies your app's installation on a specific site. Use this ID to identify specific sites in your app's code.

## **Custom app** 
App that is available only on your own sites, on your clients' sites, or for other collaborative projects. Custom apps are not listed in the Wix App Market.

## **Dashboard** 
Interface where users can manage their site and installed apps. Dashboards aren’t exposed to site visitors.

## **Development site** 
Free, pre-made premium site available to all third-party app developers for testing purposes. 

## **Editor** 
Interface where site builders design their site’s visual components. Wix currently offers 2 different editors: [Wix Editor](https://support.wix.com/en/using-the-wix-editor) and [Wix Studio](https://support.wix.com/en/wix-studio).

## **Extension** 
Functionality that an app adds to a site, for example, a dashboard page, a site widget or specific backend logic. 

## **Extension ID** 
Unique ID that identifies your extension in Wix. 

## **Identity** 
Unique identifiers Wix uses to identify actors. Each identity has their own ID and access type. Identities include visitor, member, user, app and API key.

## **Permission scope** 
Sets of permissions that you can request from Wix users when they install your app. These permissions enable you to access and manage relevant site data. You can configure the permissions scopes for your app in the app dashboard.

## **Plugin** 
Extension that adds functionality to an app created by Wix, with either a visual component or backend logic. 

## **Public key** 
Encryption key used to verify that data payloads were sent by Wix. You’ll need this to read webhook and SPI call data. You can find your app's public key on the Webhooks page in the app dashboard.

## **Query builder** 
Function that builds a query to retrieve a list of items.

## **Secret key** 
Encryption key used to create your app’s signature. You’ll need this to sign requests to Wix APIs, and Wix uses it when sending data to your app. You can find it on the OAuth page in the app dashboard. 

## **Service plugin (formerly SPI)** 
APIs designed to be implemented by Wix users or by third parties, enabling you to customize Wix's business logic within a specific business solution.  

## **Slot** 
UI placeholder within a site or dashboard page of an app created by Wix, where users can place a [plugin](#plugin).

## **User ID** 
Unique ID that identifies a [Wix user](#wix-user). 

## **Wix app** 
Any app that extends the Wix ecosystem, including apps made by Wix, apps made by third parties and apps made by site builders. A third-party app can be public (available on the Wix App Market) or private (see [custom app](#custom-app)).

## **Wix Blocks** 
[Editor](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) for building responsive Wix apps.

## **Wix business solution** 
Comprehensive app made by Wix for managing a specific type of business, such as Wix Stores and Wix Bookings.

## **Wix CLI** 
[Command-line](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) interface tool that streamlines building Wix apps with minimal setup and configuration.

## **Wix Design System** 
[Collection](https://dev.wix.com/docs/build-apps/develop-your-app/design/about-the-wix-design-system) of reusable React components and clear standards for designing Wix apps with the Wix look and feel.

## **Wix Patterns** 
[Collection](https://dev.wix.com/docs/build-apps/develop-your-app/design/about-the-wix-design-system) of Wix Design System's reusable React components organized into fully-functional design and behavior presets for common types of functionality.

## **Wix user** 
Anyone who creates an account on wix.com. Users include site owners, who create a site, and site collaborators, who are invited by site owners to help manage the site and business.
---
portal: build-apps
name: "How Apps Extend Wix"
type: ARTICLE_RESOURCE
resourceId: 0f6f0931-9cc6-4c6b-84b0-48618154dc11
---

# How Apps Extend Wix

# How Apps Extend Wix

Your app can add functionality to almost every part of the [Wix ecosystem](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem). It can display a widget on a Wix user's site, add a page to a site's dashboard, inject custom logic into a site's backend service, and much more. Each specific type of functionality that an app can provide is called an extension. See the full list of available extensions below.

An app can contain multiple extensions that work together to expose its functionality across different user interfaces and backend services. For example, Wix's [FAQ app](https://www.wix.com/app-market/wix-faq) displays a customizable FAQ widget on a site, and also has a dashboard page where the Wix user can create and manage their FAQ categories, questions, and answers.

Most extensions are built using one of Wix's [development frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks). However, some extensions only require configuration in the [app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/app-dashboard-setup/about-the-app-dashboard) with no coding involved.

You can extend Wix's [frontend interfaces](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem#frontend-interfaces) as well as various [backend capabilities](https://dev.wix.com/docs/build-apps/get-started/overview/the-wix-ecosystem#backend-capabilities).

Frontend extensions include:

- [Site extensions](#site-extensions): Components that are added to a site.
- [Dashboard extensions](#dashboard-extensions): Components that are added to the dashboard.
- [Editor extensions](#editor-extensions): Components that are added to the editor.

Backend extensions include:

- [Service plugins](#service-plugins): Business logic that's injected into a site's backend services.
- [Schema plugins](#schema-plugins): Fields that are added to the database schemas of Wix business solutions.
- [Notifications](#notifications): Notifications sent to Wix users.
- [Automations](#automations): Triggers, actions, and pre-installed automations that automate business processes.
- [APIs](#apis): Backend methods that can be called from frontend code.
- [Events](#events): Code that runs when specific events occur on a site.

## App compatibility

App compatibility varies depending on the type of site a Wix user has. Sites built with the drag-and-drop editors, Wix Editor and Wix Studio, can use any type of app. However, sites built with Wix Vibe and Headless projects can only use apps that only have dashboard extensions.

## Extension catalog

The following tables list all available extensions:

### Frontend extensions

#### Site extensions

| Extension                                                                                                                                  | What you create                                                                                                                                    | How you build it                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| [Site page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-pages/about-site-page-extensions)         | A page that's added to a site, composed of selected widgets.                                                                                       | Configuration in the app dashboard                                                                                  |
| [Site widget](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)   | A draggable component that can be placed anywhere on a site.                                                                                       | One of the following:<ul><li>Wix Blocks</li><li>Wix CLI custom element</li><li>Self-hosted custom element</li></ul> |
| [Site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions)   | A site component that extends an app created by Wix. It can be placed inside designated areas (called slots) within the hosting app's site widget. | One of the following:<ul><li>Wix Blocks</li><li>Wix CLI custom element</li><li>Self-hosted custom element</li></ul> |
| [Embedded script](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) | A script that's injected into a site's HTML code.                                                                                                  | One of the following:<ul><li>Wix CLI</li><li>Configuration in the app dashboard</li></ul>                           |

#### Dashboard extensions

| Extension                                                                                                                                                                               | What you create                                                                                                                                                                                  | How you build it                                                                             |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------- |
| [Dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions)                                  | A page that's added to a site's dashboard.                                                                                                                                                       | One of the following:<ul><li>Wix Blocks</li><li>Wix CLI</li><li>Self-hosted iframe</li></ul> |
| [External link](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/external-links/about-external-link-extensions)                                     | A link in the dashboard's [app management page](https://support.wix.com/en/article/accessing-your-apps#accessing-your-apps-from-your-sites-dashboard-1), pointing to your external site.         | Configuration in the app dashboard                                                           |
| [Dashboard plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions)                            | A dashboard component that [extends an app created by Wix](https://github.com/wix-private/developer-docs/blob/f5343e8d561f765ffb37e0e380ff66225a0fb93c/build-apps-portal/get-started/overview/integrate-business-solutions.md#plugins*original::./integrate-business-solutions.md#plugins). It's placed inside a designated area (called a slot) in the hosting app's dashboard page. | One of the following:<ul><li>Wix CLI</li><li>Self-hosted iframe</li></ul>                    |
| [Dashboard menu plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions) | An item that's added to a menu in a dashboard page of an app created by Wix. The menu item can trigger various actions.                                                                          | One of the following:<ul><li>Wix CLI</li><li>Configuration in the app dashboard</li></ul>    |
| [Dashboard modal](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals)                                         | A modal to display in the dashboard.                                                                                                                                                             | One of the following:<ul><li>Wix CLI</li><li>Self-hosted iframe</li></ul>                    |

#### Editor extensions

| Extension                                                                                                                         | What you create                                    | How you build it   |
| --------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------- | ------------------ |
| [Editor Add-on](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/editor-extensions/about-editor-add-on-extensions) | A tool that adds functionality to the Wix editors. | Self-hosted iframe |

### Backend extensions

#### Data collections

| Extension                                                                                                                                                          | What you create                                          | How you build it                   |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------- | ---------------------------------- |
| [Data collections](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions) | CMS data collections that are automatically created when your app is installed on a site. | [Configuration in the app dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/add-a-data-collections-extension-in-the-app-dashboard) |

#### Service plugins

| Extension                                        | What you create                                                                                                                                                          | How you build it                                                                                                                                                                                                                                                                                                                                        |
| ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [eCommerce additional fees service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/additional-fees/additional-fees-service-plugin/introduction)         | Business logic for calculating additional fees for a site visitor's cart and checkout.                                                                                   | CLI or self-hosted service plugin                      |
| [eCommerce shipping rates service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/shipping-rates/shipping-rates-integration-service-plugin/introduction)          | Business logic for calculating shipping rates for a site visitor's cart and checkout.                                                                                    | CLI or self-hosted service plugin         |
| [eCommerce custom discount trigger service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/discounts/custom-discount-triggers-integration-service-plugin/introduction) | Business logic for applying discount rules to a site visitor's cart and checkout.                                                                                        | CLI or self-hosted service plugin |
| [eCommerce payment settings service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/payments/payment-settings/payment-settings-integration-service-plugin/introduction)        | Business logic to determine whether to apply 3D Secure validation during a merchant's payment process.                                                                   | CLI or self-hosted service plugin        |
| [eCommerce validations service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/validations/validations-integration-service-plugin/introduction)             | Business logic for validating a site visitor's cart and checkout.                                                                                                        | CLI or self-hosted service plugin                  |
| [eCommerce recommendations service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/other-services/recommendations/recommendations-service-plugin/introduction)         | Business logic for providing advanced recommendation algorithms, helping Wix users deliver personalized suggestions that enhance user engagement and overall experience. | Self-hosted service plugin                        |
| [eCommerce catalog service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/catalogs/catalog-service-plugin/introduction)                 | Business logic for becoming a Wix catalog provider and integrating any external repository of sellable items with the Wix eCommerce platform.                            | CLI or self-hosted service plugin                                                                                                                                                                                   |
| [eCommerce gift vouchers service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/payments/gift-cards/gift-cards-service-plugin/introduction)           | Business logic for integrating with Wix as a gift card service provider.                                                                                                 | CLI or self-hosted service plugin                    |
| [eCommerce inventory service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/catalogs/inventory-service-plugin/introduction)               | Business logic for integrating with a unified inventory system, enabling decrementing and incrementing item availability based on order flows.                           | REST: Self-hosted service plugin                                                                                                                                                                                       |
| [Stores product restrictions service plugin](https://dev.wix.com/docs/api-reference/business-solutions/stores/service-plugins/product-restrictions-v3/introduction)       | Business logic for implementing editing restrictions on product fields for 3rd-party fulfillment apps such as dropshipping and print-on-demand.                          | REST: Self-hosted service plugin                                                                                                                                                                                     |
| [Marketing keyword suggestions service plugin](https://dev.wix.com/docs/api-reference/business-management/marketing/seo/seo-keywords-suggestions-service-plugin/introduction)     | Business logic for providing Wix users with keyword suggestions through the site dashboard.                                                                              | CLI or self-hosted service plugin           |
| [App Billing custom charges service plugin](https://dev.wix.com/docs/api-reference/app-management/app-billing/custom-charges-service-plugin/introduction)        | Business logic for charging Wix users for using your app.                                                                                                                | Self-hosted service plugin                                            |
| [Form submission service plugin](https://dev.wix.com/docs/api-reference/crm/forms/service-plugins/form-submissions-service-plugin/introduction)                   | Business logic for adding additional form validations.                                                                                                                   | CLI or self-hosted service plugin                                                                                                                                                                                           |
| [Bookings pricing integration service plugin](https://dev.wix.com/docs/api-reference/business-solutions/bookings/pricing/pricing-integration-service-plugin/introduction)      | Business logic for providing custom pricing calculations for your merchant's bookings.                                                                                   | REST: Self-hosted service plugin                                                                                                                                                                                 |
| [Data external database service plugin](https://dev.wix.com/docs/api-reference/business-solutions/cms/external-databases/external-database-service-plugin/introduction)            | Business logic for providing custom pricing calculations for your merchant's bookings.                                                                                   | Self-hosted service plugin                                    |
| [Automations action provider service plugin](https://dev.wix.com/docs/api-reference/business-management/automations/actions/action-provider-service-plugin/introduction)       | Business logic for implementing custom automated actions.                                                                                                                | REST: Self-hosted service plugin                                                                                                                                                                                 |
| [Payments provider service plugin](https://dev.wix.com/docs/api-reference/business-management/payments/service-plugins/payment-service-provider-service-plugin/introduction)                 | Business logic for integrating payments with Wix.                                                                                                                        | REST: Self-hosted service plugin                                                                                                                                                                   |
| [Payments tax calculation service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/tax/tax-calculation-integration-service-plugin/introduction)          | Business logic for calculating taxes.                                                                                                                                    | CLI or self-hosted service plugin                                                                                                                                                              |
| [Payments tax groups service plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/extensions/tax/tax-groups-integration-service-plugin/introduction)               | Business logic for managing default tax groups to categorize products from your app's catalog based on distinct tax treatments.                                          | REST: Self-hosted service plugin                                                                                                                                                                    |

Learn more [about service plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions).

#### Schema plugins

| Extension                                                                                                                                                          | What you create                                          | How you build it                   |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------- | ---------------------------------- |
| [Booking schema plugin](https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-writer-v2/booking-object) | Fields that are added to the Wix Booking object.         | Configuration in the app dashboard |
| [Booking service schema plugin](https://dev.wix.com/docs/api-reference/business-solutions/bookings/services/services-v2/service-object) | Fields that are added to the Wix Booking Service object. | Configuration in the app dashboard |
| [Checkout](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/purchase-flow/checkout/checkout/checkout-object) & [Order](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/orders/orders/order-object) schema plugin | Fields that are added to the Checkout and Order objects. | Configuration in the app dashboard |
| [eCommerce catalog product schema plugin](https://dev.wix.com/docs/api-reference/business-solutions/stores/catalog-v3/products-v3/product-object) | Fields that are added to the Wix Stores Product object.  | Configuration in the app dashboard |
| [eCommerce tips settings schema plugin](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/other-services/tips/tip-settings/tip-settings-object) | Fields that are added to the Tips Settings object.       | Configuration in the app dashboard |

Learn more [about schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions).

#### Notifications

| Extension                                                                                                                                            | What you create                                                                               | How you build it                   |
| ---------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- | ---------------------------------- |
| Notification       | Notifications that Wix users receive on their site dashboard and in the Wix Owner mobile app. | Self-hosted notification logic     |
| Notification topic | Topics that you can use to group notifications when they're displayed to Wix users.           | Configuration in the app dashboard |

Learn more [about notification extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/notifications/about-notification-extensions).

#### Automations

| Extension                                                                                                                                                                   | What you create                                                                                                         | How you build it                   |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| [Trigger](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/triggers/about-triggers)                                           | An event that causes an automation to run, such as a visitor action or a Wix user action.                             | Configuration in the app dashboard |
| [Action](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/actions/about-actions)                                              | An automation's response when triggered, carrying out processes such as sending an email or updating data.              | Configuration in the app dashboard |
| [Pre-installed automation](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/pre-installed-automations/about-pre-installed-automations) | A full automation combining a trigger and 1 or more actions that's added to a user's site when they install your app. | Configuration in the app dashboard |

Learn more [about automations](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/automations/about-automations).

#### APIs

| Extension                                                                                                                                               | What you create                                                                                                 | How you build it |
| ------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- | ---------------- |
| [Web method](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions) | A method defined in your app's backend that can be called from frontend code. Wix handles the communication. | CLI          |
| [HTTP function](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints)                           | An HTTP method in your app's backend that can be called from frontend code.                                   | CLI          |

#### Events

| Extension                                                                                                                           | What you create                                                                                   | How you build it |
| ----------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- | ---------------- |
| [Event](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/events/about-event-extensions) | Code that runs when specific events occur on your app or a user's site, such as a booking confirmation. | CLI          |

## See also

- [Map your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
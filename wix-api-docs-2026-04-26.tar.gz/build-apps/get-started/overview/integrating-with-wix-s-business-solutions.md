---
portal: build-apps
name: "Integrating with Wix's Business Solutions"
type: ARTICLE_RESOURCE
resourceId: 7591ed1e-fa69-42fe-9c28-6694742e40a0
---

# Integrating with Wix's Business Solutions

# Integrating with Wix’s Business Solutions

Wix offers a range of powerful [business solutions](https://support.wix.com/en/business-solutions-apps), enabling Wix users to sell products and services, run events, write blogs, manage restaurants, and more. These business solutions are designed to integrate seamlessly with Wix websites. Users add Wix business solutions to their sites by installing [apps created by Wix](https://www.wix.com/app-market/collection/made-by-wix).

## How to integrate

Integrate your app’s functionality into one of Wix’s native business solutions to tap into Wix’s vast user base, gain exposure, and generate revenue. Whether your app fulfills orders with dropshipping, boosts a blog writer's audience, or helps a restaurant manage its staff, there's an opportunity for you to offer Wix users the extra features they need.

Your app can integrate with Wix’s business solutions in the following ways:

* **Plugins**: Inject your own functionality directly into a business solution’s user interfaces and backend capabilities.
* **APIs**: Connect your services to Wix sites by gaining access to a business solution’s data and functionality.

## Plugins

With plugins, you can inject your own functionality directly into the user interfaces and backend capabilities of Wix’s business solutions. The following image shows an example of the [Wix Reviews](https://support.wix.com/en/article/wix-stores-adding-and-setting-up-wix-reviews) site plugin, which adds a product rating component inside the Wix Stores product page:

![site-plugin](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ba3d9720e4f1147b49de6fde6780522f.png)

### Frontend plugins

Create plugins for the site and dashboard interfaces of apps created by Wix:

* [Site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions): Components that users can place inside designated areas (called slots) within the site pages of an app created by Wix, such as the Stores product and checkout pages.
* Dashboard plugins:
  * [Dashboard plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions): Components that fit into designated areas (called slots) within a dashboard page of an app created by Wix.
  * [Dashboard menu plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions): Items added to the menu in the dashboard page of an app created by Wix.

### Backend plugins

Create plugins for the backend capabilities of apps created by Wix:

* [Service plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions): Business logic that’s injected into a site’s backend services.
* [Schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions): Fields that are added to the database schema of a Wix business solution.

## APIs

Take advantage of the diverse business solutions that Wix offers to enable communication and integration between your app and Wix. Wix offers multiple [API technologies](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis), including REST, JavaScript SDK, GraphQL, and Velo with Blocks. Each API technology offers a similar set of APIs.

The main business solution APIs include:

* [Wix eCommerce](https://www.wix.com/ecommerce): Manage the cart, checkout, and order phases of an online store experience. Explore [eCommerce APIs](https://dev.wix.com/docs/rest/business-solutions/e-commerce/introduction). 
  
* [Wix Stores](https://www.wix.com/app-market/wix-stores): Handle product catalogs, inventories, and collections. Explore [Stores APIs](https://dev.wix.com/docs/rest/business-solutions/stores/about-wix-stores). 
  
* [Wix Bookings](https://www.wix.com/app-market/bookings): Accept and manage bookings for services. Explore [Bookings APIs](https://dev.wix.com/docs/rest/business-solutions/bookings/about-wix-bookings). 
  
* [Wix Pricing Plans](https://www.wix.com/app-market/paid-plans): Access and manage customized paid membership plans for content and services. Explore [Pricing Plans APIs](https://dev.wix.com/docs/rest/business-solutions/pricing-plans/pricing-plans/introduction). 
  
* [Wix Events](https://www.wix.com/app-market/web-solution/events?searchLocation=home): Create events, sell tickets, and collect RSVPs. Explore [Events APIs](https://dev.wix.com/docs/rest/business-solutions/events/introduction). 
  
* [Wix Blog](https://www.wix.com/app-market/wix-blog): Access and manage blogs, including posts, draft posts, categories, tags, and statistics. Explore [Blog APIs](https://dev.wix.com/docs/rest/business-solutions/blog/introduction). 
  
* [Wix Groups](https://www.wix.com/app-market/wix-groups): Create and manage groups for posting updates, sharing media, starting discussions, and more. Explore [Groups APIs](https://dev.wix.com/docs/rest/crm/community/groups/introduction). 
  
* [Wix Forum (deprecated)](https://support.wix.com/en/article/wix-forum-about-wix-forum): Access and manage a business's member forum, including posts and categories. Explore [Forum APIs](https://dev.wix.com/docs/rest/business-solutions/forum/introduction). 
  
* [Wix Loyalty Program](https://support.wix.com/en/article/wix-loyalty-program-an-overview): Create and manage loyalty programs to increase customer retention. Explore [Loyalty APIs](https://dev.wix.com/docs/rest/crm/loyalty-program/introduction).
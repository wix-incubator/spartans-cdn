---
portal: build-apps
name: "The Wix Ecosystem"
type: ARTICLE_RESOURCE
resourceId: 9154af0e-3f5e-4924-a766-72f03fe39233
---

# Wix Ecosystem

# The Wix Ecosystem

Before diving into the world of apps, it's important to gain a basic understanding of the way the Wix ecosystem works. Once you understand what each part of the ecosystem does, start exploring the different ways to [extend Wix with your own functionality](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).

The Wix ecosystem includes a range of tools and services that enable Wix users to build a web presence and manage their businesses online.

The following diagram shows the main parts of the Wix ecosystem:

![ecosystem](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0a2942c80a61072c38f194da442c394c.gif)

## Site creation

Wix offers multiple approaches for creating websites, each designed for different needs and technical preferences.

### Drag-and-drop editors

Wix offers the following drag-and-drop editors:

- [Wix Editor](https://support.wix.com/en/using-the-wix-editor): Wix's classic site builder.
- [Wix Studio](https://support.wix.com/en/wix-studio): An advanced web creation platform for agencies, freelancers, and enterprises.

These editors offer a visual, drag-and-drop interface with AI-powered features that let Wix users:

- Add and customize site pages, elements, widgets, and more.
- Customize site functionality with code using the [Wix JavaScript SDK](https://dev.wix.com/docs/sdk).
- Manage site content including text and media.
- Add and manage business solutions, such as Wix Stores or Wix Bookings, from a selection of apps built by Wix and 3rd-party developers.

Sites built with these editors have a Wix-powered frontend.

Here's what the Wix Editor looks like:

![wix-editor](https://wixmp-833713b177cebf373f611808.wixmp.com/images/d38aa110a815e43c93ab06ff5c0feb22.gif)

### Conversational site creation

[Wix Vibe](https://support.wix.com/en/article/wix-vibe-an-overview) is Wix's conversational website creation tool that builds sites through natural language prompts. Unlike the drag-and-drop editors above, Vibe uses a chat-based interface where Wix users describe what they want, and the AI generates site content and structure. While Vibe includes visual editing components, these aren't as fully-featured as the dedicated drag-and-drop editors.

Sites built with Vibe have a React based frontend and use the Astro framework.

<blockquote classname="important">

**Important:** Wix Vibe is currently in beta and has limited support for app extensions. Sites built with Wix Vibe support only the following extension types:

- [Dashboard extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions) are fully supported.
- [Embedded script extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts) are partially supported. Compatibility varies by use case. To check your app, [contact support](https://www.wix.com/support-chatbot?nodeId=25a57397-ccf7-4376-8b74-48d51edf7159&referral=devRels).

As Wix Vibe evolves, support for additional extension types may be added.

</blockquote>

Here's what the Wix Vibe editor looks like:

![vibe-editor](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3b41eb8d543be75280cb585e5c1315d4.jpg)

### Headless development

For developers who want complete control over their frontend experience, [Wix Headless](https://dev.wix.com/docs/go-headless) enables you to build custom websites, mobile apps, or any digital experience using your preferred technologies and frameworks, while still leveraging Wix's powerful backend infrastructure and business solutions.

## Site management

Once you create a site, Wix provides tools for ongoing management and operation.

### Site dashboard

The dashboard is a site's control center. It enables Wix users to set up, manage, and operate their sites. Whether a site was built using the drag-and-drop editors, created with Vibe, or developed as a headless project, all sites use the same unified dashboard.

In the dashboard, Wix users can:

- Configure site settings.
- Manage site content including text and media.
- Manage payments, customers, online marketing, automations, and more.
- Add and manage business solutions, such as Wix Stores or Wix Bookings, from a selection of apps built by Wix and 3rd-party developers.
- Monitor site metrics, such as SEO performance, sales reports, and site traffic.

Here's what the dashboard looks like:

![dashboard](https://wixmp-833713b177cebf373f611808.wixmp.com/images/46cca8591e446c4e032473b4c8b65301.jpeg)

## Development and integration

Wix's platform offers an extensive array of services and tools for developers to integrate with and extend the Wix ecosystem.

### Wix business solutions

At the heart of Wix's backend are its native [business solutions](https://www.wix.com/app-market/collection/wix-business-solutions), which cater to diverse industries with advanced solutions for bookings, online stores, events, payments, eCommerce, loyalty programs, and more. These business solutions are designed to integrate seamlessly with Wix websites, as well as with external clients that take advantage of Wix's [headless](https://dev.wix.com/docs/go-headless) infrastructure.

### APIs

Wix APIs give you access to Wix's services and resources, providing a gateway that enables developers to easily integrate with different areas of the Wix ecosystem. APIs include:

- **Business solutions**: Interact with Wix's business solutions, such as eCommerce, Bookings, Events, and Restaurants.
- **Payments**: Manage payments with Pricing Plans, Payments, and Billing APIs.
- **CRM and Members**: Interact with and manage site contacts and members.
- **Data**: Work with data stored in Wix-hosted and external databases.
- **Automations**: Streamline work processes and send notifications.

Wix offers multiple [API technologies](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis#api-technologies) for integrating with backend services and resources, including REST, JavaScript SDK, GraphQL, and Velo.

### CMS

Wix's Content Management System (CMS) is responsible for managing the content that Wix users add to their sites, including text, media, videos, store products, and booking services. The CMS seamlessly integrates with Wix's site-building tools, providing a user-friendly interface for creating and editing content, as well as mechanisms for easily connecting CMS data to site elements.
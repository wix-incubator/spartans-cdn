---
portal: build-apps
name: "Wix's Development Frameworks"
type: ARTICLE_RESOURCE
resourceId: bd934b90-0c8b-40bd-b7ab-3bc6323171cf
---

# Wix's Development Frameworks

<style>
.wix-button {
  background-color: rgb(17, 109, 255);
  border-radius: 18px;
  color: rgb(255, 255, 255);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Madefor, 'Helvetica Neue', Helvetica, Arial, 'メイリオ', meiryo, 'ヒラギノ角ゴ pro w3', 'hiragino kaku gothic pro', sans-serif;
  font-size: 16px;
  font-weight: 530;
  height: 36px;
  line-height: 24px;
  min-width: 84px;
  padding: 6px 24px;
  text-align: center;
  transition: background-color 0.1s linear, color 0.1s linear, border-color 0.1s linear;
  user-select: none;
}

.wix-button:hover {
  background-color: #0E61E6;
  color: rgb(255, 255, 255);
}
</style>

# Wix’s Development Frameworks

Whether you're a seasoned developer or just dipping your toes into the world of coding, Wix offers an arsenal of developer-friendly tools and technologies to drive your [app-building journey](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps#your-app-building-journey). These tools and technologies are integrated within 3 frameworks, each providing a comprehensive development model. This article guides you through the process of choosing the development framework that’s right for you.

The 3 frameworks you can use are:

* [Wix Blocks](#wix-blocks): Wix’s native app editor.
* [Wix CLI](#wix-cli): Wix’s React/Node.js stack.
* [Self-hosting](#self-hosting): Your own tech stack.

[<button class="wix-button">Start Developing
</button>](https://manage.wix.com/account/custom-apps)

## Wix Blocks

Use Wix Blocks to design, code, and deploy on Wix’s native app editor. Build site and dashboard components using Wix’s drag-and-drop editor, with its powerful layout and design tools, and code your business logic using [Velo](https://dev.wix.com/docs/develop-websites/articles/getting-started/about-developing-websites), Wix’s native coding solution. Your code is deployed and hosted on the Wix cloud, with no additional costs or setup.

[Learn more about Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks)

Here's what Wix Blocks looks like:

![blocks](https://wixmp-833713b177cebf373f611808.wixmp.com/images/154dce82699db73aa7cdbeb7be51963d.png)

## Wix CLI

Use Wix CLI to code and deploy with Wix’s React/Node.js stack. Get the standard JavaScript developer experience, code on your local machine with your preferred IDE, and collaborate with your team using git. Your code is deployed and hosted on the Wix cloud, with no additional costs or setup.

[Learn more about Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)

Here's what creating an app with Wix CLI looks like:

![cli](https://wixmp-833713b177cebf373f611808.wixmp.com/images/c883b1900a71b9492fc3576ff116fb85.gif)

## Self-hosting

You can also use your own tech stack, and handle the deployment and hosting yourself. When setting up your application in your app's dashboard, simply provide URLs to your deployment assets, such as iframes, webhooks, and JavaScript bundles.

[Learn more about self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps)

Here's an example of registering a self-hosted iframe in your app's dashboard:

![dev-center](https://wixmp-833713b177cebf373f611808.wixmp.com/images/72015d598f5a57dc87de97b71c0cd06b.png)

## Combine frameworks

A Wix app’s functionality is based on a set of [extensions](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix) that are added to a site, for example, a dashboard page, a site widget or specific backend logic. You can build each of these extensions using one or more of Wix’s development frameworks.

It’s important to understand that no matter which framework you start with, you can always continue developing your app using any of the other frameworks. Your app can contain multiple extensions, each built with a different framework. In fact, there are several use cases that require multiple frameworks in the same app. Learn more about the [frameworks you can use to build each type of extension](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#extension-catalog).

## Summary

So which framework should you choose? Basically, it’s a question of which tech stack and tools you prefer to work with. Here’s a summary of the main features of each development framework:

|  **Wix Blocks** | **Wix CLI** | **Self-hosting** |
|---|---|---|
| <ul><li>Drag-and-drop UI editor.</li><li>Native Wix coding solution in an online IDE.</li><li>No-code and low-code features.</li><li>Frontend and backend coding, databases, and deployment flows.</li><li>Hosted on the Wix cloud.</li></ul> | <ul><li>Standard TypeScript full-stack developer experience.</li><li>Your preferred local IDE.</li><li>App scaffolding, live preview, and deployment flows.</li><li>Collaboration and version control on git.</li><li>Hosted on the Wix cloud.</li></ul> | <ul><li>Your own tech stack and tools.</li><li>Limited access to Wix developer utilities.</li><li>Hosted on the platform of your choice.</li></ul> |
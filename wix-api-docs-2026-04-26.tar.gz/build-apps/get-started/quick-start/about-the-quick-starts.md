---
portal: build-apps
name: "About the Quick Starts"
type: ARTICLE_RESOURCE
resourceId: d4aeb284-d8fc-42f8-a4c2-cb206a50e833
---

# About the Quick Starts

# About the Quick Start Tutorials

Create your first app and get up and running in a few short steps.

Wix offers [3 frameworks](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) for building apps. The following tutorials walk you through the initial steps of creating a basic working app using each of these frameworks. To keep things simple, each tutorial showcases only one type of [app functionality](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).

## Choose a framework

* [Wix Blocks tutorial](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-an-app-with-wix-blocks): Design, code, and deploy a site widget using Wix’s native app editor.
* [Wix CLI tutorial](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-an-app-with-wix-cli): Code and deploy a dashboard page with Wix’s React/Node.js stack.
* [Self-hosted app tutorial](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-a-self-hosted-app): Set up a dashboard page in the App Dashboard using an externally-deployed iframe.

> **Note**: You can also start by trying out one of our many [tutorials](https://dev.wix.com/docs/build-apps/get-started/tutorials/index-of-tutorials) or [app templates](https://dev.wix.com/docs/build-apps/get-started/templates/get-started-from-an-app-template).
---
portal: build-apps
name: "Create a Self-Hosted App"
type: ARTICLE_RESOURCE
resourceId: 217d55ef-2d16-41d0-a514-8d8bcf1d7ef2
---

# Create a Self-Hosted App

# Tutorial | Create a Self-Hosted App

In this tutorial, you'll create an app with a simple [dashboard page extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions) using a [self-hosted](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps) iframe.

## Before you begin

* Make sure you're logged into your Wix account, or [create an account](https://www.wix.com/) if you don't have one yet.
* If you haven't done so yet, move to the new [Wix Studio workspace](https://manage.wix.com/account/custom-apps) by [joining Wix Studio](https://support.wix.com/en/article/wix-studio-switching-to-wix-studio).

## Step 1 | Create an app in the Custom Apps page of your Wix Studio workspace

We'll start off by creating a new app.

1. In the [Custom Apps page](https://manage.wix.com/account/custom-apps), go to **My Apps**, and then click **Create New App**.
2. Select **Build from scratch**.
3. Select **Self-Hosted**, and then click **Get Started**.

![choose-app-framework](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6f0af431cfdda5320727b1ff610a9323.png)

A new app is created in the Custom Apps page.

## Step 2 | Add a dashboard page extension

We'll now add a dashboard page extension in your app's dashboard. This extension uses an iframe to embed a web page in the dashboard. We've already deployed a web page on an external server for you to use in this tutorial. When configuring the extension, you'll register the URL of this web page.

1. In the left sidebar, under **Develop**, select **Extensions**, and then click **Create Extension**.  
   A panel opens, showing the available extension types.
2. Find the **Dashboard page** extension and click **Create**.
3. Fill in the following configuration data:
   * **Name**: `Demo page`
   * **iframe URL**: `https://www.quickstartselfhostedapp.com/`
4. Click **Save**.

![iframe-url](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e6f736983a866e4395c51c405fe9b8d9.png)

You’ve finished setting up the dashboard page extension and can now install it on a site to see it in action.

## Step 3 | Install your app on a site

Wix provides a free Premium development site so you can easily install your app and see it working. In this step, you'll create a development site, install your app on the site, and try it out.

1. In the top right corner of your [app's dashboard](https://manage.wix.com/account/custom-apps), click **Test App** and select **Test on dev site**.
1. Select an existing development site or click **+ Create Dev Site** to create a new site. Select the editor and the Wix Business Solution you want to use and click **Create Dev Site**.
1. Click **Test App**. Wix installs your app and opens the site in a new tab. You can set which site page opens in your [app settings](https://dev.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fapp-settings). If you don't set a page, the site editor opens by default.

Your app is now installed on the development site. You can see the external web page embedded in the dashboard.

![self-hosted-iframe](https://wixmp-833713b177cebf373f611808.wixmp.com/images/1a96ec729b51365240528200b56b9e17.png)

## Next steps

You now have a fully working app that can be installed on Wix sites. Take some time to play around in your app's dashboard to explore more features that you can add to your app.

Use the following resources to continue building your app:

* [Wix Design System](https://wixdesignsystem.com): Learn how to use Wix's React components for a cohesive user experience consistent with Wix's design standards.
* [Wix APIs](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/about-wix-apis): Learn how to integrate your app with Wix to transfer data between your app and the site it's installed on and extend Wix business solutions, such as Wix eCommerce or Wix Bookings.
* [Extension catalog](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#extension-catalog): Learn about other extensions you can add to your app.
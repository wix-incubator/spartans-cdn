---
portal: build-apps
name: "Create an App with the Wix CLI"
type: ARTICLE_RESOURCE
resourceId: 7ef87783-2e20-41c6-b9bf-5033520da91b
---

# Quick Start an App

# Quick Start a Wix CLI App


This guide explains the minimum steps required to get a CLI app up and running using the Wix CLI. 

## Before you begin

Before getting started, make sure that you:

+ Have [Node.js](https://nodejs.org/en/) (v20.11.0 or higher).
+ Have Git installed and [configured](https://git-scm.com/docs/git-config).
+ Are logged into your Wix account. If you don't already have one, [sign up for a Wix account](https://manage.wix.com/account/custom-apps).
  
## Step 1 | Create a new app project

1. Run the following command to create a new app project:

    ```bash
    npm create @wix/new@latest app
    ```

2. When asked what you would like to do, select **Create a new Wix App**.

3. Enter a **name for your app** and a **folder name** for your project.

    + The **app name** is the name that appears in your [app's dashboard](https://manage.wix.com/account/custom-apps).
    + The **folder name** is the name of the directory containing your project's local files.

4. Enter a **namespace** for your app.

    A namespace is a unique way to identify your app, in the format `@prefix/suffix`. Some extensions, such as [data collections](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions) and [schema plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/schema-plugins/about-schema-plugin-extensions), require a namespace. Wix suggests a namespace based on your app name. You can accept the suggestion or enter your own value. Once set, you can't change your namespace.

5. Enter a **code identifier** for your app.

    The code identifier is a unique, JavaScript-compatible name for your app and its extensions. Wix suggests a code identifier based on your namespace. You can accept the suggestion or enter your own value. Once set, you can't change your code identifier.

Once the CLI has created your app, the [app's files](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure) appear in a local directory with the folder name you chose. 

Your app appears in the [app dashboard](https://manage.wix.com/account/custom-apps) but isn't yet installed on a development site.

## Step 2 | Test the app

1. Run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command to start the local development environment.

2. Select a site to install your app on for testing: 
   + **Pick an existing site:** Designates one of your existing Wix sites.
   + **Create a new Development Site:** Builds a new Wix [development site](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli#development-sites).

3. Press `Enter` to open your browser and install the application on your test site.    

4. The CLI builds a local environment for your test site and provides a menu to view your app's dashboard pages in the browser.

The development environment is set up for hot reloading, so any changes you make to your code are immediately reflected in the browser.

## Step 3 (Optional) | Call a Wix API

In this step, we show how to call an API from your app's dashboard page, using the [List Locations](https://dev.wix.com/docs/api-reference/business-management/locations/list-locations?apiView=SDK) method as an example.

1. Configure the required permissions for List Locations. For detailed instructions, see [Configure Permissions for Your App](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/configure-permissions-for-your-app).

2. Install the `@wix/business-tools` package so you can work with the [Locations API](https://dev.wix.com/docs/api-reference/business-management/locations/introduction?apiView=SDK).

        ```bash
        npm install @wix/business-tools
        ```

3. Update the code of your dashboard page extension to display a list of all the business locations in your site:

    1. Open your dashboard extension's tsx file. The path should be `/src/extensions/dashboard/pages/my-page/my-page.tsx`.
    2. Add the following import statements to your file:

        ```js
        import { locations } from '@wix/business-tools';
        import React, { useState, useEffect } from 'react';
        ```

    3. In the `DashboardPage` component add a `locationNames` state variable and a `useEffect` hook that calls `listLocations()` and extracts the list of location names to `locationNames`. Your code should look like this:

        ```tsx
        const { listLocations } = locations;
        const [locationNames, setLocationNames] = useState('');

        useEffect(() => {
        listLocations().then(response => {
            if (response.locations) {
            const names = response.locations.map(location => location.name).join('\n');
            setLocationNames(names);
            }
        });
        }, []);
        ```

    4. In the `Page.Content` element of your component, change the `title` to `"Locations List"` and the `subtitle` to the value of `locationNames`. Your code should look like this:

        ```tsx
        <Page.Content>
        <EmptyState
            title="Locations List"
            subtitle={locationNames || "Loading locations..."}
            skin="page"
        />
        </Page.Content>
        ```

    **Full example code**

    ```tsx
    import type { FC } from 'react';
    import { useState, useEffect } from 'react';
    import { EmptyState, Page, WixDesignSystemProvider } from '@wix/design-system';
    import '@wix/design-system/styles.global.css';
    import { locations } from '@wix/business-tools';

    const DashboardPage: FC = () => {
        const { listLocations } = locations;
        const [locationNames, setLocationNames] = useState('');

        useEffect(() => {
        listLocations().then(response => {
            if (response.locations) {
            const names = response.locations.map(location => location.name).join('\n');
            setLocationNames(names);
            }
        });
        }, []);

        return (
        <WixDesignSystemProvider features={{ newColorsBranding: true }}>
            <Page>
            <Page.Header
                title="Page"
                subtitle="This is a subtitle for your page"
            />
            <Page.Content>
                <EmptyState
                title="Locations List"
                subtitle={locationNames || "Loading locations..."}
                skin="page"
                />
            </Page.Content>
            </Page>
        </WixDesignSystemProvider>
        );
    };

    export default DashboardPage;
    ```

    Your dashboard page is now set up to load and display the names of the site's locations.

    <!-- > **Note:** Some API calls may require [elevated permissions](https://dev.wix.com/docs/wix-cli/guides/development/elevate-api-call-permissions). -->

4. Test the API call:

    1. [Add a location](https://manage.wix.com/account/site-selector/?actionUrl=https%3A%2F%2Fwww.wix.com%2Fdashboard%2F%7BmetaSiteId%7D%2Fbusiness-info&title=Select+a+Site&primaryButtonText=Select+Site) to your development site if you don't have any already.

    2. Run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command to start the local development environment.

    3. Click the link to open your development site's dashboard.

    4. Navigate to your app's page in the dashboard under Apps.

        ![Select app page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/afac64c5d3d548dfa074e8946ee10e35.png)

    5. Your app's dashboard page should load and display a list of locations.

        ![Locations app page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/cfce7a4042fc69634b3362d47c262c15.png)

## Next steps

After completing the above steps, you have a simple Wix app that you can experiment with and test locally.

You can now:

+ [Add extensions to your app](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions#adding-extensions).
+ [Learn more about developing your app](https://dev.wix.com/docs/wix-cli/guides/development/development-overview).

## See also

+ [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
+ [Wix CLI Development Overview](https://dev.wix.com/docs/wix-cli/guides/development/development-overview)
+ [Project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure)
+ [CLI Command Reference](https://dev.wix.com/docs/wix-cli/command-reference/introduction)
---
portal: build-apps
name: "Get Started From an App Template"
type: ARTICLE_RESOURCE
resourceId: 85836610-f836-4576-8cb0-02ced29f3936
---

# Get Started From an App Template

<style>
.wix-button-medium {
    accent-color:auto;align-content:normal;align-items:center;align-self:auto;alignment-baseline:auto;animation-composition:replace;animation-delay:0s;animation-direction:normal;animation-duration:0s;animation-fill-mode:none;animation-iteration-count:1;animation-name:none;animation-play-state:running;animation-range-end:normal;animation-range-start:normal;animation-timeline:auto;animation-timing-function:ease;app-region:none;appearance:auto;backdrop-filter:none;backface-visibility:visible;background-attachment:scroll;background-blend-mode:normal;background-clip:border-box;background-color:rgb(17, 109, 255);background-image:none;background-origin:padding-box;background-position:0% 0%;background-repeat:repeat;background-size:auto;baseline-shift:0px;baseline-source:auto;block-size:36px;border-block-end-color:rgb(255, 255, 255);border-block-end-style:none;border-block-end-width:0px;border-block-start-color:rgb(255, 255, 255);border-block-start-style:none;border-block-start-width:0px;border-bottom-color:rgb(255, 255, 255);border-bottom-left-radius:18px;border-bottom-right-radius:18px;border-bottom-style:none;border-bottom-width:0px;border-collapse:separate;border-end-end-radius:18px;border-end-start-radius:18px;border-image-outset:0;border-image-repeat:stretch;border-image-slice:100%;border-image-source:none;border-image-width:1;border-inline-end-color:rgb(255, 255, 255);border-inline-end-style:none;border-inline-end-width:0px;border-inline-start-color:rgb(255, 255, 255);border-inline-start-style:none;border-inline-start-width:0px;border-left-color:rgb(255, 255, 255);border-left-style:none;border-left-width:0px;border-right-color:rgb(255, 255, 255);border-right-style:none;border-right-width:0px;border-start-end-radius:18px;border-start-start-radius:18px;border-top-color:rgb(255, 255, 255);border-top-left-radius:18px;border-top-right-radius:18px;border-top-style:none;border-top-width:0px;bottom:auto;box-shadow:none;box-sizing:border-box;break-after:auto;break-before:auto;break-inside:auto;buffered-rendering:auto;caption-side:top;caret-color:rgb(255, 255, 255);clear:none;clip:auto;clip-path:none;clip-rule:nonzero;color:rgb(255, 255, 255);color-interpolation:srgb;color-interpolation-filters:linearrgb;color-rendering:auto;column-count:auto;column-gap:normal;column-rule-color:rgb(255, 255, 255);column-rule-style:none;column-rule-width:0px;column-span:none;column-width:auto;contain-intrinsic-block-size:none;contain-intrinsic-height:none;contain-intrinsic-inline-size:none;contain-intrinsic-size:none;contain-intrinsic-width:none;container-name:none;container-type:normal;content:normal;cursor:pointer;cx:0px;cy:0px;d:none;direction:ltr;display:flex;dominant-baseline:auto;empty-cells:show;fill:rgb(0, 0, 0);fill-opacity:1;fill-rule:nonzero;filter:none;flex-basis:auto;flex-direction:row;flex-grow:0;flex-shrink:1;flex-wrap:nowrap;float:none;flood-color:rgb(0, 0, 0);flood-opacity:1;font-family:Madefor, 'Helvetica Neue', Helvetica, Arial, メイリオ, meiryo, 'ヒラギノ角ゴ  pro w3', 'hiragino kaku gothic pro', sans-serif;font-kerning:auto;font-optical-sizing:auto;font-palette:normal;font-size:16px;font-stretch:100%;font-style:normal;font-synthesis-small-caps:auto;font-synthesis-style:auto;font-synthesis-weight:auto;font-variant:normal;font-variant-alternates:normal;font-variant-caps:normal;font-variant-east-asian:normal;font-variant-ligatures:normal;font-variant-numeric:normal;font-variant-position:normal;font-weight:530;grid-auto-columns:auto;grid-auto-flow:row;grid-auto-rows:auto;grid-column-end:auto;grid-column-start:auto;grid-row-end:auto;grid-row-start:auto;grid-template-areas:none;grid-template-columns:none;grid-template-rows:none;height:36px;hyphenate-character:auto;hyphenate-limit-chars:auto;hyphens:manual;image-orientation:from-image;image-rendering:auto;initial-letter:normal;inline-size:180.461px;inset-block-end:auto;inset-block-start:auto;inset-inline-end:auto;inset-inline-start:auto;isolation:auto;justify-content:center;justify-items:normal;justify-self:auto;left:auto;letter-spacing:normal;lighting-color:rgb(255, 255, 255);line-break:auto;line-height:24px;list-style-image:none;list-style-position:outside;list-style-type:disc;margin-block-end:0px;margin-block-start:0px;margin-bottom:0px;margin-inline-end:0px;margin-inline-start:0px;margin-left:0px;margin-right:0px;margin-top:0px;marker-end:none;marker-mid:none;marker-start:none;mask-clip:border-box;mask-composite:add;mask-image:none;mask-mode:match-source;mask-origin:border-box;mask-position:0% 0%;mask-repeat:repeat;mask-size:auto;mask-type:luminance;math-depth:0;math-shift:normal;math-style:normal;max-block-size:none;max-height:none;max-inline-size:none;max-width:none;min-block-size:auto;min-height:auto;min-inline-size:84px;min-width:84px;mix-blend-mode:normal;object-fit:fill;object-position:50% 50%;object-view-box:none;offset-anchor:auto;offset-distance:0px;offset-path:none;offset-position:normal;offset-rotate:auto 0deg;opacity:1;order:0;orphans:2;outline-color:rgba(0, 0, 0, 0);outline-offset:-1px;outline-style:solid;outline-width:1px;overflow-anchor:auto;overflow-clip-margin:0px;overflow-wrap:normal;overflow-x:visible;overflow-y:visible;overlay:none;overscroll-behavior-block:auto;overscroll-behavior-inline:auto;padding-block-end:6px;padding-block-start:6px;padding-bottom:6px;padding-inline-end:24px;padding-inline-start:24px;padding-left:24px;padding-right:24px;padding-top:6px;paint-order:normal;perspective:none;perspective-origin:90.2266px 18px;pointer-events:auto;position:static;r:0px;resize:none;right:auto;rotate:none;row-gap:normal;ruby-position:over;rx:auto;ry:auto;scale:none;scroll-behavior:auto;scroll-margin-block-end:0px;scroll-margin-block-start:0px;scroll-margin-inline-end:0px;scroll-margin-inline-start:0px;scroll-padding-block-end:auto;scroll-padding-block-start:auto;scroll-padding-inline-end:auto;scroll-padding-inline-start:auto;scroll-timeline-axis:block;scroll-timeline-name:none;scrollbar-color:auto;scrollbar-gutter:auto;scrollbar-width:auto;shape-image-threshold:0;shape-margin:0px;shape-outside:none;shape-rendering:auto;speak:normal;stop-color:rgb(0, 0, 0);stop-opacity:1;stroke:none;stroke-dasharray:none;stroke-dashoffset:0px;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-opacity:1;stroke-width:1px;tab-size:8;table-layout:auto;text-align:center;text-align-last:auto;text-anchor:start;text-decoration:none solid rgb(255, 255, 255);text-decoration-color:rgb(255, 255, 255);text-decoration-line:none;text-decoration-skip-ink:auto;text-decoration-style:solid;text-emphasis-color:rgb(255, 255, 255);text-emphasis-position:over;text-emphasis-style:none;text-indent:0px;text-overflow:clip;text-rendering:auto;text-shadow:none;text-size-adjust:auto;text-transform:none;text-underline-position:auto;text-wrap:nowrap;timeline-scope:none;top:auto;touch-action:auto;transform:none;transform-origin:90.2305px 18px;transform-style:flat;transition-behavior:normal;transition-delay:0s;transition-duration:0.1s;transition-property:background-color, color, border-color;transition-timing-function:linear;translate:none;unicode-bidi:normal;user-select:none;vector-effect:none;vertical-align:baseline;view-timeline-axis:block;view-timeline-inset:auto;view-timeline-name:none;view-transition-name:none;visibility:visible;white-space-collapse:collapse;widows:2;will-change:auto;word-break:normal;word-spacing:0px;writing-mode:horizontal-tb;x:0px;y:0px;z-index:auto;zoom:1;-webkit-border-horizontal-spacing:0px;-webkit-border-image:none;-webkit-border-vertical-spacing:0px;-webkit-box-align:stretch;-webkit-box-decoration-break:slice;-webkit-box-direction:normal;-webkit-box-flex:0;-webkit-box-ordinal-group:1;-webkit-box-orient:horizontal;-webkit-box-pack:start;-webkit-box-reflect:none;-webkit-font-smoothing:antialiased;-webkit-line-break:auto;-webkit-line-clamp:none;-webkit-locale:'en';-webkit-mask-box-image:none;-webkit-mask-box-image-outset:0;-webkit-mask-box-image-repeat:stretch;-webkit-mask-box-image-slice:0 fill;-webkit-mask-box-image-source:none;-webkit-mask-box-image-width:auto;-webkit-print-color-adjust:economy;-webkit-rtl-ordering:logical;-webkit-tap-highlight-color:rgba(0, 0, 0, 0.18);-webkit-text-combine:none;-webkit-text-decorations-in-effect:none;-webkit-text-fill-color:rgb(255, 255, 255);-webkit-text-orientation:vertical-right;-webkit-text-security:none;-webkit-text-stroke-color:rgb(255, 255, 255);-webkit-text-stroke-width:0px;-webkit-user-drag:auto;-webkit-user-modify:read-only;-webkit-writing-mode:horizontal-tb; width: 190px;
 }

.wix-button-tiny {
      --wix-font-stack: Madefor, 'Helvetica Neue', Helvetica, Arial, '\E3\192\A1\E3\201A\A4\E3\192\AA\E3\201A\AA', 'meiryo', '\E3\192\2019\E3\192\A9\E3\201A\AE\E3\192\17D\E8\A7\2019\E3\201A\B4  pro w3', 'hiragino kaku gothic pro', sans-serif;
    --wix-font-weight-regular: 400;
    --wix-font-weight-medium: 530;
    --wix-font-weight-bold: 700;
    --wix-font-weight-xbold: 800;
    -webkit-font-smoothing: antialiased;
    --wsr-color-D10: #000624;
    --wsr-color-D20: #333853;
    --wsr-color-D30: #595D70;
    --wsr-color-D40: #868AA5;
    --wsr-color-D50: #ACAFC4;
    --wsr-color-D55: #CFD1DC;
    --wsr-color-D60: #DFE5EB;
    --wsr-color-D70: #ECEFF3;
    --wsr-color-D80: #FFFFFF;
    --wsr-color-B00: #084EBD;
    --wsr-color-B05: #0F62E6;
    --wsr-color-B10: #116DFF;
    --wsr-color-B20: #5999FF;
    --wsr-color-B30: #A8CAFF;
    --wsr-color-B40: #D6E6FE;
    --wsr-color-B50: #E7F0FF;
    --wsr-color-B60: #F4F7FF;
    --wsr-color-R00: #B81206;
    --wsr-color-R05: #D0180B;
    --wsr-color-R10: #E62214;
    --wsr-color-R20: #FF6D63;
    --wsr-color-R30: #F69891;
    --wsr-color-R40: #FBD0CD;
    --wsr-color-R50: #FDE3E1;
    --wsr-color-R60: #FDECEB;
    --wsr-color-P00: #7416A5;
    --wsr-color-P05: #8E1DD1;
    --wsr-color-P10: #9A27D5;
    --wsr-color-P20: #C161F0;
    --wsr-color-P30: #CF8CF1;
    --wsr-color-P40: #E3C3F4;
    --wsr-color-P50: #F1E0F9;
    --wsr-color-P60: #F7EDFC;
    --wsr-color-G00: #1D8649;
    --wsr-color-G05: #229954;
    --wsr-color-G10: #25A55A;
    --wsr-color-G20: #51B77B;
    --wsr-color-G30: #87CEA5;
    --wsr-color-G40: #C8E8D6;
    --wsr-color-G50: #E1F4EB;
    --wsr-color-G60: #E9F6EE;
    --wsr-color-Y00: #D59900;
    --wsr-color-Y05: #E7A600;
    --wsr-color-Y10: #FFB700;
    --wsr-color-Y20: #FFC23D;
    --wsr-color-Y30: #FFD16E;
    --wsr-color-Y40: #FFE2A5;
    --wsr-color-Y50: #FFF0D1;
    --wsr-color-Y60: #FFF6E5;
    --wsr-color-O00: #DF4D00;
    --wsr-color-O05: #F05300;
    --wsr-color-O10: #FE620F;
    --wsr-color-O20: #FF7D38;
    --wsr-color-O30: #FCBD9C;
    --wsr-color-O40: #FDDBC8;
    --wsr-color-O50: #FEE5D7;
    --wsr-color-O60: #FEEFE6;
    --wsr-color-F00: #A6D0FF;
    --wsr-color-A1: #1684EA;
    --wsr-color-A2: #17B0E2;
    --wsr-color-A3: #6544F9;
    --wsr-color-A4: #3D9FA1;
    --wsr-color-A5: #D04091;
    --wsr-color-A6: #FDB10C;
    --wsr-color-B1: #FF66C5;
    --wsr-color-B2: #FF9F41;
    --wsr-color-B3: #F9677A;
    --wsr-color-B4: #1550AC;
    --wsr-color-C1: #54CE91;
    --wsr-color-C2: #1989E5;
    --wsr-color-C3: #64B4F6;
    --wsr-color-C4: #FF9290;
    --wsr-color-D10-03: rgba(0, 6, 36, 0.03);
    --wsr-color-D10-05: rgba(0, 6, 36, 0.05);
    --wsr-color-D10-06: rgba(0, 6, 36, 0.06);
    --wsr-color-D10-10: rgba(0, 6, 36, 0.10);
    --wsr-color-D10-12: rgba(0, 6, 36, 0.12);
    --wsr-color-D10-18: rgba(0, 6, 36, 0.18);
    --wsr-color-D10-20: rgba(0, 6, 36, 0.20);
    --wsr-color-D10-24: rgba(0, 6, 36, 0.24);
    --wsr-color-D10-30: rgba(0, 6, 36, 0.30);
    --wsr-color-D10-36: rgba(0, 6, 36, 0.36);
    --wsr-color-D10-42: rgba(0, 6, 36, 0.42);
    --wsr-color-D10-66: rgba(0, 6, 36, 0.66);
    --wsr-color-D10-90: rgba(0, 6, 36, 0.90);
    --wsr-color-D10-96: rgba(0, 6, 36, 0.96);
    --wsr-color-D20-48: rgba(51, 56, 83, 0.48);
    --wsr-color-D20-54: rgba(51, 56, 83, 0.54);
    --wsr-color-D20-60: rgba(51, 56, 83, 0.60);
    --wsr-color-D20-72: rgba(51, 56, 83, 0.72);
    --wsr-color-D40-20: rgba(134, 138, 165, 0.20);
    --wsr-color-D80-10: rgba(255, 255, 255, 0.10);
    --wsr-color-D80-20: rgba(255, 255, 255, 0.20);
    --wsr-color-D80-30: rgba(255, 255, 255, 0.30);
    --wsr-color-D80-48: rgba(255, 255, 255, 0.48);
    --wsr-color-D80-50: rgba(255, 255, 255, 0.50);
    --wsr-color-D80-60: rgba(255, 255, 255, 0.60);
    --wsr-color-D80-70: rgba(255, 255, 255, 0.70);
    --wsr-color-B00-24: rgba(8, 78, 189, 0.24);
    --wsr-color-B00-42: rgba(8, 78, 189, 0.42);
    --wsr-color-B00-48: rgba(8, 78, 189, 0.48);
    --wsr-color-B10-18: rgba(17, 109, 255, 0.18);
    display: inline-flex;
    align-items: center;
    cursor: pointer;
    justify-content: center;
    box-sizing: border-box;
    text-align: center;
    outline: 1px solid;
    outline-offset: -1px;
    border: 0;
    transition-duration: 100ms;
    transition-timing-function: linear;
    transition-property: background-color,color,border-color;
    background-color: var(--wds-color-fill-standard-primary, var(--wsr-color-B10, #3899EC));
    outline-color: transparent;
    color: var(--wds-color-text-standard-primary-light, var(--wsr-color-D80, #FFFFFF));
    text-decoration: none;
    user-select: none;
    white-space: nowrap;
    height: var(--wds-button-size-tiny, 24px);
    min-width: 60px;
    font-family: var(--wds-font-family-default, var(--wsr-font-family, Madefor,"Helvetica Neue",Helvetica,Arial,"\30E1\30A4\30EA\30AA","meiryo","\30D2\30E9\30AE\30CE\89D2\30B4   pro w3","hiragino kaku gothic pro", sans-serif));
    font-size: var(--wds-font-size-body-tiny, var(--wsr-text-font-size-tiny, 12px));
    font-weight: var(--wds-font-weight-bold, var(--wsr-font-weight-bold, 700));
    letter-spacing: var(--wds-font-letter-spacing-0, unset);
    line-height: 16px;
    border-radius: var(--wds-button-border-radius-tiny, 18px);
    padding: var(--wds-button-padding-vertical-tiny, 3px) var(--wds-button-padding-horizontal-tiny, 12px);
}

.wix-text-button-tiny {
      --wix-font-stack: Madefor, 'Helvetica Neue', Helvetica, Arial, '\E3\192\A1\E3\201A\A4\E3\192\AA\E3\201A\AA', 'meiryo', '\E3\192\2019\E3\192\A9\E3\201A\AE\E3\192\17D\E8\A7\2019\E3\201A\B4  pro w3', 'hiragino kaku gothic pro', sans-serif;
    --wix-font-weight-regular: 400;
    --wix-font-weight-medium: 530;
    --wix-font-weight-bold: 700;
    --wix-font-weight-xbold: 800;
    -webkit-font-smoothing: antialiased;
    --wsr-color-D10: #000624;
    --wsr-color-D20: #333853;
    --wsr-color-D30: #595D70;
    --wsr-color-D40: #868AA5;
    --wsr-color-D50: #ACAFC4;
    --wsr-color-D55: #CFD1DC;
    --wsr-color-D60: #DFE5EB;
    --wsr-color-D70: #ECEFF3;
    --wsr-color-D80: #FFFFFF;
    --wsr-color-B00: #084EBD;
    --wsr-color-B05: #0F62E6;
    --wsr-color-B10: #116DFF;
    --wsr-color-B20: #5999FF;
    --wsr-color-B30: #A8CAFF;
    --wsr-color-B40: #D6E6FE;
    --wsr-color-B50: #E7F0FF;
    --wsr-color-B60: #F4F7FF;
    --wsr-color-R00: #B81206;
    --wsr-color-R05: #D0180B;
    --wsr-color-R10: #E62214;
    --wsr-color-R20: #FF6D63;
    --wsr-color-R30: #F69891;
    --wsr-color-R40: #FBD0CD;
    --wsr-color-R50: #FDE3E1;
    --wsr-color-R60: #FDECEB;
    --wsr-color-P00: #7416A5;
    --wsr-color-P05: #8E1DD1;
    --wsr-color-P10: #9A27D5;
    --wsr-color-P20: #C161F0;
    --wsr-color-P30: #CF8CF1;
    --wsr-color-P40: #E3C3F4;
    --wsr-color-P50: #F1E0F9;
    --wsr-color-P60: #F7EDFC;
    --wsr-color-G00: #1D8649;
    --wsr-color-G05: #229954;
    --wsr-color-G10: #25A55A;
    --wsr-color-G20: #51B77B;
    --wsr-color-G30: #87CEA5;
    --wsr-color-G40: #C8E8D6;
    --wsr-color-G50: #E1F4EB;
    --wsr-color-G60: #E9F6EE;
    --wsr-color-Y00: #D59900;
    --wsr-color-Y05: #E7A600;
    --wsr-color-Y10: #FFB700;
    --wsr-color-Y20: #FFC23D;
    --wsr-color-Y30: #FFD16E;
    --wsr-color-Y40: #FFE2A5;
    --wsr-color-Y50: #FFF0D1;
    --wsr-color-Y60: #FFF6E5;
    --wsr-color-O00: #DF4D00;
    --wsr-color-O05: #F05300;
    --wsr-color-O10: #FE620F;
    --wsr-color-O20: #FF7D38;
    --wsr-color-O30: #FCBD9C;
    --wsr-color-O40: #FDDBC8;
    --wsr-color-O50: #FEE5D7;
    --wsr-color-O60: #FEEFE6;
    --wsr-color-F00: #A6D0FF;
    --wsr-color-A1: #1684EA;
    --wsr-color-A2: #17B0E2;
    --wsr-color-A3: #6544F9;
    --wsr-color-A4: #3D9FA1;
    --wsr-color-A5: #D04091;
    --wsr-color-A6: #FDB10C;
    --wsr-color-B1: #FF66C5;
    --wsr-color-B2: #FF9F41;
    --wsr-color-B3: #F9677A;
    --wsr-color-B4: #1550AC;
    --wsr-color-C1: #54CE91;
    --wsr-color-C2: #1989E5;
    --wsr-color-C3: #64B4F6;
    --wsr-color-C4: #FF9290;
    --wsr-color-D10-03: rgba(0, 6, 36, 0.03);
    --wsr-color-D10-05: rgba(0, 6, 36, 0.05);
    --wsr-color-D10-06: rgba(0, 6, 36, 0.06);
    --wsr-color-D10-10: rgba(0, 6, 36, 0.10);
    --wsr-color-D10-12: rgba(0, 6, 36, 0.12);
    --wsr-color-D10-18: rgba(0, 6, 36, 0.18);
    --wsr-color-D10-20: rgba(0, 6, 36, 0.20);
    --wsr-color-D10-24: rgba(0, 6, 36, 0.24);
    --wsr-color-D10-30: rgba(0, 6, 36, 0.30);
    --wsr-color-D10-36: rgba(0, 6, 36, 0.36);
    --wsr-color-D10-42: rgba(0, 6, 36, 0.42);
    --wsr-color-D10-66: rgba(0, 6, 36, 0.66);
    --wsr-color-D10-90: rgba(0, 6, 36, 0.90);
    --wsr-color-D10-96: rgba(0, 6, 36, 0.96);
    --wsr-color-D20-48: rgba(51, 56, 83, 0.48);
    --wsr-color-D20-54: rgba(51, 56, 83, 0.54);
    --wsr-color-D20-60: rgba(51, 56, 83, 0.60);
    --wsr-color-D20-72: rgba(51, 56, 83, 0.72);
    --wsr-color-D40-20: rgba(134, 138, 165, 0.20);
    --wsr-color-D80-10: rgba(255, 255, 255, 0.10);
    --wsr-color-D80-20: rgba(255, 255, 255, 0.20);
    --wsr-color-D80-30: rgba(255, 255, 255, 0.30);
    --wsr-color-D80-48: rgba(255, 255, 255, 0.48);
    --wsr-color-D80-50: rgba(255, 255, 255, 0.50);
    --wsr-color-D80-60: rgba(255, 255, 255, 0.60);
    --wsr-color-D80-70: rgba(255, 255, 255, 0.70);
    --wsr-color-B00-24: rgba(8, 78, 189, 0.24);
    --wsr-color-B00-42: rgba(8, 78, 189, 0.42);
    --wsr-color-B00-48: rgba(8, 78, 189, 0.48);
    --wsr-color-B10-18: rgba(17, 109, 255, 0.18);
    display: inline-flex;
    align-items: center;
    cursor: pointer;
    color: var(--wds-color-fill-standard-primary, var(--wsr-color-B10, #3899EC));
    white-space: nowrap;
    background-color: transparent;
    border-color: transparent;
    text-decoration: none;
    border: 0;
    border-radius: 2px;
    transition-duration: 100ms;
    transition-timing-function: linear;
    transition-property: background-color,color,border-color;
    outline: 0;
    padding: 0;
    user-select: none;
    font-family: var(--wds-font-family-default, var(--wsr-font-family, Madefor,"Helvetica Neue",Helvetica,Arial,"\30E1\30A4\30EA\30AA","meiryo","\30D2\30E9\30AE\30CE\89D2\30B4   pro w3","hiragino kaku gothic pro", sans-serif));
    font-size: var(--wds-font-size-body-tiny, var(--wsr-text-font-size-tiny, 12px));
    font-weight: var(--wds-font-weight-regular, var(--wsr-font-weight-regular, 400));
    line-height: var(--wds-font-line-height-body-tiny, var(--wsr-text-line-height-tiny, 15px));
    letter-spacing: var(--wds-font-letter-spacing-0, unset);
    height: 18px;
}

.wix-button-medium:hover {
  background-color: rgb(15, 98, 230);
}

.wix-button-tiny:hover {
  background-color: rgb(15, 98, 230);
}

.wix-text-button-tiny:hover {
  color: rgb(89, 153, 255);
}

 </style>

# Get Started From an App Template

Want to build an app that enhances the functionality of Wix sites? Jumpstart your development with one of our app templates and fast-track your way to a fully functioning app.

## Why start with a template?

Each of our templates provides a working foundational app that you're free to modify and build upon. By deploying a template as your starting point, you can quickly move from a concept to a fully functional app, saving valuable time and effort.

Dive into our template collection and discover the possibilities for app creation.

[<button class="wix-button-medium" style="margin-bottom: 32px">Explore Templates
</button>](http://dev.wix.com/apps-templates)

![Template page screenshot](https://wixmp-833713b177cebf373f611808.wixmp.com/images/about-app-templates-md_build-apps-portal_get-started_assets_custom-shipping-rates-template-page.png)

## Select the right template for your app

Wix offers templates specifically designed for each of the following development frameworks:

- Wix Blocks
- Wix CLI
- Self-hosted apps integrated with the App Dashboard

Choose a template that matches your preferred framework to commence your project with ease.

<div style="display: flex; flex-direction:row; flex-wrap: wrap">
    <div style=" width: 250px; min-width: 250px; height: 200px; border-style: solid; border-width: 1px; border-radius: 5px; padding-top: 20px; padding-bottom: 20px; padding-left: 16px; padding-right: 16px; margin-right: 8px; margin-bottom: 12px; border-color: #DFE5EB; display: flex; flex-direction: column;">
        <div style=" display: flex; margin-bottom: 4px; font-weight: 700; font-size: 16px; line-height: 24px;">Wix Blocks Templates</div>
        <div style=" display: flex; margin-bottom: 4px; text-wrap: wrap; width:100%; font-weight: 400; font-size: 14px; line-height: 21px;">Build a native-style Wix app in a responsive drag-and-drop editor and incorporate sophisticated functionality with Velo.</div>
        <div style=" display: flex; font-weight: 400; font-size: 14px; line-height: 24px; margin-top:auto; align-items:center">
          <div style="padding: 5px">
            <a href="fallback::https://dev.wix.com/apps-templates?filter=blocks"><button class="wix-button-tiny" style="font-size: 12px">See Templates</button></a>
         </div>
         <div style="padding: 5px">
           <a href="fallback::https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks"><button class="wix-text-button-tiny" style="font-size: 12px">Learn More</button></a>
          </div>
        </div>
    </div>
     <div style=" width: 250px; min-width: 250px; height: 200px;   border-style: solid; border-width: 1px; border-radius: 5px;padding-top: 20px; padding-bottom: 20px; padding-left: 16px; padding-right: 16px; margin-right: 8px; margin-bottom: 12px; border-color: #DFE5EB; display: flex; flex-direction: column;">
        <div style=" display: flex; margin-bottom: 4px; font-weight: 700; font-size: 16px; line-height: 24px;">Wix CLI Templates</div>
        <div style=" display: flex; margin-bottom: 4px; text-wrap: wrap; width:100%; font-weight: 400; font-size: 14px; line-height: 21px;">Get a comprehensive developer experience with minimal setup, so you can focus on coding your app.
        </div>
        <div style=" display: flex; font-weight: 400; font-size: 14px; line-height: 24px; margin-top:auto; align-items:center">
          <div style="padding: 5px">
            <a href="fallback::https://dev.wix.com/apps-templates?filter=cli"><button class="wix-button-tiny" style="font-size: 12px">See Templates</button></a>
         </div>
         <div style="padding: 5px">
           <a href="fallback::https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps"><button class="wix-text-button-tiny">Learn More</button></a>
          </div>
        </div>
    </div>
    <div style=" width: 250px; min-width: 250px; height: 200px; border-style: solid; border-width: 1px; border-radius: 5px;padding-top: 20px; padding-bottom: 20px; padding-left: 16px; padding-right: 16px; margin-right: 0; margin-bottom: 12px; border-color: #DFE5EB; display: flex; flex-direction: column;">
        <div style=" display: flex; margin-bottom: 4px; font-weight: 700; font-size: 16px; line-height: 24px;">Self-Hosted App Templates</div>
        <div style=" display: flex; margin-bottom: 4px; text-wrap: wrap; width:100%; font-weight: 400; font-size: 14px; line-height: 21px;">Develop and host an app on any platform, and integrate with Wix using the app dashboard.</div>
        <div style=" display: flex; font-weight: 400; font-size: 14px; line-height: 24px; margin-top:auto; align-items:center">
          <div style="padding: 5px">
            <a href="fallback::https://dev.wix.com/apps-templates?filter=self-hosted"><button class="wix-button-tiny" style="font-size: 12px">See Templates</button></a>
         </div>
         <div style="padding: 5px">
           <a href="fallback::https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/about-self-hosting-for-wix-apps" style="font-size: 12px"><button class="wix-text-button-tiny" style="font-size: 12px">Learn More</button></a>
          </div>
        </div>
    </div>
</div>

[See all our templates <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
<path fill="currentColor" d="M11,6 L11,7 L7,7 C6.44771525,7 6,7.44771525 6,8 L6,17 C6,17.5522847 6.44771525,18 7,18 L16,18 C16.5522847,18 17,17.5522847 17,17 L17,13 L18,13 L18,17 C18,18.1045695 17.1045695,19 16,19 L7,19 C5.8954305,19 5,18.1045695 5,17 L5,8 C5,6.8954305 5.8954305,6 7,6 L11,6 Z M18,6 L18,10 L17,10 L17,7.75 L11.9040467,12.8434838 C11.69694,13.0505906 11.3611535,13.0505906 11.1540467,12.8434838 C10.94694,12.636377 10.94694,12.3005906 11.1540467,12.0934838 L16.25,7 L14,7 L14,6 L18,6 Z"/>
</svg>](http://dev.wix.com/apps-templates)

## Template features

The Wix app templates showcase a variety of features that apps can add to Wix sites, such as:

- Pages or widgets on a live Wix site.
- Dashboard pages or components for site admins.
- Integration with 3rd-party services.
- Site analytics through embedded scripts.

## Developer tools

Each template uses a different set of Wix developer tools, including:

- [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) and [Velo](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-the-widget-code): Combine UI design in the Wix editor with coding for advanced features, offering a comprehensive app-building experience.
- [Wix Design System](https://dev.wix.com/docs/build-apps/develop-your-app/wix-design-system/about-the-wix-design-system): Utilize Wix's collection of reusable React components to craft a visually stunning and user-friendly app interface.
- [Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps): Accelerate app development and deployment with a tool that simplifies initial setup and hosting.
- [REST APIs](https://dev.wix.com/docs/rest) and [JavaScript SDK](https://dev.wix.com/docs/sdk): Access and manage site data effectively from your app, enabling sophisticated site interactions.
- [Webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks): Implement real-time responses to Wix Logs.
- [Embedded scripts](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts): Integrate custom analytics and additional functionalities seamlessly.
- [App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/dev-center-setup/about-the-wix-dev-center): Access essential resources for app configuration, permission management, and Wix integration.
---
portal: build-apps
name: "Developing Common Apps"
type: ARTICLE_RESOURCE
resourceId: 1bec812c-b79e-4cc5-b970-df9ecf91ec3e
---

# Developing Common Apps

# Developing Apps for Common Use Cases

While the Wix dev platform allows you to create various types of apps, you may choose to develop an app that meets a common need, such as fulfillment or invoicing. Below is a list of app types for common use cases. For each use case, we list key REST APIs and webhooks you might use to implement their basic functionality as well as the permissions required for these APIs and webhooks.  

This reference is intended as a helpful starting point, but keep in mind that your specific app may require additional resources. Note that the following are [REST resources](https://dev.wix.com/docs/rest). 

## Fulfillment

Integrates with fulfillment services (storage and shipping).

**APIs**
  - **App Instance:**
    - [App Instance Installed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed)
    - [Instance App Removed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-removed)
  - **Wix Stores (Catalog V1):**
    - [Create Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/create-product)
    - [Add Products To Collection](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/add-products-to-collection)
    - [Query Collections](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/query-collections)
    - [Update Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/update-product)
  - **Wix Stores (Catalog V3):**
    - [Create Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/create-product)
    - [Bulk Add Products To Categories By Filter](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/bulk-add-products-to-categories-by-filter)
    - [Query Categories](https://dev.wix.com/docs/rest/business-management/categories/query-categories)
    - [Update Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/update-product)
  - **Wix eCommerce:**
    - [Get Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/get-order)
    - [Create Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/order-fulfillments/create-fulfillment)

**Webhooks**
  - **Wix Stores (Catalog V1):**
    - [Product Created](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-created)
    - [Product Changed](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-changed)
    - [Product Deleted](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-deleted)
    - [Variants Changed](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/variants-changed)
  - **Wix Stores (Catalog V3):** 
    - [Product Created](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/product-created)
    - [Product Updated](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/product-updated)
    - [Product Deleted](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/product-deleted)
  - **Wix eCommerce:**
    - [Order Approved](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-approved)
    - [Order with Fulfillments Updated](https://dev.wix.com/docs/rest/business-solutions/e-commerce/order-fulfillments/order-with-fulfillments-updated)

**Permissions**
  - Manage Orders (SCOPE.DC-STORES.MANAGE-ORDERS)
  - Manage Products (SCOPE.DC-STORES.MANAGE-PRODUCTS)


## Invoicing

Automatically creates and sends invoices to customers.

**APIs**
  - **App Instance:**
    - [App Instance Installed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed)
    - [Instance App Removed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-removed)
  - **Wix eCommerce:**
    - [Get Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/get-order)
  - **Wix Bookings:**
    - [Query Bookings](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-reader-v2/query-extended-bookings)
    - [Query Extended Bookings](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-reader-v2/query-extended-bookings)

**Webhooks**
  - **Wix eCommerce:**
    - [Order Approved](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-approved)
  - **Wix Bookings:**
    - [Booking Notification](https://dev.wix.com/docs/rest/business-solutions/bookings/bookings/bookings-writer-v2/introduction)
  - **Wix Payments:**
    - [Payment Event](https://dev.wix.com/docs/rest/business-management/payments/cashier/cashier-pay/payment-event/payment-event)

**Permissions**
  - Read Orders (SCOPE.DC-STORES.READ-ORDERS)
  - Read Bookings - Including Participants (SCOPE.DC-BOOKINGS.READ-BOOKINGS-SENSITIVE)
  - Read Payments (SCOPE.DC-CASHIER.READ-PAYMENTS)


## Dropshipping

Integrates with product sourcing and fulfillment services (products, storage, and shipping), enabling site owners to sell products without maintaining inventory.

**APIs**
  - **App Instance:**
    - [App Instance Installed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-installed)
    - [Instance App Removed](https://dev.wix.com/docs/rest/app-management/app-instance/app-instance-removed)
  - **Wix Stores (Catalog V1):**
    - [Create Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/create-product)
    - [Add Products To Collection](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/add-products-to-collection)
    - [Query Collections](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/query-collections)
    - [Update Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/update-product)
  - **Wix Stores (Catalog V3):**
    - [Create Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/create-product)
    - [Bulk Add Products To Categories By Filter](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/bulk-add-products-to-categories-by-filter)
    - [Query Categories](https://dev.wix.com/docs/rest/business-management/categories/query-categories)
    - [Update Product](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/update-product)
  - **Wix eCommerce:**
    - [Get Order](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/get-order)
    - [Create Fulfillment](https://dev.wix.com/docs/rest/business-solutions/e-commerce/order-fulfillments/create-fulfillment)

**Webhooks**
  - **Wix Stores (Catalog V1):**
    - [Product Created](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-created)
    - [Product Changed](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-changed)
    - [Product Deleted](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/product-deleted)
    - [Variants Changed](https://dev.wix.com/docs/rest/business-solutions/stores/catalog/variants-changed)
  - **Wix Stores (Catalog V3):** 
    - [Product Created](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/product-created)
    - [Product Updated](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/product-updated)
    - [Product Deleted](https://dev.wix.com/docs/rest/business-solutions/stores/catalog-v3/products-v3/product-deleted)
  - **Wix eCommerce:**
    - [Order Approved](https://dev.wix.com/docs/rest/business-solutions/e-commerce/orders/order-approved)
    - [Order with Fulfillments Updated](https://dev.wix.com/docs/rest/business-solutions/e-commerce/order-fulfillments/order-with-fulfillments-updated)
    
**Permissions**
  - Manage Orders (SCOPE.DC-STORES.MANAGE-ORDERS)
  - Manage Products (SCOPE.DC-STORES.MANAGE-PRODUCTS)


## Considerations when developing your app

When developing your app, make sure to:

+ Include the App Instance ID in API calls to [identify app users](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/identify-and-manage-app-users).
+ [Set up your app pricing](https://dev.wix.com/docs/build-apps/launch-your-app/pricing-and-billing/about-pricing-plans-and-business-models).
+ Read through our [guidelines](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/app-market-guidelines) and our [Partner Agreement](https://dev.wix.com/docs/build-apps/launch-your-app/legal-and-security/wix-app-market-partner-agreement).
+ Review our [App Checks and Testing Guide](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/app-checks-and-testing-guide) and [test your app](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/test-your-app-on-a-premium-site) thoroughly.

When you're ready, [submit your app](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/submit-your-first-app-version) for review. 


## Additional resources

If you’re new to building Wix apps, check out the following resources: 

+ Learn [how your app extends Wix](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix).
+ [Get started creating your app](https://dev.wix.com/docs/build-apps/get-started/quick-start/about-the-quick-starts). 
+ Want to jumpstart your development? [Learn about our app templates](https://dev.wix.com/docs/build-apps/get-started/templates/get-started-from-an-app-template).
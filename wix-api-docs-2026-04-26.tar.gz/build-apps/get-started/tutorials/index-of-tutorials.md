---
portal: build-apps
name: "Index of Tutorials"
type: ARTICLE_RESOURCE
resourceId: 3fdc5789-eda9-4378-bba4-f32c43c08dea
---

# Index of Tutorials

# Index of Tutorials

This page contains a list of tutorials for building Wix apps. The tutorials are categorized by [development framework](https://dev.wix.com/docs/build-apps/get-started/overview/wix-s-development-frameworks) (Wix CLI, Wix Blocks, or self-hosted). Each tutorial includes tags that highlight the covered business solutions, interfaces, extensions, development tools, and APIs.

You can use this index to see at-a-glance information for each tutorial, such as the interfaces and extensions covered in the tutorial.

- [CLI app tutorials](#cli-app-tutorials)
- [Blocks app tutorials](#blocks-app-tutorials)
- [Self-hosted app tutorials](#self-hosted-app-tutorials)


<!-- Template to add tutorial to list:
### [](https://github.com/wix-private/developer-docs/blob/484a9fe920e3503fe8f1354f70113c4a27a27e29/build-apps-portal/get-started/resources)
- Wix business solutions: 
- Interfaces: 
- Extensions:
- Design Library:
- Has app template: 
- APIs:  
-->

## CLI app tutorials

### [Quick Start | Create an App with Wix CLI](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-an-app-with-wix-cli)
- Interfaces: Dashboard
- Extensions: Dashboard page

### [Set Up an App with the CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-set-up-an-app-with-the-cli)
- Wix business solutions: Wix Stores
- Interfaces: Dashboard, Backend
- Extensions: Dashboard page
- Design Library: Wix Design System
- APIs: SDK

### [Build a Locations App Using the Wix CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-a-locations-app-with-the-cli)
- Interfaces: Dashboard
- Extensions: Dashboard page
- Design Library: Wix Design System
- APIs: SDK

### [Create a Custom Products Catalog App with the CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-custom-products-catalog-app-with-the-cli)
- Wix business solutions: Wix Stores
- Interfaces: Dashboard
- Extensions: Dashboard page
- Design Library: Wix Design System
- APIs: SDK

### [Creating a “Top Blog Posts” Dashboard Page Using the Wix CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-top-blog-posts-dashboard-page-with-the-cli)
- Wix business solutions: Wix Blog
- Interfaces: Dashboard
- Extensions: Dashboard page
- Design Library: Wix Design System
- APIs: SDK

### [Adjust a CLI app to different pricing plans](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-adjust-a-cli-app-to-different-pricing-plans)
- Interfaces: Dashboard
- Extensions: Dashboard page
- Design Library: Wix Design System
- APIs: App Management SDK

### [Create a Site Plugin for the Wix Stores Product Page with the CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-site-plugin-for-the-wix-stores-product-page-with-the-cli)
- Wix business solutions: Wix Stores
- Interfaces: Site
- Extensions: Site plugin
- APIs: SDK

## Blocks app tutorials

### [Quick Start | Create an App in Wix Blocks](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-an-app-with-wix-blocks)
- Interfaces: Site
- Extensions: Site widget
- APIs: Velo

### [Create a Counter Widget Using Wix Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-counter-widget-with-blocks)
- Interfaces: Site
- Extensions: Site widget
- APIs: Velo

### [Create a Countdown App Using Wix Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-countdown-widget-with-blocks)
- Interfaces: Site
- Extensions: Site widget
- APIs: Velo

### [Create a Recipes App Using Wix Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-the-recipes-app-with-blocks)
- Interfaces: Site, Dashboard
- Extensions: Site widget, Dashboard page
- APIs: Velo

### [Create a Site Plugin for the Wix Stores Product Page](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-site-plugin-for-the-wix-stores-product-page)
- Wix business solutions: Wix Stores
- Interfaces: Site
- Extensions: Site plugin
- APIs: Velo

### [Create a Site Plugin for the Wix Bookings Service Page](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-site-plugin-for-the-wix-bookings-service-page)
- Wix business solutions: Wix Bookings
- Interfaces: Site
- Extensions: Site plugin
- APIs: Velo

### [Tutorial | Build an eCommerce Business Solution](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/overview)
- Wix business solutions: Wix eCommerce
- APIs: Velo, SDK
- Additional frameworks: Self-hosted

## Self-hosted app tutorials

### [Quick Start | Create a Self-hosted App](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-a-self-hosted-app)
- Interfaces: Dashboard
- Extensions: Dashboard page

### [Set Up an App with the App Dashboard](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-set-up-an-app-with-the-app-dashboard)
- Interfaces: Dashboard, Backend
- APIs: REST

### [Create a Self-hosted Custom Shipping Rates App](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-a-self-hosted-custom-shipping-rates-app)
- Wix business solutions: Wix eCommerce
- Design Library: Wix Design System
- APIs: REST, SDK
- Has app [template](https://dev.wix.com/apps-templates/template?id=0580022b-625e-4467-9f78-28cc3e618483)

### [Tutorial | Build an eCommerce Business Solution](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/overview)
- Wix business solutions: Wix eCommerce
- APIs: Velo, SDK
- Additional frameworks: Blocks

### [Tutorial | Create an Editor Add-on that Imports Icons from a Library](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-create-an-editor-add-on-that-imports-icons-from-a-library)
- Interfaces: Editor
- Extensions: Editor Add-on
- Design Library: Wix Design System
- APIs: SDK
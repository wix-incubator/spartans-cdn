---
portal: build-apps
name: "Overview"
type: ARTICLE_RESOURCE
resourceId: 5854e873-3f4b-4dce-8f30-665e89c08a90
---

# Overview

# Tutorial | Build an eCommerce Business Solution

> [Next >](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-1-create-a-custom-wix-app)

As a Wix app developer, you can build a full-scale solution for a business, similar to Wix business solutions such as Bookings or Restaurants. If your business solution requires eCommerce capabilities, you can integrate it with the [Wix eCommerce platform](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/overview/what-is-the-wix-e-commerce-platform). This lets you take advantage of Wix’s built-in eCommerce infrastructure, instead of spending the time and effort to create eCommerce functionality yourself.

This series of articles walks you through how to build an example business solution that integrates with Wix eCommerce. Though the example is simple, you can use the tools and structure shown throughout the tutorial to build more complex solutions for any kind of business.

As part of the tutorial, we’ll build an app for selling poems. This is a multistep process that involves the following major parts:

- [Step 1 | Create a Custom Wix app](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-1-create-a-custom-wix-app)

- [Step 2 | Create a Catalog Database in Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-2-create-a-catalog-database-in-blocks)

- [Step 3 | Create an Item Page in Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-3-create-an-item-page-in-blocks)

- [Step 4 | Create a Dashboard Page to Manage the Catalog](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-4-create-a-dashboard-page-to-manage-the-catalog)

- [Step 5 | Implement a Self-hosted Catalog Service Plugin](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-5-implement-a-self-hosted-catalog-service-plugin)

- [Step 6 | Test your Business Solution on a Site](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-6-test-your-business-solution-on-a-site)

Each article in the series covers a separate step. If you complete the full tutorial, you’ll have a simple business solution that implements a catalog and provides frontend functionality to both Wix users and their customers. You can use this basic app as a starting point for developing your own business solution.

## Before you begin

Before getting started, make sure that:

- You install [Node.js](https://nodejs.org/en/download/) (v20.11.0 or higher).

- You install [npm](https://www.npmjs.com/package/npm) or [yarn](https://www.npmjs.com/package/yarn).

- You’re logged into your Wix Studio account. If you don’t already have one, [sign up for a Wix Studio account](https://users.wix.com/signin?loginDialogContext=signup&referralInfo=HEADER&postLogin=https:%2F%2Fdev.wix.com%2Fdc3%2Fmy-apps&postSignUp=https:%2F%2Fdev.wix.com%2Fdc3%2Fmy-apps&forceRender=true).

**Next up:** [Step 1 | Create a Custom Wix app](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-1-create-a-custom-wix-app)
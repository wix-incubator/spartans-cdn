---
portal: build-apps
name: "Step 1 | Create a Custom Wix app"
type: ARTICLE_RESOURCE
resourceId: a328b4c1-3d68-47e4-82a6-9582877c556a
---

# Step 1 | Create a Custom Wix app

# Step 1 | Create a Custom Wix app

> [< Previous](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/overview) | [Next >](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-2-create-a-catalog-database-in-blocks)

The first thing we’ll do is create an app in the [Custom Apps](https://manage.wix.com/studio/custom-apps?referralInfo=sidebar\&shownApps=%5B%7B%22id%22%3A%22activeApps%22%2C%22name%22%3A%22All+apps%22%7D%5D\&sort=last-update+desc\&selectedColumns=name%2Capp-status%2Clatest-version%2Clast-update%2Cinstallations%2Crating%2Cdate-created+false%2Ccreated-by+false) page. The app dashboard acts as a control center for the various pieces we'll add to our app–it allows us to manage extensions, permissions, installation settings, and more. We’ll touch on a lot of this later in the tutorial. For now, we only need to do 2 things in our app dashboard:

1. Locate the app ID, public key, and app secret. These will become important a bit later when we write our server code.

    On the [home](https://dev.wix.com/app-selector?title=Select+an+App\&primaryButtonText=Select+Site\&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fhome) page of the app dashboard, in the top right corner click the **More Actions** ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3218766a5a62430e8c3f588740912244.png) button and choose **View ID & keys**.

    ![More Actions > View ID & keys](https://wixmp-833713b177cebf373f611808.wixmp.com/images/54ac97247ae485f9bd71689b397f8599.png)

    This opens a modal called **App ID & keys** that contains your app secret key, app ID, public key, and namespace. You don’t need to do anything with these values just yet, but remember this location for later.
1. Set up our app to automatically install Wix eCommerce. In order for our business solution to take advantage of eCommerce services like cart and checkout, Wix eCommerce must be installed on a Wix user’s site. Setting up automatic installation of Wix eCommerce ensures our app will function correctly without the Wix user having to take extra action. [Follow these instructions](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/get-started/apps/build-a-business-solution#step-1--set-up-automatic-installation-of-the-ecommerce-app) to configure your app to automatically install Wix eCommerce.

Now that we’re familiar with our app dashboard, let’s start building our app. In the next couple of article, we’ll be working in [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks).

**Next up:** [Step 2 | Create a Catalog Database in Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-2-create-a-catalog-database-in-blocks)
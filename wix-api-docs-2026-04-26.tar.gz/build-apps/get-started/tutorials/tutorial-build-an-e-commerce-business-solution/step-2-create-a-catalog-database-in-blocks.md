---
portal: build-apps
name: "Step 2 | Create a Catalog Database in Blocks"
type: ARTICLE_RESOURCE
resourceId: b8bd0351-c7e2-42fb-bbba-05647181cce3
---

# Step 2 | Create a Catalog Database in Blocks

# Step 2 | Create a Catalog Database in Blocks

> [< Previous](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-1-create-a-custom-wix-app) | [Next >](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-3-create-an-item-page-in-blocks)

In order to integrate with the Wix eCommerce platform, your business solution must provide a catalog of items for sale. In general, the catalog database can be hosted and managed wherever you prefer. In our example app, each site’s catalog database will live on the site itself.

A catalog database allows users to store information about the products they want to sell, and is central to any eCommerce app. For our example business solution, we’ll create a catalog of poems as a [Wix data collection](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/cms-collections-in-blocks/about-cms-collections-in-blocks). When Wix users install our app, a copy of the collection is installed on their site. Wix users can then customize this collection to meet their site’s needs.

To create a collection in Blocks, we first need to connect our app to Blocks. We can do this by creating a Blocks widget from the app dashboard.

1. To add a widget, return to your app dashboard and go to [extensions](https://dev.wix.com/app-selector?title=Select+an+App\&primaryButtonText=Select+Site\&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fextensions). Click on **+ Create Extension**.

    ![Extensions tab](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e5a2ddbd1159437acbe37eb20201438c.png)

1. In the modal that opens, search for “widget” and find the Blocks widget extension. Click **+ Create on Blocks**. This opens a new tab in the Blocks editor.

    ![Create widget on Blocks](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0dd966b4f6c5709eb5fc742676bf69db.png)

    > **Note:** If a window pops up prompting you to choose a template, you can close it.

    In the lefthand column of the Blocks editor, you should now see something that looks like this:

    ![App interface widget 1](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a95521c738c611a739aea85ef05217b1.png)

    We’ll rename and design our widget in the next step, but let’s first add the product catalog.
1. In the menu on the left, click **CMS** ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7d52559575b9bcc189382600fa9d53d1.png).

    ![Click CMS](https://wixmp-833713b177cebf373f611808.wixmp.com/images/2b05a0b3f1cdaaebc19a87ec9db8811e.png)

1. Under **Your Collections**, click **Create Collection**. A modal opens prompting you to name your app. Click **Save & Continue** to save your app name.

    ![Create your first collection](https://wixmp-833713b177cebf373f611808.wixmp.com/images/717e3838b7ce0cbd207f403849a14c6a.png)

1. Next, Blocks prompts you to create an app namespace. Wix uses this namespace to identify your apps and create the collection ID. Click **Next** to continue. A new modal that looks like this appears:

    ![Create app namespace modal](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f75336716f97cc7c14a9a962ee2c1195.png)

    The usual format of the namespace is @`accountName`/`appName`. We recommend accepting the default format. Click **Next** to continue.
1. Once you’ve set up your app name and namespace, a **Create a collection** modal appears offering you several options on how to set up your initial collection. Select the **Start from scratch** option and click **Next**.

    ![Create a collection modal](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f1b47a1b8ea9f84203eec469215e2e6f.png)

1. Name your collection **Poems** and click **Create**. Blocks opens the CMS, where you can start editing the collection structure.
1. Click **+ Add Field** to add columns to the collection. Add the following columns to the collection:

    | **Field name**  | **Field type**   |
    | --------------- | ---------------- |
    | Title           | text             |
    | Price           | text             |
    | Description     | text             |
    | Main Product ID | text             |
    | Variants        | Javascript array |

    Wix generates the field ID automatically when you name the field. Accept the default IDs.

    > **Note:** Once you save the field, you can’t change the field ID.
1. Now let’s add some sample data to get us started. Add the following items to the collection:

    |                 |           |                                                     |                     |                                                                                                                                                             |
    | --------------- | --------- | --------------------------------------------------- | ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
    | **Title**       | **Price** | **Description**                                     | **Main Product ID** | **Variants**                                                                                                                                                |
    | Birthday Poem   | 3         | Write a poem for someone’s birthday                 | 00003               | [  {    "label": "For partner",    "value": "v01"  },  {    "label": "For child",    "value": "v02"  },  {    "label": "For friend",    "value": "v03"  }] |
    | Wedding Poem    | 2         | Congratulate the bride or groom with a wedding poem | 00002               | [  {    "label": "For bride",    "value": "v01"  },  {    "label": "For groom",    "value": "v02"  }]                                                      |
    | Graduation Poem | 1         | Celebrate a new graduate with a graduation poem     | 00001               | [  {    "label": "For child",    "value": "v01"  },  {    "label": "For other relative",    "value": "v02"  }]                                             |

    When a Wix user installs the app, they’ll receive these default values in their Poems collection.

This completes our catalog database setup. In the next article, we’ll connect our widget to the collection to allow site visitors to view the available poems.

**Next up:** [Step 3 | Create an Item Page in Blocks](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-3-create-an-item-page-in-blocks)
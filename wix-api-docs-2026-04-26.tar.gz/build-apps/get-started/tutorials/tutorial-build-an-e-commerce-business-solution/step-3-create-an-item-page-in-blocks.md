---
portal: build-apps
name: "Step 3 | Create an Item Page in Blocks"
type: ARTICLE_RESOURCE
resourceId: 3602a40e-2bad-4f65-8cdb-3ffcdb780b7c
---

# Step 3 | Create an Item Page in Blocks

# Step 3 | Create an Item Page in Blocks

> [< Previous](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-2-create-a-catalog-database-in-blocks) | [Next >](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-4-create-a-dashboard-page-to-manage-the-catalog)

An item page is part of the app’s frontend interface that customers interact with. It allows customers to select the items they want and directs them to the cart and checkout pages.

You must create at least one [item page](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/get-started/apps/develop-a-business-solution-item-page-with-blocks) for your app that implements eCommerce functionality.

In this example, our item page will take the form of a widget that we can add to a site page. The widget will allow a customer to select a poem type from the site catalog, choose a variant of the poem, and set the poem length. We’ll edit the widget we created in the previous step to build a simple interface that provides this functionality.

1. Go to the **App Interface** page of the Blocks editor. In the column on the left side of the editor, click the **More Actions** ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7860e419024a15bd57bf0e117b2894a3.png) button and rename your widget to “Item selector”.

    ![Rename widget](https://wixmp-833713b177cebf373f611808.wixmp.com/images/be7c7ca5b2f2d25c75ab259c6e13ef47.png)

1. Add the following elements to the widget and set their element IDs according to this table:

    |                 |                  |
    | --------------- | ---------------- |
    | First dropdown  | #selectPoemType  |
    | Second dropdown | #selectVariant   |
    | Text input      | #numLines        |
    | Button          | #addToCartButton |

    You can change the element ID by selecting the element and then going to the **Properties & Events** panel.

    ![Change the element IDs in the Properties & Events panel](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e68a0f840fb2c345ea196f1833d1a44d.gif)

1. Select each element and click **Settings** to adjust the field title or displayed text. Your widget should look like this when you’re done:

    ![Completed item page widget](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0304d2bded037c089976077927346369.png)

1. Now we need to add functionality to the widget. First, we want the top dropdown element (`#selectPoemType`) to display the titles of the poems in our collection. We can do this easily with a [dataset](https://dev.wix.com/docs/velo/api-reference/$w/dataset/introduction).

    Start by selecting the dropdown. In the action bar, click the **Connect to CMS** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/02/27/0529fe32-8e09-4f9b-be94-38010664296d/82eea2f5-fe57-423a-a0e3-78bfc698c647.png) icon. Because we haven’t created a dataset yet, Blocks prompts us to create one in the menu on the right:

    ![Add your first dataset](https://wixmp-833713b177cebf373f611808.wixmp.com/images/047eb6779fbc9e436646989e7a7be327.png)

    Click **+ Add a Dataset** and select the Poems collection. Accept the default dataset name and click **Create**. The menu on the right displays 2 options for how the dropdown will be used; select the **Filter content** option.

    ![Select Filter content option](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ce158b98fd140c1980242d67fb7e6bdd.png)

    Under **Connections** > **Filter content by**, select the **Title** field from the dropdown menu. Leave the condition as **Is**. The `#selectPoemType` dropdown is now connected to the **Title** field in the dataset collection, and will display all available poem titles when opened. You can preview this behavior by clicking **Preview** in the top right corner of the editor.
1. We want the second dropdown (`#selectVariant`) to display the possible variants of the selected poem type. This means that the options in the second dropdown depend on the value of the first. This behavior is too complicated for a dataset, so we’ll create it in the widget code.

    Open the code panel at the bottom of the editor. Delete the default code and start by adding the following:

    ```js
    import wixData from 'wix-data';
    import {currentCart} from 'wix-ecom-backend';
    import wixEcomFrontend from "wix-ecom-frontend";

    $w.onReady(function () {
      $w('#selectVariant').hide();
      $w('#numLines').hide();
      $w('#addToCartButton').hide();
    });
    ```

    Here’s a quick explanation of the code we just added:

    **Lines 1-3**: Import several modules that we need to make our widget functional. The most important to us right now is the `wixData` module, as we’ll use this to retrieve the correct options for the second dropdown.

    **Lines 5-9**: In the widget’s `onReady()` function, hide all elements except for the first dropdown. Once the customer selects a poem type, we’ll display the remaining elements.

    Whenever a user makes a selection in the `#selectPoemType` dropdown, we want to update the second dropdown to display the variants for that poem type. To set this behavior, we use the [onChange()](https://dev.wix.com/docs/velo/api-reference/$w/dropdown/on-change) event handler as shown below:

    ```js
    $w('#selectPoemType').onChange(async (event) => {
    try {
        const result = await wixData
        .query("<COLLECTION ID>")
        .eq("title", event.target.value)
        .find();

        const item = await result.items[0];

        $w('#selectVariant').options = item.variants;
        $w('#selectVariant').show();
        $w('#numLines').show();
        $w('#addToCartButton').show();
      } catch(error) {
        console.log(error);
      }
    })
    ```

    Let’s break down this code:

    **Lines 3-8**. Query the collection for the new value of the first dropdown, and store the result. This requires the collection ID, which you can find by opening the CMS and going to the collection settings.

    **Line 10**. Set the dropdown [options](https://dev.wix.com/docs/velo/api-reference/$w/dropdown/options) for the second dropdown to the variants that correspond to the selected poem title. This is made easy by the fact that we created the **Variants** field in the collection as a Javascript array in the format necessary for dropdown elements.

    **Lines 11-13**. Display the remaining elements.

    The widget now displays the poem options stored in the collection to customers. Click **Preview** in the top right corner of the editor to test out this behavior and make sure everything works as expected.
1. Once the user has selected the poem they want, they should be able to add it to their cart and navigate to the cart page. To set this behavior in our widget, we’ll make use of the 2 eCommerce modules we imported at the top of our code.

    The first thing we do is create a function `addToCurrentCart()` which wraps the actual Wix eCom function. Beneath our `onChange()` logic, add the following function:

    ```js
    async function addToCurrentCart(lineItems) {
        return await currentCart.addToCurrentCart(lineItems);
    }
    ```

    Inside the function, we call the [addToCurrentCart()](https://dev.wix.com/docs/sdk/backend-modules/ecom/current-cart/add-to-current-cart) eCom method and pass it an object called `lineItems`. This object contains a catalog reference and quantity for each item that the customer has requested.

    We want to call `addToCurrentCart()` when a customer clicks the **Add to cart** button. Beneath the function we just wrote, add an `onClick()` handler like this:

    ```js
    $w('#addToCartButton').onClick(async (event) => {
      try {
        const result = await wixData
          .query("<COLLECTION ID>")
          .eq("title", $w('#selectPoemType').value)
          .find();

        const item = result.items[0];
        const itemId = item.mainProductId;
        const variantId = $w('#selectVariant').value;

        await addToCurrentCart({
          lineItems: [{
            catalogReference: {
              appId: "<YOUR APP ID>",
              catalogItemId: itemId,
              options: {
                audience: variantId
              }
            },
            quantity: parseInt($w('#numLines').value)
          }]
        })
        await wixEcomFrontend.refreshCart();
        wixEcomFrontend.navigateToCartPage();
      } catch(error) {
        console.log(error);
      }
    })
    ```

    Let’s break down the code in the `onClick()` to understand it:

    **Lines 3-6**. Query the collection for the value of `#selectPoemType` again. The purpose of this query is to get the ID of the selected poem.

    **Lines 8-9**. Store the result of the query in `item` and parse it for the poem’s product ID, which we store in `itemId`.

    **Line 10**. Get the selected variant from the second dropdown `#selectVariant`.

    **Lines 12-23**. Call `addToCurrentCart()` and pass it an object in the correct format. The nested `catalogReference` object requires our app ID and the product ID of the poem.

    Recall that we can find the app ID in the [home page](https://dev.wix.com/app-selector?title=Select+an+App\&primaryButtonText=Select+Site\&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fhome) of our app dashboard. For the poem’s ID, we pass the `itemId` variable.

    We also pass an options object to define the variants. In our solution, variants are defined by whoever is receiving the poem, so we define a single attribute `audience` and give it the value we took from the `#selectVariant` dropdown.

    Finally, we take the number of lines requested by the customer and pass that as the quantity.

    **Lines 24-25**. Call the frontend Wix eCommerce method [`refreshCart()`](https://dev.wix.com/docs/sdk/frontend-modules/ecom/open-side-cart) to update the cart with the latest product. Then call [`navigateToCartPage()`](https://dev.wix.com/docs/sdk/frontend-modules/ecom/navigate-to-cart-page) to send the customer to the cart page, where they’ll see a summary of their order.

    > **Note:** You can’t preview the Wix eCommerce methods in the Blocks editor. To test the behavior of eCom methods, install your app on a test site.

This completes the design and code for the item page widget. In the next article, we’ll create the dashboard for the Wix user.

**Next up:** [Step 4 | Create a Dashboard Page to Manage the Catalog](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-4-create-a-dashboard-page-to-manage-the-catalog)
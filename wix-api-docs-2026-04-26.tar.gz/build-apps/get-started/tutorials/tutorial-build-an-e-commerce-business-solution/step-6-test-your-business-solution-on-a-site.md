---
portal: build-apps
name: "Step 6 | Test your Business Solution on a Site"
type: ARTICLE_RESOURCE
resourceId: de50828f-c202-4903-9e1a-21318cc28d63
---

# Step 6 | Test your Business Solution on a Site

# Step 6 | Test your Business Solution on a Site

> [< Previous](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/step-5-implement-a-self-hosted-catalog-service-plugin)

In this article, we'll test the [poem-selling app](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-an-e-commerce-business-solution/overview) that we spent the past 5 articles building.

In order to test the app, first make sure your server code is deployed and the server is live. Then, we need to build the app in Blocks:

1. If you haven’t already, [create a Wix site](http://wixstudio.new).
1. In the top right corner of the Blocks editor, click **Release**, then click **Release** again in the modal that opens.

    ![Release a build](https://wixmp-833713b177cebf373f611808.wixmp.com/images/91bae0a34a0b4d377ce424ea514c9e98.png)

1. Wait for your build to complete. A notification will appear on screen when the build is complete. Click **Select a Site** to open the site selector.

    ![Select a site to install your app on](https://wixmp-833713b177cebf373f611808.wixmp.com/images/da184bd4e431b16e25ce92c441c20b4c.png)

1. Select the site you want to test on. This opens the site editor. When the site loads, click **Install App**.

    ![Install the app on the site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/19c7264ff7d32bcc47424a0bf620b90c.png)

    Wait while Wix adds the app to your site.
1. Once the app is installed, the site editor will display the **App Widgets** section of **Add Elements**. Select the **Item selector** widget we created in Blocks and add it to the site page.
1. Let’s check that all the components we added in Blocks are here. In the left menu, go to **CMS** ![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7d52559575b9bcc189382600fa9d53d1.png) > **Your Collections**. You’ll see the **Poems** collection we created in Blocks. If you open the collection, you’ll see that the items we created in Blocks still appear in the collection. This means that users who install your widget have default values that they can leave or edit.
1. Now let’s look at the dashboard. Close the CMS and in the top left corner open the menu and click **Dashboard**.

    ![Go to the site dashboard](https://wixmp-833713b177cebf373f611808.wixmp.com/images/dc128b4f4ccbb6e0476558980fc77105.png)

1. In the dashboard menu, hover over **Apps**. You’ll see one of the dashboard pages we created, **Poems Manager**. Note that the **Add a poem** dashboard page doesn’t appear here, because we hid it.

    ![Locate the Poems Manager dashboard page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ed8d8697f8ca1e9f392a5ff140754493.png)

    Click **Poems Manager** to go to the dashboard page. Because our collection contains items, it displays the list of poems:

    ![Current Poems Manager dashboard page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b93590b12260458f2d381abea9d64214.png)

1. Let’s remove the current poems so that we can make sure our app recognizes the empty state. Click the icon button to remove each repeater item. We now see the empty state that we created:

    ![Display the empty state](https://wixmp-833713b177cebf373f611808.wixmp.com/images/4af98c1eae591982b4915f13dfdc50af.png)

1. Next let’s add some poems to make sure the data functionality is working. Try clicking the **+ Add Poem** button inside the card.

    When we click the button, the site navigates us to the **Add a poem** dashboard page.

    ![Add a Poem dashboard page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5d807d20fa3d3051984683d132deb902.png)

    Click **Cancel** and make sure the site navigates you back to **Poems Manager** in its empty state. Then, you can try out the **Add a poem** button in the top right corner to return to **Add a poem**.

    Enter some poem details and add and remove variants. When you’re done, click **Save**. The **Poems Manager** should now be in the nonempty state and display the poem you added:

    ![Poems Manager updated with new poem](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3f4c452c89aa0814a086153888a4f364.png)

    Add a couple more poems and then return to the site editor and open the CMS. Make sure the poems you entered all appear in the CMS.
1. Now let’s test the item page. Exit out of the CMS and in the top right corner of the site editor click **Publish**. The site notifies you when publishing is complete. Click on **View Site** next to the URL to open the live site.

    ![Publish and view your test site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/943b8c864cc823f6364c721c430d1467.png)

1. Go to the site page where you added your widget and test the widget out to make sure it works properly. You should initially see just the first dropdown which displays the different poem titles in your **Poems** collection. Once you make a selection, the other 2 elements should appear:

    ![App widget in action](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3c774a12f5985ac84d6d4605e5ee7eaa.gif)

1. Now we’ll test the call to the server. When we click Add to cart, Wix calls the Get Catalog Items method that we set up in our server code, because we’re updating the current cart.

    Click **Add to cart**. If we’ve done everything correctly, you should see the cart page with the poem we added, it’s price updated to reflect the requested number of lines:

    ![Cart page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/5af191946eb293fc7f3f5362368e8bdb.png)

1. Test out the cart page by adjusting the number of lines, and make sure that the order price updates.

Congratulations! You’ve built a business solution and successfully integrated it with Wix eCommerce.

You can continue building your own business solution based on this example, or apply what you learned in this tutorial to an entirely new app.

## See also

- [What is the Wix eCommerce Platform](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/overview/what-is-the-wix-e-commerce-platform)
- [Wix App Developers: Build a New eCommerce Business Solution](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/get-started/apps/build-a-business-solution)
- [Develop a Business Solution Item Page with Blocks](https://dev.wix.com/docs/rest/business-solutions/e-commerce/wix-e-commerce-platform-handbook/get-started/apps/develop-a-business-solution-item-page-with-blocks)
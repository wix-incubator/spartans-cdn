---
portal: build-apps
name: "Tutorial | Create a Countdown Widget with Blocks"
type: ARTICLE_RESOURCE
resourceId: f250207a-ac1e-44e8-a6ee-2a94ed34fbc6
---

# Creating a Countdown Widget

# Tutorial | Create a Countdown App Using Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

This tutorial shows you how to build a countdown widget, which counts down to a specific date. It also contains a registration widget where site visitors can register and receive an email notification the day before your event. You will also learn how to install your countdown widget on a site and explore all the key features of Blocks.

 ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/f5b73e4f-7108-4d53-8479-051585eff68c/09cc3e81-decc-478d-b736-4abb6bfb810e.gif) 

## What you get in the template

To make things easier, we've created a template so that you can get started right away.

The [template](https://blocks.wix.com/wix-blocks-new-app-creator?editorType=RESPONSIVE&originTemplateId=67720f0c-6b4b-426f-aca4-918556dd36ab&http_referrer=documentation) contains:

*   A countdown widget. You need to complete its design and code its functions and properties.
*   A registration widget which you need to complete and add to your countdown widget.
*   Some public utilities that you can use to implement your widget's functionality.
*   Some backend code that you can use to implement the functions of your email notification.

Get the [template](https://blocks.wix.com/wix-blocks-new-app-creator?editorType=RESPONSIVE&originTemplateId=67720f0c-6b4b-426f-aca4-918556dd36ab&http_referrer=documentation)

## Step 1 | Complete the Design of Your Widget

To build this widget, start with this [template](https://blocks.wix.com/wix-blocks-new-app-creator?editorType=RESPONSIVE&originTemplateId=67720f0c-6b4b-426f-aca4-918556dd36ab&http_referrer=documentation) and edit it under your Wix account. The template has been left incomplete so that you can learn how to add elements to your widget.

The widget is designed with a grid so that you can easily align and place elements.

1.  Open the template. 
2.  Click **Countdown** under **App Interface**. 
3.  Click **Add Elements**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/7e9d6f8b-35db-4cf1-a7fe-4ddb986eb57c/5bd7d8c7-bb8f-4a6b-b34e-8d80bf5ff1c5.jpg)  in the top bar.
4.  Select **Text**. Drag and drop a **48px Title** box into your widget.
5.  Click **Edit Text** and change the text to **SS**.
6.  Change the text color to white and center the text using the **Inspector**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/7de6d233-3a18-4ea8-98ee-55f8ee0446c0/a15b0baf-86f5-4566-a434-726efc4cb811.png) . 
7.  Select the text box and move it into the grid square above the SECONDS label using  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/134e6519-2581-42bf-98b4-cca8a97083c5/ddfb2d91-34e7-4c1b-ad36-c01f94a2433a.png) .
8.  Resize it using  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/41b174db-5c43-45ad-b010-7b179e22723e/c0616cbf-d732-4d3d-a616-ec14a65c2195.png) .

Learn more about [designing your widget](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Getting%20Started/A%20Blocks%20App%20Workflow.md*original::../Blocks:%20Getting%20Started/A%20Blocks%20App%20Workflow.md)

* * *

<details>
<summary>See how it looks (editing text)</summary>

![edit text elements](https://wixmp-833713b177cebf373f611808.wixmp.com/images/415498097c77349bb6e15cfceebc459f.png)

</details>

<details>
<summary>See how it looks (adjusting the layout)</summary>

![seconds text box](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/27484c1a-1034-4d66-832c-4c854d09fb37/5a431e1c-7ea7-418c-adbd-fcb786dbac75.png)

</details>

* * *

## Step 2 | Add and Define Your Widget's API Properties

You can [define an API for your widget](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Tutorials/Creating%20a%20Countdown%20Widget.md*original::../Blocks:%20Tutorials/Creating%20a%20Countdown%20Widget.md), so that the site builder who installs the widget can interact with it through code. The API can contain properties, events and exported functions.

This widget uses two properties:

*   **endDate**: Defines the end date when the countdown reaches zero. Using this property, site builders can change the end date so that the widget is customized for their site.
*   **emailId**: Determines the email message that will be sent to users when they sign up for a notification.

Learn more about [widget API properties](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/blocks-widget-properties)

### Give your widget elements an ID

First you need to give your widget's elements an ID so that you can easily refer to them in the code.

1.  Click on the text box.
2.  Give the text box an ID in the **Properties & Events** ![properties icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/25/c7256f96-e80b-4fa6-8998-db91d11f98e3/e404b243-c33a-4d17-8c87-b0f2dd651945.jpg) panel. In this example, the ID is `secondsTxt`. Note that the other elements have already been given IDs.

### Define the "endDate" and "emailId" properties

1.  Click the **Widget Public API** button.
2.  Click **Add New Property** in the **Properties** section.
3.  Enter the property name, `endDate`.
4.  Select the property type. In this case, **Date and Time** (the date is displayed in US format mm/dd/yyyy).
5.  Select a default value (the site builder will be able to change this when they install your widget in the editors).
6.  Hover over **Properties** and click the ![add icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/06/10/be929c05-3c41-452d-ae3a-1503546f8883/b6abb229-8c19-4d2b-9522-d42d125dcc76.png) icon that appears.
7.  Create another property for the triggered email and call it `emailId`. This is a **Text** type property with no default value.

* * *

## Step 3 | Add Code to Make Your Widget Work

To make your widget count down, you need to create a function in the code that calculates the remaining time until the end date. To do this, your template comes with some pre-installed utilities that you can find in the **Public & Backend**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/04/d47aba86-0d01-4d2a-bdf2-b04985946a9a/9ced50f0-4a85-4e63-98fc-4f3e8762ee8c.jpg)  menu. 

Blocks uses a new global variable, **$widget** and the property, **$widget.props**, that holds all the properties that you have defined for your widget.

Blocks also uses Velo autocomplete, so that you can write code more easily.

Learn more about the [widget API](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Tutorials/Creating%20a%20Countdown%20Widget.md*original::../Blocks:%20Tutorials/Creating%20a%20Countdown%20Widget.md)

### Change the code to consider your new function

1.  Click on the **Code**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/04/d47aba86-0d01-4d2a-bdf2-b04985946a9a/9ced50f0-4a85-4e63-98fc-4f3e8762ee8c.jpg)  menu.
2.  In the code panel for **Countdown** create a function, `updateTime()`, so that your countdown widget will update the count. Your new function should look like this:

```javascript
$widget.onPropsChanged(function () {
});
    function updateTime() {
    const {days, hours, minutes, seconds} = getRemainingTime (new Date($widget.props.endDate));
    $w('#daysTxt').text = days.toString();
    $w('#hoursTxt').text = hours.toString();
    $w('#minutesTxt').text = minutes.toString();
    $w('#secondsTxt').text = seconds.toString();
 }
```

You also need to set an interval for how often the widget updates the remaining time.  
To do this, add the following code **in** your `onReady()` function. This updates the widget every second.

```javascript
$w.onReady(function () {
    updateTime();
    if (wixWindow.viewMode !== "Editor") {
        setInterval(updateTime, 1000);
    }
});
```

<blockquote class="tip">

**Edit time condition** 
Velo code only runs when you click preview or when you open the live site. The Blocks **onReady** code runs also during editing time, so that you can see it in action while working in the editor. We use the above condition so that your countdown widget doesn't count down during editing time.

</blockquote>

### Preview your widget and test its API properties

You are ready to preview your widget and its API properties.

1.  Click **Preview**. Your widget should countdown every second to the end date.
2.  Click **Test API Properties**. A panel appears with the default value you set earlier. 
3.  Change the date to check if the widget responds and counts down to the new date.

<details>
<summary>See how it looks</summary>

![test api properties](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/12/0b5c4b84-eba0-4976-9c25-1f34e89e27ce/fee00975-4b7c-4364-85aa-2da9d3c05907.gif)

</details>

* * *

## Step 4 | Create and Code a Custom Panel

You can create a custom settings panel so that site builders can change the settings of your widget when they install it on a site. In this example, the custom settings panel allows the site builder to change the end date and define an email ID that determines which email will be sent to users when they register to receive notifications.

Learn more about [panels](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Configuration%20and%20Panels/About%20Panels.md*original::../Blocks:%20Configuration%20and%20Panels/About%20Panels.md)

### Create a custom panel

1.  Click on the **Custom Panels** tab in the **Editor Experience** menu.
2.  Click **Create Panel**.
3.  Name your panel. In this example, use "My settings".
4.  Click **Create Panel**.
5.  Click **\+ Add Element**.
6.  Select **Text Input**. This will be for the end date.
7.  Click **Properties & Events** ![propeties icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/25/c7256f96-e80b-4fa6-8998-db91d11f98e3/e404b243-c33a-4d17-8c87-b0f2dd651945.jpg) . Give your text input an ID - `endDateInput`.
8.  Select the text element and click **Settings**.
9.  Add the name "End Date" in the **Field Title** field.
10.  Delete the text in the **Default Text** field.
11.  Set the placeholder text to "End Date".
12.  Add a text divider.
13.  Click **Settings**. Add a title in the **Section Title** field. In this example, use "Triggered email".
14.  Add another **Text Input**. Give your text input an ID - `emailIdInput`.
15.  Select the text element and click **Settings**.
16.  Add the name "Email ID" in the **Field Title** field.
17.  Delete the text in the **Default Text** field.
18.  Set the placeholder text to "Email ID".

The design of your custom panel is complete. Now you need to implement it by adding code.

<details>
<summary>See how it looks</summary>

![settings custom panel](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/30/faa8fae4-9464-4528-892c-b364138b91f2/6559df8f-007e-4ae8-87cb-245dc91a1263.png)

</details>

### Add code to your custom panel

You want your custom panel to display the current end date and email ID when it loads. The site builder uses the panel to change these values. You need to add code to the panel so that when these inputs change, it updates your widget.

Learn more about [adding code to your custom panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks).

To enable panel elements to interact with your widget and perform actions in the editor, you can use the Velo `wix-widget` module in your code.

To use the Widget API, import `wixWidget` from the `wix-widget` module.

Insert the following code **before** your `onReady()` function.

```javascript
import wixWidget from 'wix-widget';
```

You want your widget to update when the values change, so you need to register an `onChange` event. You also need to add `async` to your `onReady()` function as you will be using some asynchronous functions.

Your `onReady()` function should look like this:

```javascript
$w.onReady(async function () {
    const { endDate, emailId } = await wixWidget.getProps();
    $w('#endDateInput').value = endDate;
    $w('#emailIdInput').value = emailId;

    $w('#endDateInput').onChange(e => {
        wixWidget.setProps({ endDate: e.target.value });
    });

    $w('#emailIdInput').onChange(e => {
        wixWidget.setProps({ emailId: e.target.value });
    });
});
```

Click  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/31/c441d6e2-852d-4b01-819e-e5f16a84f5dd/9e2696fd-f012-4e2d-bbbd-7d8f0de70c45.png)  **Run** or **Preview** to check your code

<details>
<summary>See how it looks</summary>

![settings panel code preview](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/30/5c89b383-ae8e-4401-a5a7-7d8700913388/4474db44-3092-4c89-bb5c-775cb69755d1.gif)

</details>

* * *

## Step 5 | Configure Your Widget

Now that your panel is designed and coded, you need to configure your widget so that your panel connects to one of your widget's action bar buttons.

The **Configuration** tab within the **Editor Experience Panel**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/89cc2cba-4f66-4813-85bd-4d9904cae791/055c9aa5-3dc2-44f6-b0ed-425fb3fee6f2.png)  enables you to control how your widget behaves when a site builder installs and customizes it on a site. You can give your widget and its elements display names, so that it is clear to site builders what your widget does. You can also make changes to the floating action bars that appear in the editors when site builders select elements in your widget.

Learn more about [configuration](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Configuration%20and%20Panels/About%20Configuration.md*original::../Blocks:%20Configuration%20and%20Panels/About%20Configuration.md).

### Add your custom panel to your widget's floating action bar

1.  Click the Editor Experience Panel icon  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/89cc2cba-4f66-4813-85bd-4d9904cae791/055c9aa5-3dc2-44f6-b0ed-425fb3fee6f2.png) .
2.  Select **Configuration**. 
3.  Select your countdown widget. A floating action bar appears.
4.  Click **Settings**.
5.  Click  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/04/520f26e0-3449-4409-bc59-acb658f7555e/0f09fa28-68e4-4aec-84e4-effb07a8cd90.png)  **Action Button Settings**. The **Main Action Settings** panel appears.
6.  Select **My settings** from the dropdown list to select your custom panel.

<details>
<summary>See how it looks</summary>

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/12/7b909ba7-417e-45dc-8450-521a9ea3a64f/0bc3fc45-d3fb-4a86-991c-676a2be8a5e0.png)

</details>

* * *

## Step 6 | Add a Second (Inner) Widget and Implement the Registration Logic

The template comes with a second widget called **Registration.** You can find it under **App Interface**. 

When you click **Layers** you can see that it has been created as a multi-state box with three states. It has a button labeled **Register**, which changes to **Submit** when the site visitor clicks it. It also has a field box where site visitors can add their email address. A thank-you message appears when a site visitor has registered.

This widget also comes with a design preset which can be used for mobile view.

Learn more about [design presets](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Design%20widgets%20and%20apps/About%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/About%20Design%20Presets.md)

### Add your registration widget to the countdown widget

You're now ready to add your registration widget to your first widget, the countdown widget. In Blocks, you can create lots of different widgets and add them to other widgets. 

Learn more about working with [widgets within widgets](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Widgets%20Within%20Widgets.md*original::../Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Widgets%20Within%20Widgets.md)

1.  Working in the **Design** tab, select your countdown widget.
2.  Click **More Options** ![more options](https://d2eyqiy4n03ve6.cloudfront.net/12345678-1234-1234-1234-1234567890ab/2015/08/03/ea5aa155-aa5e-4ef1-8bea-69375765e8c4.png) and select **Add Widget**.
3.  Select **Registration**. Your inner widget appears in the middle of your countdown widget.
4.  Drag and stretch your inner widget to fit the lower section of your countdown widget.
5.  Change its ID to `registration` in **Properties & Events** ![propeties icon](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/25/c7256f96-e80b-4fa6-8998-db91d11f98e3/e404b243-c33a-4d17-8c87-b0f2dd651945.jpg).

<blockquote class="tip">

**Another way to add a widget** 
You can also add an inner widget by clicking the  ![add button](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/08/65319986-7b71-49dc-9c0a-973c4ae3536c/e7978e5c-5c79-487b-8b3e-d78b9947ac57.jpg) **Add** **Elements** menu. Select **MY WIDGETS** and drag and drop the widget you want to add into the first widget.

</blockquote>

<details>
<summary>See how it looks</summary>

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/e61248c6-db97-44c7-8bb8-914d5e4fc62f/48eac3d1-b58e-4b4d-bac5-57f9208549a5.png)

</details>

<details>
<summary>See how it looks</summary>

![drag and stretch inner widget](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/12/4bfd8693-c902-465a-ac43-ef2b3435839e/5540e47b-9396-45e7-8211-640aa2ef05d5.gif)

</details>

### Implement the registration logic in the main widget's code

You'll implement the code for user registration in the main widget (Countdown), using functions that are defined in the `contactUtils.js` and `collectionUtils.js` files. 

The `onSubmit()` function creates or updates a contact using the `wix-crm` API via the `createContact` utility, then stores the subscription data in your app's collection. The function receives the user's email address from the registration form and updates the collection. 

1.  Create a new async function.
2.  Call it `onSubmit`. It uses the create contact utility from `contactUtils.js` and the collection name helper from `collectionUtils.js`.

Your code should look like this:

```javascript
 async function onSubmit({ email }) {
   const contact = await createContact(email);
   wixData.insert(getSubscriptionsCollectionName(), {
       endDate: new Date($widget.props.endDate),
       emailId: $widget.props.emailId,
       contactId: contact.contactId
   });
 }

```

### Register for the onSubmit event

In your `onReady()`, after your `updateTime()` function, add the following code:

```javascript
$w('#registration').onSubmit(onSubmit);
```

<blockquote class="tip">

**Backend code is already included** 
The backend code is already implemented in your template in Blocks. It includes an export function, **notify()**, which uses the pre-installed utilities. It checks the remaining time, triggers the email when ready and updates the collection. You need to invoke this in the editor, as explained below in Step 10.

</blockquote>

* * *

## Step 7 | Release Your App and Give it a Namespace

Now you are ready to release your app for the first time. Your first release will be a major version. Later, when you are working on your app, you can choose a minor or major version. A minor version is updated automatically on all the sites where it appears. You just need to refresh the page. In a major version, the site builder needs to update your app manually. An indication appears next to the name of the app in the **Installed Apps** panel in the Editor. 

Learn more about [versions in Blocks](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Deploying%20and%20managing%20apps/Managing%20App%20Versions.md*original::../Blocks:%20Deploying%20and%20managing%20apps/Managing%20App%20Versions.md)

When you click build for the first time, Blocks prompts you to give your app a namespace. This namespace is used to refer to your collection in Velo code in the editors and in the app’s code in Blocks.

Learn more about the [app namespace](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Tutorials/The%20Recipes%20App.md*original::../Blocks:%20Tutorials/The%20Recipes%20App.md)

### Your first release

1.  Click **Release**.
2.  Enter a namespace for your app and click **Next**.
3.  Select **Major Version** and click **Release**.
4.  You get a message that Version 1.0 is built. Click **Got it** to continue working on your app.

## Step 8 | Add a Collection to Your Widget

Now you need to create a collection to store all of the subscriptions. Collections in Blocks are empty placeholders that you design in Blocks, which will be filled with data once the app is installed on a site. Learn more about [collections in Blocks](https://github.com/wix-private/developer-docs/blob/dcf339af2dbfed869603daa77805d7bbdabf5d6b/build-apps-portal/develop-your-app/frameworks/blocks/Blocks%3A%20Collections%20in%20Blocks/Creating%20and%20Managing%20Collections.md*original::../Blocks:%20Collections%20in%20Blocks/Creating%20and%20Managing%20Collections.md)

The template has a pre-installed utility called `getSubscriptionsCollectionName()`, in **collectionUtils.js** under **Public & Backend**. It constructs the full name of the collection so that you don't have to add your full app namespace every time you refer to it in the code.

### Configure your collection utility

To configure your collection utility:

1.  Click **collectionUtils.js** under **Public & Backend**.
2.  Add your app's namespace. Your code should look like this, with your own namespace:

    ```javascript
    const NAMESPACE = '@mywixaccount/my-app-namespace';

    export function getSubscriptionsCollectionName() {
        return `${NAMESPACE}/subscriptions`;
    }
    ```

### Create your collection

To create your collection:

1.  Click **CMS**.
2.  Click **+ Create collection**.
3.  Give your collection a meaningful name. In this example, use **Subscriptions**.
4.  Click **Create**. 

### Add fields to your collection

1.  Click **Add Item** to add a field to your collection.
2.  Enter **Title**, for example **Subscription**.
3.  Click **Add Field**.
4.  Select **Date**, click **Choose Field Type**.
5.  Enter **endDate** in the **Field Name** field. This will be the last date up until which people can register.
6.  Click **Save**.
7.  Now click **Add Field** and create a **Text** type field and call it **emailId** for the triggered email.
8.  Add another **Text** type field and call it **contactId**. This will store the contact details of registered users.
9.  Now create a **Boolean** type field and call it **notified**. This ensures that subscribers will be notified only once.

<details>
<summary>See how it looks</summary>

![add field in subscriptions](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/04/24dfdee6-73d5-467e-bcdb-c33b89672e4b/52a0a7d7-3c94-42c5-99fa-bd56f8288d39.png)

</details>

### Set permissions for your collection

You want any site visitor to be able to add content to your collection by subscribing. 

1.  Click **More Options**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/05/ae46274e-c846-4af2-ae94-3392a416ee15/d105bc7d-6e3e-4a3f-b9ea-18aad96248e6.png)  for your collection from the **CMS** menu.
2.  Select **Permissions & Privacy**. 
3.  Select the dropdown menu **Who can view this content?**.
4.  Select **Anyone**.
5.  Click **Save**.

<details>
<summary>See how it looks</summary>

![collections permissions and privacy](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/04/03567fc0-c0fe-4322-96c6-23ff51462873/4246826e-d88b-4b15-a087-4195da644b90.png)

![edit collection settings](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/05/90847e84-9da5-495f-99a8-6da370a6fd24/9da423fd-3f16-427e-b94d-1792a0ee2323.png)

</details>

* * *

## Step 9 | Install Your App on a Site in the Wix Editor

You can install your widget on any of the editors. The following example uses the Wix Editor. Before you install your app, you need to release your app a second time. This will be a major release, because you have created a collection.

1.  After releasing your app, open your website.
2.  Click **Add apps**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/13/f834347c-197b-4567-b41c-0223896006be/c7ee749e-357c-4a5b-95da-7e551b526d73.png) . 
3.  Click **Custom Apps**. A list of all your apps appears.
4.  Select your app from the **Available apps** list.
5.  Click **Install App**.
6.  Click **Add** **Elements**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/13/d5302806-c42f-4e0e-9f2b-8d63be2a4524/0a96ba99-7bb7-4f35-afb4-efa49776f90b.png) .
7.  Select **My Widgets**.
8.  Double click your widget to add it to your site. 

Your widget is fluid and you can select its elements so that you can customize the widget to your site. You can also open the settings panel and change the default end date. 

<details>
<summary>See how it looks</summary>

![countdown widget installed in the editor](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/08/31/e2d8fcc5-7225-4da9-9fd5-b82c373fe11e/dc03bc9d-38d4-4c1b-b3e0-790de4474d4f.gif)

</details>

### Set an Email ID

Users can register for an email notification. You need to create the email that will be sent and get an ID for it so that the widget API can identify which email needs to be sent.

1.  Open **My Dashboard** from the **Site** menu in the top bar.
2.  Go to **Triggered Emails** in **Developer Tools**.
3.  Click **Get Started**. 
4.  Enter a subject.
5.  Design the email using the editor tools.
6.  Click **Save & Continue**.
7.  Add the sender details, the **From name** and the **Reply-to email**, and click **Save**.
8.  Click **Got it**.
9.  Click **Save & Publish** again. You get a generated identification code that links to the email that you have designed so that it will be sent to anyone who registers. 
10.  Enter this code in your custom panel in the **Email ID** field.

### Use Backend Code in Wix Editor to Notify Subscribers

Backend code is included with your app in Blocks, but you need to invoke the notification in the editor.

### Invoke your notify function

1.  Click **\+ New web module** under **Backend** in **Public & Backend** in the Wix editor.
2.  Call it `backend.web.js`. 
3.  Import the backend function in your site's code section under **backend.wb.js**.

Your code should look like this:

```javascript
import { notify } from 'myWixId/my-application-name-backend';
```

Now create an export function `invokeNotify` in **backend.jsw** in your site's code section.

Your code should look like this:

```javascript
export function invokeNotify() {
     return notify ();
}
```

Now you need to create a [scheduled job](https://dev.wix.com/docs/velo/articles/getting-started/schedule-jobs). The widget's frontend code only runs when someone is on the page. You need a backend process that runs even when no one is visiting to check who should be notified and send emails. A Scheduled Job is the built‑in way to do that.

1.  Click **Add**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/7ef91d19-d5d6-41b5-9f31-4a03269c9a61/b3f3cded-858f-4bb2-918e-d9c00f912567.png)  in **Backend**
2.  Click  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/09/01/e0f3d35c-2ffa-4cc2-9a47-a8e01ea1c99c/cb360e28-8c01-4af5-b657-8596f865778a.png)  **Add scheduled jobs**. Add the following code under **jobs.config** in your site's code section. In this example, the notify function is invoked at 10 minutes past the hour, every hour.

Your code should look like this:

```javascript
{
   "jobs": [{
       "functionLocation": "/backend.jsw",
       "functionName": "invokeNotify",
       "description": "",
       "executionConfig": {
           "cronExpression": "10 * * * *"
       }
   }]
}
```
> **Note:** Scheduled jobs run only on the published site. Expect up to 1–2 minutes delay.

* * *

## Step 10 | Test Your App

Now you are ready to test your app. 

1.  Publish your site. 
2.  Register to receive an email notification. 
3.  Go back to the editor and check your collection. 
4.  You can see that there is a new subscriber. Wait until the countdown reaches 0 days and you'll get a notification email. You will also see a tick in the **notified** field.

<blockquote class="tip">

**Check your triggered emails** 
You can also check in **Triggered Emails** under **Developer Tools** in your dashboard to see if the email has been sent.

</blockquote>
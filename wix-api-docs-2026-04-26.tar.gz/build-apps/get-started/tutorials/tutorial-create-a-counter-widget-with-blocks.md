---
portal: build-apps
name: "Tutorial | Create a Counter Widget with Blocks"
type: ARTICLE_RESOURCE
resourceId: 9d829be5-77fb-45bf-8784-ed1ed295fbd0
---

# Creating a Counter Widget

# Tutorial | Create a Counter Widget Using Blocks

<blockquote class="caution">

**Editor compatibility**

Wix Blocks apps aren't supported in the Wix Harmony editor. Existing Blocks apps remain available for purchase on the Wix App Market for Wix Editor and Wix Studio sites. To learn more, see [About Wix Harmony and Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-harmony-and-blocks).

</blockquote>

This tutorial shows you how to build a counter widget, where you can increment and decrement a number. Through this simple widget we will walk through everything that you can do with Wix Blocks. 

 ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/10/2714292d-944d-49c9-951a-83cc5c333e4b/95962bc8-fba5-4c08-b062-876165b5ca5a.gif) 

We recommend that you build this widget from scratch, but if you get stuck, you can [view a template of the widget in Blocks and edit it](https://blocks.wix.com/wix-blocks-new-app-creator?editorType=RESPONSIVE&originTemplateId=bac5efe0-e532-4f58-8029-58adca2fb0b4&http_referrer=documentation) under your Wix account.

## Step 1 | Create a new Widget in Blocks

[Create an empty Blocks app](https://support.wix.com/en/article/wix-blocks-creating-an-app-and-opening-it). Start with a blank canvas.  

* * *

## Step 2 | Add a Flexbox

A flexbox  is a container that allows responsiveness. It will keep the other elements organized. To add a flexbox: 

1.  Click the **Add Elements** **+** button in the top menu. 
2.  Click **Layout ->**  **Flexboxes** 
3.  Click the vertical 3-section flexbox. 

<details>
<summary>Show screenshot</summary>

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/05/02/4bdd5662-aa86-4936-98a3-1189be629bb0/c789550f-3ad5-42a1-9f5d-d56735202358.png)

</details>

* * *

## Step 3 | Add Widget Elements

### Adding the buttons

1.  Click the **Add Elements** **+** button on the top menu. 
2.  Click **Buttons**. 
3.  Drag and drop a Primary Button onto the right section of the flexbox.

<details>
<summary>Show screenshot</summary>

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/1b75c84b-580c-44c3-b24d-b0184518d29c/5f2a673b-964a-4ad5-aaa9-daf8e24aa166.png)

</details>

### Changing the text

1\.  Click **Settings**. 

2\.  Select **Text only** from the drop down list. 

3\.  Change the button's text or icon to "+".

4\.  Click the **Design**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/12/caba4f61-8f8f-4889-a38d-cbd18d0b8f63/a5d2a21c-5e1d-4636-9cd3-a964c0fdd520.png)  icon in the **Inspector** panel  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/05/14/abd2dd03-8a0b-49bd-8cb9-af4503103bb6/28a66f5a-598c-4d9d-86ab-35062a41c17b.png)  and select **Text**.

5\.  Click **Themes** and select **Heading 6** from the drop down list. 

6\. Drag and drop another square button to the left section. 

7\. Change the text to "-".

<details>
<summary>Show screenshot</summary>

![text menu](https://wixmp-833713b177cebf373f611808.wixmp.com/images/3d3dd0c910ba2b69b1fd1428299f392b.png)

</details>

### Adding the middle number

1.  Click the **Add Elements** **+** button and select **Text**.
2.  Drag and drop an **32px Title** element to the central section of the flexbox. 
3.  Edit the text to "0" and align it to the center. 

<details>
<summary>Show screenshot</summary>

  

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/eb6df53306be4cd0dff87766b381bdf6.png)

</details>

#### Changing the IDs

1. Click the increment button.
1. Click the **Properties and Events**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/10/25/b8b2d885-6d3d-45ce-b4d1-ad335143e391/c4cb59f0-340d-46ed-989c-2f1f56b3cae3.jpg)  icon in the bottom right of the screen.  
2.  Change the ID of your increment button to **incBtn**.
3.  Change the ID of your decrement button to **decBtn**.
4.  Change the ID of your text element to **countTxt**.

<details>
<summary>Show screenshot</summary>

![properties and events](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/10/1e18b1f1-643c-40fb-839e-e0ee7f3dd806/142720ae-f3e7-4eec-8a87-16b469ce9014.png)

</details>

* * *

## Step 4 | Add Code to Your Elements

Now it's time to make the widget do what it's supposed to do: count up and down when the buttons are clicked. 

1\.  Go to the bottom part of your screen to add code to your widget. 

<details>
<summary>Show screenshot</summary>

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/2fd445d5-e777-4a22-919a-86e27f255d03/c714cacf-32e8-42c5-8e14-52bf9187397a.png)

</details>

2\.  Add the following code **before** your **onReady()** function.

```javascript
//Set the count to 0 
let count = 0;

//Assign the count to your text element
function render() {
 $w('#countTxt').text = count.toString();
}

//Add a certain amount to the count and fire an event in the widget API
function addToCount(amount) {
 count += amount;
 render();
}
```

3\.  Add the following code **in** your **onReady()** function. 

```javascript
 $w('#incBtn').onClick(() => {
  addToCount(1);
 });
 
   $w('#decBtn').onClick(() => {
  addToCount(-1); 
 });
  
  render();
```

4\.  Click the **Preview** button to see your widget in action. 

* * *

## Step 5 | Make Your Widget Customizable with Widget API

Blocks lets you [define an API for your widget](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/widget-api/about-the-widget-api), so that the user (a site owner who installs the widget) can customize it to their needs. The API can contain properties, events and exported functions.

Let's say that you want a user to be able to decide what the "step" of the count is. Perhaps they want the step to be 2, so that the count is 0,2,4,6 etc. 

To do that, let's define a property in the widget API named `step`.

### Define the `step` Property

1.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/12345678-1234-1234-1234-1234567890ab/2021/10/27/4e37c3ae-fd88-43a8-a374-0c6c958d897f/3db01ac0-dd5b-4e14-b878-16a6a0674532.jpg)  icon to open the Widget API panel.
2.  Click **Add New Property** in the **Properties** section (or hover over the section and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/11/01/c319bb4a-e946-4229-9abd-6f4ad77f67e6/d176d48f-2f1c-45f0-b4bd-ea403358ae49.png)  icon that appears).

<details>
<summary>Show screenshot</summary>

  

![define new property](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/10/27/af66ea44-ad74-438b-9b44-e09e76680979/972a285f-1fcb-4fc5-aee2-38043f2073d5.jpg)

</details>

### Configure the property

1. Name your property "step".
1. Give it the type **Number**.
1. Give it a default value of **1**. 

<details>
<summary>Show screenshot</summary>

  

![the step property](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/10/27/4cfb0aaf-ab77-4b08-96a1-39f47f27ed72/af5fa679-3a56-4dbb-809b-7c3b5d0544be.jpg)

</details>

### Change Your Code to Consider Your New Property

Change your code so that when the buttons are clicked, **addToCount** is called with the step from the properties rather than with the default value of 1.

Use _$widget.props_ to access your properties (notice the autocomplete Velo suggestions). 

```javascript
$w.onReady(function () {
 $w('#incBtn').onClick(() => {
  addToCount($widget.props.step);
 });
 $w('#decBtn').onClick(() => {
  addToCount(-$widget.props.step);
 });

 render();
});
```

### Test Your Property in Preview Mode

1.  Click **Preview** to move to preview mode. 
2.  Click **Test API Properties**. 

<details>
<summary>Show screenshot</summary>

  

![test api properties](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/10/e13ac194-8b23-45ab-89b2-9a4b13242efd/e9f325ab-9466-4bd8-8174-e06ed2d3dcf0.png)

</details>

3\.  Change the step to a different number and see how your widget works. 

<details>
<summary>Show screenshot</summary>

  

![change step](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/10/27/aa0da482-efba-4f57-b1b0-edef9a8af4c8/921f5840-e5a5-48d2-b658-e6e55932a329.jpg)

</details>

### Add a Public Event to Your Widget API

The widget API allows you to add an event that is fired whenever you decide. 

Add an event that is fired when the "count" variable changes:

1.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/12345678-1234-1234-1234-1234567890ab/2021/10/27/4e37c3ae-fd88-43a8-a374-0c6c958d897f/3db01ac0-dd5b-4e14-b878-16a6a0674532.jpg)  icon to open the Widget API panel. 
2.  Click **Add New Public Event** in the **Events** section (or hover over the section and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/11/01/4812e078-ae7e-4b2e-980b-a090cb734f45/79c543fb-71dd-4dbc-aec7-74f0b7c00e00.png)  icon that appears). 
3.  Name your event and describe it

<details>
<summary>Show screenshot</summary>

![new event](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/10/e1fa6fcf-08e4-4d92-a691-397f0fa40489/d98ef818-a6cf-42ff-9892-9fcdb21a399b.png)

</details>

4\.  Add this line to your **addToCount()** function, to fire the event when the count changes. 

```javascript
$widget.fireEvent('change', count);
```

5\.   Now, your **addToCount()** function should look like this: 

```javascript
function addToCount(amount) {
 count += amount;
 render();
 $widget.fireEvent('change', count);
}
```

<blockquote class="tip">
  <strong>Tip:</strong>

  You'll need to catch your event in the site editor once you have installed your widget in your website (this will be describe in Step 8).
</blockquote>

### Add a Public Function to Your Widget API

Create and export a **reset()** function, so that site owners can easily set the count to 0. 

1.  Click the **Widget API**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/12345678-1234-1234-1234-1234567890ab/2021/10/27/4e37c3ae-fd88-43a8-a374-0c6c958d897f/3db01ac0-dd5b-4e14-b878-16a6a0674532.jpg)  icon to open the Widget API panel. 
2.  Click **Add New Public Function** in the **Functions** section (or hover over the section and click the  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/11/01/4812e078-ae7e-4b2e-980b-a090cb734f45/79c543fb-71dd-4dbc-aec7-74f0b7c00e00.png)  icon that appears). 
3.  A new empty function by the default name **myPublicFunction()** is created, with a designated JSDoc (the comments block) that can be read by anyone who will use your function on a site. 

<details>
<summary>Show screenshot</summary>

![empty function](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e50f36809e5da661c096b5eb3ca20d4b.png)

</details>

4\.  Paste the following code instead of the function default code: 

```javascript
export function reset(){
 //This function is part of my public API
 count = 0;
 render();
}
```

5\.  Update the JSDoc. You must keep the function's annotation in this format.  

```javascript
/**
*@function
*@description Sets count to 0 and renders. 
*@returns nothing
*/
```

* * *

## Step 6 | (Optional) Configure Your Widget's Edit-Time Behavior

The **Configuration** tab within the **Editor Experience Panel**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/63dbfda0-a43d-4970-87d6-189c56ed4e51/855a0542-e46e-4cd1-9ffb-ac23df8fc7d6.png)  allows you to determine the behavior of the widget and its elements when a site owner edits it in the editor.  Try out a few options in the **Configuration** tab.

<details>
<summary>Show screenshot</summary>

![](https://wixmp-833713b177cebf373f611808.wixmp.com/images/44f035bcae42ecfdb3f658b09b2df0e6.png)

</details>

Set a display name for your widget elements: 

1.  Select the decrement button.
2.  Change its display name under **Component Name** to "My Decrement" in the Inspector  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/f17c44b5-38a3-4277-a82f-dedae6e37557/db339269-a960-4738-b5bf-2c294e6f4761.png)  panel.

<details>
<summary>Show screenshot</summary>

![decrement button](https://wixmp-833713b177cebf373f611808.wixmp.com/images/719466fadb9f4e97190152debb234aa3.png)

</details>

Prevent the text element from being selectable in the editor: 

1.  Select the text element that represents your count. 
2.  Click the **Can be selected** option in the **Behavior** section of the **Inspector**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/85c931fb-2a09-49f7-a042-ea1d8f162c7c/d074e6a3-af5d-4d3d-bbfb-a3e255568b94.png)  panel to remove the blue checkmark. 

<details>
<summary>Show screenshot</summary>

  

![can be selected](https://wixmp-833713b177cebf373f611808.wixmp.com/images/8043f7a2eb2e004bf706e7ca72414bc3.png)

</details>

* * *

## Step 7 | (Optional) Create More Design Presets

Blocks allows you to create various variations for your widget's design and layout, through [design presets](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Design%20Presets.md*original::../Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Design%20Presets.md). To create another design preset: 

1.  Click the **App Interface**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2024/05/01/e381745f-b13b-46fe-a339-23e286e3ee76/5c93dafc-bc3c-4197-a7f2-1cb92acf67a4.png)  panel . 
2.  Go to the **Design Presets** section.
3.  Click ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/11/01/c319bb4a-e946-4229-9abd-6f4ad77f67e6/d176d48f-2f1c-45f0-b4bd-ea403358ae49.png).
4.  Click the **ֿMore Actions** icon  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/05/24/e9f11af0-679c-4bf1-8b76-e50e26ec98f6/27128ae4-51ef-4cdd-b679-854d2e85973b.jpg)   to rename your preset (you can also duplicate or delete it). 

<details>
<summary>Show screenshot</summary>

  

![add design preset](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/10/a0fbdcd2-da90-4cee-89eb-288843484c06/62fbd714-b93b-422c-a3b0-1bf564aa08d0.png)

</details>

4\. Make some visible changes in your widget, like changing the color of the middle section.

<details>
<summary>Show screenshot</summary>

  

![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/21e446eb-7f73-4f2f-84b1-c6b77e64e45e/2024/04/24/04e9e285-561b-41cd-8280-a0784e247a9e/a746fb8b-3500-4e24-9d63-5f5ec49b6196.png)

</details>

Move back and forth between presets to see the differences.

<blockquote class="tip">
  <strong>Tip:</strong>

  Note that some design and layout changes impact only your current preset, while others impact all ([learn more](https://github.com/wix-private/developer-docs/blob/f104794e2cd2840ebaff74f14ad68a6b22a75292/build-apps-portal/develop-your-app/frameworks/blocks/Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Design%20Presets.md#make-changes-per-preset-versus-global-changes*original::../Blocks:%20Design%20widgets%20and%20apps/Creating%20and%20Managing%20Design%20Presets.md#make-changes-per-preset-versus-global-changes)).
</blockquote>

* * *

## Step 8 | Catch Your Event in the site editor

Go to your site editor to catch the event from your app. First you need to register an Event Handler for the change event:

1.  [Install your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/deploy-and-manage-blocks-apps/install-a-blocks-app-on-a-site) on a site and add the widget to the site. 
2.  Enable **Dev Mode** on the site. 
3.  Click on your widget and then click the **Properties and Events**  ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/378fd532-728d-473b-8f03-30140bda59af/2021/10/25/b8b2d885-6d3d-45ce-b4d1-ad335143e391/c4cb59f0-340d-46ed-989c-2f1f56b3cae3.jpg)  icon.
4.  Change the ID of your widget, for example, to "counter1".
5.  Click **onChange( )** under Event Handlers.
6.  Select **counter1\_change** in the box.

<details>
<summary>Show screenshot</summary>

  

![counter change event](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/6b5c7381-912e-4754-99e2-d23157db088c/2022/05/10/faf94d96-b2fc-4250-a583-fc4ad766af9b/744aeb30-91e5-43cb-aea3-5fb9bd23cdab.png)

</details>

Now write the function. It gets the \`count\` as a parameter and resets the count when it gets to whatever number you decide (in our example: 30). Your function should look like this:

```javascript
export function counter1_change({data: count}) {
 // This function was added from the Properties & Events panel. To learn more, visit http://wix.to/UcBnC-4
 // Add your code for this event here: 
 if (count > 30) {
  $w('#counter1').reset();}
}
```

Preview or publish to see your site in action.
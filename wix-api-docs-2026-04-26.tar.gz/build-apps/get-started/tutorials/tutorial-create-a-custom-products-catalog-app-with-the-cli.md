---
portal: build-apps
name: "Tutorial | Create a Custom Products Catalog App with the CLI"
type: ARTICLE_RESOURCE
resourceId: 2b21f41e-7369-4e8c-8b9b-8e8acdeb5522
---

# Tutorial | Create a Custom Products Catalog App with the CLI

# Tutorial | Create a Custom Products Catalog App with the CLI

> **Note:** This tutorial uses the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli). We recommend that you use the new [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) for new projects.

One of the ways that 3rd-party developers can extend the Wix ecosystem is by creating apps that appear in site owners' dashboards. These apps can work with data from the sites they’re installed on, such as Content Management System (CMS) data and business solution data like CRM.    

This tutorial explains how to create a React app similar to our [Custom Products Catalog template](https://dev.wix.com/apps-templates/template?id=24493a0d-18f2-4f68-b6d5-55992cef7daa) where users can add or remove products from a Wix Stores products catalog through a dashboard page.

We use the following technologies to create the app:

- [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli): Used to create, test, and deploy the app.
- [The Wix JavaScript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk): Used to retrieve blog post data from the site.
- [Wix Design System](https://www.wix-pages.com/wix-design-system/?path=/story/getting-started--about): Used to display data on the dashboard page.
- [Patterns](https://www.wix-pages.com/wix-patterns/?path=/story/getting-started--overview): Used to display and manipulate data on the dashboard page.

The end result will look like this:

![App preview](https://wixmp-833713b177cebf373f611808.wixmp.com/images/976d25416ecf405f33e3711009f6963e.png)

We use the following steps to build the “Custom Products Catalog” app:

1. [Initialize the app](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-1--initialize-the-app*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-1--initialize-the-app)
2. [Run a local development server](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-2--run-a-local-development-server*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-2--run-a-local-development-server)
3. [Add permissions](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-3--add-permissions*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-3--add-permissions)
4. [Set up Wix Stores](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-4--set-up-wix-stores*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-4--set-up-wix-stores)
5. [Install dependencies](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-5--install-dependencies*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-5--install-dependencies)
6. [Set up wrappers for our dashboard page component](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-6--set-up-wrappers-for-our-dashboard-page-component*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-6--set-up-wrappers-for-our-dashboard-page-component)
7. [Create hooks for our SDK calls](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-7--create-hooks-for-our-sdk-calls*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-7--create-hooks-for-our-sdk-calls)
8. [Create a "Create Product" modal](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-8--create-a-create-product-modal*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-8--create-a-create-product-modal)
9. [Create a dashboard page component](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-9--create-a-dashboard-page-component*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-9--create-a-dashboard-page-component)
10. [Test the app](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-10--test-the-app*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-10--test-the-app)
11. [Build and deploy the app](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/build-apps-portal/get-started/resources/tutorials/tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-11--build-and-deploy-the-app*original::./tutorial---create-a-custom-products-catalog-app-with-the-cli.md#step-11--build-and-deploy-the-app)

## Before you begin

Before getting started, make sure that:

- You install [Node.js](https://nodejs.org/en/download/) (v20.11.0 or higher).
- You install [npm](https://www.npmjs.com/package/npm) or [yarn](https://www.npmjs.com/package/yarn).
- You're logged into your Wix Studio account. If you don't already have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).

We also recommend that you check out the [Patterns documentation](https://www.wix-pages.com/wix-patterns/?path=/story/getting-started--overview). Patterns is a complex React library. Familiarizing yourself with the basics will help you better understand the code in this tutorial.

## Step 1 | Initialize the app

We use the Wix CLI to initialize our "Custom Product Catalog" app. In the process of initializing our app, the Wix CLI automatically:

- Creates a new app in the [Custom Apps page](https://manage.wix.com/account/custom-apps) of your Wix Studio workspace.
- Sets up a new folder for your app in your local file system. The folder includes:
  - A `src` folder containing initial boilerplate code for an app with a dashboard page.
  - A `package.json` file containing your app dependencies.
- Creates a local Git repository for your app. 
- Prompts you to set up a development site for testing your app.

**To initialize the app:**

1. Open a terminal and navigate to the folder where you want to create your app. 
1. Run the following command:

    ```bash
    npm create @wix/app@latest
    ```

1. Select **Create a new Wix App**.
1. Select **Create a basic app**.
1. Enter a name for your app. Let’s name our app **Custom Products Catalog**.
1. Back in the terminal, press **Enter** to select the default folder name (`custom-products-catalog`) for your app in your local file system.

You now have a new app in the [Custom Apps page](https://manage.wix.com/account/custom-apps), a new folder in your local file system, and a local Git repository for developing and testing your app.

## Step 2 | Run a local development server

Now that you’ve initialized your app, you can run a local development server to see the app in action, and view local changes as you develop your app. The local development environment runs the app and its initial boilerplate code on the development site that you chose in the previous step.    

To run a local development server for your app:

1. Navigate to your newly-created folder for your app.

    ```bash
     cd custom-products-catalog
    ```

1. Run the following command:

    ```bash
    npm run dev
    ```

1. The CLI prompts you to choose a development site (test site), which you’ll use throughout this tutorial to run and test your app. You can choose an existing Wix site as your development site, or create a new one. Let’s **Create a new Development Site**. The newly created development site is automatically named something like **Dev Site 5x2043**, and can be found in your Wix account’s list of sites.

1. Follow the prompt to open the development site on your default browser. If the browser doesn’t open, [install your app on your test site](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/test-your-app-on-a-premium-site) manually and skip the next step.

1. Click **Agree & Add** to install your app on your development site. 

1. Click the **Dashboard** link in the terminal. Your development site’s dashboard opens, and you can see your newly-created app’s dashboard page in the left sidebar. We add the content of our app’s dashboard page in the next step.

![Dashboard page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7d56c1d8ad1d3c600927d35b9413e751.png)

Your app is now running on your development site. As you develop your app, any changes made to your app’s code are reflected in real time on your development site.

If your changes don’t show up, try refreshing the page, or closing and reopening the development site.

## Step 3 | Add permissions

In this step, we'll add permissions for the app. Every SDK API requires specific permissions to use. In this app, we will use the `queryProducts()`, `createProduct()`, and `deleteProduct()` functions in the [Wix SDK’s Stores Products API](https://dev.wix.com/docs/sdk/backend-modules/stores/products/introduction) to get a list of all products, and to add and delete them.

To use these functions, we need to give our app permission requirements in the app dashboard. Once we do this, anyone installing the app will be prompted to grant the specified permissions.

You can find the permission scopes you need for each API in the individual function’s page in the [JavaScript SDK documentation](https://dev.wix.com/docs/sdk). 

Let’s first look for the permissions that we need in the **Permission Scopes** section of the `queryProducts()` function’s page.

![Permissions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6a0a3a5f05afa13003f7b29dbf8f8bfd.png)

The Permission Scopes section indicates that our app must have one of the permission scopes on the list to call the function. Let’s choose the **Manage Stores - All Permissions** permission scope. It works with `createProduct()` and `deleteProduct()` as well. 

To add permission requirements for the app:

1. Go to [**Permissions** tab](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fdev-center-permissions) in your app's dashboard.
1. Click **Add Permissions**.
1. Enter **Manage Stores - All Permissions** in the **Search by name or ID** field.
1. Check the permission scope's checkbox under **Choose Permission Scopes**.
1. Click **Save**.

## Step 4 | Set up Wix Stores

Our app integrates with Wix Stores, so we need to set up Wix Stores on our site, then reinstall the app so that our site request the required permissions:

1. Install the [Wix Stores](https://www.wix.com/app-market/wix-stores?searchLocation=home) app on your test site. You can create some new products, or use the sample ones provided by Wix.
    > **Note:** Make sure to add Wix Stores in both the Dashboard and the Editor.
1. In your test site dashboard, select **Apps > Manage Apps** from the sidebar.
1. Delete your app from the site.
1. Open your app’s dashboard in the [Custom Apps page](https://manage.wix.com/account/custom-apps).
1. Select **Test Your App > Dashboard**. Select your test site in the **Site Selector**. Follow the prompts to reinstall the app and approve the new permissions.
    > **Note:** You'll be prompted to create an extension before testing the app. Ignore this prompt and click **Test Your App**.

## Step 5 | Install dependencies

Before we start coding our app, we need to install some npm packages. In your terminal, run the following commands:

```bash
npm install @wix/dashboard-react
npm install @wix/design-system
npm install @wix/patterns
npm install @wix/stores
```

The purpose of each of these packages will become clear as we progress.

## Step 6 | Set up wrappers for our dashboard page component

It’s finally time to start writing some code!

Our plan in this tutorial is to create a React component that defines our dashboard page. We’re going to wrap this component with providers that will manage our data fetching and provide Wix styling for our dashboard page component. 

To do this, we’ll create a higher-order component that will accept our dashboard page component and return it wrapped in the necessary providers.

To create the higher-order component:

1. Create a new file in your app's repo under `src > extensions > dashboard` named `withProviders.tsx`.

1. Import the react library, and then `WixDesignSystemProvider`:

    ```js
    import React from 'react';
    import { WixDesignSystemProvider } from '@wix/design-system';
    ```

   `WixDesignSystemProvider` provides styling for Wix Design System components.

1. Import `WixPatternsProvider`:
    
    ```js
    import { WixPatternsProvider } from '@wix/patterns/provider';
    ```

    `WixPatternsProvider` provides styling and data manipulation for Wix Patterns components.

1. Import `withDashboard`:

    ```js
    import { withDashboard } from '@wix/dashboard-react';
    ```

    [`withDashboard()`](https://dev.wix.com/docs/sdk/host-modules/dashboard-react-deprecated/with-dashboard) is a higher-order component that is temporarily required for use in [Wix Patterns](https://www.wix-pages.com/wix-patterns/?path=/story/getting-started--overview). It will continue to be supported while it is required.
    We'll wrap our dashboard page with this component.

1. Write a function named `withProviders` to wrap our dashboard page component in `WixPatternsProvider`, `WixDesignSystemProvider`, and `withDashboard()`.

    ```js
    export function withProviders<P extends {} = {}>(Component: React.FC<P>) {
      return withDashboard(function DashboardProviders(props: P) {
        return (
          <WixDesignSystemProvider>
            <WixPatternsProvider>
              <Component {...props} />
            </WixPatternsProvider>
          </WixDesignSystemProvider>
        );
      });
    }
    ```

Your complete **withProviders.tsx** file should look like this:

```js
import React from 'react';
import { WixDesignSystemProvider } from '@wix/design-system';
import { WixPatternsProvider } from '@wix/patterns/provider';
import { withDashboard } from '@wix/dashboard-react';

export function withProviders<P extends {} = {}>(Component: React.FC<P>) {
  return withDashboard(function DashboardProviders(props: P) {
    return (
      <WixDesignSystemProvider>
        <WixPatternsProvider>
          <Component {...props} />
        </WixPatternsProvider>
      </WixDesignSystemProvider>
    );
  });
}
```

## Step 7 | Create hooks for our SDK calls

Our dashboard page component will need to make SDK calls to create and delete Wix Stores product data using React hooks. To simplify our component code, we define these in a separate TypeScript file.

To create your app’s React hooks:

1. Create a new folder in your app's repo under `src > dashboard` named `hooks`.
1. Create a new file in `src > dashboard > hooks` named `stores.ts`.
1. Import `products` from Wix Stores so we can use the Wix Stores Products API:

    ```js
    import { products } from '@wix/stores';
    ```

1. Import `useCallback`:

    ```js
    import { useCallback } from 'react';
    ```

    [`useCallback`](https://react.dev/reference/react/useCallback) is a react hook that caches a callback function, returning a memorized version of the function that changes only if one of the dependencies has changed. 
    
    We use this hook to define how a new product is created and how a product is deleted using the `optimisticActions` prop and `createProduct`/`deleteProduct` from `products`. 
    Whenever any of these dependencies change, `useCallback` redefines the callback function.

1. Import `CollectionOptimisticActions`:

    ```js
    import { CollectionOptimisticActions } from '@wix/patterns';
    ```

    `CollectionOptimisticActions` is a class that provides a set of utilities for managing optimistic actions on a [Wix Collection](https://support.wix.com/en/article/cms-formerly-content-manager-creating-a-collection). It allows us to perform various actions, such as adding, updating, and deleting items from a collection while assuming that these actions will succeed, even before confirming with the server. Learn more about the [CollectionOptimisticActions class](https://www.wix-pages.com/wix-patterns/?path=/story/features-actions-updates--collectionoptimisticactions).

1. Create a function to create new products named `useCreateProduct`:

    ```js
    export function useCreateProduct(optimisticActions: CollectionOptimisticActions<products.Product, {}>) {}
    ```

   Inside this function:

      1. Use `products` to get the `createProduct()` function.
          
          ```js
          const { createProduct } = products;
          ```
  
      1. Use `useCallback()` to manage our `createProduct()` call:

          ```js
          return useCallback((productName: string) => {
            const newProduct: products.Product = {
              _id: Date().toString(),
              name: productName,
              _createdDate: new Date(),
              lastUpdated: new Date(),
              productType: products.ProductType.physical,
              description: 'New Product Description',
              priceData: {
                currency: 'USD',
                price: 10,
              },
            };
            
            optimisticActions.createOne(newProduct, {
              submit: async (products: products.Product[]) => {
                const createdProduct = products[0];
                const response = await createProduct(createdProduct);
                return response.product ? [response.product] : [];
              },
              successToast: {
                message: `${newProduct.name} was successfully created`,
                type: 'SUCCESS',
              },
              errorToast: () => 'Failed to create product',
            });
          }, [optimisticActions, createProduct]);
          ```

          Let's break down the above code:
          - **Lines 2-13**: Define the properties of the new product.
          - **Lines 15-26**: Use `optimisticActions.createOne()` to create the new product.
            - **Lines 16-20**: Define the `submit` function to handle product creation.
            - **Lines 21-24**: Define the toast to show when a product is created successfully.
            - **Line 25**: Define the toast to show when product creation fails.
          - **Line 27**: Define the dependencies for `useCallback()`.

    Your function should look like this:

    ```js
    export function useCreateProduct(optimisticActions: CollectionOptimisticActions<products.Product, {}>) {
      const { createProduct } = products;
    
      return useCallback((productName: string) => {
        const newProduct: products.Product = {
          _id: Date().toString(),
          name: productName,
          _createdDate: new Date(),
          lastUpdated: new Date(),
          productType: products.ProductType.physical,
          description: 'New Product Description',
          priceData: {
            currency: 'USD',
            price: 10,
          },
        };
        
        optimisticActions.createOne(newProduct, {
          submit: async (products: products.Product[]) => {
            const createdProduct = products[0];
            const response = await createProduct(createdProduct);
            return response.product ? [response.product] : [];
          },
          
          successToast: {
            message: `${newProduct.name} was successfully created`,
            type: 'SUCCESS',
          },
          errorToast: () => 'Failed to create product',
        });
      }, [optimisticActions, createProduct]);
    }
    ```

1. Create a function to delete products named `useDeleteProducts()`:

    ```js
    export function useDeleteProducts(optimisticActions: CollectionOptimisticActions<products.Product, {}>) {}
    ```

   Inside this function:

      1. Use `products` to get the `deleteProduct()` function.

          ```js
          const { deleteProduct } = products;
          ```
  
      1. Use `useCallback()` to manage our `deleteProduct()` calls:

          ```js
          return useCallback((productsToDelete: products.Product[] ) => {
            optimisticActions.deleteMany(productsToDelete, {
              submit: async (deletedProducts: products.Product[]) => (
                await Promise.all(
                  deletedProducts.map((product) => deleteProduct(product._id!))
                )
              ),
              
              successToast: {
                message: `${
                  productsToDelete.length > 1 ? 'Products' : 'Product'
                } deleted successfully`,
                type: 'SUCCESS',
              },
              errorToast: () => `Failed to delete ${
                productsToDelete.length > 1 ? 'Products' : 'Product'
              }`,
            });
          }, [optimisticActions, deleteProduct]);
          ```

          Let's break down the above code:
          - **Lines 2-18**: Use `optimisticActions.deleteMany()` to delete the products.
            - **Lines 3-7**: Define the submit function to handle product deletion. This function iterates over the array of products to delete and calls `deleteProduct()` for each one.
            - **Lines 9-14**: Define the toast to show when a product is created successfully.
            - **Lines 15-17**: Define the toast to show when a product is not created successfully.
          - **Line 19**: Define the dependencies for `useCallback()`.

    Your function should look like this:

    ```js
    export function useDeleteProducts(optimisticActions: CollectionOptimisticActions<products.Product, {}>) {
      const { deleteProduct } = products;
    
      return useCallback((productsToDelete: products.Product[] ) => {
        optimisticActions.deleteMany(productsToDelete, {
          submit: async (deletedProducts: products.Product[]) => (
            await Promise.all(
              deletedProducts.map((product) => deleteProduct(product._id!))
            )
          ),
          
          successToast: {
            message: `${
              productsToDelete.length > 1 ? 'Products' : 'Product'
            } deleted successfully`,
            type: 'SUCCESS',
          },
          errorToast: () => `Failed to delete ${
            productsToDelete.length > 1 ? 'Products' : 'Product'
          }`,
        });
      }, [optimisticActions, deleteProduct]);
    }
    ```

Your complete `stores.ts` file should look like this:

```js
import { products } from '@wix/stores';
import { useCallback } from 'react';
import { CollectionOptimisticActions } from '@wix/patterns';

export function useCreateProduct(optimisticActions: CollectionOptimisticActions<products.Product, {}>) {
  const { createProduct } = products;

  return useCallback((productName: string) => {
    const newProduct: products.Product = {
      _id: Date().toString(),
      name: productName,
      _createdDate: new Date(),
      lastUpdated: new Date(),
      productType: products.ProductType.physical,
      description: 'New Product Description',
      priceData: {
        currency: 'USD',
        price: 10,
      },
    };
    
    optimisticActions.createOne(newProduct, {
      submit: async (products: products.Product[]) => {
        const createdProduct = products[0];
        const response = await createProduct(createdProduct);
        return response.product ? [response.product] : [];
      },
      
      successToast: {
        message: `${newProduct.name} was successfully created`,
        type: 'SUCCESS',
      },
      errorToast: () => 'Failed to create product',
    });
  }, [optimisticActions, createProduct]);
}

export function useDeleteProducts(optimisticActions: CollectionOptimisticActions<products.Product, {}>) {
  const { deleteProduct } = products;

  return useCallback((productsToDelete: products.Product[] ) => {
    optimisticActions.deleteMany(productsToDelete, {
      submit: async (deletedProducts: products.Product[]) => (
        await Promise.all(
          deletedProducts.map((product) => deleteProduct(product._id!))
        )
      ),
      
      successToast: {
        message: `${
          productsToDelete.length > 1 ? 'Products' : 'Product'
        } deleted successfully`,
        type: 'SUCCESS',
      },
      errorToast: () => `Failed to delete ${
        productsToDelete.length > 1 ? 'Products' : 'Product'
      }`,
    });
  }, [optimisticActions, deleteProduct]);
}
```

## Step 8 | Create a "Create Product" modal

We need a modal where the user can enter the name of the new product and confirm or cancel. This modal will be opened using a button on the dashboard page.
To build this modal:

1. Create a new folder in your app's repo under `src > extensions > dashboard` named `components`.
1. Create a new file in `src > extensions > dashboard > components` named `create-product.tsx`.
1. Import:
    - `React`, `useEffect`, and `useState`.
    - The components of the Wix Design System required to create our modal. Learn more about the [`Modal` component](https://www.wix-pages.com/wix-design-system/?path=/story/components-overlays-modal--modal).

    ```js
    import React, { useEffect, useState } from 'react';
    import {
      Modal,
      CustomModalLayout,
      FormField,
      Input,
    } from '@wix/design-system';
    import '@wix/design-system/styles.global.css';
    ```


1. Create a `CreateProductModal` component to define the appearance and functionality of the modal. Use the following code:

    ```js
    export function CreateProductModal({ showModal, onSave }: { showModal: boolean, onSave: (name: string) => void }) {
      const [productName, setProductName] = useState('');
      const [shown, setShown] = useState(showModal);
    
      useEffect(() => {
        setShown(showModal);
      }, [showModal])
    
      const toggleModal = () => {
        setShown(!shown);
        setProductName('');
      };
    
      return (
        <Modal
          isOpen={shown}
          onRequestClose={toggleModal}
          shouldCloseOnOverlayClick
          screen="desktop"
        >
          <CustomModalLayout
            title="Create Product"
            primaryButtonProps={{
              disabled: !productName,
              children: 'Save',
            }}
            primaryButtonOnClick={() => {
              onSave(productName)
              setProductName('')
            }}
            secondaryButtonText="Cancel"
            secondaryButtonOnClick={toggleModal}
            onCloseButtonClick={toggleModal}
            content={
              <FormField label="Name">
                <Input
                  value={productName}
                  onChange={(e) => setProductName(e.currentTarget.value)}
                />
              </FormField>
            }
          />
        </Modal>
      );
    }
    ```

    Let’s break down the above code:

    - **Lines 2-3**: Initialize state variables to manage the product name and the visibility of the modal.
    - **Lines 5-7**: Use `useEffect()` to ensure that when the `showModal` prop updates, the `shown` state variable aligns with it.
    - **Lines 9-12**: Set up a function to toggle the visibility of the modal and reset the product name input whenever the modal is shown or hidden.
    - **Lines 15-20**: Configure the modal to close when it’s toggled or if the site owner clicks outside of it on the page.
    - **Lines 21-42**: Configure the modal’s layout and content.
      - **Lines 23-30**: Add a primary **Save** button that is enabled when a product name has been entered. When clicked, it creates a product, and then resets `productName`. 
      - **Lines 31-32**: Add a secondary **Cancel** button. When clicked, it closes the modal.
      - **Lines 35-40**: Add a `FormField` component that takes an input for the product name.

Your complete `create-product.tsx` file should look like this:

```js
import React, { useEffect, useState } from 'react';
import {
  Modal,
  CustomModalLayout,
  FormField,
  Input,
} from '@wix/design-system';
import '@wix/design-system/styles.global.css';

export function CreateProductModal({ showModal, onSave }: { showModal: boolean, onSave: (name: string) => void }) {
  const [productName, setProductName] = useState('');
  const [shown, setShown] = useState(showModal);

  useEffect(() => {
    setShown(showModal);
  }, [showModal])

  const toggleModal = () => {
    setShown(!shown);
    setProductName('');
  };

  return (
    <Modal
      isOpen={shown}
      onRequestClose={toggleModal}
      shouldCloseOnOverlayClick
      screen="desktop"
    >
      <CustomModalLayout
        title="Create Product"
        primaryButtonProps={{
          disabled: !productName,
          children: 'Save',
        }}
        primaryButtonOnClick={() => {
          onSave(productName)
          setProductName('')
        }}
        secondaryButtonText="Cancel"
        secondaryButtonOnClick={toggleModal}
        onCloseButtonClick={toggleModal}
        content={
          <FormField label="Name">
            <Input
              value={productName}
              onChange={(e) => setProductName(e.currentTarget.value)}
            />
          </FormField>
        }
      />
    </Modal>
  );
}
```

## Step 9 | Create a dashboard page component

Finally, we have all the pieces in place to set up our dashboard page.

But first, let's rename our page to something more appropriate:

1. In your app's repo, navigate to `src > extensions > dashboard > pages`.
1. In the file `my-page.extension.ts`, change the value of `title` to `Custom Products Catalog`.

Now, let's create the dashboard page itself:

1. Open the `my-page.tsx` file.
1. Delete all the contents - we're starting from scratch.
1. Add the following import statements:

    ```js
    import React, { useState } from 'react';
    import {
      Box,
      Text,
      Image,
      Breadcrumbs
    } from '@wix/design-system';
    import '@wix/design-system/styles.global.css';
    import { products } from '@wix/stores';
    import { CollectionPage } from '@wix/patterns/page';
    import {
      useTableCollection,
      Table,
      PrimaryPageButton,
      useOptimisticActions,
      deleteSecondaryAction,
      MultiBulkActionToolbar,
      CustomColumns,
      Filter,
      CollectionToolbarFilters,
      dateRangeFilter,
      RangeItem,
      DateRangeFilter,
      RadioGroupFilter,
      stringsArrayFilter,
    } from '@wix/patterns';
    ```

    This file is where we start to use [Patterns](https://www.wix-pages.com/wix-patterns/).

    Patterns is a React library with advanced components that extend the functionality of the core UI React components from the [Wix Design System](https://www.wix-pages.com/wix-design-system/). It simplifies Wix app development by enabling you to easily and consistently implement complex functionalities like querying, displaying, and filtering collection data from remote servers.

    In our code, we use Patterns components to create a table of products that you can query, filter, and sort. The table also has functionality to create new products, delete existing products, and choose which columns to display. 

1. Import everything we set up in the previous sections:

    ```js
    import { withProviders } from '../withProviders';
    import { useCreateProduct, useDeleteProducts } from '../hooks/stores';
    import { CreateProductModal } from '../components/create-product';
    ```

1. Define types for filtering the table's data:

    ```js
    type TableFilters = {
      productType: Filter<products.ProductType[]>;
      lastUpdated: Filter<RangeItem<Date>>;
    }
    ```

    These are the product properties by which the table can be filtered. We'll pass this to the `useTableCollection` hook later.

1. Define supported fields for sorting the table's data:

    ```js
    type SupportedQueryFields = keyof products.Product
    ```

    This type extracts all the field names from the `products.Product` interface, ensuring that only valid product fields can be used for sorting. This approach automatically stays in sync with the SDK's type definitions.

1. Map product types to strings so that they display in a readable way in the table:

    ```js
    const productTypeToDisplayName: {[key in products.ProductType] : string | undefined} = {
      [products.ProductType.physical]: 'Physical',
      [products.ProductType.digital]: 'Digital',
      [products.ProductType.unspecified_product_type]: undefined
    }
    ```

### Create the `Products()` component

It's finally time to make our dashboard page component. We will:

- [Define and export our dashboard page component](#define-and-export-our-dashboard-page-component)
- [Define the component's states, hooks, and functions](#define-the-components-states-hooks-and-functions)
- [Create the page structure](#create-the-page-structure)

#### Define and export our dashboard page component

1. Create a function for our dashboard page component named `Products`:

    ```js
    function Products() {}
    ```

1. Export the component wrapped by `withProviders()`:

    ```js
    export default withProviders(Products);
    ```

The rest of the code on this page will be written inside the `Products()` function.

#### Define the component's states, hooks, and functions

1. Initialize the `shown` state variable to manage the visibility of the modal we created [earlier](#step-8--create-a-create-product-modal).

    ```js
    const [shown, setShown] = useState(false);
    ```

1. Use `products` to get the `queryProducts()` and `deleteProduct()` functions.

    ```js
    const { queryProducts, deleteProduct } = products;
    ```


1. Create the [`tableState`](https://www.wix-pages.com/wix-patterns/?path=/story/base-components-collections-table-tablestate--tablestate) using [`useTableCollection`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Fbase-components-collections-table-usetablecollection--usetablecollection). 
    
    `useTableCollection` is a hook that returns a `tableState` object. This is where we define:
    - Where to retrieve the data from to display in the table.
    - How much data to retrieve.
    - How to build the query that retrieves the table data, depending on what filters, sorting, and search is applied in the table.
    - The error message to display if no data is found.
    - How the filters are applied.

    ```js
    const tableState = useTableCollection<products.Product, TableFilters>({
      queryName: 'products-catalog',
      itemKey: (product: products.Product) => product._id!,
      itemName: (product: products.Product) => product.name!,
      limit: 20,
        
      fetchData: async (query) => {
        const { limit, offset, search, sort, filters } = query;
        
        const filter: any = {};
        
        if (search) {
          filter.name = { $startsWith: search };
        }
        
        if (filters) {
          const { productType, lastUpdated } = filters;

          if (productType) {
            filter.productType = { $in: productType };
          }

          if (lastUpdated) {
            if (lastUpdated.from || lastUpdated.to) {
              const dateFilter: any = {};
              
              if (lastUpdated.from) {
                dateFilter.$gt = lastUpdated.from;
              }
              
              if (lastUpdated.to) {
                dateFilter.$lt = lastUpdated.to;
              }
              
              filter.lastUpdated = dateFilter;
            }
          }
        }

        const sortArray: any[] = [];
        if (sort) {
          sort.forEach(s => {
            const fieldName = s.fieldName as SupportedQueryFields;
            sortArray.push({
              fieldName,
              order: s.order === 'asc' ? 'ASC' : 'DESC'
            });
          });
        }

        const queryObj: any = {
          query: {
            filter: Object.keys(filter).length > 0 ? filter : undefined,
            sort: sortArray.length > 0 ? sortArray : undefined,
            paging: {
              limit,
              offset
            }
          }
        };

        const { products: items = [], totalResults: total } = await queryProducts(queryObj);
        return { items, total };
      },
      
      fetchErrorMessage: () => 'Error fetching products',
        
      filters: {
        lastUpdated: dateRangeFilter(),
        productType: stringsArrayFilter({ itemName: (p) => productTypeToDisplayName[p] ?? p })
      },
    });
    ```
  
    Let's break down the above code:
  
    - **Lines 2-5**: Define basic data necessary for the query used to populate the table.
    - **Lines 7-64**: Define the function that fetches the collection data used to populate the table. 
      - **Line 8**: Deconstruct the `query` parameter. `query` is an object that is passed to the `fetchData` function. It contains all the information needed to construct the query object.
      - **Lines 10-14**: Build the filter object. If there's a search term, add a `$startsWith` filter for the product name.
      - **Lines 16-38**: Add the relevant filters to the filter object if `filters` is included in the query. Use the properties of `filters` to check if a filter has been applied for **Type** or **Last Updated**, which we defined earlier in the `TableFilters` type.
      - **Lines 40-49**: Build the sort array if `sort` is included in the query, converting the order format to uppercase.
      - **Lines 51-60**: Build the complete query object with filter, sort, and paging properties, wrapped in a `query` property as required by the SDK.
      - **Lines 62-63**: Call `queryProducts()` with the query object and return the results.
    - **Line 66**: Define the error message that will be shown if the fetch fails. 
    - **Lines 68-71**: Define which filter factories are used with the filters.
      - **Line 69**: The `lastUpdated` filter uses the [`dateRangeFilter`](https://wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-filter-factories--daterangefilter) factory.
      - **Line 70**: The `productType` filter uses the [`stringsArrayFilter`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-filter-factories--stringsarrayfilter) factory.

1. Create the [`optimisticActions`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-actions-updates--collectionoptimisticactions) class using [`useOptimisticActions`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-actions-updates--useoptimisticactions).

    `useOptimisticActions` is a hook that returns a `CollectionOptimisticActions` class. The code below defines logic that anticipates the results of the query that we defined in the previous step. When there is a change that sends a new query to the server (for example, a new filter), this logic will be applied to the data already in the page's memory while we're waiting for the server's response.

    ```js
    const optimisticActions = useOptimisticActions(tableState.collection, 
      {
        orderBy: () => [],
          
        predicate: ({ search, filters }) => {
          return (product) => {
            if (search && !product.name?.startsWith(search)) {
              return false;
            }
      
            if (filters.productType && product.productType && filters.productType.indexOf(product.productType) === -1) {
              return false;
            }
      
            if (filters.lastUpdated && product.lastUpdated) {
              const from = filters.lastUpdated.from
              const to = filters.lastUpdated.to
              const productLastUpdated = (new Date(product.lastUpdated)).getTime()
      
              if (from && productLastUpdated < from.getTime()) {
                return false
              }
                
              if (to && productLastUpdated > to.getTime()) {
                return false
              }
            }
      
            return true;
          }
        },
      }
    );
    ```

    Let’s break down the above code:
  
    - **Line 3**: Define that there is no default sorting for the data, apart from what is defined in the query.
    - **Lines 5-31**: Define a function that simulates the filtering on the server, as defined in the `tableState` above. It returns a function that returns `true` if the product would pass the filters, and `false` if it wouldn't.
      - **Lines 7-9**: Return `false` if the product wouldn't pass the `search` filter.
      - **Lines 11-13**: Return `false` if the product wouldn't pass the `productType` filter.
      - **Lines 15-27**: Return `false` if the product wouldn't pass the `lastUpdated` filter.
      - **Line 29**: Return `true` if the product would pass all of the filters.


1. Define the `createProduct()` and `deleteProducts()` functions using the hooks we created in [Step 7](#step-7--create-hooks-for-our-sdk-calls):

    ```js
    const createProduct = useCreateProduct(optimisticActions);
    const deleteProducts = useDeleteProducts(optimisticActions);
    ```

At this stage, your `Products()` function should look like this:

```js
function Products() {
  const [shown, setShown] = useState(false);

  const { queryProducts, deleteProduct } = products;
  
  const tableState = useTableCollection<products.Product, TableFilters>({
    queryName: 'products-catalog',
    itemKey: (product: products.Product) => product._id!,
    itemName: (product: products.Product) => product.name!,
    limit: 20,
    
    fetchData: async (query) => {
      const { limit, offset, search, sort, filters } = query;
      
      const filter: any = {};
      
      if (search) {
        filter.name = { $startsWith: search };
      }
      
      if (filters) {
        const { productType, lastUpdated } = filters;

        if (productType) {
          filter.productType = { $in: productType };
        }

        if (lastUpdated) {
          if (lastUpdated.from || lastUpdated.to) {
            const dateFilter: any = {};
            
            if (lastUpdated.from) {
              dateFilter.$gt = lastUpdated.from;
            }
            
            if (lastUpdated.to) {
              dateFilter.$lt = lastUpdated.to;
            }
            
            filter.lastUpdated = dateFilter;
          }
        }
      }

      const sortArray: any[] = [];
      if (sort) {
        sort.forEach(s => {
          const fieldName = s.fieldName as SupportedQueryFields;
          sortArray.push({
            fieldName,
            order: s.order === 'asc' ? 'ASC' : 'DESC'
          });
        });
      }

      const queryObj: any = {
        query: {
          filter: Object.keys(filter).length > 0 ? filter : undefined,
          sort: sortArray.length > 0 ? sortArray : undefined,
          paging: {
            limit,
            offset
          }
        }
      };

      const { products: items = [], totalResults: total } = await queryProducts(queryObj);
      return { items, total };
    },
    
    fetchErrorMessage: () => 'Error fetching products',
    
    filters: {
      lastUpdated: dateRangeFilter(),
      productType: stringsArrayFilter({ itemName: (p) => productTypeToDisplayName[p] ?? p })
    },
  });

  const optimisticActions = useOptimisticActions(tableState.collection, 
    {
      orderBy: () => [],
      
      predicate: ({ search, filters }) => {
        return (product) => {
          if (search && !product.name?.startsWith(search)) {
            return false;
          }
  
          if (filters.productType && product.productType && filters.productType.indexOf(product.productType) === -1) {
            return false;
          }
  
          if (filters.lastUpdated && product.lastUpdated) {
            const from = filters.lastUpdated.from
            const to = filters.lastUpdated.to
            const productLastUpdated = (new Date(product.lastUpdated)).getTime()
  
            if (from && productLastUpdated < from.getTime()) {
              return false
            }
            
            if (to && productLastUpdated > to.getTime()) {
              return false
            }
          }
  
          return true;
        }
      },
    }
  );

  const createProduct = useCreateProduct(optimisticActions);
  
  const deleteProducts = useDeleteProducts(optimisticActions);

  return ()
}
```

#### Create the page structure

We define our page as follows:

1. Define the [`CollectionPage`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Fbase-components-page-layouts-collection-page--collectionpage) component that will wrap all our components on this page:

    ```js
    <CollectionPage height="100vh">
      // All page components will go here.
    </CollectionPage>
    ```

1. Add a [`CollectionPage.Header`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Fbase-components-page-layouts-collection-page--collectionpage-header) component that contains the page title, breadcrumbs, and a button that opens our **Add Product** modal:

    ```js
    <CollectionPage.Header
      title={{ text: 'Products' }}
      breadcrumbs={
        <Breadcrumbs
          activeId="2"
          items={[
            { id: '1', value: 'Apps', disabled: true },
            { id: '2', value: 'Products' },
          ]}
        />
      }
      primaryAction={
        <PrimaryPageButton
          text="Add Product"
          onClick={() => setShown(!shown)}
        />
      }
    />
    ```

1. Add a [`CollectionPage.Content`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Fbase-components-page-layouts-collection-page--collectionpage-content) component below the `CollectionPage.Header`. This will wrap the rest of the components on this page.

    ```js
    <CollectionPage.Content>
      // The rest of the page components will go here.
    </CollectionPage.Content>
    ```

1. Add the `CreateProductModal` component that we created in [Step 8](#step-8--create-a-create-product-modal):

    ```js
    <CreateProductModal showModal={shown} onSave={(productName: string) => {
      createProduct(productName);
      setShown(false);
    }}/>
    ```

1. Add a [`Table`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Fbase-components-collections-table-table--table) component.

    The following code displays a table containing our columns and fetched data. 
    When no items are selected, there is also a search bar, a button that opens an accordion to customize the columns displayed, and a button that opens an accordion to filter the data. 
    When at least one product is selected, the table displays the number of selected products, the maximum number of products that can be selected, a **Select All** option, and a **Delete** button.

    ```js
    <Table
      state={tableState}
      maxSelection={20}
      filters={
        <CollectionToolbarFilters>
          <RadioGroupFilter
            accordionItemProps={{ label: 'Type' }}
            filter={tableState.collection.filters.productType}
            data={[products.ProductType.physical, products.ProductType.digital]}
          />
          <DateRangeFilter
            filter={tableState.collection.filters.lastUpdated}
            accordionItemProps={{ label: 'Last Updated' }}
          />
        </CollectionToolbarFilters>
      }
          
      bulkActionToolbar={({ selectedValues, openConfirmModal }) => {
        const disabled = selectedValues.length > 20;
        return (
          <MultiBulkActionToolbar
            primaryActionItems={[
              {
                label: 'Delete',
                tooltip: disabled
                  ? 'Deleting is supported for up to 20 items'
                  : undefined,
                disabled,
                onClick: () => {
                  openConfirmModal({
                    theme: 'destructive',
                    primaryButtonOnClick: () => {
                      deleteProducts(selectedValues);
                    },
                  });
                },
              },
            ]}
          />)
      }}
          
      customColumns={<CustomColumns />}
      columns={[
        {
          id: 'avatar',
          name: 'Avatar',
          title: '',
          width: '72px',
          render: (product) => <Image src={product.media?.mainMedia?.image?.url}/>,
          reorderDisabled: true,
          hiddenFromCustomColumnsSelection: true
        },
        {
          id: 'name',
          title: 'Product / Description',
          render: (row: products.Product) => (
            <Box direction="vertical" gap="3px">
              <Text size="medium" weight="normal">
                {row.name}
              </Text>
              <Text size="tiny" weight="thin" secondary>
                {row.description}
              </Text>
            </Box>
          ),
          width: 'auto',
          reorderDisabled: true,
          hideable: false
        },
        {
          id: 'price',
          title: 'Price',
          render: (row: products.Product) => `$${row.priceData?.price}`,
          width: '100px',
          sortable: true,
        },
        {
          id: 'type',
          title: 'Type',
          render: (row: products.Product) => {
            if (!row.productType) {
              return ''
            }

            return productTypeToDisplayName[row.productType] ?? row.productType
          },
          width: '100px',
        },
        {
          id: 'last-updated',
          title: 'Last Updated',
          render: (row: products.Product) =>
            row.lastUpdated
              ? new Date(row.lastUpdated).toLocaleDateString()
              : '',
          width: '100px',
          defaultHidden: true,
        },
      ]}
          
      actionCell={(_product, _index, actionCellAPI) => ({
          secondaryActions: [
            deleteSecondaryAction({
              optimisticActions,
              actionCellAPI,
              submit: (products: products.Product[]) => (
                Promise.all(
                  products.map((product: products.Product) => deleteProduct(product._id!))
                )
              ),
              successToast: {
                message: `${_product.name} deleted successfully.`,
                type: 'SUCCESS',
              },
              errorToast: () => 'Product deletion failed.',
            }),
          ]
        }
      )}
    />
    ```

    Let's identify where some of our key functionality is implemented in the above code. For more information on all the `Table` props, see [Patterns Table Component](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Fbase-components-collections-table-table--table&tab=API).
    - **Lines 4-16**: Define the table's filters. We use a [`CollectionToolbarFilters`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-filter-components--toolbarfilters) component to display an accordion with the filtering options.
      - **Lines 6-10**: Define the **Type** filter. The [`RadioCollectionFilter`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-filter-components--radiogroupfilter) defines the way the filter options are displayed in the accordion. 
      - **Lines 11-14**: Define the **Last Updated** filter. The [`DateRangeFilter`](https://www.wix-pages.com/wix-patterns/?path=/story/features-filter-components--daterangefilter) defines the way the filter options are displayed in the accordion. 
    - **Lines 22-38**: Use the [`MultiBulkActionToolbar`](https://www.wix-pages.com/wix-patterns/?path=%2Fstory%2Ffeatures-actions-bulk-actions--multibulkactiontoolbar) component to create the button in the toolbar that deletes all selected products. When the button is clicked, the user is asked to confirm their decision in a modal (**line 30**). If the button is disabled, a message is displayed explaining why (**lines 26-28**).
    - **Lines 43-99**: Define the table's columns.
      - **Lines 44-52**: **Product avatar** - Use the [`Image`](https://www.wix-pages.com/wix-design-system/?path=/story/components-media--image) component from the Wix Design System and feed it the image URL from the product object's nested `media.mainMedia.image.url` field.
      - **Lines 53-69**: **Product name and description** - Use a `Box` for layout with direction set to `vertical` and gap to `3px`, indicating vertical stacking with a gap of 3px. Inside this box, add two `Text` components for the product's name and description.
      - **Lines 70-76**: **Product price** - Add the product's price prefixed with a dollar sign.
      - **Lines 77-88**: **Product type** - Add the product type, formatted using `productTypeToDisplayName` which we defined earlier. If there is no product type, return an empty string.
      - **Lines 89-98**: **Product last updated date** - Add the product's last updated date, formatted as a readable string.
    - **Lines 103-116**: Create a **Delete** button for each product (**line 108**). Add success (**lines 111-114**) and error (**line 115**) toasts.

Your page structure code should look like this:

```js
<CollectionPage height="100vh">
  <CollectionPage.Header
    title={{ text: 'Products' }}
    breadcrumbs={
      <Breadcrumbs
        activeId="2"
        items={[
          { id: '1', value: 'Apps', disabled: true },
          { id: '2', value: 'Products' },
        ]}
      />
    }
    primaryAction={
      <PrimaryPageButton
        text="Add Product"
        onClick={() => setShown(!shown)}
      />
    }
  />
  <CollectionPage.Content>
    <CreateProductModal showModal={shown} onSave={(productName: string) => {
      createProduct(productName);
      setShown(false);
    }}/>
        
    <Table
      state={tableState}
      maxSelection={20}
      filters={
        <CollectionToolbarFilters>
          <RadioGroupFilter
            accordionItemProps={{ label: 'Type' }}
            filter={tableState.collection.filters.productType}
            data={[products.ProductType.physical, products.ProductType.digital]}
          />
          <DateRangeFilter
            filter={tableState.collection.filters.lastUpdated}
            accordionItemProps={{ label: 'Last Updated' }}
          />
        </CollectionToolbarFilters>
      }
          
      bulkActionToolbar={({ selectedValues, openConfirmModal }) => {
        const disabled = selectedValues.length > 20;
        return (
          <MultiBulkActionToolbar
            primaryActionItems={[
              {
                label: 'Delete',
                tooltip: disabled
                  ? 'Deleting is supported for up to 20 items'
                  : undefined,
                disabled,
                onClick: () => {
                  openConfirmModal({
                    theme: 'destructive',
                    primaryButtonOnClick: () => {
                      deleteProducts(selectedValues);
                    },
                  });
                },
              },
            ]}
          />)
      }}
          
      customColumns={<CustomColumns />}
      columns={[
        {
          id: 'avatar',
          name: 'Avatar',
          title: '',
          width: '72px',
          render: (product) => <Image src={product.media?.mainMedia?.image?.url}/>,
          reorderDisabled: true,
          hiddenFromCustomColumnsSelection: true
        },
        {
          id: 'name',
          title: 'Product / Description',
          render: (row: products.Product) => (
            <Box direction="vertical" gap="3px">
              <Text size="medium" weight="normal">
                {row.name}
              </Text>
              <Text size="tiny" weight="thin" secondary>
                {row.description}
              </Text>
            </Box>
          ),
          width: 'auto',
          reorderDisabled: true,
          hideable: false
        },
        {
          id: 'price',
          title: 'Price',
          render: (row: products.Product) => `$${row.priceData?.price}`,
          width: '100px',
          sortable: true,
        },
        {
          id: 'type',
          title: 'Type',
          render: (row: products.Product) => {
            if (!row.productType) {
              return ''
            }

            return productTypeToDisplayName[row.productType] ?? row.productType
          },
          width: '100px',
        },
        {
          id: 'last-updated',
          title: 'Last Updated',
          render: (row: products.Product) =>
            row.lastUpdated
              ? new Date(row.lastUpdated).toLocaleDateString()
              : '',
          width: '100px',
          defaultHidden: true,
        },
      ]}
          
      actionCell={(_product, _index, actionCellAPI) => ({
          secondaryActions: [
            deleteSecondaryAction({
              optimisticActions,
              actionCellAPI,
              submit: (products: products.Product[]) => (
                Promise.all(
                  products.map((product: products.Product) => deleteProduct(product._id!))
                )
              ),
              successToast: {
                message: `${_product.name} deleted successfully.`,
                type: 'SUCCESS',
              },
              errorToast: () => 'Product deletion failed.',
            }),
          ]
        }
      )}
    />
  </CollectionPage.Content>
</CollectionPage>
```

#### Complete page code

Your complete code should look like this:

```js
import React, { useState } from 'react';
import {
  Box,
  Text,
  Image,
  Breadcrumbs
} from '@wix/design-system';
import '@wix/design-system/styles.global.css';
import { products } from '@wix/stores';
import { CollectionPage } from '@wix/patterns/page';
import {
  useTableCollection,
  Table,
  PrimaryPageButton,
  useOptimisticActions,
  deleteSecondaryAction,
  MultiBulkActionToolbar,
  CustomColumns,
  Filter,
  CollectionToolbarFilters,
  dateRangeFilter,
  RangeItem,
  DateRangeFilter,
  RadioGroupFilter,
  stringsArrayFilter,
} from '@wix/patterns';
import { withProviders } from '../withProviders';
import { useCreateProduct, useDeleteProducts } from '../hooks/stores';
import { CreateProductModal } from '../components/create-product';

type TableFilters = {
  productType: Filter<products.ProductType[]>;
  lastUpdated: Filter<RangeItem<Date>>;
}

type SupportedQueryFields = keyof products.Product

const productTypeToDisplayName: {[key in products.ProductType] : string | undefined} = {
  [products.ProductType.physical]: 'Physical',
  [products.ProductType.digital]: 'Digital',
  [products.ProductType.unspecified_product_type]: undefined
}

function Products() {
  const [shown, setShown] = useState(false);

  const { queryProducts, deleteProduct } = products;
  
  const tableState = useTableCollection<products.Product, TableFilters>({
    queryName: 'products-catalog',
    itemKey: (product: products.Product) => product._id!,
    itemName: (product: products.Product) => product.name!,
    limit: 20,
    
    fetchData: async (query) => {
      const { limit, offset, search, sort, filters } = query;
      
      const filter: any = {};
      
      if (search) {
        filter.name = { $startsWith: search };
      }
      
      if (filters) {
        const { productType, lastUpdated } = filters;

        if (productType) {
          filter.productType = { $in: productType };
        }

        if (lastUpdated) {
          if (lastUpdated.from || lastUpdated.to) {
            const dateFilter: any = {};
            
            if (lastUpdated.from) {
              dateFilter.$gt = lastUpdated.from;
            }
            
            if (lastUpdated.to) {
              dateFilter.$lt = lastUpdated.to;
            }
            
            filter.lastUpdated = dateFilter;
          }
        }
      }

      const sortArray: any[] = [];
      if (sort) {
        sort.forEach(s => {
          const fieldName = s.fieldName as SupportedQueryFields;
          sortArray.push({
            fieldName,
            order: s.order === 'asc' ? 'ASC' : 'DESC'
          });
        });
      }

      const queryObj: any = {
        query: {
          filter: Object.keys(filter).length > 0 ? filter : undefined,
          sort: sortArray.length > 0 ? sortArray : undefined,
          paging: {
            limit,
            offset
          }
        }
      };

      const { products: items = [], totalResults: total } = await queryProducts(queryObj);
      return { items, total };
    },
    
    fetchErrorMessage: () => 'Error fetching products',
    
    filters: {
      lastUpdated: dateRangeFilter(),
      productType: stringsArrayFilter({ itemName: (p) => productTypeToDisplayName[p] ?? p })
    },
  });

  const optimisticActions = useOptimisticActions(tableState.collection, 
    {
      orderBy: () => [],
      
      predicate: ({ search, filters }) => {
        return (product) => {
          if (search && !product.name?.startsWith(search)) {
            return false;
          }
  
          if (filters.productType && product.productType && filters.productType.indexOf(product.productType) === -1) {
            return false;
          }
  
          if (filters.lastUpdated && product.lastUpdated) {
            const from = filters.lastUpdated.from
            const to = filters.lastUpdated.to
            const productLastUpdated = (new Date(product.lastUpdated)).getTime()
  
            if (from && productLastUpdated < from.getTime()) {
              return false
            }
            
            if (to && productLastUpdated > to.getTime()) {
              return false
            }
          }
  
          return true;
        }
      },
    }
  );

  const createProduct = useCreateProduct(optimisticActions);
  
  const deleteProducts = useDeleteProducts(optimisticActions);

  return (
    <CollectionPage height="100vh">
      <CollectionPage.Header
        title={{ text: 'Products' }}
        breadcrumbs={
          <Breadcrumbs
            activeId="2"
            items={[
              { id: '1', value: 'Apps', disabled: true },
              { id: '2', value: 'Products' },
            ]}
          />
        }
        primaryAction={
          <PrimaryPageButton
            text="Add Product"
            onClick={() => setShown(!shown)}
          />
        }
      />
      <CollectionPage.Content>
        <CreateProductModal showModal={shown} onSave={(productName: string) => {
          createProduct(productName);
          setShown(false);
        }}/>
        
        <Table
          state={tableState}
          maxSelection={20}
          filters={
            <CollectionToolbarFilters>
              <RadioGroupFilter
                accordionItemProps={{ label: 'Type' }}
                filter={tableState.collection.filters.productType}
                data={[products.ProductType.physical, products.ProductType.digital]}
              />
              <DateRangeFilter
                filter={tableState.collection.filters.lastUpdated}
                accordionItemProps={{ label: 'Last Updated' }}
              />
            </CollectionToolbarFilters>
          }
          
          bulkActionToolbar={({ selectedValues, openConfirmModal }) => {
            const disabled = selectedValues.length > 20;
            return (
              <MultiBulkActionToolbar
                primaryActionItems={[
                  {
                    label: 'Delete',
                    tooltip: disabled
                      ? 'Deleting is supported for up to 20 items'
                      : undefined,
                    disabled,
                    onClick: () => {
                      openConfirmModal({
                        theme: 'destructive',
                        primaryButtonOnClick: () => {
                          deleteProducts(selectedValues);
                        },
                      });
                    },
                  },
                ]}
              />)
          }}
          
          customColumns={<CustomColumns />}
          columns={[
            {
              id: 'avatar',
              name: 'Avatar',
              title: '',
              width: '72px',
              render: (product) => <Image src={product.media?.mainMedia?.image?.url}/>,
              reorderDisabled: true,
              hiddenFromCustomColumnsSelection: true
            },
            {
              id: 'name',
              title: 'Product / Description',
              render: (row: products.Product) => (
                <Box direction="vertical" gap="3px">
                  <Text size="medium" weight="normal">
                    {row.name}
                  </Text>
                  <Text size="tiny" weight="thin" secondary>
                    {row.description}
                  </Text>
                </Box>
              ),
              width: 'auto',
              reorderDisabled: true,
              hideable: false
            },
            {
              id: 'price',
              title: 'Price',
              render: (row: products.Product) => `$${row.priceData?.price}`,
              width: '100px',
              sortable: true,
            },
            {
              id: 'type',
              title: 'Type',
              render: (row: products.Product) => {
                if (!row.productType) {
                  return ''
                }

                return productTypeToDisplayName[row.productType] ?? row.productType
              },
              width: '100px',
            },
            {
              id: 'last-updated',
              title: 'Last Updated',
              render: (row: products.Product) =>
                row.lastUpdated
                  ? new Date(row.lastUpdated).toLocaleDateString()
                  : '',
              width: '100px',
              defaultHidden: true,
            },
          ]}
          
          actionCell={(_product, _index, actionCellAPI) => ({
              secondaryActions: [
                deleteSecondaryAction({
                  optimisticActions,
                  actionCellAPI,
                  submit: (products: products.Product[]) => (
                    Promise.all(
                      products.map((product: products.Product) => deleteProduct(product._id!))
                    )
                  ),
                  successToast: {
                    message: `${_product.name} deleted successfully.`,
                    type: 'SUCCESS',
                  },
                  errorToast: () => 'Product deletion failed.',
                }),
              ]
            }
          )}
        />
      </CollectionPage.Content>
    </CollectionPage>
  );
}

export default withProviders(Products);
```

## Step 10 | Test the app

Now that the app’s code is ready, you can test it locally using the Wix CLI.

To test your app, do the following:

1. Run a local development server for your app using the `npm run dev` command in your terminal. Your app’s dashboard page will now look like this:

    ![App preview](https://wixmp-833713b177cebf373f611808.wixmp.com/images/976d25416ecf405f33e3711009f6963e.png)

1. Click the **Add Product** button and use the modal to add a product.
1. Select some products and click the **Delete** button.
1. If things don’t look right, open your browser’s developer tools and check for errors in the console.

## Step 11 | Build and deploy the app

You have now fully developed an app that allows users to add or remove products from a Wix Stores products catalog through a dashboard page.

After testing your app and seeing that it works as expected, you can [build and deploy your app](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli).
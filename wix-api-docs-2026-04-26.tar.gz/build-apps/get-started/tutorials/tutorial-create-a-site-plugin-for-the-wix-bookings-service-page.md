---
portal: build-apps
name: "Tutorial | Create a Site Plugin for the Wix Bookings Service Page"
type: ARTICLE_RESOURCE
resourceId: 5cdbeaee-a89e-4b84-8ff5-e36d21fb40b0
---

# Tutorial | Create a Site Plugin for the Wix Bookings Service Page

# Tutorial | Create a Site Plugin for the Wix Bookings Service Page

In this tutorial, we demonstrate how to create the **Next Booking Availability** [site plugin](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions) for the Wix Bookings Service page.
This site plugin displays the next available date for a site visitor to book a particular service. It is meant to be embedded in the Wix Bookings [Service page slot](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-bookings/wix-bookings-service-page#slots).

The end result will look something like this:

![next-availability-plugin-on-site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_next-availability-site.png)

We use the following steps to build the Next Booking Availability site plugin:

1. Create an app.
2. Design your plugin in Wix Blocks.
3. Code your plugin in Wix Blocks.

## **Before you begin**

* Make sure you're logged into your Wix account, or [create an account](https://www.wix.com/) if you don't have one yet.
* If you haven't done so yet, move to the new Wix Studio workspace by [joining Wix Studio](https://support.wix.com/en/article/wix-studio-switching-to-wix-studio).

## Step 1 | Open the Wix Studio workspace and create an app

You can access Wix Blocks through the Wix Studio workspace.

1. Open the [Wix Studio workspace](https://manage.wix.com/studio/).
2. Click **Custom Apps** in the left menu.
3. Click **Create New App** and then select **Build from scratch**.
4. When prompted to choose a framework, select **Wix Blocks**.  
   Your newly-created app opens in Wix Blocks.

## Step 2 | Design your plugin’s UI

We now design our plugin in Wix Blocks:

1. Open the **Widgets and Design** panel, click ![add-plugin-icon](https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_add-plugin-icon.png), and select **Add Plugin**.
2. In the **Add a plugin panel**, set up the plugin as follows:  
   * **Plugin name**: `Next Availability`
   * **Which Wix app does it extend?**: `Wix Bookings`
   * **Slots this plugin can be added to**: `slot 1 (Service Page)`
3. Click **Create**.
4. Let's add a text element to the plugin.  
   Click **Add Elements** ![add-elements-icon](https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_add-elements-icon.png) on the left side of the editor, and then click **Title**.

5. Next, we want to make sure that the text stretches across the entire width of the plugin. When the plugin is added to a site, we want the text to stretch across the entire width of the Wix Service page slot.  
   Select the text element. In the Inspector panel on the right, click the **Layout** tab, and set the element's width to **100%**.

    <details>
    <summary><strong>See how it looks</strong></summary>
    <img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_blocks-layout.png"/>
    </details>

6. Still in the Inspector panel, click the **Design** tab, and set the text alignment to **Center align**.

## Step 3 | Code your plugin

We now write the code for our plugin. The code checks the availability of a specific service for the upcoming year, and updates the text element with the next available date for a site visitor to book the service.

1. Before coding our plugin, we need to connect our plugin to the host widget (in our case, the Wix Bookings Service page) by implementing the [`BOOKINGS_SERVICE`](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/wix-bookings/wix-bookings-service-page#bookings_service) API.  
   To do so, add the `bookingsServiceId` property to your plugin's public API.  
   In the code panel, click the **Widget Public API** ![widget-api-con](https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_widget-api-icon.jpeg) icon, and then click **Add New Property**.

    <details>
    <summary><strong>See how it looks</strong></summary>
    <img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_blocks-add-property-bookings.png"/>
    </details>

2. In the **New Property** panel, name the property `bookingsServiceId`, and then click **Create**.

3. In the code editor, add the following import statement at the beginning of your code to use Wix Bookings APIs:  
   `import wixBookingsFrontend from 'wix-bookings-frontend';`

4. Make the `$widget.onPropsChanged()` function asynchronous by adding the `async` keyword:  
   `$widget.onPropsChanged(async (oldProps, newProps) => {`
   
5. Inside the `$widget.onPropsChanged()` code block, add the following line to get the current service ID from the host widget:  
   `const serviceId = newProps.bookingsServiceId;`

   This ID identifies the service for which the availability will be checked.

6. Set up the date range for our availability query, with a `startRange` and an `endRange` that spans one year from the current date:
   ```javascript
   let startRange = new Date();
   let endRange = new Date();
   endRange.setDate(startRange.getDate() + 365);
   ```

7. Use the Wix Bookings [`getServiceAvailability()`](https://www.wix.com/velo/reference/wix-bookings-frontend/getserviceavailability) API to query the availability for the specified service (`serviceId`) within the defined date range (`rangeOptions`):
   ```javascript
   const rangeOptions = {
         startDateTime: startRange,
         endDateTime: endRange
   };
   const availability = await wixBookingsFrontend.getServiceAvailability(serviceId, rangeOptions);
   ```

8. Extract the available slots from the returned object and get the first available slot's date:
   ```javascript
   const slots = availability.slots;
   const options = { weekday: 'long', day: 'numeric', month: 'short' };
   const firstSlotDate = slots[0].startDateTime.toLocaleDateString('en-US', options);
   ```

9. Change our text element to display the message "Next availability:" followed by the formatted date of the first available slot:  
   ```javascript
   $w('#text1').text = "Next availability: " + firstSlotDate;
   ```
    Here's the complete code:

   ```javascript
   import wixBookingsFrontend from 'wix-bookings-frontend';
   
   $widget.onPropsChanged(async (oldProps, newProps) => {
      const serviceId = newProps.bookingsServiceId;
   
      let startRange = new Date();
      let endRange = new Date();
      endRange.setDate(startRange.getDate() + 365); // one year from now
   
      // get the service availability for the upcoming year
      const rangeOptions = {
         startDateTime: startRange,
         endDateTime: endRange
      };
      const availability = await wixBookingsFrontend.getServiceAvailability(serviceId, rangeOptions);
      const slots = availability.slots;
   
      // get the date of the first available slot
      const options = { weekday: 'long', day: 'numeric', month: 'short' };
      const firstSlotDate = slots[0].startDateTime.toLocaleDateString('en-US', options);
   
      $w('#text1').text = "Next availability: " + firstSlotDate; // set the text element's content 
   });
   ```

9. In the top-right corner, click **Build**. When prompted to provide an app name, enter "Booking Availability" and then click **Save & Continue**.

10. When prompted to select the type of version to build, select **Test version**.  

Our plugin is now ready for use. In the next step, we add our plugin to a site to see it in action.

## Step 4 | See your plugin in action

Plugins that you develop are immediately available for installation on your own sites, using the plugin explorer in the editors.

Go ahead and create a new site, and then install Wix Bookings. Alternatively, use [this site template](https://manage.wix.com/edit-template/from-intro?debug=all&originTemplateId=85dec86a-afc8-41cb-8a86-c12d4a525fe5), which already has Wix Bookings installed.

1. Open your editor. In the left sidebar, click **Pages** ![pages-icon](https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_pages-icon.png), and go to **Booking Pages > Service Page**.
2. On the Service page, click the page's widget, and then click the Plugins ![plugin icon](https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_plugin-icon.png) icon.

    <details>
    <summary><strong>See how it looks</strong></summary>
    <img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/plugin-tutorial-next-availability-md_build-apps-portal_get-started_resources_tutorials_bookings-plugin-tutorial_images_plugin-gfpp-bookings.png"/>
    </details>

    Your plugin should appear in the plugin explorer.

3. Hover over your plugin, and then click **Add**.  
   When prompted for consent, select the checkbox and click **Agree & Add**.

Once you install your plugin on a site, you can preview or publish the site to test the plugin's functionality and make sure it's working properly.

> **Note**: The Service page lets you reposition the plugin within the page's layout by [reordering the Service page sections](https://support.wix.com/en/article/wix-bookings-customizing-your-service-pages).
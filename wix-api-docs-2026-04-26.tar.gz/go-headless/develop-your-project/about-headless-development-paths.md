---
portal: go-headless
name: "About Headless Development Paths"
type: ARTICLE_RESOURCE
resourceId: f259a16a-69c2-43c5-84d9-dfdcd3febf3b
---

# Headless Development Paths

# About Headless Development Paths

Wix Headless enables you to build custom frontends using any technology stack, while leveraging Wix's business management platform. There are 2 headless development paths you can take to connect your custom frontend to Wix's backend services. Each path determines how much of the setup, configuration, and hosting you manage yourself, and how much Wix automates for you. The right path for you depends on your technical preferences, project requirements, and desired level of control. Understanding these development paths helps you choose the best approach for your project's needs.

Wix Headless supports 2 main development paths:

- Wix-managed headless
- Self-managed headless

## Wix-managed headless

Take advantage of a fully Wix-managed solution for developing and hosting your headless project. Wix handles hosting, authentication, and infrastructure, so you can focus on building your frontend and business logic.

You can work with Wix-managed headless projects in 2 ways:
+ **Wix CLI**: A code-first approach. The [CLI](https://dev.wix.com/docs/go-headless/cli-for-headless/about-the-wix-cli-for-headless) scaffolds an [Astro](https://astro.build/)-based project with automatic authentication and environment variable setup. You develop locally in your IDE and deploy through the command line. Built on Astro, you can use components from React, Vue, Svelte, or Solid.
+ **Wix Vibe**: A UI-based approach. [Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe) lets you create and edit your project using conversational AI prompts, without writing code.

You can move between Vibe and CLI development:

+ **Vibe → CLI**: Projects started in Vibe can always be opened locally and developed with the CLI.
+ **CLI → Vibe**: Projects created with the CLI using [Vibe-compatible templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates) can be connected to Vibe for AI-powered visual editing through conversational prompts.

Use this path when you want the fastest, most automated experience and are happy using Wix's recommended stack and hosting. It's a good fit for new projects where you want Wix to handle as much as possible, including hosting, authentication, and infrastructure.

To learn more about what Wix-managed headless provides, including the architecture, authentication model, extensions, and development workflow, see [About Wix-Managed Headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless).

## Self-managed headless

Build your own frontend from scratch with any framework or platform, and connect it directly to Wix's backend using the [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) or the [REST API](https://dev.wix.com/docs/rest). You're responsible for all configuration, authentication, and hosting.

Use this path when you need maximum flexibility and control. This approach supports integrating Wix business logic into existing sites, using any development framework, and building highly customized solutions.

## Comparison of development paths

| **Feature**                                                  | **Self-managed headless** | **Wix-managed headless** |
|--------------------------------------------------------------|---------------------------|--------------------------|
| Use any frontend framework                                   | ✓                         |                          |
| Use any hosting or deployment solution                       | ✓                         |                          |
| Astro-based frontend with React, Vue, Svelte, or Solid       |                           | ✓                        |
| Wix JavaScript SDK integration                               | ✓                         | ✓                        |
| Automatic Wix Client configuration                           |                           | ✓                        |
| Automatic project scaffolding                                |                           | ✓                        |
| Automatic environment variable setup                         |                           | ✓                        |
| Wix-managed hosting with global CDN, SSL, and auto-scaling   |                           | ✓                        |
| App extensions for custom backend logic and dashboard features |                           | ✓                        |
| AI-powered bootstrapping with Wix Vibe                      |                           | ✓                        |
| Multilingual support                                        |                           | ✓                        |

## See also

- [About Wix Headless](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless)
- [About Wix-Managed Headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless)
- [About Self-Managed Headless](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless)
- [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
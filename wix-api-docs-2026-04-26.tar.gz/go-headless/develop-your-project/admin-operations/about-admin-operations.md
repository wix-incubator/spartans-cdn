---
portal: go-headless
name: "About Admin Operations"
type: ARTICLE_RESOURCE
resourceId: 5f44a09e-4f2f-4769-9d9e-03bb5ad925af
---

# About Admin Operations

# About Admin Operations

Admin operations are backend API calls that require elevated permissions to access or modify business data across your project. These operations use API keys for authentication instead of OAuth, and are useful for building dashboards, automation scripts, and backend services.

Admin operations work the same way in both [Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless) and [self-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless) projects.

## Use cases

Use admin operations to perform actions that affect data beyond the current visitor's session:

- Create, approve, or delete site members.
- Add products to your store or update inventory.
- Update order status, issue refunds, or fulfill orders.
- Confirm, cancel, or reschedule bookings.
- Query all orders, members, or bookings across your project.

## API key authentication

API keys grant a custom set of permissions to your backend code. Unlike OAuth tokens that represent a specific visitor or member, API keys represent administrative access to your project.

To get started with API key authentication:

- [Generate an API key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/generate-an-api-key)
- [Create a JavaScript SDK Client with an API Key (JavaScript)](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/create-a-client-with-an-api-key)
- [Make API calls with an API key (REST)](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/make-rest-api-calls-with-an-api-key)

<blockquote class="important">

**Important:** Make sure to store your API keys securely and only use them in backend code.

</blockquote>

## See also

- [Generate an API Key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/generate-an-api-key)
- [Create a JavaScript SDK Client with an API Key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/create-a-client-with-an-api-key)
- [Make REST API Calls with an API Key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/make-rest-api-calls-with-an-api-key)
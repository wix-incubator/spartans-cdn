---
portal: go-headless
name: "Create a JavaScript SDK Client with an API Key"
type: ARTICLE_RESOURCE
resourceId: 0a2215ce-7c06-4324-999f-13cb72882812
---

# Create a Client with an API Key

# Create a JavaScript SDK Client with an API Key

Once you've [generated an API key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/generate-an-api-key) and obtained the IDs for your Wix account or Wix site, you can use them to create an SDK client that can perform [admin operations](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/identities#admin-authentication).

<blockquote class="important">

**Important:** To implement this flow, you must install Node.js version 18 or higher. 
</blockquote>

## Step 1 | Install packages

Install `@wix/sdk` and the packages for the domain-specific APIs you wish to work with. Domain-specific packages follow the naming convention `@wix/{domain}`. For example:

```console
npm install @wix/sdk
npm install @wix/stores
```

or

```console
yarn add @wix/sdk
yarn add @wix/stores
```

## Step 2 | Import modules

To use the APIs you have installed, import `createClient` from the `@wix/sdk` package along with an authentication strategy, and import functionality from the desired domain-specific packages you installed. For example:

```js
import { createClient, ApiKeyStrategy } from "@wix/sdk";
import { contacts } from "@wix/contacts";
import { collections, products } from "@wix/stores";
```

## Step 3 | Create a client

To get started connecting an external client with a Wix site, use the [`createClient()`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client) function imported from the `@wix/sdk` package.

```js
const myWixClient = createClient({
  auth: ApiKeyStrategy({
    apiKey: "<API_KEY>",
    siteId: "<SITE_ID>",
    accountId: "<ACCOUNT_ID>",
  }),
  modules: {
    contacts: contacts.contacts,
    products: stores.products,
  },
});
```

The `createClient()` function returns a new Wix client.

- The `modules` parameter property contains key:value pairs. Each value is an imported module you wish to enable in the client, and the key defines the name to use for working with that module.
- The `auth` parameter property contains the authentication method and credentials for connecting with your Wix project. To create a client for your Wix project, pass `ApiKeyStrategy()` with an object containing:
  - `apiKey`: An API key that you generated in the [API Key Manager](https://manage.wix.com/account/api-keys).
  - `siteId`: ID of the Wix site or project you are working with. Required for site-level API calls.
  - `accountId`: ID of the Wix account the API key belongs to. Required for account-level API calls.

Once you have created a client successfully, you can begin using it to call functions in the API Reference.

## Example

```javascript
import { createClient } from "@wix/sdk";
import { products } from "@wix/stores";

const myWixClient = createClient({
  auth: ApiKeyStrategy({
    apiKey: "<API_KEY>",
    siteId: "<SITE_ID>",
    accountId: "<ACCOUNT_ID>",
  }),
  modules: {
    cart,
    products,
  },
});

// ...

const { items } = await myWixClient.products
  .queryProducts({
    filter: { 
      name: { $startsWith: "shoes" } 
    },
    cursorPaging: { limit: 4 }
  });
```
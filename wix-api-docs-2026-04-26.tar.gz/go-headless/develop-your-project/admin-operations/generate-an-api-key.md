---
portal: go-headless
name: "Generate an API Key"
type: ARTICLE_RESOURCE
resourceId: b810a32e-8d73-4d88-b19c-b64f1db0a990
---

# Generate an API Key for Admins

# Generate an API Key

Generate an [API key](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication#admin-authentication) to grant [admin access](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/about-admin-operations) to your Wix account and site data.

To generate an API key:

1. Go to the [API Keys Manager](https://manage.wix.com/account/api-keys) to enable an authorized external client to access and manage data belonging to your Wix account, its projects and sites. You can assign a set of permissions that determine the types of APIs each key can access.

    <blockquote class="important">

    **Important:** Make sure to store your API keys securely and use them only in server-side code.
    </blockquote>

2. Retrieve a Site ID or Account ID

When using an API Key authentication strategy you need to provide either a Site ID, your Account ID, or both.

- You can extract a Site ID from the URL in your browser when accessing the project or site dashboard. The site ID appears after **/dashboard/** in the URL.
- You can retrieve your Account ID from the [API Keys Manager](https://manage.wix.com/account/api-keys) in your account settings.

## See also 
- [About Authentication](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication#admin-authentication)
- [About Admin Operations](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/about-admin-operations)
- [Make REST API Calls with an API Key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/make-rest-api-calls-with-an-api-key)
- [Create a JavaScript SDK Client with an API Key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/create-a-client-with-an-api-key)
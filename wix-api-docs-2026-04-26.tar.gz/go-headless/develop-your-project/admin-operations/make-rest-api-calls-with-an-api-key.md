---
portal: go-headless
name: "Make REST API Calls with an API Key"
type: ARTICLE_RESOURCE
resourceId: d38ccf85-dc17-4e2a-8f54-7e51d137e31c
---

# Make API Calls with an API Key

# Make REST API Calls with an API Key

Once you've [generated an API key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/generate-an-api-key) and obtained the IDs for your Wix account or Wix site, you can authenticate and perform [admin operations](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/identities#admin-authentication) with the REST API.

## Set authorization headers

To make an API call using an API key, include the key from the [API Key Manager](https://manage.wix.com/account/api-keys) in the `Authorization` header. You must also include one of the following headers, depending on the type of call:

- `wix-account-id`: The ID of the Wix account that owns the API key. Required for account-level API calls.
- `wix-site-id`: The ID of the Wix site or project you're working with. Required for site-level API calls.

> **Notes**:
> * API calls require either the `wix-account-id` header or the `wix-site-id` header, but not both. Most APIs are site-level, while account-level APIs are specified as such in the reference documentation.
> * Site-level calls only work with API keys generated from the site owner's account.

A complete header for an account-level API request looks like this:

```sh
curl <GET/POST> \
  '<endpoint>' \
  -H 'Authorization: <API_KEY>' \
  -H 'wix-account-id: <ACCOUNT_ID>' \
```

A complete header for a site-level API request looks like this:

```sh
curl <GET/POST> \
  '<endpoint>' \
  -H 'Authorization: <API_KEY>' \
  -H 'wix-site-id: <SITE_ID>' \
```

## Example request

This API call retrieves a list of products from a specific site. To make this call, you need an API key and the ID of the site you are querying.

```sh
curl POST \
'https://www.wixapis.com/stores/v1/products/query' \
-H 'Content-Type: application/json' \
-H 'Accept: application/json, text/plain, */*' \
-H 'Authorization: <API_KEY>' \
-H 'wix-site-id: <SITE_ID>' \
-d '{
      "query": {
        "filter": "{\"paymentStatus\":\"PAID\"}",
        "sort": "{\"number\": \"desc\"}",
        "paging": {
          "limit": "50"
        }
      }
    }'
```
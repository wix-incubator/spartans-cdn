---
portal: go-headless
name: "About Business Flows"
type: ARTICLE_RESOURCE
resourceId: 1c3f1638-f749-4356-8fe9-9d78ac6fdfed
---

# About Wix Managed Business Flows

# About Business Flows

Wix Headless provides access to [business solutions](https://dev.wix.com/docs/go-headless/get-started/about-headless/wix-headless-business-solutions) like eCommerce, Bookings, and Events. For certain processes that require a user interface like checkout or booking confirmation, you can redirect visitors to Wix-hosted pages instead of building them yourself. These pre-built pages handle the specific business logic, then redirect visitors back to your site or app.

> **Note:** you can use Wix-managed business flows in both Wix-managed and self-managed headless projects.

## Domain configuration

To use Wix-managed business flows, you must set up your domains:

- Approve domains that Wix can redirect visitors back to by [adding allowed redirect domains](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/add-allowed-redirect-domains).
- Set the domain users see in their browser by [setting a Wix page domain](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/set-a-wix-pages-domain).

## Available business flows

Each business flow provides a complete, pre-built solution that you can use with your headless project. The following are the available types of Wix-managed business flows:

- **Booking page**: Service details and scheduling page from [Wix Bookings](https://dev.wix.com/docs/api-reference/business-solutions/bookings/introduction).
- **Bookings checkout**: Checkout page for booking a service from [Wix Bookings](https://dev.wix.com/docs/api-reference/business-solutions/bookings/introduction).
- **eCommerce checkout**: Checkout page for a shopping cart from [Wix eCommerce](https://dev.wix.com/docs/api-reference/business-solutions/e-commerce/introduction).
- **Events checkout**: Checkout page for event ticket purchases from [Wix Events](https://dev.wix.com/docs/api-reference/business-solutions/events/introduction).
- **Paid plans checkout**: Checkout page for subscription plans from [Wix Pricing Plans](https://dev.wix.com/docs/api-reference/business-solutions/pricing-plans/introduction).
- **Product page**: Product details page from [Wix Stores](https://dev.wix.com/docs/api-reference/business-solutions/stores/introduction).

## Implementation 

You can redirect to Wix-managed business flows from your headless project using either the [JS SDK](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/redirect-to-wix-pages-using-the-js-sdk) or [REST API](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/redirect-to-wix-pages-using-the-rest-api). Both methods use the [Create Redirect Session API](https://dev.wix.com/docs/api-reference/business-management/headless/redirects/create-redirect-session) to handle the redirection process.

## See also

- [Headless Redirects: Sample Flows](https://dev.wix.com/docs/api-reference/business-management/headless/redirects/sample-flows)
- [E-commerce Quick Start](https://dev.wix.com/docs/go-headless/resources/tutorials/self-managed-headless/java-script-sdk-tutorials/e-commerce-quick-start)
- [Bookings Quick Start](https://dev.wix.com/docs/go-headless/resources/tutorials/self-managed-headless/java-script-sdk-tutorials/bookings-quick-start)
- [Pricing Plans Quick Start](https://dev.wix.com/docs/go-headless/resources/tutorials/self-managed-headless/java-script-sdk-tutorials/pricing-plans-quick-start)
- [Events Quick Start](https://dev.wix.com/docs/go-headless/resources/tutorials/self-managed-headless/java-script-sdk-tutorials/events-quick-start)
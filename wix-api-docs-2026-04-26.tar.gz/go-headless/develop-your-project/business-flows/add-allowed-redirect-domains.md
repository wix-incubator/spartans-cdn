---
portal: go-headless
name: "Add Allowed Redirect Domains"
type: ARTICLE_RESOURCE
resourceId: fefc7f57-7026-405a-bf12-6aab0bebcde3
---

# Allowed Redirect Domains

# Add Allowed Redirect Domains

If you use Wix-managed pages for processes such as checkout, Wix returns the visitor to your site or app after the process is completed. To protect data security, Wix only ever redirects visitors to addresses you approve.

For non-authorization related redirects, you provide a domain to allow redirects to all URLs under that domain.

> Authorization related redirects require exact matching URIs. To set allowed authorization redirect URIs, see [Allowed Authorization Redirect URIs](https://github.com/wix-private/developer-docs/blob/4a6b193b770190b06d0deb3890176c6a296e2360/headless-docs/setup/allow-auth-redirect-uri.md*original::./allow-auth-redirect-uri.md).

To add **Allowed redirect domains** for non-authorization redirects:

1. In your project dashboard, go to **Settings** > **Development & integrations** > [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

1. From **Headless clients**, click the three dots to the right of the OAuth app you want to edit. Choose **Settings** to open the app's settings page:

   ![Click OAuth App Settings](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f0f48aae7502e57cc89cdb6a46a2d383.png)

1. Scroll down to the **URLs** section and go to the **Allowed redirect domains** section.

   ![Allowed Redirect Domains Section](https://wixmp-833713b177cebf373f611808.wixmp.com/images/54114c57c37e71de6e5fbb227aca6ccd.png)

1. Click **Add Redirect Domain** and enter a domain you authorize Wix to redirect back to from Wix-managed pages. For example, `www.my-site.com` authorizes all URLs under this domain. To authorize multiple domains, click **Add Redirect Domain** again as many times as you need.

1. Click **Save** to save your changes and return to the main **Headless Settings** page.
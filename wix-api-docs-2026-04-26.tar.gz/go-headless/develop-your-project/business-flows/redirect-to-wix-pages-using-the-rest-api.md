---
portal: go-headless
name: "Redirect to Wix Pages Using the REST API"
type: ARTICLE_RESOURCE
resourceId: e4dafa28-2190-40ec-bb65-f70e45d5f0a7
---

# Redirect to Wix Pages

# Redirect to Wix-Managed Pages Using the REST API

 

Wix Headless provides you with the flexibility to create an app or site on any platform and take advantage of Wix's backend business solutions via APIs. However, for certain processes, such as authentication and checkout, you can save time and effort by redirecting visitors to frontend pages Wix implements for you.

For example, your site can temporarily redirect a visitor to a Wix-managed page for authentication or for a checkout process for a Bookings, eCommerce, Events, or Paid Plans transaction. When the process is over, Wix redirects the visitor back to your external site.

For instructions on redirecting to Wix for authorization, login, and logout, see [Handle Members with Managed Login](https://github.com/wix-private/developer-docs/blob/c14ef56100997dd3ac61188110aef9a4eb235d7f/headless-docs/coding/rest/members-managed-login.md*original::./members-managed-login.md).

To take advantage of Wix's checkout services, you need to redirect to a Wix-managed checkout page using the [Redirects API](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/introduction).

## Before you begin

Make sure to complete the following:

- [Create a project](https://github.com/wix-private/developer-docs/blob/c14ef56100997dd3ac61188110aef9a4eb235d7f/headless-docs/setup/create-a-project.md*original::../../setup/create-a-project.md)
- [Create an OAuth app for visitors and members](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/create-an-oauth-app)
- [Add a Wix pages domain](https://github.com/wix-private/developer-docs/blob/c14ef56100997dd3ac61188110aef9a4eb235d7f/headless-docs/setup/custom-domains.md*original::../../setup/custom-domains.md)
- [Add an allowed redirect domain](https://github.com/wix-private/developer-docs/blob/c14ef56100997dd3ac61188110aef9a4eb235d7f/headless-docs/setup/allow-redirect-domains.md*original::../../setup/allow-redirect-domains.md)

## Redirect flow

To use Wix-managed checkout services:

1. [Get the data you need for the redirection](#step-1--get-the-data-you-need-for-the-redirection)
2 [Determine the post-flow URL](#step-2--determine-the-post-flow-url)
3. [Use the Redirects API to get a custom redirect session URL](#step-3--use-the-redirects-api-to-get-a-custom-redirect-session-url)
4. [Redirect your visitor to the URL provided](#step-4--redirect-your-visitor-to-the-url-provided)
5. [Handle the next stage in your visitor flow](#step-5--handle-the-next-stage-in-your-visitor-flow)

## Step 1 | Get the data you need for the redirection

Determine which checkout service you need. For example, Bookings, eCommerce, Events, or Paid Plans.

In the documentation for [`Create Redirect Session`](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/create-redirect-session), find the body parameter matching the checkout type you need. For example, `eventsCheckout` or `ecomCheckout`.

In the property descriptions, find the APIs you can use to get the information you need to send to [Create Redirect Session](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/create-redirect-session). For example, for `eventsCheckout` you can use [`Query Events`](https://dev.wix.com/docs/rest/business-solutions/events/events-v3/query-events) and [`Create Reservation`](https://dev.wix.com/docs/rest/business-solutions/events/orders/create-reservation) and for `ecomCheckout` you can use [`Create Checkout`](https://dev.wix.com/docs/rest/business-solutions/e-commerce/checkout/create-checkout).

Call whichever APIs are appropriate for obtaining the data you need for the desired checkout.

## Step 2 | Determine the post-flow URL

To implement a redirect session, it's essential to identify the destination for visitors on your external site once the Wix-managed flow concludes.

When developing your external site or app, determine a post-flow URL. This is the URL your visitors will be redirected back to when the Wix-managed flow is over.

For greater customization, you may also provide callback URLs for specific purposes, such as a custom thank you page on your external site. If you don't provide this, a standard page is used. See [`Create Redirect Session`](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/create-redirect-session) for details.

> **Note:** Wix returns visitors to a URL you provide only if its domain has been authorized in advance. The URL must be under an [allowed redirect domain](https://github.com/wix-private/developer-docs/blob/c14ef56100997dd3ac61188110aef9a4eb235d7f/headless-docs/setup/allow-redirect-domains.md*original::../../setup/allow-redirect-domains.md).

## Step 3 | Use the Redirects API to get a custom redirect session URL

You now have the information you need to generate a URL for a Wix-managed checkout.

To generate the redirect session URL, call [`Create Redirect Session`](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/create-redirect-session). Pass the data needed for your redirect session type. Also pass your post-flow URL and any optional callback URLs in the `callbacks` parameter.

For example, if you're performing an eComm checkout, pass the `checkoutId` in the `ecomCheckout` property of the body and the `postFlowUrl` in the `callbacks` property.

```curl
curl -X POST 'https://www.wixapis.com/redirect-session/v1/redirect-session' \
  -H 'authorization: <AUTH>' \
  -d '{
     "ecomCheckout": {
        "checkoutId": "7d2b240c-5c60-4580-8bc3-948bca6b4e4e"
     },
     "callbacks": {
        "postFlowUrl": "https://www.my-store.com"
     }
  }'
```

The response contains a single-use redirect session URL in `redirectSession.fullUrl`.

```json
{
  "redirectSession": {
    "id": "<REDIRECT_SESSION_ID>",
    "fullUrl": "https://www.checkout.my-site.com/checkout?appSectionParams=%7B%22checkoutId%22%3A%227d2b240c-5c60-4580-8bc3-948bca6b4e4e%22%7D&headlessExternalUrls=~%28home~%27https*3a*2f*2fwww.my-store.com*%29"
  }
}
```

## Step 4 | Redirect your visitor to the URL provided

Redirect your visitor to the URL returned by [`Create Redirect Session`](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/create-redirect-session). The URL contains the information needed for Wix to process the checkout, including the post-flow URL to redirect the visitor back to on your external site.

> **Note:** You can customize the domain that visitors see when your external site redirects them to Wix-managed pages. Learn how to [connect a domain for Wix-managed pages](https://github.com/wix-private/developer-docs/blob/c14ef56100997dd3ac61188110aef9a4eb235d7f/headless-docs/setup/custom-domains.md*original::../../setup/custom-domains.md).

## Step 5 | Handle the next stage in your visitor flow

Wix redirects the visitor back to the URL (or URLs) you provided, so make sure to implement the next stage in your flow at this address.

Upon redirecting back to your site, Wix includes a `wixMemberLoggedIn` boolean query parameter. If set to true, this indicates that a visitor successfully logged in during the preceding Wix-managed process.

Additionally, Wix passes specific query parameters depending on the checkout type. For details, refer to `callbacks` in [`Create Redirect Session`](https://dev.wix.com/docs/rest/business-management/headless-authentication/redirects/create-redirect-session).
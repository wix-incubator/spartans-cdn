---
portal: go-headless
name: "Set a Wix Pages Domain"
type: ARTICLE_RESOURCE
resourceId: 525a6271-a33b-49e7-a789-81a0fa7cbe66
---

# Wix Pages Domain

# Set a Wix Pages Domain

Wix Headless provides you with the flexibility to create an app or site on any platform and take advantage of Wix's business solutions via APIs. However, for some processes, such as authentication and checkout, you can save time and effort by using standard pages Wix implements for you. These Wix-managed pages are incorporated into the flow of your external site.

If you use Wix-managed pages for processes such as login and checkout, the **Wix pages domain** will be the domain visitors see when going to those pages.

To set your **Wix pages domain**:

1. In your project dashboard, go to **Settings** > **Development & integrations** > [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

1. On the **Headless Settings** page, scroll down to the **Manage URLs** section.

1. In the **Wix pages domain** section, you can view your free Wix domain, and you can customize the path that visitors see. For example, if your free Wix domain is `http://sandrasworld.wixsite.com/` and you enter the path `my-project`, visitors are taken to `http://sandrasworld.wixsite.com/my-project`.

1. If you've purchased a premium plan, click **custom domain** to connect a unique web address you like, instead of your free Wix domain. Follow the instructions to either connect a domain you already own or purchase a new domain.

   You may wish to connect a subdomain of your external site's domain, to make visitors' experience seamless. For example, if your external site is at `my-external-site.com`, you can make `portal.my-external-site.com` the URL that visitors see when they are redirected to a Wix-managed page. (**Note:** You can connect a subdomain of your external site's domain, but you can't connect your external site's domain itself.)
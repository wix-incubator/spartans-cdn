---
portal: go-headless
name: "Add a Frontend Link for Marketing Campaigns"
type: ARTICLE_RESOURCE
resourceId: 553509a6-4b53-45cd-a50d-850c68eaf589
---

# Frontend Link

# Add a Frontend Link for Marketing Campaigns

Wix offers powerful solutions for communicating with your customers via [marketing emails](https://www.wix.com/features/email-marketing). These emails typically include a link to your site.

To choose a URL for the links in emails your customers receive:

1. In your project dashboard, go to **Settings** > **Development & integrations** > [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

1. Under **Manage URLs**, go to the **Frontend link** section and click **Add Link**.

   ![Click "Add link"](https://wixmp-833713b177cebf373f611808.wixmp.com/images/704721d557f7e6cd8de0f3a0996e8cdc.png)

1. In the modal that opens, enter the URL for your site's frontend presence, then click **Add**. This URL will be used for links to your site in emails your customers receive.

   ![Enter your frontend URL](https://wixmp-833713b177cebf373f611808.wixmp.com/images/9ba8976735a86e72cc742781956223d5.png)

1. If you successfully set the frontend link for your project, you'll see it under **Frontend link**. You can edit the link by clicking the **Edit Link** button.

   ![Top dashboard bar with link](https://wixmp-833713b177cebf373f611808.wixmp.com/images/b09c0c3c6f319bf524b95add59d5a361.png)
---
portal: go-headless
name: "Add Apps to a Project"
type: ARTICLE_RESOURCE
resourceId: 4e2d18a8-9b97-472e-84fd-0b8c222d70ca
---

# Add Apps to a Project

# Add Apps to a Project

 

When you [create a Headless project](https://github.com/wix-private/developer-docs/blob/4a6b193b770190b06d0deb3890176c6a296e2360/headless-docs/setup/create-a-project.md*original::./create-a-project.md), you can install apps for business solutions such as eCommerce, Bookings, Pricing Plans, or Events.

If you want to add more apps later, follow these steps:

1. In the [project dashboard](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Fhome) click **Apps** in the sidebar menu, then click **Explore Apps**.

   ![Click Explore Apps](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ad540e8210b7d8796d0bb667e7d7b796.png)

1. In the Headless Wix Apps menu, choose one of the business solutions to see a description of the app.

   ![Headless Wix Apps menu](https://wixmp-833713b177cebf373f611808.wixmp.com/images/180b491b6b500da22102436b8c12fe17.png)

1. Click **Add to Site** to install the app.
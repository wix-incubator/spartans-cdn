---
portal: go-headless
name: "Invite Collaborators"
type: ARTICLE_RESOURCE
resourceId: 7841884f-a9e2-4eaf-ab12-f91bbb4fd6ee
---

# Invite Collaborators

# Invite Collaborators

This article explains how to grant access to your project's [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

## Step 1 | Create a custom role

1. Open your headless project dashboard.
1. Go to **Settings** > **Roles & Permissions**.
1. Click **Manage Roles**.
1. Click **Create a New Role**. Enter a **Role Title** and optional **Description**. 
1. Click **Site Dashboard**, then select **Manage headless settings**.
    
    ![Permission to grant](https://wixmp-833713b177cebf373f611808.wixmp.com/images/71584bfe8570b3889696c8e537a136ce.png)

1. Click **Save**.

Your new custom role appears in the **Manage Roles** list.

## Step 2 | Add collaborators

You can assign the custom role to existing collaborators or invite new collaborators with that role.

To assign the role to an existing collaborator:

1. Go to **Settings** > **Roles & Permissions**.
1. Find the collaborator you want to update.
1. click **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/11e10e4f-b84d-4136-a5a9-6109fab0b7d7/2020/10/25/347cc5c6-bce3-4407-82c3-e211e02cab98/398ced84-9ef5-4f70-87cd-4cb39a66dd65.png) next to their name and select **Change role**.
1. Choose the custom role you created.
1. Click **Save**.

To invite new collaborators with the role:

1. On the [**Manage Roles**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Froles-and-permissions/roles) page, find your new role and click **More Actions** ![](https://d2x3xhvgiqkx42.cloudfront.net/12345678-1234-1234-1234-1234567890ab/11e10e4f-b84d-4136-a5a9-6109fab0b7d7/2020/10/25/347cc5c6-bce3-4407-82c3-e211e02cab98/398ced84-9ef5-4f70-87cd-4cb39a66dd65.png).
1. Select **Invite collaborators**.
1. Enter the email addresses of the people to invite.
1. Click **Send Invite**.

Now, the relevant collaborators can access your project's [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).
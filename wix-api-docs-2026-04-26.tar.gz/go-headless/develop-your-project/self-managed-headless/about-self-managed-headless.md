---
portal: go-headless
name: "About Self-Managed Headless"
type: ARTICLE_RESOURCE
resourceId: 0db671d2-f674-447f-a7a1-bd22f6817753
---

# Overview

# About Self-Managed Headless

Self-managed headless lets you build your frontend with any framework and connect it to Wix's backend using the JavaScript SDK or REST API. You handle configuration, authentication, and hosting yourself—giving you maximum flexibility and control.

This approach is ideal for integrating Wix business solutions into existing sites, using non-standard frameworks, or building highly customized solutions.

> **Note:** For a simplified setup with managed hosting and authentication, see [Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless).

<div style="text-align:center">
<iframe width="560" height="315" src="https://youtube.com/embed/RCnvFtu5UXc" title="Wix Headless Series - Part 1 - Getting Started" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
</div>

## Create a project

A Headless project is essentially a Wix site that uses Wix's business management platform without necessarily using a Wix frontend. This approach allows you to build your own custom frontend while leveraging Wix's powerful business management tools. Headless projects appear in your Wix account alongside your Wix sites, making it easy to manage all your Wix projects in one place. To get started, [create a headless project](https://github.com/wix-private/developer-docs/blob/68b9a33548b7505856a4bbd5210049d36d3c4168/headless-docs/setup/create-a-project.md*original::./create-a-project.md).

If you already have a live Wix site, you can still use headless features to create additional interfaces that access and manage a site's data using APIs. In this case, you don't need to create a new headless project. Instead, continue with the next steps using your existing Wix site.

## Project apps

To take advantage of business solutions, such as eCommerce, Bookings, Pricing Plans, or Events, add the apps relevant to your needs. If you didn't already do this when creating your Wix project, [add apps to your project](https://github.com/wix-private/developer-docs/blob/68b9a33548b7505856a4bbd5210049d36d3c4168/headless-docs/setup/add-apps.md*original::./add-apps.md) now.

## Authorization strategy

To work with Wix APIs in your Headless site or app, you need to be authorized to call APIs. The authorization strategy you should choose depends on what kind of headless site or app you are developing.

- [**Visitors and Members (OAuth)**](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/authentication-strategies#visitor-and-member-oauth): An external site or app for use by customers, such as anonymous visitors and logged-in members. To get started with this authorization strategy, start by [creating an OAuth app](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/create-an-oauth-app).
- [**Admin (API Key)**](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/authentication-strategies#admin-api-key): An external site or app with customized administrative access to your Wix account's sites and projects. To get started with this authorization strategy, start by [generating an API key](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/generate-an-api-key).

In some cases, you may want to use more than 1 authorization strategy or use a number of API keys in the same site or app.

> **Note:** The authorization strategy serves 2 purposes:
>
> - Authorizes your app to call Wix APIs.
> - Directs your calls to Wix APIs to a site or project.

To learn more about authorization strategies, see [Authorization Strategies](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication).

## JavaScript SDK and the REST API

At this point your project is all set up and you're almost ready to start coding. Next, you need to choose how you're going to call Wix APIs.

There are 2 ways to interact with the Wix platform from the site or app you're building:

- **[JavaScript SDK](https://dev.wix.com/docs/sdk)**: If you're coding in JavaScript, use the JavaScript SDK to call Wix APIs.
- **[REST API](https://dev.wix.com/docs/rest)**: If you're not coding in JavaScript, use the REST API to call Wix APIs.

In some cases, you may want to work with both the JavaScript SDK and the REST API.

## Invite collaborators

[Invite collaborators](https://dev.wix.com/docs/go-headless/get-started/setup/general-setup/invite-collaborators) to your project so they can view and manage your [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings), including creating and connecting new headless clients. This makes it easier to share responsibility across your team and streamline development.
---
portal: go-headless
name: "About Authentication"
type: ARTICLE_RESOURCE
resourceId: 867c1819-af94-47dc-92dc-d116d330bf69
---

# About Authentication

# About Authentication

In self-managed headless projects, you must handle authentication manually. This article explains the identities and authentication strategies you need to implement.

> **Note:** In [Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless), the CLI handles visitor and member authentication automatically. You don't need to configure OAuth or manage tokens yourself.

## Identities
When you call a Wix API from your headless project, it's called by a specific [identity](https://dev.wix.com/docs/api-reference/articles/authentication/about-identities).

Wix restricts some methods based on which identities can call them. Authorization notes in the API reference indicate when an identity restricts a method.

A headless project can use the following identities:

- Visitor
- Member
- API key admin

## Visitor and member authentication

Operations that access or manage information relating to a current site visitor, such as adding items to the current visitor's cart, require OAuth. With OAuth, your site or app can recognize individual visitors and members using tokens to access their data.

- **Visitors**: Wix generates tokens automatically since visitors don't need personal authentication. You also have the option to manually generate tokens. Learn how to implement visitor authentication using [the JavaScript SDK](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/handle-visitors) or [the REST API](https://dev.wix.com/docs/go-headless/coding/rest-api/visitors-and-members/handle-visitors).
- **Members**: Wix must verify their identity through a login process before generating member-specific tokens. Learn how to implement different [member login options](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/about-member-login).

> **Note**: OAuth for Wix Headless only requires a client ID. It doesn't require a client secret.

## Admin authentication

For API calls that require administrative access, use an API key. With a Wix API key, you can grant a custom set of permissions to a site or app for accessing or managing business data, including members, orders, products, events, bookings, and more.

Unlike visitor and member authentication, API key authentication works the same in both self-managed and Wix-managed headless projects.

Learn more about [admin operations](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/about-admin-operations).

## See also
- [Create an OAuth app](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/create-an-oauth-app)
- [Generate an API key](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/generate-an-api-key)
---
portal: go-headless
name: "About Calling Site HTTP Functions"
type: ARTICLE_RESOURCE
resourceId: 93bfc100-4a9e-4a5a-96c8-5cf3d952e959
---

# Calling Site HTTP Functions

# About Calling Site HTTP Functions
[HTTP functions](https://dev.wix.com/docs/velo/velo-only-apis/wix-http-functions/introduction) allow you to expose the functionality of a Wix site as a service in the form of REST APIs. If you’ve added functionality to a site with code and want to use it in a Headless site or app, you can expose HTTP functions and call the APIs in your client's code.

Learn more about [exposing a site API with HTTP functions](https://dev.wix.com/docs/develop-websites/articles/coding-with-velo/integrations/exposing-services/about-custom-site-apis). 

## Authentication context
Authentication context is information about which [identity](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-identities) is calling an API.

If a HTTP function on a Wix site doesn't receive authentication context, it treats the call as if it was made by an anonymous site visitor. This restricts the methods you can use in your code without overriding authentication using [`elevate()`](https://dev.wix.com/docs/velo/apis/wix-auth/elevate).

Providing your HTTP functions with authentication context allows you to:
- Restrict HTTP function usage on your site to admins or site members.
- Use functions that return different responses based on who calls them, such as [`getCurrentMember()`](https://dev.wix.com/docs/velo/apis/wix-members-v2/members/get-current-member).

> **Note:** [Wix app identity](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-identities#wix-app) isn't supported.

## Implementation approaches

You can call site HTTP functions using 2 approaches:

-  The [JavaScript SDK](https://dev.wix.com/docs/sdk/backend-modules/http-functions/introduction) to call your site's endpoints with authentication context.

- The [REST API](https://dev.wix.com/docs/velo/velo-only-apis/wix-http-functions/introduction) using [access tokens](https://dev.wix.com/docs/rest/app-management/oauth-2/introduction) or [API Keys](https://dev.wix.com/docs/rest/articles/getting-started/api-keys) to send authentication context to your site's HTTP functions.

## See also

- [Connect a frontend to your self-managed headless project](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/connect-a-frontend-to-your-self-managed-headless-project)
- [Generate an API key](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/admin-operations/generate-an-api-key)
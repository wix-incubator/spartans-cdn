---
portal: go-headless
name: "Add Allowed Authorization Redirect URIs"
type: ARTICLE_RESOURCE
resourceId: 3bd43f93-ce64-4183-8e15-45ffc4cfa3aa
---

# Allowed Authorization Redirect URIs

# Add Allowed Authorization Redirect URIs

If you use a Wix login page to authorize site members, Wix redirects members back to your site or app after the login process is completed. In order to protect data security, Wix only redirects members to addresses you allow in advance.

For authorization related redirects, you need to provide exact matching URIs.

> **Notes:** 
> - Wix-managed Headless adds relevant redirect URIs automatically during setup. However, you can [add additional redirect URIs](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/add-allowed-authorization-redirect-uris) if needed.
> - Non-authorization related redirects only require you to provide a domain, which allows redirects to all URLs under that domain. To set allowed redirect domains for non-authorization related redirects, see [Allowed Redirect Domains](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/add-allowed-redirect-domains).

To add allowed redirect URIs for authorization redirects:

1. In your project dashboard, go to **Settings** > **Development & integrations** > [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

1. From **Headless clients**, click the three dots to the right of the OAuth app you want to edit. Choose **Settings** to open the app's settings page:

   ![Click OAuth App Settings](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f0f48aae7502e57cc89cdb6a46a2d383.png)

1. Under **URLs**, go to the **Allowed authorization redirect URIs** section.

   ![Allowed authorization redirect URIs](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ba5bf73882d36668bfc100f1cd0af010.png)

1. Click **Add Redirect URI** and enter a precise URI you authorize Wix to redirect back to from Wix-managed authentication pages. For example, `https://www.my-site.com/login-callback` authorizes only this path and doesn't authorize other URIs under the same domain. To authorize multiple URIs for authorization redirects, click **Add Redirect URI** again as many times as you need.

1. Click **Save** to save your changes and return to **Headless Settings**.
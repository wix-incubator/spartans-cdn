---
portal: go-headless
name: "About Custom Login Pages"
type: ARTICLE_RESOURCE
resourceId: 380a4b4b-8031-41ef-8059-9c1f5bb28c02
---

# About Custom Login Pages

# About Custom Login Pages
> **Note:** Custom login pages are only possible to implement in self-managed headless projects.

With [self-managed](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless) Wix Headless, you can create a fully customized login experience for your [members](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/about-authentication#identities). This allows members to securely sign in and access content or features that are specific to their account, such as their profile, saved items, order history, or other private information.

Custom login uses Wix's authentication service while letting you design and control the entire login UI experience. This approach is best when you need to maintain a consistent branded experience throughout your site or app.

> **Note:** If you don't need a custom login experience, you can use a [Wix login page](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-login-page/about-wix-login-pages), where Wix handles both the login UI and authentication process.

## Prerequisites

Before getting started, make sure to: 
- [Create an OAuth app for visitors and members](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/connect-a-frontend-to-your-self-managed-headless-project)
- [Add an allowed authorization redirect URI](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/add-allowed-authorization-redirect-uris)
- [Set the login URL](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/custom-login-page/set-a-login-url)

## See also
- [About reCAPTCHA](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/about-re-captcha)
- [Handle Members with a Custom Login Page Using the JS SDK](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/custom-login-page/custom-login-using-the-js-sdk)
- [Handle Members with a Custom Login Page Using the REST API](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/custom-login-page/custom-login-using-the-rest-api)
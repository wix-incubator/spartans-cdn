---
portal: go-headless
name: "Set a Login URL"
type: ARTICLE_RESOURCE
resourceId: 951d7ed3-d941-4a4d-bf3e-669283217463
---

# Login URL

# Set a Login URL

When you create a custom login page, you need to define a login URL that points to your custom login page. This tells Wix where to redirect users when they encounter Wix-managed business flows that require login, for example a checkout page. If you use a Wix login page instead, this setup isn't required since Wix handles the login process automatically. 

Learn more about [login options](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/about-authentication#login-options-using-oauth) for Headless sites.


To set a login URL:

1. In your project dashboard, go to **Settings** > **Development & integrations** > [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

1. From **Headless clients**, click the 3 dots to the right of the OAuth app you want to edit. Choose **Settings** to open the app's settings page:

   ![Click OAuth App Settings](https://wixmp-833713b177cebf373f611808.wixmp.com/images/f0f48aae7502e57cc89cdb6a46a2d383.png)

1. Scroll down to the **URLs** section and go to the **Login URL** section.

   ![Login URL](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ecee3fe4c26ed47db9e0c42aa9b2162c.png)

1. Enter the URL to your custom login interface. When Wix needs to log in a member, the member will be redirected to the URL you entered.

1. Click **Save** to save your changes and return to **Headless Settings**.
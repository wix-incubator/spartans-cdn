---
portal: go-headless
name: "Implement reCAPTCHA Using the REST API"
type: ARTICLE_RESOURCE
resourceId: ef1f623c-a14b-4d7a-9d77-04879fe121b4
---

# Implement reCAPTCHA

# Implement reCAPTCHA with Custom Login Using the REST API

> **Note:** This article is only relevant for [self-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless).

This article explains how to implement [reCAPTCHA](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/about-re-captcha) with member authentication using the REST API.

You'll learn how to:

- Implement reCAPTCHA using a 3rd party.
- Use reCAPTCHA tokens during register and login.

## Step 1 | Implement reCAPTCHA using a 3rd party

Use a 3rd-party library like [Google reCAPTCHA](https://www.google.com/recaptcha/admin/create) to implement the reCAPTCHA or choose to implement it yourself using [Google's APIs](https://cloud.google.com/recaptcha-enterprise/docs/apis).

You can choose to always require reCAPTCHA verification or only require it for suspected bots.

- To always require reCAPTCHA verification, use a visible site key when loading the reCAPTCHA script.
- To only require reCAPTCHA verification for suspected bots, use an invisible site key when loading the reCAPTCHA script.

<blockquote class="important">

**Important:** When implementing a reCAPTCHA:

- Use a Wix site key, not your own, when loading the reCAPTCHA script.
  - **Visible site key**: `'6Ld0J8IcAAAAANyrnxzrRlX1xrrdXsOmsepUYosy'`
  - **Invisible site key**: `'6LdoPaUfAAAAAJphvHoUoOob7mx0KDlXyXlgrx5v'`
- Be sure to load the [enterprise](https://www.google.com/recaptcha/enterprise.js) reCAPTCHA script.

</blockquote>

For example, [implement a visible reCAPTCHA widget with Google reCAPTCHA](https://cloud.google.com/recaptcha/docs/instrument-web-pages-with-checkbox):

```html
<html>
  <head>
    <script src="https://www.google.com/recaptcha/enterprise.js" async defer></script>
  </head>
  <body>
    <div class="g-recaptcha"
         data-sitekey="6Ld0J8IcAAAAANyrnxzrRlX1xrrdXsOmsepUYosy"
         data-callback="onSuccess">
    </div>
    <script>
      function onSuccess(token) {
        // This function is called when the user successfully completes the reCAPTCHA
        console.log('reCAPTCHA token:', token);
        // You can now send this token to your backend for verification if needed
      }
    </script>
  </body>
</html>
```

## Step 2 | Use reCAPTCHA tokens to register or login

Call the [`Register V2`](https://dev.wix.com/docs/rest/business-management/headless/authentication/register-v-2) or [`Login V2`](https://dev.wix.com/docs/rest/business-management/headless/authentication/login-v-2) endpoint with the appropriate reCAPTCHA token returned to your reCAPTCHA implementation.

When always requiring reCAPTCHA verification, send the token using the `captcha_tokens.Recaptcha` property.

```curl
curl --location 'https://www.wixapis.com/_api/iam/authentication/v2/login' \
--header 'authorization: <ACCESS_TOKEN>' \
--header 'content-type: application/json' \
--data '{
  "loginId":{
    "email": "john@doe.com"
  },
  "password": "verySecurePassword",
  "captcha_tokens":[{
    "Recaptcha": "<TOKEN>"
  }]
}'
```

When only requiring reCAPTCHA verification for suspected bots, send the token using the `captcha_tokens.InvisibleRecaptcha` property.

```curl
curl --location 'https://www.wixapis.com/_api/iam/authentication/v2/login' \
--header 'authorization: <ACCESS_TOKEN>' \
--header 'content-type: application/json' \
--data '{
  "loginId":{
    "email": "john@doe.com"
  },
  "password": "verySecurePassword",
  "captcha_tokens":[{
    "InvisibleRecaptcha": "<TOKEN>"
  }]
}'
```
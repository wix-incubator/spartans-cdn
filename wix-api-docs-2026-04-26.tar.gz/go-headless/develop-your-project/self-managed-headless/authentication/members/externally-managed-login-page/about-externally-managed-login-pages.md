---
portal: go-headless
name: "About Externally Managed Login Pages"
type: ARTICLE_RESOURCE
resourceId: 2121a92c-fa42-4c81-baac-3b1d794f7a7e
---

# About Externally Managed Login Pages

# About Externally-Managed Login Pages

> **Note:** Custom login pages are only available for self-managed headless projects. Wix-managed headless projects can [implement a Wix login page](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-login-page/wix-managed-headless/handle-members-with-a-wix-login-page).

You might choose to allow [members](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/identities#member) to log in to your site or app with an external provider, using a custom login interface that syncs with Wix’s authentication.

> **Notes**:
> - External login with Google and Facebook are fully supported in the [Wix login page](https://dev.wix.com/docs/go-headless/coding/rest-api/visitors-and-members/handle-members-with-wix-managed-login). When working with Google or Facebook as your external identity provider, only use this externally-managed flow if you require a custom login interface.
> - See our tutorial and sample repo to [Set Up an Externally-Managed Login Flow with Next.js and Github](https://dev.wix.com/docs/go-headless/tutorials-templates/other-tutorials/set-up-an-externally-managed-login-flow-with-next-js-and-github).

## Prerequisites

Before getting started, make sure you have the following:

- An account with an external identity provider
- A Wix site or [self-managed](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless) Wix headless project with a JavaScript environment.
- A [Wix API Key](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) with Members & Contacts permission
- An [OAuth App for visitors and members](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/create-an-oauth-app-for-visitors-and-members)

## See also
- [Handle Members with Externally-Managed Login](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/externally-managed-login-page/handle-members-with-externally-managed-login)
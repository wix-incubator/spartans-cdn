---
portal: go-headless
name: "Handle Members with Externally-Managed Login"
type: ARTICLE_RESOURCE
resourceId: 2359176d-58a2-4ecf-90b7-cc255185b995
---

# Handle Members with Externally-Managed Login

# Handle Members with Externally-Managed Login

> **Note:** This article is only relevant for [self-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless).

Complete the following steps to log a visitor into your site using an external authentication provider:

1. Authorize the member with the external provider and collect their email address.
1. Collect the relevant Wix member ID. To do so, check if this email address has a Wix member ID, and if not, create one.
1. Request and store access and refresh tokens for the Wix member ID.

Once the member is logged in, you can redirect them to your home page.

## Step 1 | Authenticate with the external provider and collect the member’s email address

1. When a visitor first lands on your login interface, follow the steps in [handle visitors](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/handle-visitors) to create a client and generate new visitor tokens.
1. When a member logs in using their external provider credentials, follow the external provider’s OAuth flow to authenticate users.
1. Once the member has been authenticated, collect their email address.

## Step 2 | Collect a Wix member ID

Once you have the member’s email address, you can check if any of them are associated with a Wix member ID using the [Members API](https://dev.wix.com/docs/sdk/backend-modules/members/members/introduction).

```js
const { items } = await wixAdminClient.members
  .queryMembers({
    filter: { loginEmail: email }
  });
```

- If an associated Wix member ID exists, collect it to pass in the next step.
- If no associated Wix member ID exists, create a member for them and collect the returned ID.

Note that creating members without explicit registration is an admin function. Make sure to use a [WixClient](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/create-a-client-with-oauth) with an [API key](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) that has permission to create members.

## Step 3 | Request and store Wix access and refresh tokens

Now that you have the Wix member ID, request access and refresh tokens for the member with the [`getMemberTokensForExternalLogin()`](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#getmembertokensforexternallogin) function.

<blockquote class="important">

**Important:** Before requesting member tokens, ensure visitor [tokens are set on the client](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#tokens). You can either provide active tokens when creating the client or call [`wixClient.auth.generateVisitorTokens()`](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#generatevisitortokens).

</blockquote>

```js
const memberTokens =
  await wixClient.auth.getMemberTokensForExternalLogin(
    member._id,
    <YOUR_API_KEY>
  );
```

Note that getting access and refresh tokens is an admin function. Make sure to use the [WixClient](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/create-a-client-with-oauth) with your [OAuth app](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/create-an-oauth-app-for-visitors-and-members) that created this visitor, along with an [API key](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) that has permission to create member access tokens, to save the visitor’s activity from before they logged in.

Now all that’s left is to store the tokens for later.

## See also
- [About Externally-Managed Login Pages](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/externally-managed-login-page/about-externally-managed-login-pages)
- [Set Up an Externally-Managed Login Flow with Next.js and GitHub](https://dev.wix.com/docs/go-headless/tutorials-templates/other-tutorials/set-up-an-externally-managed-login-flow-with-next-js-and-github)
---
portal: go-headless
name: "About reCAPTCHA"
type: ARTICLE_RESOURCE
resourceId: bfe4f851-6acc-4832-a5a0-34c55477818c
---

# About reCAPTCHA

# About reCAPTCHA

With Wix Headless, you can [enable reCAPTCHA](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/enable-re-captcha-for-member-login) for member registration and login flows. reCAPTCHA is a security service that helps protect sites and apps from fraud and abuse by distinguishing between real visitors and automated bots.

## Types of reCAPTCHA

Wix supports 2 types of reCAPTCHA:

- **Visible reCAPTCHA**: Always requires visitor interaction, such as solving a challenge or checking a box.
- **Invisible reCAPTCHA**: Only prompts visitors when suspicious activity is detected. Most visitors won't see a challenge.

We recommend using invisible reCAPTCHA because it provides strong security with less friction for site visitors. Invisible reCAPTCHA is generally more accessible, as most visitors won't need to solve a challenge unless suspicious activity is detected.

## Implementing reCAPTCHA

The process for implementing reCAPTCHA varies slightly depending on whether you're using a Wix login page or your own custom login page.

- **Wix login page:** Simply enable reCAPTCHA in your project settings, and Wix automatically adds reCAPTCHA to your member registration and login flows.
- **Custom login page:** Enable reCAPTCHA in your project settings. Then, you're responsible for adding the reCAPTCHA component to your forms and passing the verification token to Wix during registration and login. For implementation details, see [Implement reCAPTCHA for Custom Login](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/implement-re-captcha-with-custom-login).
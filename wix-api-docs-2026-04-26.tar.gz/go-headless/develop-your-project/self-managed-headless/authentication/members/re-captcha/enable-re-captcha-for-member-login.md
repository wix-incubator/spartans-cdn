---
portal: go-headless
name: "Enable reCAPTCHA for Member Login"
type: ARTICLE_RESOURCE
resourceId: b97c9180-699a-4b7c-8ba7-8ba65b96393f
---

# Enable reCAPTCHA for Member Login

# Enable reCAPTCHA for Member Login

With Wix Headless, you can add [reCAPTCHA](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-re-captcha) to your member registration and login flows for added security.

To enable reCAPTCHA, follow these steps:

1. Go to your project dashboard.
2. Navigate to **Settings** > **Site Member Settings** > **Signup & Login Security**.
3. Choose where to add reCAPTCHA:
    - **Add reCAPTCHA to signup**: Requires reCAPTCHA verification when a new site member registers.
    - **Add reCAPTCHA to login**: Requires reCAPTCHA verification when an existing site member logs in.
4. For each option, select when to require reCAPTCHA:
    - **Always**: All visitors must complete a reCAPTCHA challenge, such as solving a puzzle or checking a box.
    - **For suspected bots**: Only visitors with suspicious activity are prompted to complete a reCAPTCHA challenge. Most visitors won't see a challenge.
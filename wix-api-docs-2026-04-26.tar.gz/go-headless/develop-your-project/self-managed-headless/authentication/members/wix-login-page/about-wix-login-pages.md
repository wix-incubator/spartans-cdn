---
portal: go-headless
name: "About Wix Login Pages"
type: ARTICLE_RESOURCE
resourceId: 6890618b-7607-4f7a-9c8c-fc51bc17b691
---

# About Wix Login Pages

# About Wix Login Pages

With Wix Headless, you can authenticate [members](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/about-authentication#identities) on a site or app using Wix as your identity provider. This allows members to securely sign in and access content or features that are specific to their account, such as their profile, saved items, order history, or other private information.

Using a Wix login page is the simplest way to set up member authentication, as Wix handles the user experience and authentication process. However, you can't change the look and feel of the Wix login page.

## Login flow

When using a Wix login page, you're responsible for writing the code to start the login and handle the response. Wix handles the login UI and authentication.

The login flow looks like this:

1. A member starts the login on your site or app. For example, they click a "Log in" button. Your site or app redirects the member to the Wix login page.
1. The member logs in on the Wix login page. Wix then redirects the member back to your site or app using a callback URL you've configured. This URL must be one of your [allowed authorization redirect URIs](https://dev.wix.com/docs/go-headless/get-started/setup/manage-urls/add-allowed-authorization-redirect-urls).

> **Note:** Parts of the login flow are automated for you when using [Wix-managed Headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-the-wix-cli-for-headless).

## Prerequisites

Before implementing a Wix login page, make sure to:
- [Create an OAuth app for visitors and members](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/connect-a-frontend-to-your-self-managed-headless-project)
- [Add a Wix pages domain](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/set-a-wix-pages-domain)
- [Add an allowed redirect domain](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/add-allowed-redirect-domains)

> **Note:** If you're using Wix-managed Headless, you don't need to do these steps. Wix handles them automatically.

## See also

- [Handle Members with a Wix Login Page](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-login-page/wix-managed-headless/handle-members-with-a-wix-login-page) (Wix-managed Headless)
- [Handle Members with a Wix Login Page Using the JS SDK](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-managed-login-page/wix-managed-login-using-the-js-sdk) (self-managed Headless)
- [Handle Members with a Wix Login Page Using the REST API](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-managed-login-page/wix-managed-login-using-the-rest-api) (self-managed Headless)
---
portal: go-headless
name: "About OAuth Authentication"
type: ARTICLE_RESOURCE
resourceId: 7c263005-85bc-4993-8d14-b63cb510f6d2
---

# About OAuth Authentication

# About OAuth Authentication

> **Note:** In Wix-managed headless projects, OAuth is handled automatically. See [About Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless).

OAuth is the authentication protocol used for visitor and member authentication in headless projects. It allows your site or app to recognize individual visitors and members using tokens, enabling access to visitor-specific data like shopping carts, order history, and profile information.

For administrative operations like adding products or managing orders, use an [API key](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/generate-an-api-key) instead.

## See also

- [Create a Client for Authentication with OAuth](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/create-a-client-for-authentication-with-oauth)
- [Make REST API Calls Using OAuth](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/make-rest-api-calls-using-oauth)
---
portal: go-headless
name: "Create a Client for Authentication with OAuth"
type: ARTICLE_RESOURCE
resourceId: 8ceee19c-570c-44a7-b20a-472ba289dcf1
---

# Create a Client with OAuth

# Create a Client for Authentication with OAuth

> **Note:** This article is only relevant for [self-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless). [Wix-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-the-wix-cli-for-headless) handle this automatically.

After you [create an OAuth app](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/connect-a-frontend-to-your-self-managed-headless-project) for your client site or app in your project dashboard, you can begin coding by installing the Wix JavaScript SDK, importing modules in your code, and creating an SDK client.

<blockquote class="important">

 **Important:** To implement this flow, you must install Node.js version 18 or higher. 
 
</blockquote>

## Step 1 | Install packages

Install `@wix/sdk` and the packages for the domain-specific APIs you wish to work with. Domain-specific packages follow the naming convention `@wix/{domain}`. For example:

```console
npm install @wix/sdk
npm install @wix/bookings
npm install @wix/stores
```

or

```console
yarn add @wix/sdk
yarn add @wix/bookings
yarn add @wix/stores
```

## Step 2 | Import modules in your code

To use the APIs you have installed, import `createClient` from the `@wix/sdk` package along with an authentication strategy, and import functionality from the desired domain-specific packages you installed. For example:

```js
import { createClient, OAuthStrategy } from '@wix/sdk';
import { availabilityCalendar, services } from '@wix/bookings';
import { products } from '@wix/stores';
```

Make sure to import both `createClient` and `OAuthStrategy` from `@wix/sdk`.

## Step 3 | Create a client

> **Note:** OAuth for Wix Headless only requires a client ID. It doesn't require a client secret.

To get started connecting to a Wix project, use the [`createClient()`](https://dev.wix.com/docs/sdk/core-modules/sdk/wix-client) method imported from the `@wix/sdk` package to create a new client.

For example:

```js
  const myWixClient = createClient({
    modules: {
      products,
      services
    },
    auth: OAuthStrategy({
      clientId: '<YOUR_CLIENT_ID>',
      tokens: {
        accessToken: {
          value: '<ACCESS_TOKEN_VALUE>',
          expiresAt: '<ACCESS_TOKEN_EXPIRY_DATE>'
        },
        refreshToken: {
          value: '<REFRESH_TOKEN_VALUE>'
        }
      }
    })
  })
```

Pass the modules you want to use and authorization information when creating the client.

- The `modules` property contains key:value pairs. Each value is an imported module you wish to enable in the client, and the key defines the name to use for working with that module.
- The `auth` property contains the authentication method and credentials for connecting with your Wix project. To use the OAuth authentication strategy, call `OAuthStrategy()` with an object containing:
  - `clientId`: The **Client ID** of your OAuth app. You can find this value in your [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings). If you haven't created an OAuth app yet, see [Create an OAuth App](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/connect-a-frontend-to-your-self-managed-headless-project).
  - `tokens`: Optional. An object containing access and refresh tokens for a site visitor or member. If you pass tokens, every call made by the client uses these tokens to maintain a persistent session.
 
<blockquote class="tip">

**Tip:** Create your client once and reuse it throughout your app to maintain authentication state.

</blockquote>

## Step 4 | Call APIs with a client

After creating a client, you can use it to call APIs.

For example:

```js
const { items } = await myWixClient.products.queryProducts({});
```

## Step 5 | Work with visitor or member sessions

Often, you will need to maintain a persistent session to work with site or app visitors and members. Sessions are maintained using tokens. Most of the token management is handled by the client object, but there is some work you need to do, which differs depending on your situation.

- To handle site visitor sessions, see [Handle Visitors](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/headless-docs/coding/js-sdk/visitors.md*original::./visitors.md).
- To handle member sessions with a Wix login page, see [Handle Members with Managed Login](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/headless-docs/coding/js-sdk/members-managed-login.md*original::./members-managed-login.md).
- To handle member sessions with a custom login page, see [Handle Members with Custom Login](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/headless-docs/coding/js-sdk/members-custom-login.md*original::./members-custom-login.md).
- To handle member sessions with an external identity provider, see [Handle Members with Externally-Managed Login](https://github.com/wix-private/developer-docs/blob/7a616b5ba1def8a88ad3513271bfc75c938e880c/headless-docs/coding/js-sdk/members-external-login.md*original::./members-external-login.md).
- For a complete list of available methods, see the [OAuthStrategy reference](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy).
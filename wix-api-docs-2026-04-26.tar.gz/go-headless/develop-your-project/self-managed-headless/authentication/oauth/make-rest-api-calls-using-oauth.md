---
portal: go-headless
name: "Make REST API Calls Using OAuth"
type: ARTICLE_RESOURCE
resourceId: 7602d5d2-4bcf-4bad-9262-c43d49bc9702
---

# Make API Calls with OAuth

# Make REST API Calls Using OAuth

> **Note:** This article is only relevant for [self-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless). [Wix-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-the-wix-cli-for-headless) handle this automatically.

After you set up [an OAuth app](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/create-an-oauth-app) for your site or app in your project dashboard, you can begin coding by getting OAuth tokens and using them to make API calls.

## Step 1 | Generate tokens

There are several ways to generate tokens. Which way you choose depends on the type of user you need tokens for and whether you use a Wix login page or a custom login for members.

- **Visitors**: To generate tokens for visitors who aren't logged into your site or app, see [Handle Visitors](https://github.com/wix-private/developer-docs/blob/b46f26426712e09530cc805a1f7c6b6721ea88d1/headless-docs/coding/rest/visitors.md*original::./visitors.md).
- **Members with a Wix login page**: To generate tokens for logged in members using a Wix login page, see [Handle Members with Managed Login](https://github.com/wix-private/developer-docs/blob/b46f26426712e09530cc805a1f7c6b6721ea88d1/headless-docs/coding/rest/members-managed-login.md*original::./members-managed-login.md).
- **Members with a custom login page**: To generate tokens for logged in members using a custom login page, see [Handle Members with Custom Login](https://github.com/wix-private/developer-docs/blob/b46f26426712e09530cc805a1f7c6b6721ea88d1/headless-docs/coding/rest/members-custom-login.md*original::./members-custom-login.md).

When you generate tokens with any of the above methods, you get two tokens:

- **Access token**: Access tokens are used to authorize API calls. Every time you make an API call, you need to authorize the call using a valid access token. Access tokens are short-lived. They are valid for 4 hours from the time they are created.
- **Refresh token**: Refresh tokens are used to get new access tokens after your access tokens have expired. Refresh tokens are long-lived.

## Step 2 | Make an API call

Once you have your tokens, you can use them to make API calls. Use the access token in the authorization header when making an API call.

```sh
curl POST \
'https://www.wixapis.com/stores/v1/products/query' \
-H 'Content-Type: application/json' \
-H 'Authorization: <ACCESS_TOKEN>' \
-d '{
        "includeVariants": true
    }'
```
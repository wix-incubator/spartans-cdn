---
portal: go-headless
name: "About Handling Visitors"
type: ARTICLE_RESOURCE
resourceId: ded7180b-007c-4cc6-8001-0dccfb1d51ef
---

# About Handling Visitors

# About Handling Visitors

> **Note**: In [Wix-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-the-wix-cli-for-headless), you don't need to handle visitor tokens manually. The CLI automatically generates and manages visitor tokens for you.

Visitor tokens maintain anonymous visitor sessions, allowing you to track visitor-specific data like shopping cart contents across page visits. Without them, each API call is treated as a new visitor and session data is lost.

When you create a Wix client, visitor tokens are generated automatically. To persist sessions across page loads, store and restore tokens yourself.

For implementation details, see [Handle visitors using the JavaScript SDK](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/handle-visitors-using-the-js-sdk) or [Handle visitors using the REST API](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/handle-visitors-using-the-rest-api).

## See also
- [Create a Client for Authentication with OAuth](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/create-a-client-for-authentication-with-oauth)
- [Make REST API Calls Using OAuth](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/make-rest-api-calls-using-oauth)
---
portal: go-headless
name: "Handle Visitors Using the JS SDK"
type: ARTICLE_RESOURCE
resourceId: c13a79af-f72d-4c41-be65-7e2a20a31408
---

# Handle Visitors

# Handle Visitors Using the JavaScript SDK

> **Note:** This article is only relevant for [self-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless). For [Wix-managed headless projects](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-the-wix-cli-for-headless), the CLI automatically generates and manages visitor tokens for you.

Use visitor tokens to maintain anonymous visitor sessions in your self-managed headless project. The SDK uses these tokens when making requests to Wix APIs on behalf of a visitor, preserving their data such as cart items or event reservations.

<div style="text-align:center">
<iframe width="560" height="315" src="https://youtube.com/embed/v--v5vJzpyc" title="Wix Headless Series - Part 2 - Intro to Session Management" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
</div>

## Step 1 | Create a client

Create a Wix client with the [OAuth strategy](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy). When initializing your app, check if you have stored tokens from a previous session. If tokens exist, pass them to the client to resume the session. If not, create a new client without tokens.

```javascript
import { createClient, OAuthStrategy } from "@wix/sdk";
import { products } from "@wix/stores";

// Retrieve tokens from your storage (see Step 3 for storage options)
const existingTokens = getStoredTokens();

const wixClient = createClient({
  modules: { products },
  auth: OAuthStrategy({
    clientId: "<YOUR_CLIENT_ID>",
    // Pass tokens if they exist, otherwise omit to start a new session
    tokens: existingTokens,
  }),
});
```

> **Note:** OAuth for Wix Headless only requires a client ID. It doesn't require a client secret.

If no tokens are passed, tokens are prepared but not yet populated. They're created when you either:
- Make your first API call.
- Explicitly call [generateVisitorTokens()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#generatevisitortokens).

If tokens are passed, the client resumes the previous visitor's session, preserving their data such as cart items or event reservations.

## Step 2 | Make API calls

Make API calls as usual. The client handles token generation and renewal automatically.

```javascript
const { items } = await wixClient.products
  .queryProducts({
    filter: { 
      name: { $startsWith: "shoes" } 
    },
    cursorPaging: { limit: 4 }
  });
```

After your first API call, the client has valid tokens containing:
- An **access token** that expires after 4 hours.
- A **refresh token** for generating new access tokens.

## Step 3 | Save tokens to persist the session

To maintain a visitor's session across page reloads or app restarts, save the tokens to local storage, a cookie, or a file.

Retrieve the current tokens using [getTokens()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#gettokens):

```javascript
const tokens = wixClient.auth.getTokens();
```

The function returns an object in this format:

```javascript
{
  accessToken: {
    value: "OauthNG.JWS.eyJraWQiOi...3NbrhrauQ",
    expiresAt: 1677581109
  },
  refreshToken: {
    value: "JWS.eyJraWQiOiJZSEJzdUpwSCIsImFsZyI6IkhTMjU2In0.eyJkYXRhIjoiXCJkMDY4OTM4OS1kNTExLTRlYWMtYThjZC03MWQwMzA1NGIxM2NcIiIsImlhdCI6MTY3NzU2NjcwOSwiZXhwIjoxNzA5MTAyNzA5fQ.w2D7wECX_T-XfRzP4pXSoH8XSdHFBPnKx50FYzftRdc",
    role: "visitor"
  }
}
```

Save the tokens to your preferred storage:

```javascript
// Browser: Save to localStorage
localStorage.setItem("wixSession", JSON.stringify(tokens));

// Browser: Save to a cookie
document.cookie = `wixSession=${encodeURIComponent(JSON.stringify(tokens))}; path=/; max-age=31536000`;

// Server-side: Save to your session store or database
// The implementation depends on your stack (e.g., Redis, database, or framework session management)
await saveTokensToSession(userId, tokens);
```

## Manage tokens manually

In most cases, the client manages tokens automatically. Use these methods when you need manual control.

### Set tokens on an existing client

If you already have a client instance and need to set tokens on it later, use [setTokens()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#settokens):

```javascript
const savedTokens = JSON.parse(localStorage.getItem("wixSession"));
wixClient.auth.setTokens(savedTokens);
```

Once tokens are set, the visitor's data is preserved. For example, items added to a cart or tickets reserved are reflected in future API calls.

### Generate tokens explicitly

Call [generateVisitorTokens()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#generatevisitortokens) to create tokens before making any API calls:

```javascript
const tokens = await wixClient.auth.generateVisitorTokens();
```

### Confirm or renew existing tokens

Pass existing tokens to [generateVisitorTokens()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#generatevisitortokens) to confirm they're valid or renew them if expired:

```javascript
const refreshedTokens = await wixClient.auth.generateVisitorTokens(existingTokens);
```

The function returns:
- The same tokens if the access token is still valid.
- A new access token if the access token expired but the refresh token is valid.
- New access and refresh tokens if the refresh token is invalid.

### Force token renewal

Use [renewToken()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#renewtoken) to generate a new access token without checking if the current one is valid:

```javascript
const tokens = wixClient.auth.getTokens();
const newTokens = await wixClient.auth.renewToken(tokens.refreshToken);
```

### Check login status

Use [loggedIn()](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#loggedin) to check if the current visitor is a logged-in member:

```javascript
const isLoggedIn = wixClient.auth.loggedIn();
// Returns false for anonymous visitors, true for logged-in members
```

## Example

This example demonstrates creating a client that handles both new and returning visitors, making API calls, and saving tokens:

```javascript
import { createClient, OAuthStrategy } from "@wix/sdk";
import { currentCart } from "@wix/ecom";
import { products } from "@wix/stores";

// Check for existing tokens from a previous session
const existingTokens = localStorage.getItem("wixSession");

// Create a client - resume session if tokens exist, start new session if not
const wixClient = createClient({
  modules: { currentCart, products },
  auth: OAuthStrategy({
    clientId: "<YOUR_CLIENT_ID>",
    tokens: existingTokens ? JSON.parse(existingTokens) : undefined,
  }),
});

// Make API calls - tokens are generated automatically for new visitors,
// or the existing session is used for returning visitors
const { items } = await wixClient.products
  .queryProducts({
    filter: { 
      name: { $startsWith: "shoes" } 
    },
    cursorPaging: { limit: 4 }
  });

// Save tokens after API calls to persist the session
const tokens = wixClient.auth.getTokens();
localStorage.setItem("wixSession", JSON.stringify(tokens));

// The visitor's cart is preserved across sessions
const cart = await wixClient.currentCart.getCurrentCart();
```

## See also

- [About Handling Visitors](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/visitors/about-handling-visitors)
- [OAuthStrategy API Reference](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy)
- [Handle Members with a Custom Login Page](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/handle-members-with-custom-login)
---
portal: go-headless
name: "Connect a Frontend"
type: ARTICLE_RESOURCE
resourceId: d17d8553-bd1c-4354-84f0-6bc0fe7a9938
---

# Create an OAuth App

# Connect a Frontend to Your Self-Managed Headless Project

Wix Headless uses [OAuth 2.0 for authorization and authentication](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication#authentication-strategies) of [visitors](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication#visitor) and [members](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication#member). The OAuth protocol allows visitors or members to grant an external app or site (a "client") access to their data on a Wix project, without them needing to provide the client with their login credentials for the Wix project itself.

You can either add an OAuth app programmatically by calling [Create OAuth App](https://dev.wix.com/docs/rest/business-management/headless-authentication/oauth-apps/create-oauth-app) or manually through the UI. An OAuth app enables headless functionality by allowing external sites or apps to securely access your project data using Wix APIs.

Create an OAuth app for each client that you want to interact with your project. For example, if you're creating a site and a mobile app, create 2 OAuth apps, one for the site and the other for the mobile app.

To create an OAuth app through the UI:

1. In your project dashboard, go to **Settings** > **Development & integrations** > [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

2. In the **Headless clients** section, click **Create New Client** to create an OAuth app for your client.

   ![Click create new client](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ffd7ecc4e204e3725199e02d12760edd.png)

3. Enter a name for the OAuth app in the **Client name** field. Choose a name that identifies the client clearly. For example, if the client is a fitness-related smartwatch app, you can name the OAuth app "Smartwatch Gym Client App".

   Once you enter a name, select the client type and click **Create & Continue**.

   ![Enter name and description](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6d5791b774fead9b792f618d378b8c52.png)

4. Select the stack you're using to call Wix APIs.

   ![Select your stack](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e1080753cd0ca15ce1d27e5d35d7523d.png)

   Once you select the stack, the modal expands to display code snippets for 5 apps built by Wix. Each code snippet is customized for the stack that you choose. You can copy these snippets to help you get started working with Wix APIs.

   ![Code snippets example](https://wixmp-833713b177cebf373f611808.wixmp.com/images/e502b165b60246c0eaa5c5f5b1918cde.png)

   Once you choose your stack and copy any snippets you need, click **Continue**.

5. Click **View Your Setup** to close the modal and view your project's **Headless Settings**. Optionally, you can test out API calls using one of the two options displayed:

   - **Test API calls in the JavaScript playground:** Clicking **Open Playground** opens a new modal that lets you select different APIs and methods, and test out calls to them using the client ID you just created.
   - **See an example site in CodeSandbox**: Clicking **Go to Sandbox** opens a new tab with a CodeSandbox project. The project contains complete code that makes calls to various APIs like eCommerce and Bookings. You can copy code straight from the example, or fork the project to start editing and testing your own code.

   ![Choose a testing tool](https://wixmp-833713b177cebf373f611808.wixmp.com/images/8e1fd99ecf4ebb69c76f7904847f5869.png)

6. In the **Headless clients** section, your new OAuth app now appears with the client ID.

   Copy the **Client ID** and use it to connect and authenticate with your Wix project from a client. You can also retrieve the client ID later by returning to the [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings) page.

7. Many external client sites redirect visitors to Wix-managed pages for processes such as authentication and checkout. Wix then returns the visitor to the external site. To protect data security, Wix only ever redirects visitors to site addresses you approve in the **URLs** section. Therefore, if you want your external site to redirect to Wix-managed pages, you need to provide approval for the following URLs:

   - [**Allow Redirect Domains**](https://github.com/wix-private/developer-docs/blob/3f660d5cec6e6cf8ab7127c3e94b6197b5616d94/headless-docs/setup/allow-redirect-domains.md*original::./allow-redirect-domains.md): Domains that Wix can redirect visitors to from Wix-managed pages.
   - [**Login URL**](https://github.com/wix-private/developer-docs/blob/3f660d5cec6e6cf8ab7127c3e94b6197b5616d94/headless-docs/setup/login-url.md*original::./login-url.md): URL of your custom login interface, if you will develop one.
   - [**Allow Authorization Redirect URIs**](https://github.com/wix-private/developer-docs/blob/3f660d5cec6e6cf8ab7127c3e94b6197b5616d94/headless-docs/setup/allow-auth-redirect-uri.md*original::./allow-auth-redirect-uri.md): URIs that Wix can redirect members back to after they complete the authorization process.

> **Note:** Return to [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings) to see a list of clients authorized for your project, to retrieve a client ID, or to edit settings.
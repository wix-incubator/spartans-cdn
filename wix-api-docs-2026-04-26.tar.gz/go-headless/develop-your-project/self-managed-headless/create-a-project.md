---
portal: go-headless
name: "Create a Project"
type: ARTICLE_RESOURCE
resourceId: 672efad8-7bc6-42bc-a408-8c0f1132ec1d
---

# Create a Project

# Create a Self-Managed Headless Project

Wix Headless lets you build your frontend with any framework and integrate with Wix’s production-ready [business solutions](https://dev.wix.com/docs/go-headless/get-started/about-headless/wix-headless-business-solutions) such as eCommerce, Bookings, and Events. Headless projects appear in your Wix account alongside your Wix sites, making it easy to manage all your Wix projects in one place.

This article explains how to set up a self-managed headless project. For a simplified setup with managed hosting and authentication, see [Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless).

To create and set up a headless project:

1. Create a [new headless project](https://www.wix.com/intro/headless?ref=docs_vanilla).
2. Choose your project's purpose.

   ![Select project purpose](https://wixmp-833713b177cebf373f611808.wixmp.com/images/c72264418af2ea8f2891b84622e87d53.png)

3. Choose your role.

   ![Select your role](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0b991dac3db34ee5e099fb8be9c956ad.png)

4. Choose the business features you want to add, such as eCommerce, Bookings, Pricing Plans, or Events. You can always [add more](https://github.com/wix-private/developer-docs/blob/fd74565f56b08183812d674ca522fc524b5abebe/headless-docs/setup/add-apps.md*original::./add-apps.md) later.

   ![Select business solutions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/83b20c3ee3cce60c704586c9ec2b84f3.png)

5. Enter a name for your project. You can always change your project's name later in the [project dashboard](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Fhome).

   ![Select project name](https://wixmp-833713b177cebf373f611808.wixmp.com/images/036b524f7727f5aad7fa6d7bf680089a.png)

> **Note:** You need to upgrade to a Premium Plan to receive payments, view detailed analytics, connect a custom domain, and access other advanced functionality. Without a Premium Plan you can still begin coding, but you'll need to upgrade later in order to enable these features.
---
portal: go-headless
name: "About Wix-Managed Headless"
type: ARTICLE_RESOURCE
resourceId: 739b7a55-d83f-4575-85f6-f962f4888cda
---

# About Wix-Managed Headless

# About Wix-Managed Headless

Wix-managed headless is a fully managed solution for building and hosting headless projects on Wix. It combines Wix [business solutions](https://dev.wix.com/docs/go-headless/get-started/about-headless/wix-headless-business-solutions) with managed infrastructure, automatic authentication, and a modern development stack, so you can focus on building your frontend while Wix handles the backend complexity.

Unlike [self-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless), you don't need to configure OAuth, manage authentication tokens, or set up hosting. Wix handles builds, deployments, scaling, and security for you.

To create a Wix-managed headless project with the CLI, run:

```bash
npm create @wix/new@latest headless
```

For a full walkthrough, see [Quick Start a Headless Project](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project).

## Benefits

When you create a Wix-managed headless project, you get a complete development environment backed by Wix infrastructure:

- **Managed hosting with global CDN**: Wix builds, deploys, and serves your project on a global content delivery network with automatic SSL certificates. The infrastructure scales automatically to meet traffic demands.
- **Automatic authentication**: Visitor sessions, member login flows, and token management are all handled for you. You can call [Wix SDK](https://dev.wix.com/docs/sdk) methods directly in your code. The SDK is pre-configured with the right credentials, so there's no client setup or token management required.
- **Astro-based framework**: Your project is built on the [Astro](https://astro.build/) web framework, which gives you fast, server-rendered pages with the flexibility to use components from React, Vue, Svelte, or Solid wherever you need them.
- **Extend with custom backend logic and dashboard UIs**: Use [extensions](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/about-extensions) to handle events like order placements, customize business logic, and build management interfaces that appear in the Wix dashboard.

## Ways to work with Wix-managed headless

You can develop Wix-managed headless projects through code with the [Wix CLI](#wix-cli), through a visual UI with [Wix Vibe](#wix-vibe), or a combination of both.

### Wix CLI

The [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli) is the code-first approach. You develop locally in your preferred IDE, use standard coding practices, and deploy through the CLI. The Wix-Managed Headless documentation focuses on this approach, covering the [architecture](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/architecture-and-project-structure), [authentication model](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/authentication/authentication-and-api-integration), [extensions](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/about-extensions), and [development workflow](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/development-build-and-deployment) of CLI-based headless projects.

To get started, see [Quick Start with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project).

> **Note:** 
> 
> The previous tool, Wix CLI for Headless, remains available for existing projects but no longer receives updates or new features. For the best developer experience and the latest features, start new projects with the new Wix CLI. 
> 
> Documentation for the previous CLI is in the [legacy reference](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/about-the-wix-cli-for-headless).

### Wix Vibe

[Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe) is a UI-based approach that lets you create, edit, and manage your project using conversational AI prompts. You describe what you want to build, and Vibe generates the project structure, pages, and components for you.

To get started, see [Build with Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe).

### Moving between Vibe and CLI

Projects started in Vibe can always be opened locally and developed with the CLI. Projects created with the CLI using [Vibe-compatible templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates) can be connected to Vibe for visual editing. In both cases, your local code remains the source of truth.

## Key concepts

The following articles explain the core concepts behind Wix-managed headless projects:

- [Architecture and project structure](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/architecture-and-project-structure): The Astro framework, project file structure, private app, and hosting infrastructure that power your project.
- [Authentication and API integration](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/authentication/authentication-and-api-integration): How automatic authentication works for visitors, members, and admins, and how you call Wix APIs in your code.
- [Extensions](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/about-extensions): Backend event handlers, service plugins, and dashboard UIs that extend your project beyond the frontend.
- [Development, build, and deployment](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/development-build-and-deployment): Local development with hot reloading, the build-preview-release workflow, environment variables, and AI-assisted development with Wix Skills.

When you're ready to start building, see [Get Started](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/get-started) for a guide to choosing your entry point and next steps.

## Comparison with self-managed headless

Self-managed headless gives you full control over your framework, hosting, and authentication setup. Wix-managed headless trades some of that flexibility for a faster, more automated development experience.

For a detailed comparison of both paths, including a feature-by-feature table, see [About Headless Development Paths](https://dev.wix.com/docs/go-headless/develop-your-project/about-headless-development-paths).

## See also

- [About Wix Headless](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless)
- [About Headless Development Paths](https://dev.wix.com/docs/go-headless/develop-your-project/about-headless-development-paths)
- [Wix Headless Business Solutions](https://dev.wix.com/docs/go-headless/get-started/about-headless/wix-headless-business-solutions)
- [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
- [About Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe)
---
portal: go-headless
name: "Authentication and API Integration"
type: ARTICLE_RESOURCE
resourceId: fefa8be7-1045-478f-9e89-c62cdb28e1c1
---

# Authentication and API Integration

# Authentication and API Integration

One of the main advantages of Wix-managed headless is that authentication is handled for you. In a [self-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/self-managed-headless/about-self-managed-headless) project, you need to create an OAuth app, generate tokens, and manage sessions manually. In a Wix-managed headless project, the CLI and hosting infrastructure take care of all of this, so you can call [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) methods directly in your code.

## Automatic authentication

When you create a Wix-managed headless project, the CLI configures a [private app](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/architecture-and-project-structure#your-projects-private-app) that acts as the OAuth handler for your project. The app's credentials are stored as environment variables in your project, and the hosting infrastructure uses them to authenticate API calls automatically.

This means you don't need to:

- Create an OAuth app in the Wix dashboard.
- Set up a Wix client in your code.
- Generate, refresh, or store access tokens.
- Write session management logic.

You can import a Wix SDK module and call its methods directly. The infrastructure handles the rest.

## Calling Wix APIs

With authentication handled automatically, calling Wix APIs in your code is straightforward. Install the SDK package for the API you need, import it, and call the method.

For example, to retrieve a list of site members:

```ts
---
import { members } from "@wix/members";

const memberList = await members.listMembers();
---
```

The SDK knows how to authenticate the call because the infrastructure provides the necessary credentials. You don't create a Wix client or pass tokens manually.

This pattern works for any [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) module. Browse the [Wix API Reference](https://dev.wix.com/docs/api-reference?apiView=SDK) to see what's available.

## Elevated permissions

Some SDK methods require higher permissions than visitor or member. For example, retrieving site properties or accessing business data may need app-level authorization. When you call these methods from frontend code, you'll get a 403 Forbidden error.

The solution is to move the call to a backend [HTTP endpoint](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints) and use `auth.elevate()` to run it with elevated permissions.

For step-by-step instructions, see [Elevate API Call Permissions](https://dev.wix.com/docs/wix-cli/guides/development/elevate-api-call-permissions) in the CLI documentation. For troubleshooting 403 errors, see [Fix 403 Errors for API Calls](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/troubleshooting/fix-403-errors-for-api-calls).

## Visitor sessions

Anonymous visitors to your site are automatically authenticated with visitor-level permissions. The hosting infrastructure's session management middleware generates and manages visitor tokens in the background, and persists session data using cookies.

This automatic session management means:
- Visitors can add items to shopping carts, and the cart persists across page views.
- Visitors can start a bookings flow and continue it on another page.
- Session data carries over as visitors navigate your site, without you writing any state management code.

You don't need to do anything to enable this behavior. It works out of the box for all Wix-managed headless projects.

## Member login

For members who need to log in, the CLI provides built-in login routes that handle the entire login flow: redirecting to the Wix login page, exchanging tokens, and managing the authenticated session. You link to these routes from your frontend, and the CLI takes care of the rest.

Once a member is logged in, their identity is available to subsequent API calls, enabling features like viewing order history, managing account settings, or accessing member-only content.

To learn how to add member login to your project, see [Handle Members with a Wix Login Page](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/handle-members-with-a-wix-login-page).

## See also

- [Handle Members with a Wix Login Page](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-login-page/wix-managed-headless/handle-members-with-a-wix-login-page)
- [Elevate API Call Permissions](https://dev.wix.com/docs/wix-cli/guides/development/elevate-api-call-permissions)
- [Fix 403 Errors for API Calls](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/troubleshooting/fix-403-errors-for-api-calls)
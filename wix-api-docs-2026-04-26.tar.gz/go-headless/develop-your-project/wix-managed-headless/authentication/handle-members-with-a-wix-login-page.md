---
portal: go-headless
name: "Handle Members with a Wix Login Page"
type: ARTICLE_RESOURCE
resourceId: 0b5aa58e-d879-457f-8ad0-419c621ac6e8
---

# Handle Members with a Wix Login Page

# Wix-Managed Headless: Handle Members with a Wix Login Page

In Wix-managed headless, the CLI provides built-in `/api/auth/login` and `/api/auth/logout` endpoints that handle the entire login flow. Just link to these endpoints and the CLI takes care of redirecting to the Wix login page, exchanging tokens, and managing the authenticated session.

## Log in
To log in or sign up a member, redirect the browser to the following URL: `/api/auth/login`. For example:
```html
<a href="/api/auth/login" class=login-btn">Log In</a>
```

This redirects the browser to the Wix login page, where Wix handles the login process.

You can specify the URL to redirect to after the login process using a `returnUrl` query parameter in the initial request. For example, `/api/auth/login?returnUrl=/home` redirects the browser to `/home` after the login process. If you don't specify a `returnUrl`, Wix redirects the browser to the URL that the member was on before you directed them to the login page.

## Log out
To log out a member, make a `POST` request to the following URL: `/api/auth/logout`. For example:
```javascript
axios.post('/api/auth/logout')
```

This logs the member out. You can specify the URL to redirect to after the logout process using a `returnUrl` query parameter in the initial request. For example, `/api/auth/logout?returnUrl=/home` redirects the browser to `/home` after the logout process. If you don't specify a `returnUrl`, Wix redirects the browser to the URL that the member was on before you logged them out.

## Troubleshooting

If you encounter issues with a Wix login page, make sure that:

- The `returnUrl` query parameter is listed in your [allowed authorization redirect URIs](https://dev.wix.com/docs/go-headless/get-started/setup/manage-urls/add-allowed-authorization-redirect-urls), and that the values match exactly. If you provided this URL when you created your Wix-managed headless project, Wix automatically added it to the allowed authorization redirect URIs, but if it's not, you need to add it manually.
- You haven't set a custom login URL in your OAuth app settings. Wix-managed headless uses Wix's login page automatically, so the **login URL** field should be empty in your [Headless Settings](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).
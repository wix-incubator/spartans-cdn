---
portal: go-headless
name: "About Extensions"
type: ARTICLE_RESOURCE
resourceId: 0bd14dc7-1e55-4169-9ed0-39447e910720
---

# About Extensions

# About Extensions

Extensions let you add functionality to your Wix-managed headless project beyond what your frontend provides. They run on the backend through your project's [private app](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/architecture-and-project-structure#your-projects-private-app), giving you the ability to handle backend events, customize business logic, and build custom management interfaces in the Wix dashboard.

You add extensions to your project using the CLI's `generate` command, which scaffolds the extension files under `src/` and registers them in your project's `extension.ts` configuration file. For a full list of available extension types, see [About Extensions in the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions).

> **Note:** The CLI documentation also covers site extensions. These are only relevant to Wix app projects, not headless projects. In a headless project, you have full control over your frontend, so there's no need to extend it through site extensions.

## Backend extensions

Backend extensions let you run code on the server in response to events, customize how Wix business logic behaves, and expose your own APIs. They're how you add backend capabilities to your project without managing a separate server.

For example, you might use backend extensions to send a custom notification when a new order is placed, calculate dynamic shipping rates based on your own logic, or build an API that integrates with a 3rd-party service.

For details on available backend extension types and how to add them, see [About Backend Extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/about-backend-extensions) in the CLI documentation.

## Dashboard extensions

Dashboard extensions let you build custom interfaces that appear in the [Wix dashboard](https://support.wix.com/en/article/about-your-wix-dashboard), alongside the standard Wix management tools. This is useful when you need management workflows or views that are specific to your project.

For example, you might build a custom analytics page that shows data from multiple Wix business solutions in a specific view, or a content management interface tailored to your project's specific data structure. You build dashboard extensions with React and can optionally use the [Wix Design System](https://www.wixdesignsystem.com/) for a native look and feel.

For details on each dashboard extension type and how to add them, see [About Dashboard Extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/about-dashboard-extensions) in the CLI documentation.

## See also

- [About Extensions in the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions)
- [About the extension.ts File](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file)
- [About Backend Extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/about-backend-extensions)
- [About Dashboard Extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/about-dashboard-extensions)
- [About HTTP Endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints)
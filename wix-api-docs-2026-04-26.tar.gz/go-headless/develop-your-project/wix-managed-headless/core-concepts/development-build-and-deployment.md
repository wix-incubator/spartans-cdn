---
portal: go-headless
name: "Development, Build, and Deployment"
type: ARTICLE_RESOURCE
resourceId: c7201411-996d-4b0a-8771-2092f81b5b54
---

# Development, Build, and Deployment

# Development, Build, and Deployment

Wix-managed headless projects follow a development workflow that includes local development with hot reloading, a 3-stage deployment process, and built-in support for environment variables and AI-assisted development. This article explains what each stage of the workflow involves, so you know what to expect before diving into the CLI documentation for step-by-step instructions.

## Local development

During development, you work locally in your preferred IDE and use the CLI's `dev` command to start a local development environment. This environment:

- Builds and serves your project locally.
- Provides links to view the site and Wix dashboard.
- Supports hot reloading through the [Vite toolchain](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/architecture-and-project-structure#the-vite-toolchain), so changes you make to your code are reflected in the browser without a full page reload.

You write your frontend code in standard [Astro](https://astro.build/) files, add [extensions](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/about-extensions) for backend logic and dashboard UIs, and call [Wix APIs](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/authentication/authentication-and-api-integration#calling-wix-apis) using the JavaScript SDK. The local environment connects to your Wix project's real data, so you can test with actual business data from your dashboard.

For details on starting and using the local dev environment, see [Wix CLI Development Overview](https://dev.wix.com/docs/wix-cli/guides/development/development-overview).

## Build, preview, and release

When you're ready to deploy, the CLI provides a 3-stage process:

### Build

The [`build`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build) command compiles your project's assets. This is the same build step that runs before preview and release.

### Preview

The [`preview`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/preview) command pushes your project to Wix's servers and creates a shareable preview URL. This is useful for sharing work-in-progress with team members or stakeholders. Each preview creates a unique URL that points to a specific snapshot of your project.

> **Note:** The `preview` command uploads your code but doesn't register all extensions. Some extensions, like embedded scripts and site widgets, only work after a full release.

### Release

The [`release`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) command pushes your project to Wix's servers, registers all extensions, and publishes the site. After releasing, the CLI provides the URL of your published site and preview URLs for the site and dashboard.

For step-by-step deployment instructions, see [Build and Deploy a Project](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project) in the CLI documentation.

## Environment variables

The CLI provides built-in support for [environment variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables), allowing you to store configuration values and secrets outside your code. You can define variables with different security levels. Public variables are stored locally, while secret variables are stored securely on Wix servers to prevent accidental exposure. For details, see [Manage Environment Variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/manage-environment-variables) in the CLI documentation.

## AI-assisted development with Wix skills

New CLI projects include [Wix Skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) by default. Wix Skills are self-contained instructions that AI tools like Claude and Cursor can use to develop, deploy, and manage your project.

Wix Skills follow the [Agent Skills specification](https://agentskills.io/specification) and are stored in tool-specific directories in your project, such as `.claude/` or `.cursor/`. You can update them to the latest version using [`wix skills update`](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/skills-update).

For more details and sample prompts, see [About Wix Skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills).

## CI/CD integration

The CLI can be integrated into CI/CD pipelines, allowing you to automate tasks like running tests, building, and deploying. For example, you can create a GitHub Actions workflow that runs unit tests on every pull request.

For details on unit testing, see [Write Unit Tests for a Wix CLI Project](https://dev.wix.com/docs/wix-cli/guides/development/app-development/write-unit-tests-for-a-wix-cli-project) in the CLI documentation.

## See also

- [Wix CLI Development Overview](https://dev.wix.com/docs/wix-cli/guides/development/development-overview)
- [Build and Deploy a Project](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project)
- [About Environment Variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables)
- [About Wix Skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills)
- [CLI Command Reference](https://dev.wix.com/docs/wix-cli/command-reference/introduction)
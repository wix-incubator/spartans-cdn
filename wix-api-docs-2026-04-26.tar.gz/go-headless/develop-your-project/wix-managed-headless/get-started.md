---
portal: go-headless
name: "Get Started"
type: ARTICLE_RESOURCE
resourceId: fa218548-8640-4445-b64c-da0e9b8ca8c5
---

# Get Started

# Get Started

Wix-managed headless projects can be created through code using the Wix CLI, through a visual UI using Wix Vibe, or a combination of both. This article helps you choose the right starting point for your workflow and directs you to the resources you need to get building.

## Choose your starting point

There are 2 primary ways to start a Wix-managed headless project:

- **Wix CLI**: A code-first approach where you develop in your IDE, choose from starter templates, and manage your project through the command line. This is the path covered in depth by the other articles in this section.
- **Wix Vibe**: A UI-based approach where you describe what you want to build using conversational AI prompts. No coding required.

These approaches aren't mutually exclusive. You can [move between them](#move-between-vibe-and-the-cli) depending on your template choice.

## Start with the Wix CLI

The Wix CLI is the right choice when you want full control over your code and prefer working in your own IDE. The CLI scaffolds a complete [Astro-based project](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/core-concepts/architecture-and-project-structure) with [automatic authentication](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/authentication/authentication-and-api-integration), then you develop, test, and deploy through the command line.

> **Note:** If you want to be able to use Wix Vibe alongside the CLI, choose a [Vibe-compatible template](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates) when creating your project.

To create a project:

1. Make sure you have [Node.js](https://nodejs.org/en/) v20.11.0 or higher and [Git](https://git-scm.com/) installed.

2. Run the following command:

    ```bash
    npm create @wix/new@latest headless
    ```

3. Follow the prompts to name your project, choose a [template](#templates), and select a directory for your project files.

4. After the CLI finishes generating your project, navigate to your project directory and start the local development environment:

    ```bash
    cd <your-project-directory>
    wix dev
    ```

For the full step-by-step walkthrough, see [Quick Start a Headless Project](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project) in the CLI documentation.

## Start with Wix Vibe

[Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe) is the right choice when you want to get a project up and running without writing code, or when you want to explore ideas visually before committing to a code-based workflow.

With Vibe, you describe what you want to build using conversational prompts. Vibe generates a complete project with pages, components, and Wix business solution integrations. You can continue editing in the Vibe editor, or open the project locally and switch to CLI-based development at any time.

For details on working with Vibe, see [About Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe).

## Move between Vibe and the CLI

You can move between Vibe and CLI development throughout your project's lifecycle:

- **Vibe to CLI**: Projects created in Vibe can always be opened locally and developed with the CLI. This works regardless of which template was used to create the project.
- **CLI to Vibe**: Projects created with the CLI can be connected to Vibe for visual editing, but only if you used a [Vibe-compatible template](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates). Run the following command to establish the connection:

    ```bash
    wix connect
    ```

    Projects created with standard templates can't be connected to Vibe.

In both cases, your local code remains the source of truth. Changes made in Vibe are synchronized with your local files.

## Templates

When you create a project with the CLI, you can choose a starter template. Templates are organized into Vibe-compatible templates, which work with both the CLI and [Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe), and standard templates, which are for CLI development only.

For details on each template, including links to their source code, see [Wix CLI for Headless Templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates).

## Next steps

Once you've created your project, these resources help you continue:

- [Wix CLI Development Overview](https://dev.wix.com/docs/wix-cli/guides/development/development-overview): Learn about the development process, testing, and building.
- [Wix CLI Project Structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure): Understand the files and directories in your project.
- [Build and Deploy a Project](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project): Deploy your project to production.
- [Wix JavaScript SDK](https://dev.wix.com/docs/sdk): Browse the APIs available for your project.

## See also

- [Quick Start a Headless Project](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project)
- [About Wix Vibe](https://dev.wix.com/docs/go-headless/wix-vibe/about-wix-vibe)
- [Wix CLI for Headless Templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates)
- [About Wix-Managed Headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless)
---
portal: go-headless
name: "About Wix Headless"
type: ARTICLE_RESOURCE
resourceId: 240e7eb0-206c-4d9b-9996-7c59a1d1bc1f
---

# About Wix Headless

# About Wix Headless

[Wix Headless](https://www.wix.com/studio/developers/headless) lets you build your frontend with any framework and integrate with Wix’s production-ready [business solutions](https://dev.wix.com/docs/go-headless/get-started/about-headless/wix-headless-business-solutions) such as eCommerce, Bookings, and Events.

Headless projects appear in your Wix account alongside your Wix sites and are managed through the same [dashboard](https://support.wix.com/en/article/about-your-wix-dashboard). From there, you can manage customers, process orders, and track analytics.

You can connect multiple frontends to a single Wix project. For example, a website, mobile app, and other clients can share the same underlying business data.

## Development paths

Wix Headless supports the following [development paths](https://dev.wix.com/docs/go-headless/develop-your-project/about-headless-development-paths), depending on how much setup and hosting you want to manage yourself. Both paths allow you to connect to Wix backend services using [Wix APIs](https://dev.wix.com/docs/api-reference).

### Wix-managed headless

Wix-managed headless is a fully managed solution for developing and hosting your headless project. You can bootstrap projects with [Wix Vibe](#wix-vibe) using conversational AI prompts, or use the [CLI for Headless](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli#headless-project-support) to scaffold a project from starter templates or build from scratch. Projects started in Vibe can always be opened locally and developed with the CLI. For projects created with the CLI using [Vibe-compatible templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates), you can connect to Vibe for AI-powered visual editing alongside code development.

Learn more about the [benefits of Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-wix-managed-headless).

> **Note**: This path requires less setup and is the recommended option for most use cases.

### Self-managed headless

Build your frontend from scratch with any framework and host it anywhere. You handle all configuration, authentication, and deployment.

Use this path when you need more flexibility, want to integrate Wix into an existing site, or have specific hosting requirements.

## Wix Vibe

[Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe) is an AI-powered tool for Wix-managed headless projects. You can use Vibe to bootstrap your entire project using conversational prompts, or connect it to CLI-created projects (with [Vibe-compatible templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates)) for AI-powered visual editing. Your local code remains the source of truth, and you can switch between editing in the Vibe editor and your preferred IDE.

## Pricing

While you can start using Wix Headless for free, upgrading to a Premium Plan unlocks advanced features that help you grow your business. These include receiving payments, accessing in-depth analytics, connecting a custom domain, and other features. Consider [upgrading to a Premium Plan](https://www.wix.com/premium-purchase-plan/dynamo).

## Get in touch

Join the [Headless channel](https://discord.gg/47gUT9KabP) of the Devs on Wix Discord community to discuss features and connect with our growing community of developers.
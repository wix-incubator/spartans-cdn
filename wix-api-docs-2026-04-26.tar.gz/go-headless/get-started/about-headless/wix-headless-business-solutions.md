---
portal: go-headless
name: "Wix Headless Business Solutions"
type: ARTICLE_RESOURCE
resourceId: 165f44fa-636f-4df0-81ec-9098256fe65d
---

# Wix Headless Business Solutions

# Wix Headless Business Solutions

With Wix Headless, you can take advantage of the diverse business services our platform offers. The functionality of our APIs is constantly expanding to provide access to more features of the following business solutions:

- **[Bookings](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction)**: Accept and manage bookings for services. Learn more about [Wix Bookings](https://www.wix.com/app-market/bookings).
- **[Events](https://dev.wix.com/docs/sdk/backend-modules/events/introduction)**: Create and manage events, sell tickets, and collect RSVPs. Learn more about [Wix Events](https://www.wix.com/app-market/events).
- **[Contacts](https://dev.wix.com/docs/sdk/backend-modules/crm/contacts/introduction)**: Access and manage a business's contact list. Learn more about [Wix Contacts](https://support.wix.com/en/article/contacts).
- **[eCommerce](https://dev.wix.com/docs/sdk/backend-modules/ecom/introduction)**: Manage the cart, checkout, and order phases of an online store experience. Learn more about [Wix eCommerce](https://www.wix.com/ecommerce).
- **[Stores](https://dev.wix.com/docs/sdk/backend-modules/stores/collections/setup)**: Manage product catalogs, inventories, and collections. Learn more about [Wix Stores](https://www.wix.com/app-market/wix-stores).
- **[Pricing Plans](https://dev.wix.com/docs/sdk/backend-modules/pricing-plans/introduction)**: Access and manage customized paid membership plans for accessing content and services. Learn more about [Wix Pricing Plans](https://www.wix.com/app-market/paid-plans).
- **[Restaurants](https://dev.wix.com/docs/api-reference/business-solutions/restaurants/introduction)**: Create and manage menus, online orders, and reservations for restaurants. Learn more about [Wix Restaurants](https://support.wix.com/en/article/wix-restaurants-an-overview).
- **[Blog](https://dev.wix.com/docs/sdk/backend-modules/blog/introduction)**: Access and manage blogs, including posts, draft posts, categories, tags, and statistics. Learn more about [Wix Blog](https://www.wix.com/app-market/wix-blog).
- **[Forum](https://dev.wix.com/docs/sdk/backend-modules/forum/posts/setup)**: Access and manage a business's member forum, including posts and categories. Learn more about [Wix Forum (deprecated)](https://support.wix.com/en/article/wix-forum-about-wix-forum).
- **[Groups](https://dev.wix.com/docs/sdk/backend-modules/groups/groups/introduction)**: Create and manage groups for posting updates, sharing media, starting discussions, and more. Learn more about [Wix Groups](https://www.wix.com/app-market/wix-groups).
- **[Inbox](https://dev.wix.com/docs/sdk/backend-modules/inbox/messages/setup)**: Communicate with customers, contacts, and members through Wix Chat, SMS, or social media. Learn more about [Wix Inbox](https://support.wix.com/en/article/wix-inbox-an-overview).
- **[Loyalty](https://dev.wix.com/docs/sdk/backend-modules/loyalty/accounts/setup)**: Create and manage loyalty programs to increase customer retention. Learn more about [Wix Loyalty Program](https://support.wix.com/en/article/wix-loyalty-program-an-overview).
- **[Marketing Tags](https://dev.wix.com/docs/sdk/backend-modules/marketing-tags/marketing-tags/setup)**: Embed and manage marketing tags for tracking user activity, ad conversion rates, and more.
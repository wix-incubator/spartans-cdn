---
portal: go-headless
name: "Wix MCP Sample Prompts for Headless"
type: ARTICLE_RESOURCE
resourceId: 0a21ad0a-7cd0-4629-9ee3-c29f72aa1378
---

# Wix MCP Sample Prompts for Headless

# Wix MCP Sample Prompts for Headless

Ready to build and develop your [Wix Headless](https://dev.wix.com/docs/go-headless) project with AI? This article showcases some sample prompts and flows that an AI client can run using the [Wix MCP](https://dev.wix.com/docs/sdk/articles/use-the-wix-mcp/about-the-wix-mcp). Use these prompts to launch your own project and accelerate your development.

## Set up headless projects

Whether you want to start your project from scratch or use one of our [templates](https://dev.wix.com/docs/go-headless/tutorials-templates/templates/web/next-js-templates), the Wix MCP can help you kickstart your headless development. The MCP guides your AI client in setting up the necessary environment and files to work with Wix.

### Create a headless project

**Prompt**: Create a Wix headless project for me called Aeroflex Gym Headless. Add Wix Pricing Plans and Wix Bookings solutions to the project.

**Expected AI response**: The AI client creates a new headless project in your Wix account, with the Wix Pricing Plans and Bookings business solutions already installed. The new project appears in your [sites list](https://manage.wix.com/studio/sites?referralInfo=sidebar\&viewId=all-items-view).

### Create an OAuth app

**Prompt**: Add a new Oauth app named Aeroflex Gym: Mobile to my headless project AeroFlex Gym Headless.

**Expected AI response**: The AI client creates a new OAuth app with the requested name in your headless project [settings](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings), and returns the details for you to check.

### Use a headless template

**Prompt:** Create a local project for Wix Headless based on the Professional Coach Next.js template.

**Expected AI response:** The AI client clones the [Professional Coach](https://github.com/wix/headless-templates/tree/main/nextjs/appointments-subscriptions#readme) Next.js project to your local environment, installs dependencies, and sets up the required environment variables.

## Write code for headless

Once you’ve created your headless project, you don’t need to write all the code by yourself. With the MCP’s help, your client can provide support for implementing Wix APIs in your project.

### Display products with Wix Stores

**Prompt:** Create code that will query the product collections I have on my site, like Men's Sportswear, Women's Sportswear, etc., then dynamically display them on a **Our collections** page. When customers select one of the collections, query that collection's products and navigate to a **Product page** that displays the products.

**Expected AI response**:

The AI client creates an **Our Collections** page that queries the available product collections and displays them as clickable buttons to customers. It also adds code to navigate to a **Products Page** that displays the products in the selected collection.

### Add a My Cart button and summary

**Prompt**: I want to add a **My Cart** button that appears on all site pages. When clicked, the button should display a summary of the customer's current cart. The customer should be able to delete items from the cart and update item quantities within this summary, as well as navigate to the full cart page.

**Expected AI response**: The AI client adds a new component that displays a summary of the items in the customer’s current cart. The client writes component code that uses Wix eCommerce API methods like [`getCurrentCart()`](https://dev.wix.com/docs/sdk/backend-modules/ecom/current-cart/get-current-cart) and [`removeLineItemsFromCurrentCart()`](https://dev.wix.com/docs/sdk/backend-modules/ecom/current-cart/remove-line-items-from-current-cart) to enable the customer to update their cart directly from the summary.

### Let users create new events

**Prompt**: In my local `party-planner-headless` project, add a new React component `EventBuilder` that lets the site owner create a new event. It should have fields to define the event title, description, date, and price, as well as at least one image.

**Expected AI response**: The AI client adds a new React component `EventBuilder` to the `party-planner-headless` project that uses the Wix Events APIs to create a new event. If necessary, the client prompts you to import any packages such as the [Wix Events SDK](https://dev.wix.com/docs/sdk/backend-modules/events/introduction) and makes adjustments to authentication code.

### Create a member profile page

**Prompt**: Build a dashboard page for members of my Wix site that displays the profile of the currently logged-in member.

**Expected AI response**: The AI client writes code that gets the information of the currently logged-in member, and uses the response to populate a member profile page.

### Redirect customers to the Wix Bookings checkout

**Prompt**: Add code to my Wix headless project to allow a customer to book a course. As part of this code, create a redirect session that sends a user to the Wix bookings checkout, then returns them to the original site when the checkout flow completes. For now just provide an example post-flow URL.

**Expected AI response**: The AI client creates a frontend UI that allows site visitors to register for a course. As part of the booking code, it sets up a [redirect session](https://dev.wix.com/docs/sdk/backend-modules/redirects/redirects/create-redirect-session) that sends the customer to the Wix Bookings checkout page, then returns them to a URL on the headless site.

## Manage headless projects

When your headless site or app is up and running, you don’t need to go to [wix.com](http://wix.com) to manage it. You can manage the project directly from your client, from installing apps to publishing changes.

### Install an app

**Prompt**: Install Wix Events on my headless site The Party Planner.

**Expected AI response**: The AI client installs the [Wix Events](https://dev.wix.com/docs/sdk/backend-modules/events/introduction) business solution on the requested site.

### Create a new collection

**Prompt:** Create a collection `listings` with fields `title`, `description`, `price`, `images`, `seller phone`, `seller email`.

**Expected AI response**: The AI client creates a new collection `listings` with the requested schema.
---
portal: go-headless
name: "Netlify Quick Launch"
type: ARTICLE_RESOURCE
resourceId: af455dcf-9482-4189-999a-ed37c009bf82
---

# Netlify Quick Launch

# Netlify Quick Launch

 

After selecting a Next.js template, you can integrate it with a Wix site or project and deploy the site on [Netlify](https://www.netlify.com/).

To connect a template with Wix and deploy it, take the following steps:

1. Open the [templates page](https://www.wix.com/developers/headless/templates).
2. Choose the template you want to use. The description for each template indicates the Wix business services it integrates with.
3. Below the preview image for the desired template, click **Deploy**.  
   ![Deploy Wix template](https://wixmp-833713b177cebf373f611808.wixmp.com/images/netlify-quick-launch-md_headless-docs_assets_deploy-button.png)
4. On the **Deploy this Template** page, select **Netlify** and click **Continue**. A list of your existing Wix sites and projects is displayed.
   ![Connect template to Netlify](https://wixmp-833713b177cebf373f611808.wixmp.com/images/netlify-quick-launch-md_headless-docs_assets_deploy-to-netlify.png)
5. Hover over the project or site that you want to connect to the template and click **Connect**.  
   To create a new project to connect to the template click **Create New** at the bottom of the list. A new tab opens in the browser. Follow the prompts to create a new project. Return to the previous tab to continue the Netlify setup.
6. Click **Agree & Add** to give Netlify access to your Wix project.  
   ![Grant Netlify Wix permissions](https://wixmp-833713b177cebf373f611808.wixmp.com/images/netlify-quick-launch-md_headless-docs_assets_netlify-permissions.png)
7. Click **Connect to GitHub** to connect Netlify to your GitHub account. If prompted, log in to GitHub and authenticate.  
   ![Connect Netlify project to GitHub](https://wixmp-833713b177cebf373f611808.wixmp.com/images/netlify-quick-launch-md_headless-docs_assets_netlify-connect-github.png)
8. Click **Save & Deploy** to create a repository on your GitHub account to host the template code. Netlify deploys your new site.  
   ![Deploy your project on Netlify](https://wixmp-833713b177cebf373f611808.wixmp.com/images/netlify-quick-launch-md_headless-docs_assets_netlify-deploy.png)
9. Once the site is deployed, click **Open production deploy** to see the live site.  
   ![View live site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/netlify-quick-launch-md_headless-docs_assets_netlify-open-site.png)
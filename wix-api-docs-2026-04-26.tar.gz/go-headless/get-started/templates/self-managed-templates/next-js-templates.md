---
portal: go-headless
name: "Next.js Templates"
type: ARTICLE_RESOURCE
resourceId: 8e9bc428-5f70-463c-bf75-6691c075d7d8
---

# Next.js Templates

# Next.js Templates

 

With Wix Headless, you can create any site or app you like, and integrate Wix functionality and business solutions.

To help get you started, we've developed several Next.js templates for sites that take advantage of the features Wix Headless offers.

You can adapt these templates to create your own site quickly, or you can use them as examples to help inspire a site you develop from scratch.

Each of our templates uses a different set of business solutions and APIs.

## Professional Coach

![Professional coach site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/816924b86baaa3ee9f2df0facbed6d5e.png)

This template uses the [Bookings](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction) and [Pricing Plans](https://dev.wix.com/docs/sdk/backend-modules/pricing-plans/introduction) APIs.

See a [preview](https://netlify.bookings-appointments-demo.wix.dev/).

Go to the [GitHub repo](https://github.com/wix/headless-templates/tree/main/nextjs/appointments-subscriptions#readme) for instructions on getting started.

## Artist's Music Tour

![Music tour site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/57e0b20fcf9bcf33dab12305519a9316.png)

This template uses the [Events](https://dev.wix.com/docs/sdk/backend-modules/events/introduction) and [eCommerce](https://dev.wix.com/docs/sdk/backend-modules/ecom/introduction) APIs.

See a [preview](https://netlify.commerce-ticketing-demo.wix.dev/).

Go to the [GitHub repo](https://github.com/wix/headless-templates/tree/main/nextjs/commerce-ticketing#readme) for instructions on getting started.

## Personal Trainer

![Personal trainer site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/14488ff2a688c95cf10f084569cf0f47.png)

This template uses the [Bookings](https://dev.wix.com/docs/sdk/backend-modules/bookings/introduction) and [Pricing Plans](https://dev.wix.com/docs/sdk/backend-modules/pricing-plans/introduction) APIs.

See a [preview](https://netlify.bookings-classes-demo.wix.dev/).

Go to the [GitHub repo](https://github.com/wix/headless-templates/tree/main/nextjs/classes-subscriptions#readme) for instructions on getting started.

## Non-Profit Organization

![Non-profit organization site](https://wixmp-833713b177cebf373f611808.wixmp.com/images/80de1cad4414d0930a13b31c61d628e8.png)

This template uses the [Wix Data](https://dev.wix.com/docs/sdk/backend-modules/data/introduction) API.

See a [preview](https://netlify.cms-demo.wix.dev/).

Go to the [GitHub repo](https://github.com/wix/headless-templates/tree/main/nextjs/cms-education#readme) for instructions on getting started.
---
portal: go-headless
name: "React Native template"
type: ARTICLE_RESOURCE
resourceId: 0af6b7ad-6999-4ed0-92c4-a20503af6e36
---

# React Native template

# About the React Native Template

This article introduces the [React Native mobile eCommerce template](https://github.com/wix/headless-templates/tree/main/react-native/mobile-ecommerce) for Wix Headless. The template showcases how to create a secure and flexible mobile application that integrates with Wix business solutions. The template is built using [React Native](https://reactnative.dev/docs/getting-started) and [Expo](https://docs.expo.dev/), a platform for building React applications including mobile apps for Android and iOS. You can customize this template to create your own React Native application, or use it as an example to help inspire your own mobile app.

To explore all available web and mobile templates, visit [Wix Headless Templates](https://www.wix.com/studio/developers/headless/templates).

## Authentication

Authentication is essential for secure interactions with a Wix Headless backend. This template provides built-in strategies for effective authentication management, including:

- Management of active sessions for visitors and members
- Secure redirect-based login
- Silent login during a Wix redirect session

![Mobile member page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/7a2357423f2753db80f47a6be58740fa.png)

To learn more about authentication with Wix Headless, see [Authentication Strategies](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/about-authentication).

## Integration with Wix business solutions

Wix Headless makes it possible to integrate a customized frontend with Wix's backend business solutions. This template exemplifies such integration within a React Native application using the following features of the [Wix eCommerce API](https://dev.wix.com/docs/sdk/backend-modules/ecom/introduction):

- Products Catalog
- Product Details View
- Cart functionality
- Buy now button
- Secure checkout

![Mobile products page](https://wixmp-833713b177cebf373f611808.wixmp.com/images/802065eb06e89f6ae17bc0ad111bad69.png)

If you require a different business solution, you can adapt the template accordingly. For example, you could substitute eCommerce with Wix Bookings. For a list of available business solutions, see [Wix Headless Business Solutions](https://github.com/wix-private/developer-docs/blob/b46f26426712e09530cc805a1f7c6b6721ea88d1/headless-docs/about-headless/business-solutions.md*original::../about-headless/business-solutions.md).

## Use cases

This template provides the groundwork for developing a React Native application that can integrate with your own headless project. Alternatively, it can serve as a guide for integrating Wix Headless features into a different application built with your preferred technologies. To get started, clone the [React Native template](https://github.com/wix/headless-templates).
---
portal: go-headless
name: "Template Deployment"
type: ARTICLE_RESOURCE
resourceId: 930355eb-55c6-41aa-a872-c9a73d78543e
---

# Template Deployment

# Template Deployment



Our Next.js template repositories support quick-start deployment on [Netlify](https://dev.wix.com/docs/go-headless/tutorials-templates/templates/web/netlify-quick-launch).

You can also deploy our templates on any platform that supports Next.js 13 and the [App Router Roadmap](https://beta.nextjs.org/docs/app-directory-roadmap).

For example, you can deploy Next.js projects on:

- [Vercel](https://nextjs.org/docs/deployment#managed-nextjs-with-vercel)
- [Amazon Web Services](https://aws.amazon.com/blogs/mobile/amplify-next-js-13/)
- [Azure](https://learn.microsoft.com/en-us/azure/static-web-apps/nextjs)
- [Firebase](https://firebase.google.com/docs/hosting/nextjs)
- [Heroku](https://elements.heroku.com/buildpacks/mars/heroku-nextjs)

> **Note:** Before attempting to deploy templates on these platforms, check the most up-to-date information from the provider.

For more information about deploying Next.js projects to production on a variety of platforms, see the Next.js [deployment guide](https://nextjs.org/docs/deployment).

Our template repositories require a single environment variable, `NEXT_PUBLIC_WIX_CLIENT_ID`, which should contain a client ID authorizing access to a Wix project. To generate a client ID, [create a project](https://github.com/wix-private/developer-docs/blob/69cb275effee232a8318fb6a7da1baa3ebea6422/headless-docs/setup/create-a-project.md*original::../setup/create-a-project.md) and then [create an OAuth app](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/create-an-oauth-app). If you've already created an OAuth app, you can find the client ID in your project's [**Headless Settings**](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Foauth-apps-settings).

Want to request support for quick-start deployment on another platform? <a href="fallback::mailto:contact-headless@wix.com">Contact us</a> to suggest a platform.
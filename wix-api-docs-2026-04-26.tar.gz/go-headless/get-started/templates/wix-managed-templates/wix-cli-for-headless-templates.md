---
portal: go-headless
name: "Wix CLI for Headless Templates"
type: ARTICLE_RESOURCE
resourceId: 1f91af70-d6ae-4388-8a4e-3cb0f5ec4cbf
---

# Wix CLI for Headless Templates

# Wix CLI for Headless Templates

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


When you [create a new Wix headless project](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/quick-start) using the CLI, you can choose from several templates to jumpstart your development. Each template is pre-configured for a specific business solution or use case, helping you get up and running quickly with a tailored frontend and integrated Wix APIs.

## Templates

| Template | Use case | Key features |
|---|---|---|
| [Commerce (Wix Stores)](https://github.com/wix/headless-templates/tree/main/astro/commerce) | Online stores | Product catalog management, shopping cart, checkout flows, Wix Stores integration. |
| [Scheduler (Wix Bookings)](https://github.com/wix/headless-templates/tree/main/astro/scheduler) | Appointment-based businesses | Scheduling, bookings, Wix Bookings integration. |
| [Registration (Wix Forms)](https://github.com/wix/headless-templates/tree/main/astro/registration) | Data collection and registrations | Form submissions, user registration, Wix Forms integration. |
| [Blank](https://github.com/wix/headless-templates/tree/main/astro/blank) | Fully custom projects | Minimal starter template, essential project structure, no prebuilt business logic. |
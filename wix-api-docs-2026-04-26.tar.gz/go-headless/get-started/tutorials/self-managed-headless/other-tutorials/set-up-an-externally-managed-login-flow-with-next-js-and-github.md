---
portal: go-headless
name: "Set up an Externally-Managed Login Flow with Next.js and Github"
type: ARTICLE_RESOURCE
resourceId: e471a5c7-efbb-496b-a874-37c10321c77c
---

# Set up an Externally-Managed Login Flow with Next.js and Github

# Set Up an Externally-Managed Login Flow with Next.js and GitHub

This tutorial shows how to use the [external identity provider code](https://github.com/wix/headless-templates/tree/main/nextjs/external-identity-provider) from the [Headless Templates repo](https://github.com/wix/headless-templates/tree/main) to set up a login flow managed by an external provider, in this case GitHub, using a custom login interface that syncs with Wix authentication.

> **Note:** External login with Google and Facebook are fully supported in the [Wix login page](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/handle-members-with-wix-managed-login). When working with Google or Facebook as your external identity provider, only use this externally-managed login flow if you require a custom login interface.

Complete the following steps to log a visitor into your site or app with their GitHub credentials:

1. [Authorize the member in GitHub](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps#web-application-flow) and collect their email address.
1. Collect the relevant Wix member ID.
1. Request and store access and refresh tokens for the Wix member ID.

Once the member is logged in, you can redirect them to your home page.

## Before you begin
Before getting started, make sure you have the following:
- A Wix account
- A GitHub account
- A GitHub App
  - In your GitHub app, be sure to set the following settings:
    - Homepage URL: `http://localhost:3000`
    - Authorization callback URL: `http://localhost:3000/api/auth/github/callback`
- A Wix site or Wix Headless project
- A [Wix API Key](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) with Members & Contacts permission
- An [OAuth App for visitors and members](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/create-an-oauth-app-for-visitors-and-members)
- A copy of the [Headless Templates repo](https://github.com/wix/headless-templates/tree/main)
- A custom login interface

## Step 1 | Authenticate in GitHub and collect the member’s email address
1. When a visitor first lands on your login page, follow the [handle visitors](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/handle-visitors) flow.
1. When a member chooses to log in using GitHub on your login page:
    a. Follow the [GitHub OAuth web flow](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps#web-application-flow) to authenticate users with the `@octokit/auth-app package`. See the  [`getGithubAuth`](https://github.com/wix/headless-templates/blob/main/nextjs/external-identity-provider/src/app/api/auth/github/callback/route.ts#L31) function.
    a. Once the member has been authenticated by GitHub, call GitHub’s [Get the authenticated user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user) endpoint. See the [`getGithubUserEmail`](https://github.com/wix/headless-templates/blob/main/nextjs/external-identity-provider/src/app/api/auth/github/callback/route.ts#L49) function.

## Step 2 | Collect a Wix member ID
Once you have the member’s email addresses, check if any of them are associated with a Wix member ID.

See the [`getOrCreateWixMember()`](https://github.com/wix/headless-templates/blob/main/nextjs/external-identity-provider/src/app/api/auth/github/callback/route.ts#L61) function. Call the [`queryMembers()`](https://dev.wix.com/docs/sdk/backend-modules/members/members/query-members) function and filter by the email address collected in step 1:
```js
// ...
async function getOrCreateWixMember(email: string) {
  const wixAdminClient = createClient({
    auth: ApiKeyStrategy({
      apiKey: process.env.WIX_API_KEY!,
      siteId: process.env.WIX_SITE_ID!,
    }),
    modules: {
      members,
    },
  });
 const { items } = await wixAdminClient.members
    .queryMembers({
      filter: { loginEmail: email }
    });
  let member;
  if (items.length === 0) {
    member = await wixAdminClient.members.createMember({
      member: {
        loginEmail: email,
        status: members.Status.APPROVED,
        privacyStatus: members.PrivacyStatusStatus.PRIVATE,
      },
    });
  } else {
    member = items[0];
  }
  return member;
}
```
- If an associated Wix member ID exists, collect it and pass it in the next step.
- If no associated Wix member ID exists, call the [`createMember()`](https://dev.wix.com/docs/sdk/backend-modules/members/members/create-member) function to create one and collect the returned ID.

Note that creating members without explicit registration is an admin function. Make sure to use a [WixClient](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/create-a-client-with-oauth)
and pass an [API key](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) that has permission to create members. See the [serverWixClient.ts](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) file in the sample project.

## Step 3 | Request and store Wix access and refresh tokens
Now that you have the Wix member ID, you can request member tokens.

See the [`getMemberTokensForExternalLogin()`](https://dev.wix.com/docs/sdk/core-modules/sdk/oauth-strategy#getmembertokensforexternallogin) function, which passes the member ID collected in step 2.
```js
// ...
const memberTokens =
    await getServerWixClient().auth.getMemberTokensForExternalLogin(
      member._id!,
      process.env.WIX_API_KEY!
    );
```

Note that getting access and refresh tokens is an admin function. Make sure to use the [WixClient](https://dev.wix.com/docs/go-headless/coding/java-script-sdk/visitors-and-members/create-a-client-with-oauth) with your [OAuth app](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/create-an-oauth-app-for-visitors-and-members) that created this visitor, and pass an [API key](https://dev.wix.com/docs/go-headless/getting-started/setup/authentication/generate-an-api-key-for-admins) that has permission to create member access tokens, to save the visitor’s activity from before they logged in.

Now you can:
- Store the token in a browser cookie to save the member’s session.
- Redirect the member to your homepage which triggers a client and uses the token in the cookie to make requests on their behalf.
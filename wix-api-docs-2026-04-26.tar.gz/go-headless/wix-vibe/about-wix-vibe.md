---
portal: go-headless
name: "About Wix Vibe"
type: ARTICLE_RESOURCE
resourceId: d70e5da9-6082-45b7-97ac-85fe1e9d934f
---

# About Wix Vibe

# About Wix Vibe

[Wix Vibe](https://support.wix.com/en/article/wix-vibe-an-overview) is an AI-powered website builder that lets you create sites from scratch using conversational prompts. An AI chatbot assists with development, and you can also write and edit code directly, giving you full control over your site.

Wix Vibe creates a Wix [headless project](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless) and a frontend interface that's also hosted by Wix. The frontend uses [Astro](https://docs.astro.build/en/getting-started/), a web development framework for content-focused websites, with UI components written in React. This provides access to Wix's business management platform, including eCommerce operations, bookings, and payment processing, with an AI-assisted frontend.

## Wix Vibe editor

The Wix Vibe editor lets you switch between visual editing, direct code access, and business management tools. An AI chatbot assists by generating and modifying code, based on conversational prompts.

![The Wix Vibe editor](https://wixmp-833713b177cebf373f611808.wixmp.com/images/50bc616319a137440f39808f50f0431f.png)

The editor includes:

- **Site tab**: Allows manual visual editing, and displays the site's current appearance.
- **Code tab**: Provides direct access to your project's code for reviewing files, identifying errors, and making edits.
- **Dashboard tab**: Provides access to the site's business operations, including customer data, order processing, and analytics.
- **AI chatbot panel**: Allows you to communicate with the AI agent in natural language to create pages, add functionality, and modify designs.

Learn more about the [Wix Vibe editor](https://support.wix.com/en/article/wix-vibe-about-the-wix-vibe-editor).

## GitHub integration

You can connect a Wix Vibe site to a GitHub repository, allowing you to work in your preferred IDE and collaborate with your team. Learn more about [Wix Vibe GitHub integration](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-git-hub-integration).

## See also

- [Getting Started with Wix Vibe](https://support.wix.com/en/getting-started-with-wix-vibe)
- [About the Wix Vibe Code Tab](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-the-wix-vibe-code-tab)
- [About Wix Headless](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless)
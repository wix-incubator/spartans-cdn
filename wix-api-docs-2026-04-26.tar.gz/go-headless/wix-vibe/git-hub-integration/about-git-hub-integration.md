---
portal: go-headless
name: "About GitHub Integration"
type: ARTICLE_RESOURCE
resourceId: d76c787a-4103-4545-90e9-f89b86f54d8e
---

# About GitHub Integration

# About Wix Vibe GitHub Integration

<blockquote classname="caution">

Due to a recent global vulnerability discovered on the npm supply chain, this feature is currently limited to online editing only.

</blockquote>

Wix Vibe GitHub integration connects a Wix Vibe project to a dedicated GitHub repository. This gives you GitHub's version control and collaboration capabilities, as well as the flexibility to work in whatever IDE you prefer.

## Code in your preferred IDE

Develop a Wix Vibe site using your preferred IDE. Wix sets up a repository that you can clone and develop in using standard development workflows.

## Work with multiple collaborators at once

You can let others interact with a Wix Vibe site's code by inviting them as [collaborators](https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-personal-account-on-github/managing-access-to-your-personal-repositories/inviting-collaborators-to-a-personal-repository) on your GitHub repository. Multiple developers can work on a site's code at once.

> **Note:** Only the owner of a Wix Vibe site can access the Wix Vibe editor.

## Version control

GitHub integration extends Wix Vibe's [version management](https://support.wix.com/en/article/wix-vibe-about-versions). Your Wix Vibe site reflects the main branch of your repository. To sync your local changes with Wix Vibe, merge them to the main branch.

Wix Vibe saves changes to the site's code when:
- You press the **Save** button in the **Code** tab.
- You edit UI elements on the site in the **Site** tab.
- The AI agent makes a change to the site.

Saved changes are tracked as commits in your GitHub repository, giving you a clear history of edits and the ability to revert to previous versions when needed.

When multiple sources edit the same files simultaneously, conflicts can occur. If you push changes to the repository while the AI agent makes changes to the same files, the AI agent shows a rejection message. If your local clone of the repository has files that aren't up to date and you push changes to those files, you'll get a rejection message in your IDE.

## File structure

Wix Vibe projects are built using [Astro](https://docs.astro.build/en/getting-started/), a web development framework optimized for performance. The UI components provided by Wix Vibe are written in React.

<blockquote class="caution">

__Caution:__
Only edit files that are in the **src** folder. Editing other files may cause unexpected behavior or damage to your project.

</blockquote>

### Extensions folder

Your Wix Vibe project may also include an `extensions` folder. This folder hosts the code for any [Wix app extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions) included in your project. App extensions allow you to extend dashboard and backend functionality. For example, you can add custom dashboard pages or implement backend logic to handle events.

> **Note**: The [supported extension types](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/about-app-extensions#supported-extension-types) for Wix Vibe are the same as those supported by the CLI for Headless.

## Get started

To get started with GitHub integration, [set up GitHub integration](https://dev.wix.com/docs/go-headless/resources/wix-vibe/set-up-git-hub-integration) to connect your project to a repository.

> **Note**: GitHub integration only supports creating new repositories. You can't reconnect to an existing repository.

## See also

- [About the Wix Vibe Code Tab](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-the-wix-vibe-code-tab)
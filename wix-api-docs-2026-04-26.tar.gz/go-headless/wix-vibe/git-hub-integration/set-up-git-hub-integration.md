---
portal: go-headless
name: "Set Up GitHub Integration"
type: ARTICLE_RESOURCE
resourceId: ff6b590f-ffc7-431e-b20c-980cb93db757
---

# Set Up GitHub Integration

# Set Up GitHub Integration
 
<blockquote classname="caution">

Due to a recent global vulnerability discovered on the npm supply chain, this feature is currently limited to online editing only.

</blockquote>

## Connect to GitHub

Set up [GitHub integration](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-git-hub-integration) to connect a Wix Vibe project to a dedicated repository created in your GitHub account. This enables version control, collaboration, and the ability to edit the site either via the **Code** tab or in any external IDE.

To set up GitHub integration:

1. In the Wix Vibe **Code** tab, click the **Connect to GitHub** button. The GitHub integration menu opens.
2. In the menu, click **Connect to GitHub**. A new window opens.
3. Log in to GitHub, if needed. 
4. In the window, select your GitHub account or organization, and then click **Install & Authorize**. After installation, the window closes.
5. The GitHub integration menu now shows your connected account and a repository name. You can type in a different name for the repository. After you choose a name, click **Create Repository**.
6. To create a local clone of the repository, click **Clone to your computer** in the menu.

> **Note**: GitHub integration only supports creating new repositories. You can't reconnect to an existing repository.

### Set up your local project

After cloning the repository to your computer:

1. In your local project directory, install the project dependencies.
2. Pull your project's environment variables by running [`wix env pull`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/env-pull). This merges the environment variables into your local `.env.local` file.
3. Start the local development server by running [`wix dev`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev).

## Disconnect from GitHub

If you need to, you can disconnect a Wix Vibe site from GitHub. When you do this, the site retains the code from the most recent commit to its GitHub repository's default branch. After disconnecting, the repository still exists in GitHub, but changes to it aren't reflected on the site.

To disconnect a site from GitHub:
1. Click ⋯ **More Actions** in the GitHub integration menu, and then click **Disconnect from GitHub**. A confirmation window opens.
2. In the confirmation window, click **Disconnect from GitHub**.

<blockquote class="important">

**Important:** 
Once you disconnect a site from its GitHub repository, you can't reconnect the site to that repository again. If you reconnect the site to GitHub later, a new repository is created.

</blockquote>

## See also

- [About GitHub Integration](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-git-hub-integration)
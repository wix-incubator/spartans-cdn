---
portal: wix-cli
name: "login"
type: ARTICLE_RESOURCE
resourceId: fc977823-c139-45e7-acd9-f5f7fd35762c
---

# login

# wix login


Logs in to your Wix account. 

## Usage

```bash
wix login [flags]
```

## Flags

The following flags are available for the `wix login` command:

| Flag           | Description                             |
| -------------- | --------------------------------------- |
| `--api-key <token>` | Authenticate using an API key for automations and CI environments.|
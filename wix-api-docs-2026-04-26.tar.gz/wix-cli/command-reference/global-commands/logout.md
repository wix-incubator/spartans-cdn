---
portal: wix-cli
name: "logout"
type: ARTICLE_RESOURCE
resourceId: 4f1de2a5-fdb3-4f6b-bd14-890ba5944467
---

# logout

# wix logout


Logs out of your Wix account.

> **Note:** To switch to another Wix account:
>1. Run `wix logout`.
>2. Run `wix login`, then click the link provided.
>3. Click **Log in with another account**.

## Usage

```bash
wix logout
```
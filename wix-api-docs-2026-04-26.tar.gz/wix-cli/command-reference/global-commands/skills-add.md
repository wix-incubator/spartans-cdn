---
portal: wix-cli
name: "skills add"
type: ARTICLE_RESOURCE
resourceId: d0fca50d-163b-4fe0-a552-a67b4ec3b7b2
---

# skills add

# wix skills add

Add [Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) to your project. Use this command on projects that don't have skills installed. For more information about where skills appear in your project, see the [CLI Project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure#skills-directories).

## Usage

```bash
wix skills add
```
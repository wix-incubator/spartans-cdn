---
portal: wix-cli
name: "skills update"
type: ARTICLE_RESOURCE
resourceId: f387a05b-cf55-42cd-8578-e1ddff28415e
---

# skills update

# wix skills update

Updates [Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) in your project to the latest version. Run this command when you upgrade the CLI or when you want to pull the latest skills.

> **Note:** Updated skills target the most recent CLI. Make sure your CLI is up to date.

## Usage

```bash
wix skills update
```
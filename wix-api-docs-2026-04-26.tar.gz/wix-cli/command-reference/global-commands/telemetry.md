---
portal: wix-cli
name: "telemetry"
type: ARTICLE_RESOURCE
resourceId: eba10891-6b57-4304-80db-172d2e2a0fb6
---

# telemetry

# wix telemetry


Opts in or out of sending anonymous usage information (telemetry) to Wix.

## Usage

```bash
wix telemetry [state]
```

## States

The following states are available for the `wix telemetry` command:

- `on`: Opt in to sending anonymous usage information to Wix.
- `off`: Opt out of sending anonymous usage information to Wix.
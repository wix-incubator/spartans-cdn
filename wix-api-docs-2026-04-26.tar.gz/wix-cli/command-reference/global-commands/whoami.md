---
portal: wix-cli
name: "whoami"
type: ARTICLE_RESOURCE
resourceId: b353a97e-caf6-49f3-84f3-84a9097c7421
---

# whoami

# wix whoami


Displays the email address of the logged-in Wix user.

## Usage

```bash
wix whoami
```
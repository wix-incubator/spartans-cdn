---
portal: wix-cli
name: "Introduction"
type: ARTICLE_RESOURCE
resourceId: d3afac17-81e3-4c32-a9d8-63d3e33c320f
---

# Introduction

# Wix CLI Reference


With Wix CLI you can develop, test, and deploy Wix projects directly from your terminal. This reference guide provides detailed documentation for all available CLI commands.

## Command overview

|Command      | Description                                                  |
|-------------|--------------------------------------------------------------|
| [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev)         | Starts a local development environment that serves your project. |
| [build](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build)       | Builds your project.                                         |
| [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate)    | Generates an extension for your project.                     |
| [preview](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/preview)     | Creates an online preview of your built project.             |
| [release](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release)     | Starts a process that guides you through releasing your project. |
| [env pull](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/headless-only-commands/env-pull)         | Pulls all your environment variables from Wix's servers and merges them into the `.env.local` file.                             |
| [env set](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/headless-only-commands/env-set)         | Sets an environment variable on Wix's servers.                             |
| [env remove](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/headless-only-commands/env-remove)         | Removes an environment variable from Wix's servers.                             |
| [login](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/login)       | Logs in to your Wix account.                                  |
| [logout](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/logout)      | Logs out of your Wix account.               
| [skills add](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/skills-add)   | Adds Wix skills to your project.                              |
| [skills update](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/skills-update)   | Updates Wix skills in your project to the latest version.     |
| [telemetry](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/telemetry)   | Opts in or out of sending anonymous usage information (telemetry) to Wix.    |
| [translation pull](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/translation-pull)   | Pulls the translations from the Multilingual dashboard.    |
| [translation push](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/translation-push)   | Uploads translation keys to the Multilingual dashboard.    |
| [whoami](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/whoami)      | Displays the email address of the logged-in Wix user.         |

## Command syntax

All Wix CLI commands follow this general syntax:

```bash
wix <command> [subcommand] [flags]
```

Where:
- `<command>` is the primary action (for example, `dev`, `build`, `release`)
- `[subcommand]` is an optional secondary action (for example, `env set`)
- `[flags]` are optional parameters that modify the command's behavior
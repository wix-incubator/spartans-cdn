---
portal: wix-cli
name: "build"
type: ARTICLE_RESOURCE
resourceId: 3e39b7a1-4b33-436c-8e60-24a31bc41e4c
---

# build

# wix build


Builds your project.

You must build your project before:

* Releasing your project.
* Previewing your project.

## Usage

```bash
wix build
```
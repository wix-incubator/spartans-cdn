---
portal: wix-cli
name: "connect"
type: ARTICLE_RESOURCE
resourceId: 192e4ddf-547d-4d91-972e-71ba8ea57e02
---

# connect

# wix connect


Connects your CLI project to [Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe), enabling AI-powered visual editing alongside your local development workflow.

This command is only available for projects created with [Vibe-compatible templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates). After connecting, you can use the Vibe editor to make visual changes to your project using conversational AI prompts, while your local code remains the source of truth.

## Usage

```bash
wix connect
```

## Prerequisites

+ You must have created your project using a Vibe-compatible template. For a list of Vibe-compatible templates, see [Wix CLI for Headless Templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates).
+ Projects created with standard templates can't be connected to Vibe.

## What happens when you connect

When you run `wix connect`, the CLI:

1. Sets up the connection between your local project and the Vibe editor.
2. Enables synchronization between your local files and Vibe.
3. Provides a link to access the Vibe editor for your project.

Once connected, you can:

+ Use AI prompts to modify a site's design and layout in Vibe.
+ Make visual changes without writing code.
+ Switch between coding in your IDE and designing in Vibe.
+ Preview changes in real-time.

Changes made in Vibe are synchronized with your local project files.

## See also

+ [Quick Start a Headless Project](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project)
+ [About Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe)
+ [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
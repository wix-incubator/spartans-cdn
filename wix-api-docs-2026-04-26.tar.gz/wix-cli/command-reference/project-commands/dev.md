---
portal: wix-cli
name: "dev"
type: ARTICLE_RESOURCE
resourceId: 427d9216-8abd-43db-8c33-7fe4b2aa74b2
---

# dev

# wix dev


Starts a local development environment that serves your project. Follow the prompts to open the site or dashboard of your project in the local development environment in your browser.

The development environment is set up for hot reloading, so any changes you make to your code are immediately reflected in the browser.

While the local development environment is running, you can press `C` to assign a new development site.

## Usage

```bash
wix dev [flags]
```

## Flags

The following flags are available for the `wix dev` command:

::::tabs
:::Apps
| Flag           | Alias     | Description                             |
| -------------- | --------- | --------------------------------------- |
| `--https`  | `-s` | Starts your local development environment server on HTTPS. Use this flag if your browser doesn't allow iframes that contain HTTP pages within HTTPS pages. |
| `--port <port>` | | Specify which port to run on. Defaults to 4321.  |
| `--allowed-hosts <allowedHosts>` | | Specify a comma-separated list of allowed hosts or allow any hostname. | 
:::
:::Headless
| Flag           | Alias     | Description                             |
| -------------- | --------- | --------------------------------------- |
| `--port <port>` | | Specify which port to run on. Defaults to 4321.                    |
| `--allowed-hosts <allowedHosts>` | | Specify a comma-separated list of allowed hosts or allow any hostname. | 
:::
::::
---
portal: wix-cli
name: "env pull"
type: ARTICLE_RESOURCE
resourceId: eebced05-2b30-44b5-8234-5057b7a9f796
---

# env pull

# wix env pull


Pulls all your [environment variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables) from Wix's servers and merges them into the `.env.local` file.

## Usage

```bash
wix env pull
```
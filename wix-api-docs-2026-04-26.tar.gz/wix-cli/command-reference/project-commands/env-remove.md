---
portal: wix-cli
name: "env remove"
type: ARTICLE_RESOURCE
resourceId: 9b3dd32f-d06d-4236-80b5-3c1a529b0d53
---

# env remove

# wix env remove


Removes an [environment variable](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables) from Wix's servers.

## Usage

```bash
wix env remove [flags]
```

## Flags

The following flags are available for the `wix env remove` command:

| Flag           | Description                             |
| -------------- | --------------------------------------- |
| `--key <key>`  | (Required) Name of the variable.                   |
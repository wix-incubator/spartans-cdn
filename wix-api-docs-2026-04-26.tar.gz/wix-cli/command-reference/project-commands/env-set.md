---
portal: wix-cli
name: "env set"
type: ARTICLE_RESOURCE
resourceId: c7186f31-a0c4-478b-85c0-f33a365ffb44
---

# env set

# wix env set


Sets an [environment variable](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables) on Wix's servers.

## Usage

```bash
wix env set [flags]
```

## Flags

The following flags are available for the `wix env set` command:

| Flag           | Description                             |
| -------------- | --------------------------------------- |
| `--key <key>`  | (Required) Name of the variable.                   |
| `--value <value>`  | (Required) Value of the variable.              |
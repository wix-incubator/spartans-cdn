---
portal: wix-cli
name: "generate"
type: ARTICLE_RESOURCE
resourceId: 20550061-e3bf-4d47-8f21-12ecde4a263c
---

# generate

# wix generate


Starts a process that guides you through adding an extension to your project. After selecting an extension you are prompted for relevant configuration details, then your extension is generated in your project's local files, where each extension will have its own `extension.ts` file.

## Usage

```bash
wix generate
```

## Flags

The following flags are available for the `wix generate` command:

::::tabs
:::Apps
| Flag           | Description                             |
| -------------- | --------------------------------------- |
| `--type`  | Generates an extension with the specified type. Supported values: <br><br> <ul><li>`DASHBOARD_PAGE`</li><li>`DASHBOARD_MODAL`</li><li>`DASHBOARD_PLUGIN`</li><li>`DASHBOARD_MENU_PLUGIN`</li><li>`EMBEDDED_SCRIPT`</li><li>`CUSTOM_ELEMENT`</li><li>`REACT_COMPONENT`</li><li>`SITE_PLUGIN`</li><li>`EVENT`</li><li>`SERVICE_PLUGIN`</li></ul> |
:::
:::Headless
| Flag           | Description                             |
| -------------- | --------------------------------------- |
| `--type` | Generates an extension with the specified type. Supported values: <br><br> <ul><li>`DASHBOARD_PAGE`</li><li>`DASHBOARD_MODAL`</li><li>`DASHBOARD_PLUGIN`</li><li>`DASHBOARD_MENU_PLUGIN`</li><li>`EMBEDDED_SCRIPT`</li><li>`EVENT`</li><li>`SERVICE_PLUGIN`</li></ul> |
:::
::::
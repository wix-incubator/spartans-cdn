---
portal: wix-cli
name: "translation pull"
type: ARTICLE_RESOURCE
resourceId: 724aeda4-9812-42df-8ba8-f5d40abba074
---

# translation pull

# wix translation pull

Pulls the translations from the [Multilingual dashboard](https://support.wix.com/en/article/wix-multilingual-managing-your-languages).

For more information see [Add Multilingual Support](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/add-multilingual-support).

## Usage

```bash
wix translation pull
```
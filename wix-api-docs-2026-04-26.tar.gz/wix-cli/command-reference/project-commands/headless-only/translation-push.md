---
portal: wix-cli
name: "translation push"
type: ARTICLE_RESOURCE
resourceId: 3503cf6a-f077-48bb-902d-165fd9269d86
---

# translation push

# wix translation push

Uploads translation keys to the [Multilingual dashboard](https://support.wix.com/en/article/wix-multilingual-managing-your-languages). 

For more information see [Add Multilingual Support](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/add-multilingual-support).

## Usage

```bash
wix translation push
```
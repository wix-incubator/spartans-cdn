---
portal: wix-cli
name: "preview"
type: ARTICLE_RESOURCE
resourceId: 175c4927-afb0-49f7-a9e4-330b9ba78f8c
---

# preview

# wix preview


Creates an online preview of your built project and provides a preview URL in the console. By default, the code for your preview is hosted on Wix's servers. 

A preview URL is a link you can share with team members that allows them to preview and test your project. Each preview URL directs to a unique version of your project hosted on Wix's servers. Subsequent updates to your project won't affect any previously created versions.

>**Note:** Before previewing the project, run the [build](https://dev.wix.com/docs/wix-cli/command-reference/build) command.

<blockquote class="important">

__Important:__
The `preview` command uploads your code but does not register all extensions in your app's configuration. Some extensions, such as embedded scripts, site widgets, and site plugins, won't work until you create an app version with [`release`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release).

</blockquote>

## Usage

```bash
wix preview [flags]
```

## Flags

The following flags are available for the `wix preview` command:

::::tabs
:::Apps
| Flag           | Alias     | Description                             |
| -------------- | --------- | --------------------------------------- |
| `--site <site-id>`  | `-s <site-id>` | Allows you to set the `site` used for application preview URLs. If this flag is not provided, the `site-id` defaults to the currently-selected development site. You can get the ID of a site from the site URL in your browser. |
| `--base-url <url>` | | Sets the base URL for uploading your static files to an external CDN. If this flag is not provided, the code for your preview will be hosted on Wix's servers. |
:::
:::Headless
The flags aren't applicable.
:::
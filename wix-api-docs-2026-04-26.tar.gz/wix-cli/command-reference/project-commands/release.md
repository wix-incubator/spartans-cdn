---
portal: wix-cli
name: "release"
type: ARTICLE_RESOURCE
resourceId: 74291f35-4b74-469c-a10d-d19b79fb8688
---

# release

# wix release

Starts a process that guides you through releasing your project. Releasing pushes your project to Wix's servers and publishes it. Once complete, the CLI displays preview URLs for your project and dashboard, along with the published project URL.

For apps specifically, this command releases a new [version](https://dev.wix.com/docs/build-apps/manage-your-app/versioning/about-app-versioning) of your app. This also registers extension components in your app's configuration. Some extensions won't work until you've run `release`.

Once the app version is released, you can [submit it for review](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/submit-your-first-app-version) to publish it to the [Wix App Market](https://www.wix.com/app-market). If you choose not to list your app in the Wix App Market, you can distribute your app by [sharing an install link](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/share-an-app-install-link) or [install it directly](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/install-your-app-directly-on-sites) on a site within your account.

>**Note:** Before releasing the project, run the [build](https://dev.wix.com/docs/wix-cli/command-reference/build) command.

## Usage

```bash
wix release [flags]
```

## Flags

The following flags are available for the `wix release` command:

::::tabs
:::Apps
| Flag           | Alias     | Description                             |
| -------------- | --------- | --------------------------------------- |
| `--site <site-id>`  | `-s <site-id>` | The site ID to use for application preview URLs. Defaults to the current selected development site. |
| `--base-url <url>` | | Sets the base URL for uploading your static files to an external CDN. If this flag isn't provided, the code for your project is hosted on Wix's servers. |
| `--comment <comment>`  | `-c <comment>` | The comment for your release version. Not visible to Wix users. |
| `--version-type <type>`  | `-t <type>` | The type of version you would like to create. <br><br> Accepted values for `<type>`: `major`, `minor`. |
:::
:::Headless
The flags aren't applicable.
:::
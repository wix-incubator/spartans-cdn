---
portal: wix-cli
name: "About The Wix CLI"
type: ARTICLE_RESOURCE
resourceId: bb871dfc-067d-4da1-983d-45767c3d5dd7
---

# About The Wix CLI

# About the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Development Overview](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/development-overview).
- Wix CLI for Headless: [Development Overview](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/project-development/development-overview).

This CLI is for Wix apps and headless projects. For Wix site development, see [Git Integration & Wix CLI for Sites](https://dev.wix.com/docs/develop-websites/articles/workspace-tools/developer-tools/git-integration-wix-cli/about-git-integration-wix-cli).

</blockquote>

The Wix CLI is a unified command-line tool for creating, developing, and deploying Wix apps and Wix Headless projects. It simplifies development by automatically generating a complete project structure and handling initial setup and configuration. It also provides commands to generate extensions and manage your project throughout development, and includes [Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills), which enable AI tools to perform CLI tasks. This allows you to focus on building the unique features of your project.

The Wix CLI:

- Provides a modern, streamlined development experience with an AI-assisted workflow.
- Makes it easy to develop, test, and manage both app and headless projects.
- Provides a fully managed hosting solution on Wix’s servers.

## Modern development experience

The CLI uses a standardized project structure based on the Astro web framework. Astro is a JavaScript-based web framework designed for building fast, content-focused websites. The CLI also supports backend development with [HTTP endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints).

### Why Astro?

The Wix CLI is built on Astro because it offers several key advantages for modern web development:

- **Performance-focused architecture:** Astro focuses on making websites that load quickly and perform well, which is especially important for content-heavy sites. It uses server-side rendering by default, making it easier to build high-performing websites without the added complexity of client-side rendering.
- **Flexibility and simplicity:** Astro gives you flexibility in how you build. You can use plain HTML, CSS, and vanilla JavaScript for most of your project, and only add framework components (React, Vue, Svelte) where you need them. This means you import only what you need rather than loading a full framework for the entire site.
- **Partial hydration:** Astro uses partial hydration, which means it strips out unused JavaScript and sends only what the client actually needs. This results in smaller bundle sizes and faster page loads.
- **Framework agnostic:** Unlike frameworks that lock you into a specific technology, Astro lets you mix and match. You can use React components in one part of your site, Vue in another, or stick with plain HTML throughout. This flexibility makes it easier to adopt new technologies or work with existing codebases.
- **Simplified development model:** Astro eliminates framework-specific complexities like hooks, stale closures, and observables. This makes development more approachable, especially for developers who prefer working with standard web technologies.
- **No new language to learn:** Everything in Astro is still written in HTML, CSS, and JavaScript (or TypeScript if you prefer). There's no proprietary templating language or significant learning curve.

## Development capabilities

The CLI allows you to:

- Generate [extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions) to quickly add functionality to your project, such as custom dashboard pages and event handlers. 
- Call [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) methods directly, as the CLI handles token management and authentication for you, eliminating the need to set up a [Wix Client](https://dev.wix.com/docs/sdk/articles/set-up-a-client/about-the-wix-client).
- [Test projects](https://dev.wix.com/docs/wix-cli/guides/development/development-overview#develop-and-test-projects) locally with hot reloading.
- Create shareable [preview versions](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/preview) of your project for collaboration.

The CLI also provides full TypeScript support with IntelliSense, offering autocomplete suggestions and validation as you code.

You can use [Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) to implement the development capabilities of the CLI. 

## Wix app support

The CLI generates the complete project structure needed for [Wix app](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps) development. You can add [extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions) built with TypeScript, React components, and the Wix Design System, providing a native Wix look and feel.

### Development sites

When developing apps, you can test your functionality using development sites. These are premium Wix sites that you can use for app testing. You can maintain up to five development sites simultaneously for testing different aspects of your app.

## Wix skills

New CLI projects include [Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) by default. Wix skills enhance your AI workflow by providing instructions and context that supported AI tools use to develop, deploy, and validate a CLI project.

## Headless project support

The CLI simplifies and streamlines [Wix Headless](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless) project development, making it easy to work with Wix's business solutions and dashboard, and allowing you to build your own custom frontend using any technology supported by Astro.

When you create a headless project, the CLI generates the code for an Astro site so you can begin developing immediately. Projects started with [Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe) can be opened locally and developed with the CLI. For projects created with the CLI using [Vibe-compatible templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates), you can connect to Vibe.

### Project's private app

When you create a headless project, the CLI sets up a private app that allows you to add features to your project through [extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions). The app also acts as the [OAuth app](https://dev.wix.com/docs/go-headless/get-started/setup/authentication/create-an-oauth-app) that handles authentication for your project's frontend. This private app can't be shared with others, it's only for use in your headless project.

### Custom domain support

You can use a [custom domain](https://www.wix.com/my-account/site-selector/?buttonText=Select%20Site&title=Select%20a%20Site&autoSelectOnSingleSite=true&actionUrl=https:%2F%2Fwww.wix.com%2Fdashboard%2F%7B%7BmetaSiteId%7D%7D%2Fadd-domain) for headless frontends to provide a branded experience for users.

## Flexible file system

The CLI uses a [standardized project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure) based on Astro, while giving you the flexibility to organize your extensions into custom folders within the `src/` directory. This allows you to structure your code in a way that works best for your project.

## Environment variables

The CLI provides built-in support for [environment variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables), allowing you to store configuration values and secrets outside of your code. You can define type-safe environment variables with different security levels, which makes your applications more secure and portable.

## Hosting and infrastructure

The CLI provides a serverless hosting solution where scaling, resource allocation, and maintenance are fully managed, so you don't have to worry about infrastructure.

The main features include:

- **Static sites hosting:** The hosting environment is powered by a global CDN that ensures fast and reliable content delivery to users.
- **Serverless architecture:** Run full-stack apps without managing servers. Scaling and resource management are handled automatically by Wix.
- **Automatic SSL certificates:** SSL certificates are automatically provisioned and renewed, ensuring secure connections.
- **Session management middleware:** A middleware manages session tokens and cookies for the current site visitor, allowing you to use stateful session APIs like e-commerce carts, site visitor authentication, and more. 

## Use these docs with AI tools

Wix developer documentation is available in machine-readable formats for use with AI coding assistants and LLMs:

- **llms.txt index:** Browse a structured index of all documentation at [dev.wix.com/docs/llms.txt](https://dev.wix.com/docs/llms.txt).
- **Markdown format:** Append `.md` to any documentation page URL to retrieve a Markdown version of that page.
- **Page menu:** Use the "Ask Assistant" dropdown on any documentation page to copy the page as Markdown or get a direct link to the Markdown version.

## Get started

- [Quick Start an App](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-an-app)
- [Quick Start a Headless Project](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project)
---
portal: wix-cli
name: "About Wix Skills"
type: ARTICLE_RESOURCE
resourceId: 2c6a5925-849f-48b7-a271-ebd3b5463533
---

# About Wix Skills

# About Wix Skills

[Wix skills](https://dev.wix.com/docs/api-reference/articles/ai-tools/about-wix-skills) help external AI tools, such as Claude and Cursor, work with the [CLI](https://dev.wix.com/docs/wix-cli) by providing the instructions and context needed to develop, deploy, and manage CLI projects.

## Wix skills capabilities

Wix skills support every stage of CLI project development, from coding to deployment.

### Develop

You can use Wix skills to develop capabilities such as:

- [Dashboard extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/about-dashboard-extensions): pages, modals, and plugins
- [Backend extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/about-wix-cli-backend-extensions): service plugins, event handlers, and backend APIs
- [Site extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/about-site-extensions-in-the-wix-cli): site widgets, site plugins, and embedded scripts
- [UI with the Wix Design System](https://dev.wix.com/docs/build-apps/develop-your-app/wix-design-system/about-the-wix-design-system): components for dashboard and site UIs

### Verify, build, and deploy

You can also use Wix skills to verify app readiness and handle the [build and deploy process](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project). This includes:

- Installing dependencies
- Running type checks
- Troubleshooting and debugging
- [Building](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build) and [deploying a preview](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/preview)

For more information about supported skills, see the [Wix skills repository](https://github.com/wix/skills).

## Manage Wix skills in your project

New CLI projects include Wix skills by default. To see where skills appear in your project, see the [CLI project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure#skills-directories).

To add Wix skills to an existing project, use the [wix skills add](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/skills-add) command.

To update Wix skills to the latest version, use the [wix skills update](https://dev.wix.com/docs/wix-cli/command-reference/global-commands/skills-update) command.

> **Note**: Keep the CLI and Wix skills aligned. When you upgrade one, upgrade the other so they stay compatible.

## Sample prompts

The following are example prompts you can try with supported AI tools. They provide a useful starting point as you explore what you can build with Wix skills.

**Dashboard extension prompts**

- Add a dashboard page that lists all contacts with search and filters.

- Add a **Delete** confirmation modal before removing a product from the catalog.

**Backend extension prompts**

- Add a backend API that returns the last 10 orders as JSON.

- Add custom shipping rates based on weight and destination.

**Site extension prompts**

- Add a site widget that shows a **Sale ends in** countdown with a configurable end date.

- Add a site plugin that shows **Back in stock** in the product slot.

**Validate and test prompts**

- Run the full validation workflow after the last change and report any failures.

- Verify release readiness and report any issues.

## See also

- [CLI Development Overview](https://dev.wix.com/docs/wix-cli/guides/project-development/development-overview)
- [Wix skills repository](https://github.com/wix/skills)
- [About the Wix MCP](https://dev.wix.com/docs/sdk/articles/use-the-wix-mcp/about-the-wix-mcp)
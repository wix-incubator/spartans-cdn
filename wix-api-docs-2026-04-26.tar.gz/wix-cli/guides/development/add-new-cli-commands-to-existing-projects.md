---
portal: wix-cli
name: "Add New CLI Commands to Existing Projects"
type: ARTICLE_RESOURCE
resourceId: 3e6853a2-f1d9-4575-88a2-e07e23599baa
---

# Add New CLI Commands to Existing Projects

# Add New CLI Commands to Existing Projects


When a new command is introduced to the CLI, it enhances the functionality and capabilities available for development. 
However, it's important to note that projects created before the release of the new command won't automatically have it integrated into their environments. 
Instead, you need to add the new command to your `package.json` file manually before you can use it.

Failure to update the `package.json` with the new command will result in errors when you attempt to use the new command.

## Adding a new command

1. Identify the new command from the [CLI Command Reference](https://dev.wix.com/docs/wix-cli/command-reference/introduction).
1. Open your project and locate the `package.json`. This file contains all the dependencies and configurations for your project.

    > **Note**: Your project's file structure is documented in [CLI Project Structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure).

1. Under the `scripts` section in the `package.json` file, add the command and a name as a key:value pair.

    For example:

   ```json
   "scripts": {
       ...
       "release": "wix release",  
       ...
   }
   ```

1. Save your changes.
1. Ensure you are using the [latest version](https://dev.wix.com/docs/wix-cli/guides/development/development-overview#keep-the-cli-up-to-date) of the CLI before using the new command.
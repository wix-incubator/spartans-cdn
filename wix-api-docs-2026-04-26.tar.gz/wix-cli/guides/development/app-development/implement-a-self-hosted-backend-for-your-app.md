---
portal: wix-cli
name: "Implement a Self-Hosted Backend for Your App"
type: ARTICLE_RESOURCE
resourceId: a7b4ddaa-38eb-4597-89cb-62db6a7a7fd2
---

# Implement a Self-Hosted Backend for Your App

# Implement a Self-Hosted Backend for Your App


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Implement a Backend for Your App](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/implement-a-backend-for-your-app).

</blockquote>

While building a CLI app, you may need to use your own APIs, employ third-party APIs, and work with a database. In order to do these things in a secure manner, you need to implement a backend for your app. The simplest way to implement a backend is to use the CLI's [HTTP endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints).

You also have the option to integrate with a self-hosted backend.

## Integrate with a self-hosted backend

You can use any server technology you want to create a backend that integrates with your Wix CLI app.

There are a few things you need to keep in mind when implementing your backend:

- **CORS**: You need to set up CORS properly to make sure your server accepts requests from your app.
- **Authentication**: You need to check that requests to your server are coming from your app and not a malicious user.
- **Multiple instances**: You can optionally differentiate between the multiple instances of your app when they make requests to the server.
- **Call Wix APIs**: You can call Wix APIs from your backend using the [Wix REST API](https://dev.wix.com/docs/rest). You need to authenticate your requests using either [OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth) or [API keys](https://dev.wix.com/docs/rest/articles/getting-started/api-keys).

### CORS

When making HTTP requests from your app code to your backend, you need to make sure that your backend allows those requests. Your app frontend code is hosted on [the Wix App CDN](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/development-overview#the-wix-apps-cdn). The app is served from its own `wix.run` subdomain. To allow your app frontend code to make HTTP requests to your backend, you need to allow CORS requests from your frontend's domain.

Add the following headers to your backend's HTTP responses to allow CORS requests from your app.

Replace **\<your-app-id\>** with your app's ID. You can find it in your [app's dashboard](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fhome). Also, only allow the HTTP methods that your app requires.

```http
Access-Control-Allow-Origin: https://<your-app-id>.wix.run
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
```

To enable local development, you also need to allow CORS requests from `localhost:5173` or, preferably, from all origins with `localhost`.

```http
Access-Control-Allow-Origin: http://localhost:5173
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
```

## Authenticate incoming requests

If you expose a self-hosted backend API for your app, you need to make sure that requests to your API are coming from your app and not from malicious users.

For a detailed guide on how to do this, see [Authenticate Incoming Requests to Your Self-Hosted Backend](https://github.com/wix-private/developer-docs/blob/418ddd0223c485cd4b17122784b638b2b850cc58/cli-portal/guides/project-development/authenticate-incoming-requests-to-your-backend.md*original::./authenticate-incoming-requests-to-your-backend.md).

### Differentiate between multiple instances

As described in the guide above, when an app sends a request to your server it must include an instance string containing an **`instanceId`**, This is the unique ID of the current instance of your app, and can be used to differentiate between the multiple instances of your app when they make requests to the server.
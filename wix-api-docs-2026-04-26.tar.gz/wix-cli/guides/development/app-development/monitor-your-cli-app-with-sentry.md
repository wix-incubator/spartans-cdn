---
portal: wix-cli
name: "Monitor Your CLI App With Sentry"
type: ARTICLE_RESOURCE
resourceId: 94ded6bf-8edf-40ca-ac41-e7372c3c41ef
---

# Monitor Your CLI App With Sentry

# Monitor Your CLI App With Sentry


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Monitor Your App with Sentry](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/monitor-your-app-with-sentry).

</blockquote>

As you develop and deploy your CLI application to users, the importance of robust monitoring becomes crucial. Wix can send monitoring data to your [Sentry](https://sentry.io/) account, allowing you to effectively track and fix errors in your app. By setting up Sentry and connecting it to your app, you'll gain valuable, out-of-the-box insights into your app's health and comprehensive error reporting across the various Wix platforms.

Learn more about [Sentry](https://open.sentry.io/benefits) and how to maximize its capabilities.

This article will guide you through the process of creating a monitoring extension for your app that integrates with Sentry using your Sentry DSN (Data Source Name) and the Wix JavaScript SDK.

<blockquote class="important">
  <strong>Important:</strong>
  Before making calls to the methods defined below using this solution, make sure you have the latest version of <a href="fallback::https://dev.wix.com/docs/sdk/core-modules/essentials/introduction">@wix/essentials</a> and the Wix CLI.
</blockquote>

## Step 1 | Get a Sentry DSN

1. Go to the [Sentry website](https://sentry.io/) and create an account if you haven't already.
2. Create a new project. Selecting the platform that aligns with your app's stack.
3. Collect the project's DSN key. You'll need the DSN key to connect your app to Sentry.

## Step 2 | Configure your app

1. Enable the monitoring feature through Wix CLI by adding the following to your `wix.config.json` file.

  ```json
  {
    "monitoring": {
      "sentry": {
        "dsn": "<YOUR_SENTRY_DSN>"
      }
    }
  }
  ```

  When you save your changes, a monitoring extension is automatically added to your app.

2. To preview your changes, run the following command using npm or yarn:

    **npm**

    ```js
    npm run dev
    ```

    **yarn**

    ```js
    yarn dev
    ```

  Note that when Wix recognizes the changes to your `wix.config.json` file,  Wix will report unhandled errors to your Sentry project automatically.
  You can also report errors directly in your code:

- [`captureException()`](https://dev.wix.com/docs/sdk/core-modules/essentials/monitoring#capture-exception)
- [`captureMessage()`](https://dev.wix.com/docs/sdk/core-modules/essentials/monitoring#capture-message)
- [`addBreadcrumb()`](https://dev.wix.com/docs/sdk/core-modules/essentials/monitoring#add-breadcrumb)
- [`startSpan()`](https://dev.wix.com/docs/sdk/core-modules/essentials/monitoring#start-span)

## Step 3 | Monitor in the Sentry dashboard

Access your Sentry dashboard to observe logged errors and monitor app performance for real-time insights and debugging.

Regularly check your Sentry dashboard to monitor errors, performance, and gain insights into your application's health and issues.
Leverage features such as issue tracking, release tracking, and performance monitoring to continuously improve your application.

## Supported Wix CLI Extensions

The monitoring solution is available for the following types of extensions:

**Dashboard Extensions**

- [Dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions-with-the-cli)
- [Dashboard plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extension-with-the-cli)
- [Dashboard modals](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions-with-the-cli)

**Backend Extensions**

- [Events](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/events/add-event-extensions-with-the-cli)
- [Service plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/add-service-plugin-extensions-with-the-cli)

**Site Extensions**

- [Embedded scripts](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-cli)
- [Site widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/custom-element-site-widgets/add-a-site-widget-extension-in-the-cli)
- [Site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/add-a-site-plugin-extension-in-the-cli)

## Best practices

- Set up [alerts in Sentry](https://docs.sentry.io/product/alerts/) to notify you of critical failures.
- Set up [notifications](https://docs.sentry.io/product/alerts/notifications/) in Sentry.

## See also

- [Sentry documentation](https://docs.sentry.io/)
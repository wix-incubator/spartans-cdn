---
portal: wix-cli
name: "Build and Deploy a Project"
type: ARTICLE_RESOURCE
resourceId: b5a337d0-c9c0-47be-9cad-ff730f856640
---

# Build and Deploy a Project

# Build and Deploy a Project with the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Build and Deploy an App with the CLI](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli).
- Wix CLI for Headless: [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/project-development/build-and-deploy-a-project).

</blockquote>

After developing and testing your Wix CLI project locally, you can take it to production. This article guides you through that process. You can also use [Wix Skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) to implement the build and deploy process. For app testing guidelines, see [App Checks and Testing Guide](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/app-checks-and-testing-guide).

For instructions on creating a project, see [Quick Start a Headless Project](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-a-headless-project), or [Quick Start an App](https://dev.wix.com/docs/wix-cli/guides/get-started/quick-start-an-app).


## Before you begin

Before getting started, make sure that you have [Node.js](https://nodejs.org/en/) (v20.11.0 or higher).

## Step 1 | Build the project

Run the [build](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build) command to build the assets for your project.

## Step 2 (Optional) | Create preview URLs

A preview URL is a link you can share with team members that allows them to preview and test your project. Each preview URL directs to a unique version of your project hosted on Wix's servers. Subsequent updates to your project won't affect any previously created versions.

To push your project to Wix's servers for hosting and create preview URLs, run the [preview](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/preview) command.

This returns unique URLs linking to preview versions of your site, editor (for apps), and dashboard that you can share with others.

<blockquote class="important">

__Important:__
The `preview` command uploads your code but does not register all extension components in your app's configuration. Some extensions, such as embedded scripts, site widgets, and site plugins, won't be recognized by the platform until you run [`release`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release).

</blockquote>

## Step 3 | Release your project

To push your project to Wix's servers for hosting and releasing a version, run the [release](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) command and follow the prompts. This step also registers extension components in your app's configuration. Some extensions won't work until you've run `release`.

::::tabs
:::Apps
The CLI guides you through the process of releasing a new [app version](https://dev.wix.com/docs/build-apps/manage-your-app/versioning/about-app-versioning). An app version allows you to publish an app to the [Wix App Market](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/install-your-app-directly-on-sites) or install it on a site with a direct install URL. You can view [your app versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

Learn more about [app distribution](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/about-app-distribution).
:::
:::Headless
Releasing pushes your project to Wix's servers and publishes your site. After releasing your project, the CLI provides the URL of your published site, and preview URLs for your project's site and dashboard.
:::
::::

## Next steps
You now have a fully working project.

Use the following resources to continue building your project:

+ [Add extensions to your project](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions).
+ [Learn more about how to develop your project](https://dev.wix.com/docs/wix-cli/guides/development/development-overview).
+ [Learn about the project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure).
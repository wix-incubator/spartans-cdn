---
portal: wix-cli
name: "Determine Which CLI Your Project Uses"
type: ARTICLE_RESOURCE
resourceId: 70d1d320-4b2c-4467-bc65-81d355ed1a3c
---

# Check your Wix CLI Version

# Determine Which CLI Your Project Uses


The new Wix CLI is a unified tool for both Wix apps and Wix Headless projects.

If you're working on an existing project, you can identify which CLI it uses by checking a few key indicators.

## Check your package.json

Look for `@wix/astro` in your project's `devDependencies`.

```json
{
  "devDependencies": {
    "@wix/astro": "^2.0.0"
  }
}
```

## Check for extensions.ts file

Look for an `extensions.ts` file in your project's `src` folder.

```
src/
├── extensions.ts
└── ...
```

If your project has these indicators, then it uses the new Wix CLI documented in this reference.

If your project doesn't have these indicators, your project uses one of the other CLI tools. To learn more, see the relevant documentation:

- [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps)
- [Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/about-the-wix-cli-for-headless).
---
portal: wix-cli
name: "Elevate API Call Permissions"
type: ARTICLE_RESOURCE
resourceId: 316d2cd0-bd1a-43e7-9736-d329bde4df2c
---

# Elevate API Call Permissions

# Elevate API Call Permissions


<blockquote class="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Elevate API Call Permissions with the CLI](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/elevate-api-call-permissions-with-the-cli).

</blockquote>

Some SDK methods require [elevated permissions](https://dev.wix.com/docs/api-reference/articles/authentication/about-elevated-permissions?apiView=SDK) to access sensitive data or perform privileged operations. For example, retrieving site properties or accessing business data often requires app-level authorization that [site visitors](https://dev.wix.com/docs/api-reference/articles/authentication/about-identities?apiView=SDK#site-visitor), [site members](https://dev.wix.com/docs/api-reference/articles/authentication/about-identities?apiView=SDK#site-member), and [Wix users](https://dev.wix.com/docs/api-reference/articles/authentication/about-identities?apiView=SDK#wix-user) don't have. Without elevation, these calls return a 403 Forbidden error.

> **Note:** To determine whether a method requires elevation, check that method's [reference documentation](https://dev.wix.com/docs/api-reference?apiView=SDK).
>
> - If a site visitor action in your frontend triggers the call (for example, submitting an image to CMS), use `auth.elevate()` in your backend endpoint.
>
> - If the call runs only between servers, or it's an admin operation (for example, a synchronization job that updates catalog data), use [API keys](https://dev.wix.com/docs/go-headless/develop-your-project/admin-operations/about-admin-operations).

To elevate API call permissions:

1. Set up your project's backend code to handle elevated requests.
1. Send a request from your frontend code to your project's backend.

You can make calls from your frontend code to your project's backend using [HTTP endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints). How you call the endpoint from the frontend depends on whether you're building a [headless project](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless) or an [app](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps).

>**Note:** For an example on how to elevate methods, see the [Upload Images to CMS](https://dev.wix.com/docs/go-headless/get-started/tutorials/wix-managed-headless/upload-images-to-cms) tutorial.

<blockquote class="important">

**Important:** Exposed elevated API calls create a security risk for [privilege escalation attacks](https://en.wikipedia.org/wiki/Privilege_escalation). Make sure to protect your exposed API calls with the appropriate logic.

</blockquote>

## Step 1 | Set up the endpoint in your project's backend

Set up your project's backend to handle requests for elevated API calls from your frontend. 

To set up your backend:

1. Create an [HTTP endpoint](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/add-http-endpoints-to-your-project). Do only the **Step 1 | Create the endpoint file** from the linked article.

1. In the file that defines your endpoint, import `APIRoute` from `astro`, the [`auth`](https://dev.wix.com/docs/sdk/core-modules/essentials/auth) submodule from `@wix/essentials`, and the module containing the method you want to call with elevated permissions.

   ```ts
   import type { APIRoute } from "astro";
   import { auth } from "@wix/essentials";
   import { <module> } from "@wix/<package>";
   ```

1. Expose an endpoint that calls the API method you need. Wrap the method with [`auth.elevate()`](https://dev.wix.com/docs/sdk/core-modules/essentials/auth#elevate) before calling it.

   ```ts
   export const GET: APIRoute = async ({ request }) => {
     const elevatedFunction = auth.elevate(<module>.function);
     const response = await elevatedFunction();
     // ...    
   }
   ```

## Step 2 | Call the endpoint from your frontend

Call your backend endpoint from your project's frontend. How you call the backend depends on whether you're building a headless project or an app.

::::tabs
:::Headless-projects
In headless projects, use the standard `fetch()` API to call your endpoint, with the following path: `/api/<your-endpoint-name>`.

```js
const result = await fetch('/api/<your-endpoint-name>');
```
:::
:::Apps
In apps, use the [`httpClient.fetchWithAuth()`](https://dev.wix.com/docs/sdk/core-modules/essentials/http-client) method from `@wix/essentials`. To construct the full endpoint URL and call the endpoint:

1. Import `httpClient` from `@wix/essentials`.

   ```ts
   import { httpClient } from "@wix/essentials";
   ```

2. Retrieve the base URL from `import.meta.url`:

   ```ts
   const baseApiUrl = new URL(import.meta.url).origin;
   ```

3. Call the endpoint using `httpClient.fetchWithAuth()` with the following path: `${baseApiUrl}/api/<your-endpoint-name>`.

   ```ts
   const result = await httpClient.fetchWithAuth(`${baseApiUrl}/api/<your-endpoint-name>`);
   ```
:::
::::

## Examples

These examples demonstrate how to elevate [Get Site Properties](https://dev.wix.com/docs/api-reference/business-management/site-properties/properties/get-site-properties?apiView=SDK).

### Backend code

The backend code is the same for both headless and app projects.

```ts
// src/pages/api/my-api.ts
import type { APIRoute } from 'astro';
import { auth } from "@wix/essentials";
import { siteProperties } from '@wix/business-tools';

export const GET: APIRoute = async ({ request }) => {
  const elevatedGetSiteProperties = auth.elevate(siteProperties.getSiteProperties);
  const retrievedSiteProperties = await elevatedGetSiteProperties();
  return new Response(JSON.stringify(retrievedSiteProperties));
}
```

### Frontend code

::::tabs
:::Headless-projects

```astro
<!-- src/pages/index.astro -->
<script>
  async function getSiteProperties() {
    const result = await fetch('/api/my-api');
    const retrievedSiteProperties = await result.json();
    console.log("Site properties:", retrievedSiteProperties.properties);
  }

  getSiteProperties();
</script>
```

:::
:::Apps 

```tsx
// src/extensions/dashboard/pages/my-page/my-page.tsx
import { httpClient } from "@wix/essentials";

async function getSiteProperties() {
  const baseApiUrl = new URL(import.meta.url).origin;
  const result = await httpClient.fetchWithAuth(`${baseApiUrl}/api/my-api`);
  const retrievedSiteProperties = await result.json();
  console.log("Site properties:", retrievedSiteProperties.properties);
}

getSiteProperties();
```

:::
::::

## See also

+ [About Permissions](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/about-permissions)
+ [About Elevated Permissions](https://dev.wix.com/docs/api-reference/articles/authentication/about-elevated-permissions?apiView=SDK)
+ [About HTTP Endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints)
+ [Add HTTP Endpoints to Your Project](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/add-http-endpoints-to-your-project)
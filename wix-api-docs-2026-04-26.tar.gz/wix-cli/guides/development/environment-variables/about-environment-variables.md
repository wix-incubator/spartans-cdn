---
portal: wix-cli
name: "About Environment Variables"
type: ARTICLE_RESOURCE
resourceId: 1f44c8ba-ba29-423e-a384-ccda00621232
---

# About Environment Variables

# About Environment Variables


Environment variables allow you to store configuration values and secrets outside of your code, making your applications more secure and portable. The Wix CLI uses [the built-in support in Astro for environment variables](https://docs.astro.build/en/guides/environment-variables/), providing type-safe environment variables that can be used in backend or client-side code.

This article explains the types of environment variables available in Wix CLI projects and when to use each type.

## Types of environment variables

The Wix CLI supports the following types of environment variables, each designed for specific use cases and security requirements.

| Type | Availability | Storage Location | Use case |
|------|--------------|------------------|----------|
| Public client variables | Client-side and backend | `.env.local` file | Non-sensitive configuration that needs to be accessed in the browser (for example, API endpoints, feature flags). |
| Public server variables | Backend only | `.env.local` file | Non-sensitive server configuration (for example, port numbers, timeouts). |
| Secret server variables | Backend only | Wix servers | Sensitive data like API keys, database credentials, and authentication tokens. These variables are securely stored on Wix servers and must be pulled to your local environment. |

### Secret server variables

Secret server variables are designed to ensure maximum security:

- Secret variables are set using the [`wix env set`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/env-set) command and stored securely on Wix servers, not in your local `.env.local` file.
- To run your project locally with secret variables, you must pull them from Wix servers using the [`wix env pull`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/env-pull) command. This downloads the secret variables to your local environment temporarily.
- Since secret variables aren't stored in your `.env.local` file, they're never at risk of being accidentally committed to your repository.

### Public variables on Wix servers

While public variables are typically stored in your `.env.local` file, you can also manage them using `wix env set` and `wix env pull`, similar to secret variables. This approach offers additional benefits:

- Store all environment variables on Wix servers instead of tracking them locally.
- Team members can sync variables without sharing `.env.local` files.
- Add `.env.local` to your `.gitignore` and pull variables when needed, eliminating the risk of accidentally committing sensitive configuration.

## See also

- [Manage Environment Variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/manage-environment-variables)
- [Wix CLI Project Structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure)
- [Astro Environment Variables Documentation](https://docs.astro.build/en/guides/environment-variables/)
---
portal: wix-cli
name: "Manage Environment Variables"
type: ARTICLE_RESOURCE
resourceId: 0842cd52-b400-4b31-aa94-b8ee77315181
---

# Manage Environment Variables

# Manage Environment Variables


Configure and use environment variables in your Wix CLI project to store configuration values and secrets outside of your code. Learn about the [types of environment variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables) available in Wix CLI projects.

## Step 1 | Define the schema

In this step, you define the structure of your environment variables in `astro.config.mjs`, specifying each variable’s type, context (client or server), and access level (public or secret) before assigning actual values.

```js
import { defineConfig, envField } from 'astro/config';
import wix from '@wix/astro';
import react from "@astrojs/react";
import cloudflare from "@astrojs/cloudflare";

export default defineConfig({
  output: "server",
  adapter: cloudflare(),
  integrations: [wix(), react()],
  image: { domains: ["static.wixstatic.com"] },
  devToolbar: { enabled: false },
  env: {
    schema: {
      API_URL: envField.string({ context: "client", access: "public", optional: true }),
      PORT: envField.number({ context: "server", access: "public", default: 4321 }),
      API_SECRET_KEY: envField.string({ context: "server", access: "secret" }),
    }
  }
});
```

Read more about the schema definition in the [Astro documentation](https://docs.astro.build/en/guides/environment-variables/#define-your-schema).

## Step 2 | Configure environment variables

In this step, you configure public or secret variables.

### Configure public client variables

To configure public variables:

1. Add your variables to the `.env.local` file in your project root.

```bash
API_URL=https://api.example.com
PORT=8080
```

2. Use the `wix env set` command to set the variables.

```bash
wix env set --key=API_URL --value=https://api.example.com
wix env set --key=PORT --value=8080
```

<blockquote class="important">

__Important:__
Don't edit any of the `WIX_CLIENT` variables in the `.env.local` file. The Wix CLI manages these variables.

</blockquote>

### Configure secret server variables

To configure secret server variables:

1. Use the `wix env set` command to set the secret variable.

```bash
wix env set --key=API_SECRET_KEY --value=your-secret-value
```

2. Pull the secret variables to your development environment using the `wix env pull` command.

```bash
wix env pull
```

> **Note:** You must run `wix env pull` after setting secret variables. Without running `wix env pull`, the `wix dev` command doesn't work.

## Step 3 | Use environment variables in your code

In this step, you learn how to import and use environment variables.

### Use client variables

Import public client variables from `astro:env/client`. The following example imports and uses the `API_URL` variable.

```js
import { API_URL } from "astro:env/client";

const response = await fetch(`${API_URL}/users`);
```

### Use backend variables

Import public server and secret variables from `astro:env/server`:

```js
import { API_SECRET_KEY, PORT } from "astro:env/server";

const response = await fetch("https://api.example.com/data", {
  headers: {
    "Authorization": `Bearer ${API_SECRET_KEY}`
  }
});

const internalServiceUrl = `http://localhost:${PORT}/api/internal-service`;
```

## Step 4 | Build and release your project

After setting your environment variables, build and release your project to apply the changes.

To build and release:

1. [Build](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build) your project.

```bash
wix build
```

2. [Release](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) your project to apply the changes.

```bash
wix release
```

## See also

- [About Environment Variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables)
- [Build and Deploy a Project](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project)
---
portal: wix-cli
name: "About HTTP Endpoints"
type: ARTICLE_RESOURCE
resourceId: 123f57ef-ef75-456b-a3cf-d24ca26ff046
---

# About HTTP Endpoints

# About HTTP Endpoints

Wix CLI projects support HTTP endpoints, which you can use to build backend APIs for handling HTTP requests and coordinating frontend and backend logic. HTTP endpoints can serve any kind of data.

> **Note:** HTTP endpoints replace [HTTP functions](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/backend-extensions/api/http-functions/add-http-function-extensions-with-the-cli) from the previous CLI version. If you're migrating from HTTP functions, see the [Migration Guide](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/migration-guide).

## Use cases

Use HTTP endpoints when you need to:
- Integrate with external APIs or services that require HTTP requests.
- Handle complex form submissions or file uploads.
- Serve dynamic content like images, RSS feeds, or personalized data.
- Build REST APIs with multiple HTTP methods.
- Access runtime data or server-side databases.

## See also 

- [Add HTTP Endpoints to Your Project](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/add-http-endpoints-to-your-project)
- [Migration Guide](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/migration-guide)
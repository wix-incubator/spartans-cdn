---
portal: wix-cli
name: "Add HTTP Endpoints to Your Project"
type: ARTICLE_RESOURCE
resourceId: eb9aa6cf-04b0-4651-b049-f5d66e2dd211
---

# Add HTTP Endpoints to Your Project

# Add HTTP Endpoints to Your Project

This article shows you how to create an HTTP method in your CLI project and call it from your frontend to handle HTTP requests. These endpoints handle server-side logic and can return any kind of data to your frontend.

To create an HTTP endpoint:

1. Create an endpoint file with HTTP method handlers.
2. Add frontend code to call the endpoint.

## Step 1 | Create the endpoint file

Create the backend endpoint file that handles HTTP requests. At the end of this step, you'll have a working endpoint that can respond to GET and POST requests.

1. Create a new file in the `src/pages/api/` directory with the name `<your-endpoint-name>.ts` in your CLI project.

2. Add endpoint handlers for the HTTP methods you want to support. Each handler receives a `request` object and returns a `Response`:

    ```ts
    import type { APIRoute } from 'astro';

    export const GET: APIRoute = async ({ request }) => {
        console.log('Log from GET.'); // This message logs to your CLI.
        return new Response('Response from GET.'); // This response is visible in the browser console
    };
    
    export const POST: APIRoute = async ({ request }) => {
        const data = await request.json();
        console.log('Log POST with body: ', data); // This message logs to your CLI.
        return new Response(JSON.stringify(data)); // This response is visible in the browser console.
    };
    ```

## Step 2 | Call the endpoint from your frontend

Call your endpoint from frontend components using Wix's built-in HTTP client. At the end of this step, you'll be able to send requests to your backend endpoint and receive responses.

1. In your frontend component, use `httpClient.fetchWithAuth()` to call your endpoint:

    ```tsx
    import { httpClient } from '@wix/essentials';

    function Index() {
      const callEndpointGET = async () => {
        try {
          const baseApiUrl = new URL(import.meta.url).origin;
          const res = await httpClient.fetchWithAuth(`${baseApiUrl}/api/<your-endpoint-name>`);
          const data = await res.text();
          console.log('Response:', data);
        } catch (error) {
          console.error('Error:', error);
        }
      };

      const callEndpointPOST = async () => {
        try {
          const baseApiUrl = new URL(import.meta.url).origin;
          const res = await httpClient.fetchWithAuth(`${baseApiUrl}/api/<your-endpoint-name>`, {
            method: 'POST',
            body: JSON.stringify({ message: 'Hello from frontend' }),
          });
          const data = await res.json();
          console.log('Response:', data);
        } catch (error) {
          console.error('Error:', error);
        }
      };

      return (
        <WixDesignSystemProvider>
          <Page>
            <Page.Content>
              <button onClick={callEndpointGET}>Call GET Endpoint</button>
              <button onClick={callEndpointPOST}>Call POST Endpoint</button>
            </Page.Content>
          </Page>
        </WixDesignSystemProvider>
      );
    }
    ```
2. Start your local development environment to test the endpoints:

```bash
npm run dev
```

3. Press `Dashboard` to open the dashboard page in your browser, and click the buttons to execute the HTTP endpoint calls.

4. View the logs in the CLI and browser console. You should see something like:

   ### CLI 
   ```
   1:13:38 PM [backend] Log from GET.
   1:13:39 PM [backend] Log POST with body: { message: 'Hello from frontend' }
   ```

   ### Browser console
   ```
   Response: Response from GET.
   Response: {"message":"Hello from frontend"}
   ```

## Step 3 | Build and deploy your project

[Build and deploy your project](https://github.com/wix-private/developer-docs/blob/0ae8712c004dc188c4d3bc4d9654761353d74d27/cli-portal/guides/project-development/build-and-deploy.md*original::build-and-deploy.md) to make your endpoints available in production. Once deployed, your endpoints will be accessible at the production URLs and can handle live traffic from your site's visitors.

## Delete an HTTP endpoint

To delete an HTTP endpoint from your project, delete the file under `src/pages/api/` that contains your HTTP endpoint and build and deploy again.
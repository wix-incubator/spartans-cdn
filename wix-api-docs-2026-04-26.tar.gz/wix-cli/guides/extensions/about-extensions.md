---
portal: wix-cli
name: "About Extensions"
type: ARTICLE_RESOURCE
resourceId: 3ef6f3a5-f277-494d-aec0-7b791df49879
---

# About App Extensions in the Wix CLI

# About Extensions in the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [About CLI App Extensions](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions).
- Wix CLI for Headless: [About App Extensions in the Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/about-app-extensions).

</blockquote>

The Wix CLI allows you to easily extend your project's functionality with [extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions). For example, with extensions you can add custom dashboard pages or implement backend logic to handle events. 

The Wix CLI supports multiple [extension types](#supported-extension-types) depending on the type of project you create. The creation and setup process for extensions in the CLI takes place in the terminal. Then, to edit your extensions, you write code directly in your project's local files. 

> **Note:** When you add an extension to a headless project, the CLI adds it to your project's [private Wix app](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli#private-apps).

## Adding extensions

You can add extensions to your project using the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command.

This command starts a process that guides you through adding an extension to your project. 

After selecting an extension, you'll be prompted for the relevant configuration details. Your extension will then be generated in your project's local files under `src/extensions/`. If you want to move your extension files in your project, make sure the new path is specified in the `extension.ts` file. Learn more [about the `extension.ts` file](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file).

<blockquote class="important">

__Important:__
Some extensions require you to run [`release`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) to create an app version before they work. The [`preview`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/preview) command uploads your code but doesn't register all extension components in your app's configuration, so extensions like embedded scripts, site widgets, and site plugins can't be tested through `preview` alone.

</blockquote>

## Supported extension types

The Wix CLI currently supports the following extensions:

### Dashboard extensions

- [Dashboard pages](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions-with-the-wix-cli)
- [Dashboard plugins](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extensions-with-the-wix-cli)
- [Dashboard menu plugins](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions-with-the-wix-cli)
- [Dashboard modals](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions-with-the-wix-cli)

### Backend extensions

- [Events](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/events/add-event-extensions-with-the-wix-cli)
- [Service plugins](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/service-plugins/add-service-plugin-extensions-with-the-wix-cli)

#### HTTP endpoints

Wix CLI projects support [HTTP endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints) for backend API development.

> **Note:** HTTP endpoints replace [HTTP functions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/api/http-functions/add-http-function-extensions-with-the-cli) from the previous Wix CLI for Apps.

### Site extensions

> **Note:** Site extensions in the CLI are only relevant for app projects.

- [Embedded scripts](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-wix-cli)
- [Site widgets](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/add-a-site-widget-extension)
- [Site plugins](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-plugins/add-a-site-plugin-extension-with-the-wix-cli)

## Data collection extension

The [data collections extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/about-data-collections-extensions) allows your app to automatically create CMS data collections when it's installed on a site. Use the data collections extension whenever your app needs to store or manage structured data on a site, such as app settings, content, analytics, or user-generated content.

You can't add data collection extensions to your app using the CLI. Instead, you can add them in the app dashboard. For detailed instructions, see [Add a Data Collections Extension in the App Dashboard](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/data-collections/add-a-data-collections-extension-in-the-app-dashboard).

## See also

- [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
- [Map your functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
- [About the extensions.ts File](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file)
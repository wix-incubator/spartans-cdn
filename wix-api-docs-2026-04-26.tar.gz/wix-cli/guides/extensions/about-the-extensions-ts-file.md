---
portal: wix-cli
name: "About the extensions.ts File"
type: ARTICLE_RESOURCE
resourceId: 19e1cfe2-0dfa-4a55-966e-3ce91d9de768
---

# About the extensions.ts File

# About the extensions.ts File


The `extensions.ts` file is the central configuration file for all [extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/about-app-extensions-in-the-wix-cli) in your Wix CLI project. This file must be located in the `src/` directory and serves as the registry where you define and organize all the extensions that add functionality to your project.

## How the extensions.ts file works

The `extensions.ts` file uses a builder pattern syntax that allows you to chain extension configurations together. This approach provides a clean, readable way to manage multiple extensions in your project.

The `extensions.ts` file follows this basic structure:

```typescript
import { app, extensions } from '@wix/astro/builders';

export default app()
  .use(extensions.extensionType({
    // Extension configuration
  }));
```

The file:

- Imports the necessary builders from `@wix/astro/builders`.
- Exports a default app configuration.
- Uses the `.use()` method to register extensions.

### Import-based registration

You can also import extension configurations from separate files and register them. For example:

**extension.ts**

```typescript
import { app } from '@wix/astro/builders';
import myImportedPage from './extensions/dashboard/pages/my-imported-page/my-imported-page.extension.ts';

export default app()
  .use(myImportedPage);
```

**my-imported-page.extension.ts**

```typescript
import { extensions } from '@wix/astro/builders';

export default extensions.dashboardPage({
  id: '154f642e-a705-4ff3-8421-6119354a3384',
  title: 'My Imported Page',
  routePath: 'my-imported-page',
  component: './extensions/dashboard/pages/my-imported-page/my-imported-page.tsx',
});
```

## Automatic extension management

You can add extensions to your project using the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command. After running this command and following the prompts, CLI:

- Creates the extension's files and code, including an `extension.ts` file containing the builder. By default, it uses the naming pattern `[extension-name].extension.ts`, however, you can rename these files to anything you want.
- Adds the necessary import statement and `.use()` method call to register the new extension in the `extensions.ts` file.

## Remove deleted extensions

When you delete an extension from your project, you should also remove its registration from the `extensions.ts` file. This involves removing both:

- The import statement for any extension builders.
- The `.use()` method call that registers the extension.


## See also

- [About App Extensions in the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/about-app-extensions-in-the-wix-cli)
- [Wix CLI Project Structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure)
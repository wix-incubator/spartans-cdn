---
portal: wix-cli
name: "About Backend APIs"
type: ARTICLE_RESOURCE
resourceId: daad0c67-b129-45d2-b72f-08d8101024a2
---

# About Backend APIs

# About Backend APIs

Backend APIs are built with [HTTP endpoints](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/about-http-endpoints), which are powered by Astro endpoints.

Unlike other backend extensions, HTTP endpoints:

- Can't be added using `npm run generate`. Instead, create endpoint files directly in `src/pages/api/`.
- Don't appear on the **Extensions** page in the app dashboard.

Learn how to [add HTTP endpoints to your project](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/add-http-endpoints-to-your-project).

> **Note:** HTTP endpoints replace HTTP functions from the previous Wix CLI for Apps. See the [Migration Guide](https://dev.wix.com/docs/wix-cli/guides/development/http-endpoints/migration-guide).
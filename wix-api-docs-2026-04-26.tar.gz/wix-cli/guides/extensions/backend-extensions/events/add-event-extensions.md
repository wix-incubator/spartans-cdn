---
portal: wix-cli
name: "Add Event Extensions"
type: ARTICLE_RESOURCE
resourceId: 11ea3517-3211-40f2-994c-989b4905c7c2
---

# Add Event Extensions with the Wix CLI

# Add Event Extensions with the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Add Event Extensions with the Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/events/add-event-extensions-with-the-cli).
- Wix CLI for Headless: [Add Event Extensions with the Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/backend-extensions/events/add-event-extensions).

</blockquote>


Events are triggered when specific conditions occur in your project. For app projects, these are conditions on a Wix user's site. For headless projects, they're conditions on your project's site. 
Your project can respond to these events using event extensions. Events in the Wix CLI are built on JavaScript SDK webhooks, and event extensions subscribe your project to these webhooks behind the scenes.

Learn more [about event extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/events/about-event-extensions).

> **Note:** Event extensions are built on [webhooks](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks), and changes to events automatically create a new minor app version. Learn more about [webhooks and versioning](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-webhooks#webhooks-and-versioning).

Follow the instructions below to:

1. Create an event extension for your project.
2. Test the event extension in your project.
3. Deploy your project with the event extension.

Once this task is complete, your project will have an event extension that's triggered when a specific event occurs.

<blockquote class="important">

**Important:** 

You can't have 2 event extensions listening to the same event in your app. Each event can only have one handler. This includes extensions added to your app in the [app dashboard](https://manage.wix.com/account/custom-apps), not only those in the local files for your project.

</blockquote>

## Step 1 | Create the extension

In the terminal:

1. Navigate to your project repo.
2. Run the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command.

3. The CLI will display a menu of extensions to generate. Select **Event** and hit enter to continue.
4. The CLI will prompt you to name your event folder. This is the name of the folder in the project directory that contains the event code, and the name of the event. Only you will see this name.

Upon completion, the extension files will be created in your project directory with the following structure:

```bash
src/
  └── extensions/
      └── backend/
          └── events/
              └── <your-event-name>/
                  ├── <your-event-name>.extension.ts
                  └── <your-event-name>.ts
```

> **Note:** This is the default folder structure created by the CLI. You can move these files to any location within the `src/` folder and update the references in your `extension.ts` file. Learn more about the [flexible file system](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure#your-custom-extension-folder).

Learn more about [event extension files and code](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/events/event-extension-files-and-code).

> **For app projects**: You may need to [configure permissions for your app](https://dev.wix.com/docs/build-apps/develop-your-app/access/authorization/configure-permissions-for-your-app) to receive the event.

<!-- Not currently supported
## Step 2 | Test your event extension

<blockquote class="important">

**Important:**
Currently, local development is not supported for all events in the Wix CLI. If you are unable to test your event in the local development environment as described in this step, you can still see it in action by pushing your changes to production. See [Build and deploy your project.](#build-and-deploy-your-project).

</blockquote>

To test your event extension, you must:

1. Add logging inside your backend logic.
2. Trigger the event.
3. View the logs in the terminal.

### Add logging inside your backend logic

Inside your event's `.ts` file, add a `console.log()` command to one of your functions. For example:

```tsx
import { contacts } from "@wix/crm";

export default contacts.onContactCreated((event) => {
  console.log("A contact was created.", event.entity);
});
```

### Trigger the event

The process for triggering an event depends on the type of event:

- Events that can be triggered by actions in your project's dashboard can be triggered in the CLI's local development environment, in which case logs will be displayed in the CLI.
- Events that can't be triggered by actions in your project's dashboard can't currently be tested with the CLI for Headless.

To trigger the event in the local development environment, you must navigate to your project's site or dashboard in your local development environment, then take an action that will trigger your event.

1. From your project's directory in the terminal, run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command.

1. Click the link to open your project's dashboard or site in your browser, depending on where you need to trigger the event.
1. Take an action that will trigger your event. This action depends on your specific event.

### View the logs in the terminal

Navigate back to the CLI terminal and you will see the logs from your backend logic in the following form:

```ts
5:45:11 PM Your console log message.
```

> **Note:** You can't view logs from backend code in production. -->


## Step 2 | Test your event extension

To test your event extension you must:

1. [Release a version](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) with your changes.
2. Take an action that will trigger your event.

## Build and deploy your project

Once your project is ready for production, you can [build and deploy](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project) it.


>**Note:**
> When you release an app project, you release a new version of the app allowing you to publish the app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct install URL. You can view [your app's versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

## Delete an event extension

To delete an event extension from your project:

1. Delete the folder that contains your event extension's files.
2. Remove the import and `.use()` statements for the extension from the [`extensions.ts`](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file) file.

<blockquote class="important">

**For app projects:** 

If you already have a version of your app project, you must build and deploy the project again after removing the event extension files. 

</blockquote>


## See also

- [Event Extension Files and Code](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/events/event-extension-files-and-code)
- [About Events](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/events-and-webhooks/about-events)
- [About Event Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/events/about-event-extensions)
---
portal: wix-cli
name: "Event Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: 3e747b53-82b7-4298-b43c-fd9381a94d52
---

# Event Extension Files and Code

# Event Extension Files and Code


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Add Event Extensions with the Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/events/add-event-extensions-with-the-cli).
- Wix CLI for Headless: [Add Event Extensions with the Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/backend-extensions/events/add-event-extensions).

</blockquote>

When you generate an event extension, the CLI adds the following files to your project:

- `<your-event>.extension.ts`: Builds the [event](#event-builder).
- `<your-event>.ts`: Defines the [event handler logic](#event-handler).

## Event builder

The `<your-event>.extension.ts` file contains an event extension's builder configuration.

The event builder is defined using the following schema, shown here as a TypeScript type:

```ts
import { extensions } from '@wix/astro/builders';

export default extensions.event({
  id: string,
  source: string,
});
```

Here's an example builder definition:

```ts
import { extensions } from '@wix/astro/builders';

export default extensions.event({
  id: '9912811d-5f5b-41f9-b4d6-ef4163b714a7',
  source: './extensions/backend/events/my-event/my-event.ts',
});
```

### Builder fields

The following fields can be used in the configuration object:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Event extension ID as a ([GUID](https://en.wikipedia.org/wiki/Universally_unique_identifier)). The ID is automatically generated and must be unique across all extensions in the project. |
| `source` | string | Path to the event handler file that contains the event logic. |

<blockquote class="important">

**Important:** You can't have 2 event extensions listening to the same event in your app. Each event can only have one handler. This includes extensions added to your app in the [app dashboard](https://manage.wix.com/account/custom-apps), not only those in the local files for your project.

</blockquote>

## Event handler

The `<your-event>.ts` file contains an event extension's handler logic.

This file contains:

- The relevant import statement for the event.
- An event function where you can implement your custom logic. Wix calls this function when the given event occurs, passing the event object and its metadata. Event functions are documented in their module in the [JavaScript SDK reference](https://dev.wix.com/docs/sdk).

The generated `<your-event>.ts` file will contain example code for an event.

The `<your-event>.ts` file must be in the following format:

```ts
import { <submodule> } from '@wix/<service-module>';

export default <submodule>.<event-handler>((event) => {
  // Add your logic here
});
```

Here's an example `my-event.ts` file for the Wix CRM [onContactCreated()](https://dev.wix.com/docs/sdk/backend-modules/crm/contacts/on-contact-created) event:

```ts
import { contacts } from '@wix/crm';

export default contacts.onContactCreated((event) => {
  // Add your logic here
});
```
---
portal: wix-cli
name: "Add Service Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 18b82817-66a0-43ed-9c23-9be0ec61801d
---

# Add Service Plugin Extensions with the Wix CLI

# Add Service Plugin Extensions with the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Add Service Plugin Extensions with the Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/add-service-plugin-extensions-with-the-cli).
- Wix CLI for Headless: [Add Service Plugin Extensions with the Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/backend-extensions/service-plugins/add-service-plugin-extensions).

</blockquote>


[Service plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions) are a set of APIs defined by Wix that you can use to inject custom logic into the existing backend flows of [Wix business solutions](https://dev.wix.com/docs/build-apps/develop-your-app/wix-business-solutions/about-wix-business-solutions) or to introduce entirely new flows to Wix sites.

You can implement service plugin extensions in your project using the Wix CLI.

Follow the instructions below to:

1. Create a service plugin extension for your project.
2. Test your service plugin extension.

Once this task is complete, your project will have a service plugin extension with custom functions that Wix calls during a specific flow.

## Before you begin

+ You must have a project that was [created using the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli).
+ You must be logged into your Wix account. If you don't have one, [sign up for a Wix account](https://manage.wix.com/account/custom-apps).

## Step 1 | Create the extension

In the terminal:

1. Navigate to your project repo.
1. Run the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command.

1. The CLI will display a menu of extensions to generate. Select **Service Plugin** and hit enter to continue.
1. The CLI will prompt you to select a service plugin from a list of available service plugins.
1. The CLI will prompt you to name your service plugin. This is the name of the folder in the project repo that contains the service plugin code, and the name of the plugin that appears in your app dashboard when developing an app. Only you will see this name.

Upon completion, the extension files will be created in your project directory with the following structure:

```bash
src/
  └── extensions/
      └── backend/
          └── service-plugins/
              └── <your-service-plugin-name>/
                  ├── <your-service-plugin-name>.extension.ts
                  └── <your-service-plugin-name>.ts
```

> **Note:** This is the default folder structure created by the CLI. You can move these files to any location within the `src/` folder and update the references in your `extension.ts` file. Learn more about the [flexible file system](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure#your-custom-extension-folder).

Learn more about the [service plugin extension files](https://dev.wix.com/docs/wix-cli/guides/extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code).

## Step 2 | Test your service plugin extension

To test your service plugin extension you must:

1. Release a version with your changes.
2. Trigger the call to your service plugin.

For example, to test a service plugin extension for [Additional Fees](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/additional-fees/introduction) that adds a $5 packaging fee to all orders:

1. Go to your site's store in the local development environment.
2. Select any product and add it to the cart, then view the cart.
3. Check if the additional fee is listed in the order summary.
   
New service plugins or changes to existing service plugins won't take affect until you've built and released your project.

<!-- <blockquote class="important">

__Important:__

Logging in the backend logic of service plugins can't be tested in the CLI's local development environment (`npm run dev`). Instead, you must trigger the call to the service plugin from your project and check for the expected result.
</blockquote> -->


## Build and deploy your project

Once your project is ready for production, you can [build and deploy](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project) it.

>**Note:**
> When you release an app project, you release a new version of the app allowing you to publish the app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct install URL. You can view your app's [versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

## Delete a service plugin extension

To delete a service plugin extension from your project:

1. Delete the folder under `src/extensions` that contains your service plugin extension's files.
2. Remove the import and `.use()` statements for the extension from the [`extensions.ts`](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file) file.

<blockquote class="important">

**For app projects:** 

If you already have a version of your app project, you must build and deploy the project again after removing the service plugin extension files. 

</blockquote>
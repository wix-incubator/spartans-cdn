---
portal: wix-cli
name: "Service Plugin Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: d27111a0-0584-4fcc-8341-08d214596922
---

# Service Plugin Extension Files and Code

# Service Plugin Extension Files and Code


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Service Plugin Extension Files and Code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code).
- Wix CLI for Headless: [Service Plugin Extension Files and Code](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code).

</blockquote>

When you generate a service plugin extension, the CLI adds the following files to your project:

- `<your-service-plugin>.extension.ts`: Builds the [service plugin](#service-plugin-builder).
- `<your-service-plugin>.ts`: Defines the [service plugin handler logic](#service-plugin-handler).

## Service plugin builder

The `<your-service-plugin>.extension.ts` file contains the service plugin builder configuration. This file provides all required configuration for your plugin.

The service plugin builder is defined using the following schema, shown here as a TypeScript type:

```ts
import { extensions } from '@wix/astro/builders';

export default extensions.<servicePluginType>({
  id: string,
  name: string,
  description: string,
  source: string,
  // Additional fields may vary by service plugin type
});
```

Here's an example builder definition for an eCommerce Shipping Rates service plugin:

```ts
import { extensions } from '@wix/astro/builders';

export default extensions.ecomShippingRates({
  id: '00eeeac1-d01a-4d96-9d76-5617d8658735',
  name: 'my-service-plugin',
  description: 'Short description about this shipping provider',
  fallbackDefinitionMandatory: false,
  source: './extensions/backend/service-plugins/my-service-plugin/my-service-plugin.ts',
});
```

### Builder fields

The following fields are commonly used in the configuration object:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Service plugin ID as a ([GUID](https://en.wikipedia.org/wiki/Universally_unique_identifier)). The ID is automatically generated and must be unique across all extensions in the project. |
| `name` | string | The service plugin name. |
| `description` | string | A short description of what the service plugin does. |
| `source` | string | Path to the service plugin handler file that contains the plugin logic. |

Additional fields may be required or optional depending on the specific service plugin type. You can find the details for each field by locating your service plugin in [this table](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#service-plugins) and clicking on the link to view its documentation.

## Service plugin handler

The `<your-service-plugin>.ts` file contains the service plugin handler logic.

This file contains:

- The relevant import statement for the service plugin.
- Handler functions that Wix calls automatically when the relevant site action triggers them. These functions are where you add your custom logic.

The generated `<your-service-plugin>.ts` file will contain example code with empty placeholders for each of the functions.

The `<your-service-plugin>.ts` file must be in the following format:

```ts
import { <servicePlugin> } from '@wix/<service-module>/service-plugins';

<servicePlugin>.provideHandlers({
  <handlerFunction>: async ({ request, metadata }) => {
    // Add your logic here
  },
});
```

Here's an example `my-service-plugin.ts` file for the eCommerce [Shipping Rates](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/shipping-rates/introduction) service plugin:

```ts
import { shippingRates } from '@wix/ecom/service-plugins';

export default shippingRates.provideHandlers({
  getShippingRates: async ({ request, metadata }) => {
    return {
      shippingRates: [],
    };
  },
});
```

Your custom logic should be placed inside each handler function. To find out what your function receives in the parameters and what it must return, see the documentation for your specific service plugin. Locate your service plugin in [this table](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#service-plugins) and click on the link to view its documentation, then navigate to the specific function in the menu.
---
portal: wix-cli
name: "About Dashboard Extensions"
type: ARTICLE_RESOURCE
resourceId: 2b380165-1572-43b8-9d34-8738a9d0f5ab
---

# About the Wix CLI Dashboard Extensions

# About Dashboard Extensions in the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

</blockquote>

Dashboard extensions allow you to extend the functionality of the Wix dashboard with customizable features, such as a page or a plugin. 

The Wix CLI allows you to easily create dashboard extensions for your projects. 

The following dashboard extensions are available in the Wix CLI: 
- [Dashboard pages](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions-with-the-wix-cli)
- [Dashboard modals](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions-with-the-wix-cli)
- [Dashboard plugins](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extensions-with-the-wix-cli)
- [Dashboard menu plugins](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions-with-the-wix-cli)

## Dashboard extension integration

You can add dashboard extensions using the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command and following the prompts to create your extension. Once created, your extension files appear in your project directory.

You can preview dashboard extensions using the `npm run dev` command, which provides a link to open a preview of a dashboard in your browser.

Dashboard extensions extend the functionality of the Wix dashboard to help you or your users manage site and business data.  
Dashboard extensions aren't visible to site visitors. 

## See also
- [About Extensions in the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions)
- [About the extensions.ts File](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file)
---
portal: wix-cli
name: "Add Dashboard Menu Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 0721995c-87a6-4a84-9bdc-73c2f0634cf0
---

# Add Dashboard Menu Plugin Extensions with the Wix CLI

# Add Dashboard Menu Plugin Extensions with the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Add a Dashboard Menu Plugin Extensions with the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions-with-the-cli).
- Wix CLI for Headless: [Add a Dashboard Menu Plugin Extensions with the Wix CLI for Headless](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions).

</blockquote>


[Dashboard menu plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions) add menu items into [pre-configured slots in dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) of apps made by Wix in your project. When clicked, it either displays a dashboard modal or directs the project administrator to another dashboard page.

Follow the instructions below to:

1. Create and configure a dashboard menu plugin extension for your project.
2. Customize your dashboard menu plugin.

Once this task is complete, the dashboard menu you specified in the installation process will contain the item you added.

## Step 1 | Create the extension

In your project directory, run the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command and follow the prompts to create a dashboard menu plugin extension.

Upon completion, the extension files will be created in your project directory with the following structure:

```bash
src/
  └── extensions  
      └── dashboard/
          └── menu-plugins/
              └── <your-menu-plugin-folder-name>/
                  └── <your-menu-plugin-name>.extension.ts
```

> **Note:** This is the default folder structure created by the CLI. You can move these files to any location within the `src/` folder and update the references in your `extension.ts` file. Learn more about the [flexible file system](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure#your-custom-extension-folder).

Learn more about the [dashboard menu plugin extension files](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/dashboard-menu-plugin-extension-files-and-code).

## Step 2 | Customize your dashboard plugin

1. Run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command to open the dev menu.

1. Click the link to open the dashboard in the browser. Navigate to the dashboard page hosting your menu plugin.


2. Go to your `.extension.ts` file and edit the `title` to "Hello world!".

  ```ts
  
  export default extensions.dashboardMenuPlugin({
    id: '1a096bd2-df15-41af-9db1-a037e0c89a68',
    title: 'My Menu Plugin',
    extends: 'b2af2156-d82c-4d6c-9961-cf1cec053566',
    iconKey: 'Sparkles',
    action: {
      navigateToPage: {
        pageId: '695fbcfe-ad2e-4b09-b6e5-6bbed53eaf21',
      }
    },
  });
  
  ```
 
1. Save your file.

1. Navigate back to the dashboard page in your browser and see your changes.

## Build and deploy your project

Once your project is ready for production, you can [build and deploy](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project) it.

  >**Note:**
> When you release an app project, you release a new version of the app allowing you to publish the app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct install URL. You can view [your app's versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

## Delete a dashboard menu plugin

To delete an existing dashboard menu plugin from your project:

1. Delete the folder that contains your dashboard menu plugin extension's file.
2. Remove the import and `.use()` statements for the extension from the [`extensions.ts`](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file) file.

<blockquote class="important">

**For app projects:** 

If you already have a version of your app project, you must build and deploy the project again after removing the dashboard menu plugin file. 

</blockquote>


## See also
- [Dashboard Menu Plugin Extension Files and Code](https://dev.wix.com/docs/wix-cli/guides/extensions/dashboard-extensions/dashboard-menu-plugins/dashboard-menu-plugin-extension-files-and-code)
- [About Dashboard Menu Plugin Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions)
- [About Dashboard Page Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots)
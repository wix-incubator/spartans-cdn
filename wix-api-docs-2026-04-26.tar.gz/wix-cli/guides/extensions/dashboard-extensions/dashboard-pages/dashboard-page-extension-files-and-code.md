---
portal: wix-cli
name: "Dashboard Page Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: 2fd6b027-faf9-47fc-a771-d6102dfb458a
---

# Dashboard Page Extension Files and Code

# Dashboard Page Extension Files and Code


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Dashboard Page Extension Files and Code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-pages/dashboard-page-extension-files-and-code).
- Wix CLI for Headless: [Dashboard Page Extension Files and Code](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/supported-extensions/dashboard-extensions/dashboard-pages/dashboard-page-extension-files-and-code).

</blockquote>

When you generate a dashboard page extension, the CLI adds the following files to your project:

- `<your-page-name>.extension.ts`: Builds the [page](#page-builder).
- `<your-page-name>.tsx`: Defines the [page content](#page-content).

## Page builder

The `<your-page-name>.extension.ts` file contains a dashboard page's builder configuration.

The page builder is defined using the following schema, shown here as a TypeScript type:

```ts
export default extensions.dashboardPage({
  id: string,
  title: string,
  routePath: string,
  component: string,
});
```

Here's an example builder definition:

```ts
export default extensions.dashboardPage({
  id: '40c70303-4eac-44cb-bb53-4e583a036682',
  title: 'My Prohect',
  routePath: 'my-project',
  component: './extensions/dashboard/pages/my-project/my-project.tsx',
});
```

### Builder fields

The following fields can be used in the configuration object:

| Field | Type | Description |
|--|--|--|
| `id` | string | Page ID as a ([GUID](https://en.wikipedia.org/wiki/Universally_unique_identifier)). The ID is used to register the page in the [app dashboard](https://manage.wix.com/account/custom-apps). It must be unique across all pages in the app. |
| `title` | string | The page title. The title is used as the browser tab title and as the dashboard sidebar label if the page is configured to appear in the sidebar. |
| `routePath` | string | Route that lead to this page. Use this route in code to reference the page. |
| `component` | string | A route to the page content component. |

## Page content

The `<your-page-name>.tsx` file contains a dashboard page's content.

The content is defined as a [React](https://react.dev/) component that renders when the page is active.

Inside a dashboard page component you can use:

- The [Wix Dashboard React SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard-react-deprecated/introduction) to navigate users to pages in the dashboard, display modals, and send users alerts using toasts.
- The [Wix Design System](https://www.wixdesignsystem.com/) to display content using the same React components Wix uses to build its own dashboard pages.
- The [Wix JavaScript SDK](https://dev.wix.com/docs/sdk) to access and manage other Wix data.
---
portal: wix-cli
name: "About Site Extensions"
type: ARTICLE_RESOURCE
resourceId: cfbe1e77-6b5d-49fa-9ef3-5a6ca4c3e84b
---

# About Site Extensions in the Wix CLI

# About Site Extensions in the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [About CLI App Site Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/about-cli-app-site-extensions).

</blockquote>

The Wix CLI allows you to add [site extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) to your app project. These extensions aren't relevant for headless projects.

The following site extensions are available in the Wix CLI:

- [Site widget extensions](#site-widget-extensions)
- [Embedded script extensions](#embedded-script-extensions)
- [Site plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/about-site-plugin-extensions)

You can add these extensions using the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command.

## Site widget extensions

Site widgets are draggable UI components that Wix site owners can add to pages on their website. They enhance a site's functionality by displaying content or enabling site visitors to perform various tasks. When working in the site editor, site owners can adjust the size of the widget, reposition it, and customize it using its settings panel.

The Wix CLI allows you to design and develop site widgets entirely with code. When generating a site widget, you can choose between two framework options:

- **Custom Element**: Build site widgets with custom element technology using web components standard. Available on Wix Studio, Wix Harmony, and for the Wix App Market.
- **Editor React Component (Alpha)**: Build site widgets with React framework for highly customizable experiences. Available on Wix Harmony for selected partners only.

Learn more about [site widget extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/about-site-widget-extensions).

## Embedded script extensions

An embedded script is an app extension that injects an HTML code fragment into the DOM of a site. Embedded scripts are used for analytics, accessing site data, interacting with other apps, customizing site behavior, and more. You can implement an embedded script extension in your app project using the CLI. Learn more about [embedded script extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-wix-cli).

<!--
## Site plugin extensions

With site plugins, you can create interactive and feature-rich widgets that seamlessly integrate into Wix’s [business solutions](https://support.wix.com/en/business-solutions-apps) such as Wix Stores and Wix Bookings, extending their functionality and user experience. You can implement site plugin extensions in your app project using the CLI. Learn more about [site plugin extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-plugins/add-a-site-plugin-extension-with-the-wix-cli).
-->

## See also
<!-- - [Add a Site Plugin Extension with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-plugins/add-a-site-plugin-extension-with-the-wix-cli) -->
- [About Site Widget Extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/about-site-widget-extensions)
- [Add a React Component Site Widget Extension with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/add-react-component-site-widget-with-the-wix-cli)
- [Add a Custom Element Site Widget Extension with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/add-a-site-widget-extension)
- [About Embedded Scrips and the CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-wix-cli)
- [Add an Embedded Script Extension with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension-with-the-wix-cli)
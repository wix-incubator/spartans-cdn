---
portal: wix-cli
name: "About Embedded Scripts"
type: ARTICLE_RESOURCE
resourceId: 1d36766d-37da-4b16-b5fb-41e125f0a79e
---

# About Embedded Scripts and the Wix CLI

# About Embedded Scripts and the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [About Embedded Scripts and the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-cli).

</blockquote>

The Wix CLI makes it easy to create and develop embedded script extensions for your app project. Embedded scripts are HTML code fragments that get injected into the DOM of Wix sites, enabling integration with third-party services, analytics tracking, advertising, and custom JavaScript functionality.

For general information about this extension type, read [About Embedded Scripts](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts).

## Why create an embedded script extension with the CLI

The Wix CLI simplifies setup, testing, and deployment for embedded script extensions.

+ **Single-command setup:** Generate an embedded script extension in your app with one command.
+ **Easy, early testing:** Test the embedded script extension on a development site before building an app. You can specify values for dynamic parameters to use during testing.
+ **Use local files:** Reference any file in your app project's directory from your HTML code with a relative link. There's no need for external hosting or CORS handling.
+ **Simple embedding:** Offload the responsibility for embedding the script to the user, avoiding complex authentication procedures.


## See also
+ [Add Embedded Script Extensions with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/embedded-scripts/add-an-embedded-script-extension-with-the-wix-cli)
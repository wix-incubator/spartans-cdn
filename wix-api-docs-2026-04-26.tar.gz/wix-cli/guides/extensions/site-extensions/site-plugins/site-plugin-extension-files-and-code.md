---
portal: wix-cli
name: "Site Plugin Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: 82172ae2-edbb-4112-8d7a-64f277355a85
---

# Site Plugin Extension Files and Code

# Site Plugin Extension Files and Code


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Site Plugin Extension Files and Code](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/site-plugin-extension-files-and-code).

</blockquote>

[Add a new site plugin](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-plugins/add-a-site-plugin-extension-with-the-wix-cli) to your CLI project with the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command.

The CLI generates this directory structure in your project repo:

```tsx
.
└── <your-app-name>/
    └── public/
    |   └── your-plugin-name-logo.svg
    |
    └── src/
        └── site/
            └── plugins/
                └── <your-plugin-name>
                    ├── your-plugin-name.panel.tsx
                    ├── your-plugin-name.extension.ts
                    └── your-plugin-name.tsx
```

The following files are created in your site plugin's folder:

+ A `your-plugin-name.panel.tsx` file that contains the code for the site plugin's settings panel.
+ A `your-plugin-name.extension.ts` file that configures how your site plugin integrates with a Wix site. It defines the locations where the plugin can be added.
+ A `your-plugin-name.tsx` file contains the custom element code that supports the site plugin.

A `your-plugin-name-logo.svg` file is also created inside the `public` folder.

It is possible to create a site plugin extension manually by adding these files yourself, but we don't recommend it for a couple of reasons:

+ You're more likely to make errors in the file path if you add the files and folders yourself. If the file path is incorrect, the CLI can't detect the custom element and the site plugin won't work.
+ The auto-generated files offer React template code that helps you get started developing.

## Plugin logo

A `logo.svg` file is created inside the `public` folder when you generate this extension. The file is used as your plugin's logo in the plugin explorer in the editor. The file isn't required, however, it's referenced in the `logoUrl` field in the `your-plugin-name.extension.ts` file. 

<blockquote class="important">

__Important:__
If you rename the file, you must update the path in `logoUrl`. If you remove the file, you must remove the `logoUrl` property entirely. The file must be a square JPG, PNG, or SVG.

</blockquote>

## your-plugin-name.extension.ts

The `your-plugin-name.extension.ts` file configures which slots your plugin can be added to. This file is required, so don't delete it after the site plugin is generated. If you add your own files, you must include a `your-plugin-name.extension.ts`.

When you generate a new site plugin in your project, you'll see the following code in `your-plugin-name.extension.ts` (`placements` will contain the details of your selected plugin slot):

```ts
import { extensions } from '@wix/astro/builders';

export default extensions.sitePlugin({
  id: '269df530-84bf-430f-bf15-6e19ecded9e7',
  name: 'bookings-plugin',
  marketData: {
    name: 'bookings-plugin',
    description: 'Marketing Description',
    logoUrl: '{{BASE_URL}}/bookings-plugin-logo.svg',
  },
  placements: [{
    appDefinitionId: '13d21c63-b5ec-5912-8397-c3a5ddb27a97',
    widgetId: 'a91a0543-d4bd-4e6b-b315-9410aa27bcde',
    slotId: 'slot1',
  }],
  installation: { autoAdd: true },
  tagName: 'bookings-plugin',
  element: './extensions/site/plugins/bookings-plugin/bookings-plugin.tsx',
  settings: './extensions/site/plugins/bookings-plugin/bookings-plugin.panel.tsx',
});
```

The `placements` array is generated with the details of the slot you selected. You can add slots to the `placements` array to allow your plugin to be added to multiple slots. For detailed information on each available slot, see [About Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots).

By default, your file is configured so that your app will add the plugin to its slots on the site automatically upon installation.

If you have more than one placement for slots on a single page, the plugin will be added to the first slot in the array by default. Users may then manually move the plugin to their desired location in the editor.

| Field                            | Type     | Description                                                                                                                                                                                                                                                                                                                                |
|----------------------------------|----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `id`                             | string   | A unique identifier for your site plugin. The CLI generates this GUID for you. If you add the extension file yourself, you must generate your own GUID.                                                                                                                                                                                          |
| `name`                           | string   | Your name for the plugin.                                                                                                                                                                                                  |
| `marketData.name`           | string   | The name of your plugin as it will appear in the plugin explorer in the editor and in your [app dashboard](https://manage.wix.com/account/custom-apps). |
| `marketData.description`           | string   | The description of your plugin as it will appear in the plugin explorer in the editor and in your [app dashboard](https://manage.wix.com/account/custom-apps). |
| `marketData.logoUrl`           | string   | The relative path from your `your-plugin-name.extension.ts` to your logo file. |
| `placements`           | array   | An array of placement objects that define the slots your plugin can be added to. For detailed information on each available slot, see [About Slots](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-plugins/supported-wix-app-pages/about-slots).  |
| `placements.appDefinitionId`           | string   | The ID of the app that the slot belongs to. |
| `placements.widgetId`           | string   | The ID of the page that contains the slot. |
| `placements.slotId`           | string   | The ID of the slot your plugin can be added to. |
| `installation.autoAddToSite`           | boolean   | Whether the plugin should be added to the specified slots automatically when your app is installed on a site. |
| `tagName`           | string   | The custom HTML element tag name for your site plugin (for example, `bookings-plugin`). This tag name is used to render your plugin as a custom element in the site, similar to standard HTML tags like `<div>` or `<h1>`. Must follow [custom element naming rules](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements#name) (lowercase, contain a hyphen). |
| `element`           | string   | The relative path from your `your-plugin-name.extension.ts` to your custom element file. |
| `settings`          | string   | The relative path from your `your-plugin-name.extension.ts` to your site plugin's settings file. |

## your-plugin-name.tsx

The `your-plugin-name.tsx` file is where you write the code for the custom element that defines the site plugin. You can write code in other files and include it here, but you must return your main component in this file. This is where the CLI looks for the site plugin definition.

This file is required for the site plugin to work, so don't delete it. If you add the files on your own, you must include `your-plugin-name.tsx`.

When the `your-plugin-name.tsx` file is generated, it looks like this:

<!--start-tag PLUGIN_TSX -->
```ts
class MyElement extends HTMLElement {
  static get observedAttributes() {
    return ['display-name'];
  }

  constructor() {
    super();
  }

  connectedCallback() {
    this.render();
  }

  attributeChangedCallback() {
    this.render();
  }

  render() {
    const displayName = this.getAttribute('display-name') || `Your Widget's Title`;

    this.innerHTML = `
      <div style="font-size: 16px; padding: 16px; border: 1px solid #ccc; border-radius: 8px; margin: 16px; height: 50%;">
        <h2>${displayName}</h2>
        <hr />
        <p>
          This is a Site Plugin generated by Wix CLI.<br />
          Edit your element's code to change this text.
        </p>
      </div>
    `;
  }
}

export default MyElement;

```
<!--end-tag PLUGIN_TSX -->

The file sets up a [web component](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements) named `MyElement` where you write the custom element code.

In this example, `displayName` is fetched from the `your-plugin-name.panel.tsx` and shown in the UI.

## your-plugin-name.panel.tsx

The `your-plugin-name.panel.tsx` file contains the code that defines your site plugin's settings panel. The settings panel lets site users customize the plugin after they install your app. 

When the `your-plugin-name.panel.tsx` file is generated, it looks like this:

```javascript
import React, { type FC, useState, useEffect, useCallback } from 'react';
import { widget } from '@wix/editor';
import {
  SidePanel,
  WixDesignSystemProvider,
  Input,
  FormField,
} from '@wix/design-system';
import '@wix/design-system/styles.global.css';

const Panel: FC = () => {
  const [displayName, setDisplayName] = useState<string>('');

  useEffect(() => {
    widget.getProp('display-name')
      .then(displayName => setDisplayName(displayName || `Your Plugin's Title`))
      .catch(error => console.error('Failed to fetch display-name:', error));
  }, [setDisplayName]);

  const handleDisplayNameChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newDisplayName = event.target.value;
    setDisplayName(newDisplayName);
    widget.setProp('display-name', newDisplayName);
  }, [setDisplayName]);

  return (
    <WixDesignSystemProvider>
      <SidePanel width="300" height="100vh">
        <SidePanel.Content noPadding stretchVertically>
          <SidePanel.Field>
            <FormField label="Display Name">
              <Input
                type="text"
                value={displayName}
                onChange={handleDisplayNameChange}
                aria-label="Display Name"
              />
            </FormField>
          </SidePanel.Field>
        </SidePanel.Content>
      </SidePanel>
    </WixDesignSystemProvider>
  );
};

export default Panel;

```

The file contains a React component called `Panel` where you write the code that defines the plugin's settings panel.
`WixDesignSystemProvider` wraps the child components to align them with Wix's design conventions.

The file also contains a `useEffect` hook to fetch and set the initial value of the `displayName` property from the plugin's properties when the component mounts.

As with `your-plugin-name.tsx`, you can write code in other files and include it here, but you must return your main component in this file. The panel code must be written in React to work with the rest of the CLI project.

You can manage the properties of your site plugin's custom element using the [Widget API](https://dev.wix.com/docs/sdk/host-modules/editor/widget/introduction). You can also use Wix's [JavaScript SDK](https://dev.wix.com/docs/sdk) in the panel's code to [retrieve environmental data from the editor](https://dev.wix.com/docs/sdk/host-modules/editor/info/introduction) and access and manage Wix business solutions.

To apply changes made in the settings panel to the plugin, use the Widget API's [`setProp()`](https://dev.wix.com/docs/sdk/host-modules/editor/widget/set-prop) function. Widget properties are bound to your custom element's attributes, so any change in the properties automatically updates the corresponding attribute.

Learn more about [creating a settings panel for a site plugin built with the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/create-a-settings-panel-for-a-site-widget-or-plugin-wix-cli-and-self-hosting).
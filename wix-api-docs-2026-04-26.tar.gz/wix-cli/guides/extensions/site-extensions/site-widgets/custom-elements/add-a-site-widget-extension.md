---
portal: wix-cli
name: "Add a Site Widget Extension"
type: ARTICLE_RESOURCE
resourceId: dd1542ef-eb52-43d2-bee8-fb5631f858aa
---

# Add a Custom Element Site Widget Extension with the Wix CLI

# Add a Custom Element Extension with the Wix CLI


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [Add a Custom Element Extension with the Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/custom-element-site-widgets/add-a-site-widget-extension-in-the-cli).

</blockquote>


The Wix CLI makes it easy to add and develop custom element site widgets in your app project. These are considered app extensions and appear on the Extensions page in your app's dashboard. For more general information about site widgets, see [About Site Widget Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/site-widgets/about-site-widget-extensions)

Custom element site widgets extensions are built in the CLI with [custom element](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements) technology. The custom element is essentially a new HTML tag that you define, which is made available in the Wix editors as a widget.

The Wix CLI creates the necessary files with template code so you can easily start developing your site widget. It also calls [`define()`](https://developer.mozilla.org/en-US/docs/Web/API/CustomElementRegistry/define) for the custom element that the site widget is built on, so you don't need to explicitly call it in your code.

Follow the instructions below to:

1. Add a custom element site widget to your app project.
2. Test the site widget on a site.
3. Deploy your app with the site widget.

## Step 1 | Add a site widget to your app project

In the terminal:

1. Navigate to your project repo.
2. Run the [generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate) command.

    The CLI will display a menu of extensions to generate. Select **Site Widget** and hit enter. 
    
3. When prompted, choose **Custom Element** as your framework.

    The CLI will then prompt you for the following items:

    + **Element name**: The name of the element that appears in the `element.json` configuration file. Only you will see this.
    + **Element folder**: The name of the folder in the project repo that contains the custom element code that the site widget is built on. Only you will see this.

Upon completion, the extension files will be created in your project directory with the following structure:

```bash
src/
  └── extensions/
      └── site/
          └── widgets/
              └── <your-widget-name>/
                  ├── <your-widget-name>.extension.ts
                  ├── <your-widget-name>.tsx
                  ├── <your-widget-name>.panel.tsx
                  ├── <your-widget-name>.module.css
                  └── thumbnail.png
```

> **Note:** This is the default folder structure created by the CLI. You can move these files to any location within the `src/` folder and update the references in your `extension.ts` file. Learn more about the [flexible file system](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure#your-custom-extension-folder).

Learn more about the [Custom Element site widget extension files](https://dev.wix.com/docs/wix-cli/guides/extensions/site-extensions/site-widgets/site-widget-extension-files-and-code).

## Step 2 | Testing your site widget

You can test your site widget while you're developing by running the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command.
Select the option in the CLI menu to view your site widget in the editor. This will open your test site editor, where you can view and try out your site widget.

<details>  

<summary>Why do I get a placeholder when previewing my site widget?  
<br/>
<img src="https://wixmp-833713b177cebf373f611808.wixmp.com/images/38a8352eac676919a6cce81fdb96463a.jpg" style="max-width: 8vw" />
<br/>
</summary>

In some cases, your site widget doesn't display when previewed, but does display as expected when viewed on a published site. We are currently working to fix this issue, but in the meantime, we display a placeholder. 

This can happen if: 

- You open the dashboard, site, or editor from the menu options. Run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command to restart your local environment.
- You preview a site when the site was opened with the editor menu option. Run the [build](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build) command and then the [release](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) command to release a new version.

</details>

<blockquote class="tip">

**Tip:** Access to site environment data and interact with other Wix Apps, such as Wix Stores and Wix Bookings, using the [Site API](https://dev.wix.com/docs/sdk/host-modules/site/introduction).

</blockquote>

## Step 3 | Build and deploy your project 

Once your app project is ready for production, you can build it and release a version in the app dashboard.

1. Run the [build](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/build) command.

2. Run the [release](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/release) command and follow the prompts to release an app version.

An app version allows you to publish an app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct install URL. You can view [your app versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

For more information about building and deploying your app, see [Build and Deploy an App with the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/development/build-and-deploy-a-project).

## Delete a site widget extension

To delete an existing site widget extension from your app:

1. Delete the folder that contains your site widget's files.
2. Remove the import and `.use()` statements for the extension from the [`extensions.ts`](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file) file.

> **Note**: If you've already created a version of your app, deleting a site widget's files from your project doesn't remove the site widget from your app's latest version in the app dashboard. To remove the site widget, create a new version after deleting the site widget extension files.
---
portal: wix-cli
name: "Integrate Existing Apps with App Projects"
type: ARTICLE_RESOURCE
resourceId: 964610ba-35a0-4f41-ac77-59c70aa990af
---

# Integrate Existing Apps with App Projects

# Integrate Existing Apps with CLI App Projects


When developing an app, you can use the Wix CLI to work with existing app versions in the [app dashboard](https://manage.wix.com/account/custom-apps). This allows you to add new features to your app using the CLI without having to migrate the entire app to your CLI project.

Follow these steps to integrate your app with the CLI.

## Prerequisites

Before getting started, make sure you have the following set up:

+ [Node.js](https://nodejs.org/en/) (v20.11.0 or higher)
+ An existing Wix App

## Step 1 | Extend an existing app

To extend an existing app with a new Wix CLI project:

1. Run the following command:

    ```bash
    npm create @wix/new@latest app
    ```

1. Choose **Extend existing application**.
1. Choose the app to extend.
1. Choose a package name for your project. The package name is the name of the package created locally for your project, and the name of the directory containing your project's local files.

### What you get

Once the process is complete, you'll have all the files for your app in a local directory with the package name you chose. For more information about the local files generated for your app, see [CLI project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure).

When working on the CLI extension project locally or in preview versions, you can only work with the app extensions that are registered in your CLI project. Other app extensions from your app's dashboard are still loaded into your development site where you can preview and test them, but they will use their production versions.

Changes to your extension's local files will not be reflected in your app's dashboard until you create a new [app version](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/development-overview#app-versions-and-deployment).

## Step 2 | Test the app

Your app won't be active on your development site at this stage, however, you can preview and test it in a local development environment.

To set up a local development environment, use the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command.

To test your app, you'll be asked to choose an existing site or create a [development site](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli#development-sites). You can use the CLI to open the different parts of your app on the development site in your browser.

## Next steps

After completing the above steps, you have integrated your existing app into a Wix CLI project that you can experiment with and test locally.

You can now:

+ [Add extensions to your project's private app](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions).
+ [Learn more about developing your project](https://dev.wix.com/docs/wix-cli/guides/development/development-overview).

## See also

+ [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
+ [Project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure)
+ [CLI Command Reference](https://dev.wix.com/docs/wix-cli/command-reference/introduction)
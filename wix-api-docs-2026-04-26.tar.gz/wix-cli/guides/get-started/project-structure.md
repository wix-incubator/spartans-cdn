---
portal: wix-cli
name: "Project Structure"
type: ARTICLE_RESOURCE
resourceId: 82cb0f36-4c96-4630-a31f-1b265605a3f2
---

# Project Structure

# Wix CLI Project Structure


<blockquote classname="note">

**CLI Documentation Notice**

You're viewing documentation for the new Wix CLI, which we recommend for all new projects. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).

Previous CLI documentation:
- Wix CLI for Apps: [CLI App Structure](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/cli-app-structure).
- Wix CLI for Headless: [Project Structure](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-headless/project-development/project-structure).

</blockquote>

This article describes the structure of a Wix CLI project. The CLI uses a standardized project structure based on the Astro web framework for both app projects and headless projects.

Every CLI project includes Astro files, Wix-specific files, [Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills), and directories for extensions and configuration. Headless projects contain additional Astro development files to define the project's frontend, such as [pages](https://docs.astro.build/en/basics/astro-pages/), [components](https://docs.astro.build/en/basics/astro-components/), [layouts](https://docs.astro.build/en/basics/layouts/), and more.

## Project file structure

```text
.
├── .agent/ 
      └── skills/
├── .cursor/ 
      └── skills/
├── .claude/ 
      └── skills/
├── .astro/
├── .wix/
├── dist/
├── node_modules/
├── public/
├── src/
│   ├── your-custom-extension-folder/
|   └── extension.ts
├── astro.config.mjs
├── .env.local
├── package.json
├── tsconfig.json
├── wix.config.json
└── .gitignore
```

> **Note:** Some of these files and directories don't exist when you initially create your project. They're created when you add extensions, and when you build or run your project.

## Skills directories

[Wix skills](https://dev.wix.com/docs/wix-cli/guides/development/about-wix-skills) support many AI agents and tools. Each supported agent has a top-level directory configured in a way that each agent can read and use the skills. For example, Wix skills for Cursor are in the `.cursor/` directory and Wix skills for Claude are in the `.claude/` directory.  

## .astro/
Astro build and type files. Managed by Astro.

## .wix/
Contains configuration and log files related to the Wix environment. 

<blockquote class="caution">

__Caution:__
This directory contains internal data. Don't edit it.

</blockquote>

## dist/
Contains the production build output of your project. This directory is created automatically when you build your project. You generally don't need to edit files here.

## public/
Static files served at the root of your site.

## src/
Source directory. Contains all the source code and core resources of your application.

### your-custom-extension-folder/
You can organize your extensions into multiple custom folders and reference their paths in the `extension.ts` file. The CLI's flexible file system allows you to structure your extensions in any way that makes sense for your project, as long as it's inside the `/src` folder. 

When you generate an extension using [wix generate](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/generate), the CLI creates a default folder structure based on the extension type. For example, dashboard pages are created in `src/extensions/dashboard/pages/`. While this default pattern helps maintain consistency, you're free to reorganize these files however you prefer. After moving an extension to a new location, simply update the file path reference in your `extension.ts` file to point to the new location.

### extension.ts
The configuration file where you register all extensions for your project. This file imports and registers all your extensions, regardless of where they're located in your project structure. When you move an extension file, update the import path in this file to maintain the connection. Learn more about the [extension.ts file](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file).

## astro.config.mjs
Astro configuration file.

## .env.local
Contains [environment variables](https://dev.wix.com/docs/wix-cli/guides/development/environment-variables/about-environment-variables) required to setup authentication for your local development environment. Don't edit any of the `WIX_CLIENT` variables.

## package.json
Holds various metadata relevant to the project. It manages the project's dependencies, scripts, and more.

## tsconfig.json
Configuration for the TypeScript compiler.

## wix.config.json
Defines basic information about your project, including `appId` of your private app, and `projectId` of your headless project. Don't edit this file.

## See also

- [About Extensions](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions)
- [About the extensions.ts File](https://dev.wix.com/docs/wix-cli/guides/extensions/about-the-extensions-ts-file)
---
portal: wix-cli
name: "Quick Start a Headless Project"
type: ARTICLE_RESOURCE
resourceId: f2f14ea8-fea5-4560-a04f-2f33a9d31e56
---

# Quick Start a Headless Project

# Quick Start a Wix CLI Headless Project

<blockquote class="caution"> 
The Wix CLI is in Developer Preview and is subject to change.
</blockquote>

This guide explains the minimum steps required to get a headless project up and running using the [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). As part of this setup, you'll get a frontend site and [private app](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli#projects-private-app) integrated with a headless project.

> **Note:** This setup also initializes useful headless settings for your project, such as [adding allowed redirect domains](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/add-allowed-redirect-domains) and [setting a Wix Pages domain](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-business-flows/set-a-wix-pages-domain).

## Before you begin

Before getting started, make sure that you:

+ Have [Node.js](https://nodejs.org/en/) (v20.11.0 or higher).
+ Have Git installed and [configured](https://git-scm.com/docs/git-config).
+ Are logged into your Wix account. If you don't already have one, [sign up for a Wix account](https://manage.wix.com/account/custom-apps).
  
## Step 1 | Create a new headless project

1. Run the following command to create a new headless project:

    ```bash
    npm create @wix/new@latest headless
    ```

2. Enter the **name of your business**. This is the name of your headless project on Wix. The CLI creates a Wix Headless project for you with this name. This project is added to your Wix sites list.

3. Choose an **initial template** for your project. You'll see 2 categories:
   + **Wix Vibe compatible**: Templates that can be connected to [Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe) for AI-powered visual editing. For a list of Vibe-compatible templates, see [Wix CLI for Headless Templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates).
   + **Standard templates**: For traditional headless development, not compatible with Wix Vibe, see [Wix CLI for Headless Templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates).

4. Choose the **directory** where you want to create your local project files. The CLI generates the [local code files](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure) for your project in a directory with the name you chose.

5. Wait for the CLI to generate your project. This includes installing dependencies, initializing a git repository, and configuring your project files.

6. If you chose a Vibe-compatible template, the CLI prompts you to set up your project for editing in Wix Vibe:
   + **Set up project for Wix Vibe and create a GitHub repository (recommended)**: Opens your browser to create a GitHub repository for your project. After creating the repository, the CLI syncs your code to GitHub and completes the Vibe setup.
   + **Skip for now**: You can set up Vibe later using the [`wix connect`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/connect) command (see [Step 4](#step-4-optional-connect-to-vibe-for-visual-editing)).

7. After the CLI finishes generating your headless project, the CLI builds and publishes your site, and gives you the site URL.

## Step 2 | Test the project

1. Navigate to your project directory:

2. Run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command to start the local development environment. The CLI builds a local environment for your project and provides links to view your site and dashboard.

The development environment is set up for hot reloading, so any changes you make to your code are immediately reflected in the browser.

## Step 3 (Optional) | Call a Wix API 

> **Note:** In this step we're calling `listMembers()` in the Wix Members API, but you can use any method in any [Wix JavaScript SDK](https://dev.wix.com/docs/api-reference?apiView=SDK) API.

1. Close the local development environment that started when you ran the dev command.
2. Install the `@wix/members` package:

    ```bash
    npm install @wix/members
    ```

3. Add the following to your `index.astro` file's front matter:

    ```ts
    import { members } from "@wix/members";

    const memberList = await members.listMembers();
    console.log("Site members:", memberList);
    ```

    Your front matter should look something like this:

    ```ts
    ---
    import Welcome from '../components/Welcome.astro';
    import Layout from '../layouts/Layout.astro';

    import { members } from "@wix/members";

    const memberList = await members.listMembers();
    console.log("Site members:", memberList);
    ---
    ```

4. Run the [dev](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/dev) command to restart the local development environment.

5. Click the link to open your site.
6. Return to the terminal. You should see the following log showing that your site currently has 0 members:

    ```bash
    Site members: {
        members: [],
        metadata: { count: 0, offset: 0, total: 0, tooManyToCount: false }
    }
    ```

    > **Note**: If you added members, you may not see their data in this list due to their status being set to `PRIVATE` by default. For more information, see [List Members](https://dev.wix.com/docs/api-reference/crm/members-contacts/members/member-management/members/list-members?apiView=SDK).

## Step 4 (Optional) | Connect to Vibe for visual editing

If you created your project with a Vibe-compatible template and want to use [Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe) for AI-powered visual editing, you can connect using the [`wix connect`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/connect) command.

Your local code remains the source of truth, and changes made in Vibe are synchronized with your local project files.

> **Note:** If you chose "Set up project for Wix Vibe and create a GitHub repository" during initial project creation, your Vibe setup is already complete and you don't need to run this command.

If you skipped the Vibe setup during initial creation:

1. Navigate to your project directory.

2. Run the following command:

    ```bash
    wix connect
    ```

3. The CLI opens your browser to create a GitHub repository, then completes the Vibe setup and provides you with a link to access the Vibe editor.

> **Note:** The [`wix connect`](https://dev.wix.com/docs/wix-cli/command-reference/project-commands/connect) command is only available for projects created with Vibe-compatible templates. For a full list of available templates, see [Wix CLI for Headless Templates](https://dev.wix.com/docs/go-headless/get-started/templates/wix-managed-templates/wix-cli-for-headless-templates#wix-vibe-compatible-templates).

## Next steps

After completing the above steps, you have a simple headless project that you can experiment with and test locally.

You can now:

+ [Add extensions to your project's private app](https://dev.wix.com/docs/wix-cli/guides/extensions/about-extensions)
+ [Learn more about developing your project](https://dev.wix.com/docs/wix-cli/guides/development/development-overview)

## See also

+ [About the Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli)
+ [About Wix Vibe](https://dev.wix.com/docs/go-headless/resources/wix-vibe/about-wix-vibe)
+ [Wix CLI Development Overview](https://dev.wix.com/docs/wix-cli/guides/development/development-overview)
+ [Project structure](https://dev.wix.com/docs/wix-cli/guides/get-started/project-structure)
+ [CLI Command Reference](https://dev.wix.com/docs/wix-cli/command-reference/introduction)
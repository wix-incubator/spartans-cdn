---
portal: wix-cli
name: "Authenticate Incoming Requests to Your Backend"
type: ARTICLE_RESOURCE
resourceId: b621dc90-cbb0-4b43-b947-8e344aa18ce5
---

# Authenticate Incoming Requests to Your Backend

# Authenticate Incoming Requests to Your Self-Hosted Backend

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

Once you expose a self-hosted backend API to make it available for your app, you need to make sure that requests to your API are coming from your app and not from malicious users.

To authenticate requests, use your app's unique app instance object, which is signed with your app's secret key.

## App instance object

An app instance object is a JSON object that contains information about the site an app is installed on, the current user, and the current instance of your app. Wix encrypts this object and passes it in string format to your app's iframe as a query parameter.

The app instance object contains the following useful fields:

- **`instanceId`**: ID of the current instance of your app.
- **`uid`**: ID of the user who is logged into the site your app is installed on.

To learn more about the app instance object and its fields, see [About App Instances](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/about-app-instances).

## Step 1 | Get the app instance

In your app’s frontend code, you need to retrieve the app instance string so you can send it along with your requests to the backend.

To retrieve the app instance string, use the following helper function in your code:

```ts
export function getAppInstance() {
  return new URLSearchParams(window.location.search).get('instance')!;
}
```

## Step 2 | Send the app instance

Once you've retrieved the app instance, you need to send it in requests you make to your backend. Your backend should use the app instance to authenticate requests and extract any information needed from the app instance.

To make HTTP requests to your backend with the signed instance, use something similar to the following (TypeScript) helper function:

```ts
export async function fetchWithWixInstance(url: string, options: RequestInit) {
  return fetch(url, {
    ...options,
    headers: {
      Authorization: getAppInstance(),
      ...options.headers,
    },
  });
}
```

This function sends the app instance string in the authorization header when making requests to the backend.

## Step 3 | Validate the app instance

When a request is made to your app’s backend, you should authenticate it before continuing to process it. To do this, you need your app's secret key. You can get your app's secret key from the [**OAuth**](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Foauth) page in your app's dashboard.

<blockquote class="important">

**Important:** Store your app secret securely on your server.

</blockquote>

The app instance string has 2 parts — signature and data. To authenticate a request, extract the signature from the app instance string sent in the request and verify it was signed with your app's secret key.

For parsing examples in a number of programming languages, see [Parse the Encoded App Instance Parameter](https://dev.wix.com/docs/build-apps/develop-your-app/access/app-instances/parse-the-encoded-instance-query-parameter).

Here is an example of how to parse the instance in TypeScript:

```ts
import { createHmac } from 'crypto';

export function parseInstance(
  instance: string,
  appSecret: string
): {
  instanceId: string;
  appDefId: string;
  signDate: string;
  uid: string;
  permissions: 'OWNER';
  demoMode: boolean;
  siteOwnerId: string;
  siteMemberId: string;
  expirationDate: string;
  loginAccountId: string;
  pai: null;
  lpai: null;
} | null {
  var parts = instance.split('.'),
    hash = parts[0],
    payload = parts[1];

  if (!payload) {
    return null;
  }

  if (!validateInstance(hash, payload, appSecret)) {
    return null;
  }

  return JSON.parse(base64Decode(payload, 'utf8'));
}

function validateInstance(hash: string, payload: string, secret: string) {
  if (!hash) {
    return false;
  }

  hash = base64Decode(hash);

  var signedHash = createHmac('sha256', secret)
    .update(payload)
    .digest('base64');

  return hash === signedHash;
}

function base64Decode(input: string, encoding: 'base64' | 'utf8' = 'base64') {
  return Buffer.from(
    input.replace(/-/g, '+').replace(/_/g, '/'),
    'base64'
  ).toString(encoding);
}
```
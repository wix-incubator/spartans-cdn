---
portal: wix-cli
name: "Build and Deploy an App with the CLI"
type: ARTICLE_RESOURCE
resourceId: 3d73c8b9-3111-4bee-9eeb-97055dd0b4f6
---

# Build and Deploy an App with the CLI

# Build and Deploy an App with the CLI

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

After developing and testing your Wix CLI app locally, you can take it to production. This article guides you through that process.

The following diagram shows the overall flow for creating a CLI app. The steps in the red rectangle are covered in this article.

![Build and deploy an app](https://wixmp-833713b177cebf373f611808.wixmp.com/images/6f2b65e940aec9b65dac2daf93230652.png)

## Prerequisites

To follow this guide you need a Wix CLI App. For instructions on creating an app, see [Quick Start](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/quick-start).
  
## Step 1 | Build the app

Run the following command to build the assets for your app:

```bash
npm run build
```

## Step 2 (Optional) | Create an app preview URL

An app preview URL is a URL you can share with team members. The link allows them to preview and test your app.

To push your app to Wix's servers for hosting and create an app preview URL, run the following command:

```bash
npm run preview
```

## Step 3 | Release an app version

Now that you’ve built your app, it's time to create an [app version](https://dev.wix.com/docs/build-apps/manage-your-app/versioning/about-app-versioning).

An app version allows you to publish an app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct install URL.

The CLI guides you through the process of releasing a new app version. You can view your [app versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

To push your app to Wix's servers for hosting and releasing an app version, run the following command and follow the prompts:

```bash
npm run release
```

To learn more about app versions, see [App Versions and Deployment](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#app-versions-and-deployment).

## Step 4 (Optional) | Publish your app

Once you have an app version, you can submit it for review and then publish it to the [Wix App Market](https://www.wix.com/app-market) or have users install it on their sites with a direct install URL.

For more information on publishing your app, see [About Market Listings](https://dev.wix.com/docs/build-apps/launch-your-app/market-listing/about-market-listings).

## Next steps

You now have a fully working app that can be installed on Wix sites.

Use the following resources to continue building your app:

+ [Add extensions to your app](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions).
+ [Learn more about how to develop your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview).
---
portal: wix-cli
name: "Command Reference"
type: ARTICLE_RESOURCE
resourceId: d5b286b7-50c2-4fcc-a1dc-cf1458cc4a5c
---

# CLI Command Reference

# Wix CLI for Apps Command Reference

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

This article documents the CLI commands for building [Wix Apps](https://dev.wix.com/docs/build-apps/get-started/overview/about-wix-apps).

For a detailed explanation of the process and how to initially create an app, see our [Quick Start article](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/quick-start).

## Command overview

| Category          | Command            | Description                                                  |
|----------------|--------------------|--------------------------------------------------------------|
| CLI for Apps   | [create](#create)  | Creates a new Wix app project.                              |
|                | [dev](#dev)        | Starts a local development environment that serves your app. |
|                | [generate](#generate)    | Generates an extension for your app.                   |
|                | [build](#build)    | Builds your app.                                             |
|                | [preview](#preview)| Creates an online preview of your built app.                 |
|                | [release](#release)| Starts a process that guides you through releasing a new app version. |
|                | [create-version](#create-version)  | Deprecated, use [release](#release) instead. |
|                | [logs](#logs)      | Shows backend logs from your app.                 |
| Global CLI     | [login](#login)    | Logs in to your Wix account.                                   |
|                | [logout](#logout)  | Logs out of your Wix account.                                  |
|                | [telemetry](#telemetry)| Opts in or out of sending anonymous usage information (telemetry) to Wix. |
|                | [whoami](#whoami)  | Displays the email address of the logged-in Wix user.         |

## create

Creates a new Wix app project. This command guides you through the process of setting up a new app, allowing you to either create a basic app from scratch or start from a template.

```bash
npm create @wix/app@latest
```

Once completed, your app will appear in the [app dashboard](https://manage.wix.com/account/custom-apps) and the app files will be created in a local directory.

> **Note:** You can also integrate an existing Wix app during this process. For more information see [Integrate Existing Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/integrate-existing-apps).

## dev

Starts a local development environment that serves your app. Follow the prompts to open the different parts of your app on your development site in your browser.

The development environment is set up for hot reloading, so any changes you make to your code are immediately reflected in the browser.

```tsx
wix app dev
```

### Options

| Option           | Alias     | Description                             |
| -------------- | --------- | --------------------------------------- |
| `--https`  | `-s` | Starts your local development server on HTTPS. Use this flag if your browser does not allow iframes that contain HTTP pages within HTTPS pages. |

## generate

Starts a process that guides you through adding an [extension](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions) to your app. 

After selecting an extension you will be prompted for relevant configuration details, then your extension will be generated in your app's local files.

```tsx
wix app generate
```

### Options

| Option         | Description                             |
| -------------- | --------------------------------------- |
| `--type` <type> | Generates an extension with the specified type. <br><br> Accepted values for `<type>`: `HTTP_FUNCTION`, `BACKEND_EVENT`, `SERVICE_PLUGIN`, `WEB_METHOD`, `DASHBOARD_PLUGIN`, `DASHBOARD_MENU_PLUGIN`, `DASHBOARD_MODAL`, `DASHBOARD_PAGE`, `EMBEDDED_SCRIPT`, `SITE_PLUGIN`, `SITE_WIDGET`.  |


## build

Builds your app.

You must build your app before:

* Creating a version
* Previewing your app
  
```tsx
wix app build
```

## preview

Creates an online preview of your built app and provides an inline link to an app preview URL in the console.

An app preview URL is a URL you can share with team members who are [collaborators](https://support.wix.com/en/article/inviting-people-to-contribute-to-your-site) on your development site. It directs to a dashboard page where they can preview and test your app.

By default, the code for your app preview is hosted on Wix's servers.

```tsx
wix app preview
```

### Options

| Option                 | Alias         | Description                                                           |
| -------------------- | ------------- | --------------------------------------------------------------------- |
| `--site <site-id>`   | `-s <site-id>` | Allows you to set the `site` used for application preview URLs. If this flag is not provided, the `site-id` defaults to the currently-selected development site.<br><br>You can get the ID of a site from the site URL in your browser. For example, the site ID appears after the `/dashboard/` part of this URL:<br><br>![Site ID](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ad5c872775e393432b2163e752408170.png) |
| `--base-url <url>`     |   | Sets the base URL for uploading your static files to an external CDN. If this flag is not provided, the code for your preview will be hosted on Wix's servers. |


## release

> **Note**: The release command was added to v1.1.68 of the CLI, published on Feb 23, 2025. If the release command is missing, [update your CLI dependencies](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#keeping-the-cli-up-to-date) to the latest version and [add the new command to your `package.json` file](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/updates/add-new-cli-commands-to-existing-apps).

Starts a process that guides you through releasing a new app version. You can view your [app versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

Once the app version is released, you can [submit it for review](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/submit-your-first-app-version) to publish it to the [Wix App Market](https://www.wix.com/app-market). If you choose not to list your app in the Wix App Market, you can distribute your app by [sharing an install link](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/share-an-app-install-link) or [install it directly](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/install-your-app-directly-on-sites) on a site within your account.

To learn more about app versions, see [App Versions and Deployment](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#app-versions-and-deployment).

```tsx
wix app release
```

### Options

| Option                      | Alias          | Description                                                           |
| ------------------------- | -------------- | --------------------------------------------------------------------- |
| `--site <site-id>`        | `-s <site-id>` | The site ID to use for application preview URLs. Defaults to the current selected development site. |
| `--base-url <url>`        |                | Sets the base URL for uploading your static files to an external CDN. If this flag isn't provided, the code for your app is hosted on Wix's servers.|
| `--comment <comment>`     | `-c <comment>` | The comment for your release version. Not visible to users. |
| `--version-type <type>`   | `-t <type>`    | The type of version you would like to create. <br><br> Accepted values for `<type>`: `major`, `minor`. |
| `--approve-minor`         | `-y`           | Approve minor version release automatically. |

## create-version

> **Deprecation Notice**
>
> The create-version command has been replaced by the [release](#release) command. 
The create-version command will be supported for a limited time to allow you to switch to the new command. 

Starts a process that guides you through creating a new app version. You can view your [app versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

Once the app version is created, you can [submit it for review](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/submit-your-first-app-version) to publish it to the [Wix App Market](https://www.wix.com/app-market). If you choose not to list your app in the Wix App Market, you can distribute your app by [sharing an install link](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/share-an-app-install-link) or [install it directly](https://dev.wix.com/docs/build-apps/launch-your-app/app-distribution/install-your-app-directly-on-sites) on a site within your account.

To learn more about app versions, see [App Versions and Deployment](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#app-versions-and-deployment).

```tsx
wix app create-version
```

### Options

| Option                 | Alias         | Description                                                           |
| -------------------- | ------------- | --------------------------------------------------------------------- |
| `--version-type <type>`   | `-t <type>` | Specifies the type of version to create. <br><br> Accepted values for `<type>`: `major`, `minor`.
| `--approve-preview`   | `-y` | Automatically approves continuing with the publishing process after the preview is provided. Without this flag, you are asked for approval.
| `--base-url <url>`     |   | Sets the base URL for uploading your static files to an external CDN. If this flag isn't provided, the code for your app is hosted on Wix's servers. |


## logs

Shows backend logs of a selected [version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#app-versions-and-deployment) of your app. 


```tsx
wix app logs
```

### Options

| Option                 | Alias         | Description                                                           |
| -------------------- | ------------- | --------------------------------------------------------------------- |
| **yarn** <br> `--version <version>` <br> <br> **npm** <br> `-- --version <version>`  |         | Required. The version of the app to show logs for. For example, `--version 1.0.0`  |


## login

Logs in to your Wix account.

```tsx
wix login
```

## logout

Logs out of your Wix account.

>**Note:** To switch to another Wix account:
>1. Run `wix logout`.
>2. Run `wix login`, then click the link provided.
>3. Click **Log in with another account**.

```tsx
wix logout
```

## telemetry

Opts in or out of sending anonymous usage information (telemetry) to Wix.

```tsx
wix telemetry [on | off]
```

## whoami

Displays the email address of the logged-in Wix user.

```tsx
wix whoami
```
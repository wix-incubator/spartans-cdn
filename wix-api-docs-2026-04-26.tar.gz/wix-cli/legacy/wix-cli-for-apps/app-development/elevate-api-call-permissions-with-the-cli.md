---
portal: wix-cli
name: "Elevate API Call Permissions with the CLI"
type: ARTICLE_RESOURCE
resourceId: 46242455-fe5b-4ed2-9ccf-60a6863eab85
---

# Elevate API Call Permissions with the CLI

# Elevate API Call Permissions with the CLI

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

In workflows that use mostly [site visitor](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#site-visitors), [site member](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#site-members), or [Wix user](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#wix-users) authentication, you may occasionally need to make calls with [elevated permissions](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-elevated-permissions). You can use the [JavaScript SDK](https://dev.wix.com/docs/build-apps/develop-your-app/api-integrations/java-script-sdk) to provide specific calls with [Wix app](https://dev.wix.com/docs/build-apps/develop-your-app/access/about-identities#wix-apps) authentication.

The process involves 2 steps:

1. Set up your app's backend code to handle elevated requests.
1. Send an authenticated call from your frontend code to your app's backend. Frontend code includes [site extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) and [dashboard extension](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/about-dashboard-extensions) code.

You can make calls from your frontend code to your app's backend using either [web method extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/web-methods/add-web-method-extensions-with-the-cli) or [API extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/api/add-api-extensions-with-the-cli). We recommend using web method extensions in this situation as they [offer several advantages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions#web-methods-vs-api-extensions) over API extensions.

<blockquote class="important">

**Important:** Exposed elevated function calls create a security risk for [privilege escalation attacks](https://en.wikipedia.org/wiki/Privilege_escalation). Make sure to protect your exposed function calls with the appropriate logic.

</blockquote>

## Elevating permissions using a web method extension

To elevate permissions for calls to Wix APIs using a web method extension:

### Step 1 | Set up the web method in your app's backend

Set up your app's backend to handle requests for elevated function calls from your frontend.

To set up your backend:

1. Create a [web method extension](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/web-methods/add-web-method-extensions-with-the-cli) to define a function in your app's backend that you can call from your frontend code.
1. In the extension's `web.ts` file in your CLI project, import the [`auth`](https://dev.wix.com/docs/sdk/core-modules/essentials/auth) submodule from `@wix/essentials` as well as the module containing the function that you want to make elevated calls to.

   ```js
   import { auth } from "@wix/essentials";
   import { <module> } from "@wix/<package>";
   ```

1. Define a web method that calls the function you need, using the [permissions parameter](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions#web-method-permissions) to define the required permissions.

Wrap the function with [`auth.elevate()`](https://dev.wix.com/docs/sdk/core-modules/essentials/auth#elevate) before calling it.

   ```js
   export const myWebMethod = webMethod(Permissions.Anyone, async () => {
      const elevatedFunction = auth.elevate(<module>.function);
      const elevatedResponse = elevatedFunction();
      // ...
   })
   ```

### Step 2 | Call the web method from your frontend

To call the web method, import it from the extension's `web.ts` file, then call it in your code.

   ```js
   import { myWebMethod } from "<relative-path>/my-web-method-file.web.ts";

   const result = await myWebMethod();
   ```

This call is authenticated automatically.

## Elevating permissions using an API extension

To elevate permissions for calls to Wix APIs using an API extension:

### Step 1 | Set up the API extension in your app's backend

Set up your app's backend to handle requests for elevated function calls from your frontend.

To set up your backend:

1. Create an [API extension](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/api/add-api-extensions-with-the-cli) to allow your app to expose backend HTTP functions.
1. In the `api.ts` file in your CLI project, import the [`auth`](https://dev.wix.com/docs/sdk/core-modules/essentials/auth) submodule from `@wix/essentials` as well as the module containing the function that you want to make elevated calls to.
   ```js
   import { auth } from "@wix/essentials";
   import { <module> } from "@wix/<package>";
   ```
1. Expose an endpoint that calls the function you need. Wrap the function with [`auth.elevate()`](https://dev.wix.com/docs/sdk/core-modules/essentials/auth#elevate) before calling it.
   ```js
   export function GET(request) {
     const elevatedFunction = auth.elevate(<module>.function);
     const elevatedResponse = elevatedFunction();
     // ...    
   }
   ```

### Step 2 | Send authenticated requests from your frontend

Send authenticated requests from your site's frontend code to your backend endpoint.

To send requests:

1. Import the [`httpClient`](https://dev.wix.com/docs/sdk/core-modules/essentials/http-client) submodule from the `@wix/essentials` package.  
   This submodule includes a function called `fetchWithAuth`. This function automatically signs API calls with an authorization header that identifies the current site visitor, site member, or Wix user.
   ```js
   import { httpClient } from "@wix/essentials";
   ```
1. Call your app's backend HTTP function using `fetchWithAuth()`.  
   The base URL for your endpoint is provided automatically by the CLI. Note that the path for your endpoint is based on the name of its containing folder in the CLI.
   ```js
   const response = await httpClient.fetchWithAuth(`${import.meta.env.BASE_API_URL}/<your-api-path>`);
   ```



## See also
+ [About Elevated Permissions](https://dev.wix.com/docs/sdk/articles/work-with-the-sdk/about-elevated-permissions)
+ [Elevate API Call Permissions with Self-hosting](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/self-hosting/elevate-sdk-call-permissions-with-self-hosting)
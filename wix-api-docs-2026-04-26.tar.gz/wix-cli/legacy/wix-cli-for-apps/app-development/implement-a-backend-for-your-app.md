---
portal: wix-cli
name: "Implement a Backend for Your App"
type: ARTICLE_RESOURCE
resourceId: 800b4c09-4f1e-4403-b354-ef323a0776c7
---

# Integrate Your Own Backend

# Implement a Backend for Your App

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

While building a CLI app, you often need to use your own APIs, employ third-party APIs, and work with a database.

In order to do these things in a secure manner, you need to implement a backend for your app.

The simplest way to implement a backend is to use the CLI's [backend extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/about-cli-app-backend-extensions). 

You also have the option to integrate with a self-hosted backend. 

## Integrate With a Self-Hosted Backend

You can use any server technology you want to create a backend that integrates with your Wix CLI app.

There are a few things you need to keep in mind when implementing your backend:

- **CORS**: You need to set up CORS properly to make sure your server accepts requests from your app.
- **Authentication**: You need to check that requests to your server are coming from your app and not a malicious user.
- **Multiple instances**: You can optionally differentiate between the multiple instances of your app when they make requests to the server.
- **Call Wix APIs**: You can call Wix APIs from your backend using the [Wix REST API](https://dev.wix.com/docs/rest). You need to authenticate your requests using either [OAuth](https://dev.wix.com/docs/build-apps/develop-your-app/access/authentication/about-oauth) or [API keys](https://dev.wix.com/docs/rest/articles/getting-started/api-keys).

### CORS

When making HTTP requests from your app code to your backend, you need to make sure that your backend allows those requests. Your app frontend code is hosted on [the Wix App CDN](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#the-wix-apps-cdn). The app is served from its own `wix.run` subdomain. To allow your app frontend code to make HTTP requests to your backend, you need to allow CORS requests from your frontend's domain.

Add the following headers to your backend's HTTP responses to allow CORS requests from your app.

Replace **\<your-app-id\>** with your app's ID. You can find it in your [app's dashboard](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fhome). Also, only allow the HTTP methods that your app requires.

```http
Access-Control-Allow-Origin: https://<your-app-id>.wix.run
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
```

To enable local development, you also need to allow CORS requests from `localhost:5173` or, preferably, from all origins with `localhost`.

```http
Access-Control-Allow-Origin: http://localhost:5173
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
```

### Authenticate incoming requests

Once you expose a backend API to make it available for your app, you need to make sure that requests to your API are coming from your app and not from malicious users.

For a detailed guide on how to do this, see [Authenticate Incoming Requests to Your Backend](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/authenticate-incoming-requests-to-your-self-hosted-backend).

#### Differentiating between multiple instances

As described in the guide above, when an app sends a request to your server it must include an instance string containing an **`instanceId`**, This is the unique ID of the current instance of your app, and can be used to differentiate between the multiple instances of your app when they make requests to the server.
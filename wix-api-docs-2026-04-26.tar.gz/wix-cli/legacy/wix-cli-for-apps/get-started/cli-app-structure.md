---
portal: wix-cli
name: "CLI App Structure"
type: ARTICLE_RESOURCE
resourceId: bdf77a93-c2d7-4c22-ba5a-24b64d5d683e
---

# CLI App Structure

# CLI App Structure

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

A Wix CLI App has the following file structure:

```tsx
.
└── <your-app-name>/
    ├── .wix/
    ├── dist/
    ├── node_modules/
    ├── src/
    │   ├── dashboard/
    │   ├── site/
    │   ├── backend/
    │   ├── assets/
    │   └── env.t.ds
    ├── .gitignore
    ├── .nvmrc
    ├── package.json
    ├── README.md
    ├── tsconfig.json
    └── wix.config.json

```

> **Note:** Some of these files and directories will not exist when you initially create your app. They are created when you [build your app](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli).

## .wix/

Contains configuration and log files related to the Wix environment.

<blockquote class="caution">

__Caution:__
This directory contains internal data. Don't edit it.

</blockquote>

## dist/

Contains a distributable version of the app. This directory and its contents are created automatically from your local project files when you [build your app](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli). 

Don't edit the files in this directory.

## src/

Source directory. It contains all the source code and core resources of your application.

### dashboard/

Contains subdirectories for each of your app's dashboard extensions. 

For more information, see [About CLI App Extensions](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions)

### site/

Contains subdirectories for each of your app's site extensions. 

For more information, see [About CLI App Extensions](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions)

### backend/

Contains subdirectories for each of your app's backend extensions. 

For more information, see [About CLI App Extensions](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions)

### assets/

A directory for storing static assets such as images and media files.

During the `build` process, the contents of this directory are renamed and copied to the `dist` directory.

To reference files from this directory in `.json` configuration files, use relative paths. For example, `{ "myImagePath": "../../assets/my-image.svg" }`.  
Likewise, to import files from this directory into your source code, use relative paths. For example, `import myImage from "../../assets/my-image.svg";`.

#### env.t.ds

TypeScript declaration file for environment variables. 

Don't edit this file.

#### .nvmrc

Contains the version of Node.js that this project uses. Use the `nvm use` command to switch to this defined version using Node Version Manager (NVM).

#### package.json

Holds various metadata relevant to the project. It manages the project's dependencies, scripts, and more.

#### tsconfig.json

Configuration for the TypeScript compiler.

#### wix.config.json

Defines basic information about your app, including `appId` and `projectId`. The `appId` is the same as your app ID in your [app's dashboard](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fhome), as shown here:

![appId](https://wixmp-833713b177cebf373f611808.wixmp.com/images/a1ba08281f01d53e0e22104a9c55d07c.png)
---
portal: wix-cli
name: "Integrate Existing Apps"
type: ARTICLE_RESOURCE
resourceId: 0ce8f58f-43b4-47e9-a1c1-15a994ab0a98
---

# Integrate Existing Apps

# Integrate with Existing Apps

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

The following diagram shows the overall flow for creating a CLI app. The steps in the red rectangle are covered in this article.

![Create and test an app](https://wixmp-833713b177cebf373f611808.wixmp.com/images/ee9d903ea1c3a6eab65a58c80922e06e.png)

You can use the Wix CLI for Apps to work with existing app versions in the [app dashboard](https://manage.wix.com/account/custom-apps). This allows you to add new features to your app using the CLI without having to migrate the entire app to your CLI project.

Because the Wix CLI for Apps is a new tool, it does not yet support all Wix App features. By working with both the app dashboard and the CLI you can continue to create and manage existing app extensions in the app dashboard, and benefit from the CLI’s capabilities.

Follow these steps to integrate your app with the CLI.

## Prerequisites

Before getting started, make sure you have the following set up:

+ [Node.js](https://nodejs.org/en/) (v20.11.0 or higher)
+ [A Wix Studio account](https://manage.wix.com/account/custom-apps).
+ An existing Wix App.

## Step 1 | Extend an existing app

To extend an existing app with a new Wix CLI for Apps project:

1. Run the following command:

    ```bash
    npm create @wix/app@latest
    ```

1. Choose **Extend existing application**.
1. Choose the app to extend.
1. Choose a package name for your project. The package name is the name of the package created locally for your project, and the name of the directory containing your project’s local files.

### What you get

Once the process is complete, you will have all the files for your app in a local directory with the package name you chose.

When working on the CLI extension project locally or in preview versions, you can only work with the app extensions that are registered in your CLI project. Other app extensions from your app's dashboard are still loaded into your development site where you can preview and test them, but they will use their production versions.

Changes to your extension’s local files will not be reflected in your app's dashboard until you create a new [app version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#app-versions-and-deployment).

For more information about the local files generated for your app, see [CLI App Structure](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/cli-app-structure).

## Step 2 | Test the app

Your app won't be active on your development site at this stage, however, you can preview and test it in a local development environment.

To set up a local development environment, use the following command:

```bash
npm run dev
```

To test your app, you will be asked to choose an existing site or create a [development site](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps#local-preview). You can use the CLI to open the different parts of your app on the development site in your browser.

## Next steps

After completing the above steps, you have integrated your existing app into a Wix CLI app that you can experiment with and test locally.

You can now:

+ [Add extensions to your app](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/supported-extensions/about-cli-app-extensions).
+ [Learn more about developing your app](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview).
+ [Prepare your app for production](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli).

# See also

+ [About the Wix CLI for apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps)
+ [CLI app structure](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/cli-app-structure)
+ [CLI Command Reference](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/command-reference)
---
portal: wix-cli
name: "About CLI App Extensions"
type: ARTICLE_RESOURCE
resourceId: 35a26853-9ea1-4413-ac17-e838b9584cba
---

# About CLI App Extensions

# About CLI App Extensions

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

Your app can add functionality to various parts of the Wix ecosystem, such as adding a page to a site's dashboard or injecting custom code into a site's DOM. Each specific type of functionality that an app can provide is called an extension. For general information about Wix app extensions, read [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions).

Wix CLI for apps supports multiple app extension [types](#supported-extension-types). The creation and setup process for extensions in the CLI takes place in the terminal. Then to edit your extensions, you write code directly in your CLI app project's files.

## Why create extensions in the CLI app

You can create app extensions in the app dashboard, however, there are several advantages to doing so in the CLI.

+ Streamlined, structured creation. When you create extensions using the generate command, you are prompted for any required details, and then the extension files are generated for you.
+ Additional features and customization. See the documentation for [supported extension types](#supported-extension-types) for details.
+ Local previews during development.
+ Your app and its extensions are hosted on Wix’s servers by default.

## Adding extensions

You can add extensions to your CLI app using the generate command:

```tsx
npm run generate
```

This command starts a process that guides you through adding an extension to your app. 

After selecting an extension, you’ll be prompted for the relevant configuration details. Your extension will then be generated in your app's local files.

Your extension's files are placed under the directory of its general extension type, such as `site` or `dashboard`. For example, `/src/site/<your-extension-name>` or `/src/dashboard/<your-extension-name>`.

## Supported extension types

CLI apps currently support the following extensions:

**Dashboard Extensions**
+ [Dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions-with-the-cli)
+ [Dashboard plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extension-with-the-cli)
+ [Dashboard menu plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions-with-the-cli)
+ [Dashboard modals](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions-with-the-cli)

**Site Extensions**
+ [Embedded scripts](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-cli)
+ [Site widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/custom-element-site-widgets/add-a-site-widget-extension-in-the-cli)
+ [Site plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/add-a-site-plugin-extension-in-the-cli)

**Backend Extensions**
+ [Web methods](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/web-methods/add-web-method-extensions-with-the-cli)
+ [API](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/api/add-api-extensions-with-the-cli)
+ [Events](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/events/add-event-extensions-with-the-cli)
+ [Service plugins](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/add-service-plugin-extensions-with-the-cli)

## Extensions not currently supported

Any extensions not listed above are currently unavailable in the CLI. Your app can still use these extensions, but they must be managed in the [app dashboard](https://manage.wix.com/account/custom-apps) and are not represented in your app's local files.

For more information about adding extensions in the app dashboard, see [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions).

## See also
- [Map your app's functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
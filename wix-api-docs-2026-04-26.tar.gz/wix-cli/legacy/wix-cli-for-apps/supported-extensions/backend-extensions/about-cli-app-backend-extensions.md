---
portal: wix-cli
name: "About CLI App Backend Extensions"
type: ARTICLE_RESOURCE
resourceId: 91990c23-8344-4cf7-886c-0b4fb183f39e
---

# About CLI App Backend Extensions

# About CLI App Backend Extensions

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

The Wix CLI allows you to add [backend extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/about-backend-extensions) to your app.

The following backend extensions are available in the CLI:

- [Service plugin extensions](#service-plugin-extensions).
- [API extensions](#api-extensions).
- [Event extensions](#event-extensions).

You can add these extensions using the `npm run generate` command.

All backend extensions built with the CLI have:

- **Logging functionality:** You can use the CLI to view logs from the backend of any version of your app. Read more about [logging](#logging).
- **Limits:** Backend extensions have execution limits, rate limits, and a time limit for backend functionality in previews. Read more about [limits](#limits).

## Service plugin extensions

Service plugin extensions (formerly SPIs) are a set of APIs defined by Wix that you can use to enable your app to inject custom logic into existing app flows or to introduce entirely new flows to Wix sites. You can implement service plugin extensions in your app using the CLI. Read more about [service plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/add-service-plugin-extensions-with-the-cli).

## API extensions

API extensions allow you to define functions that can be invoked from any frontend component in your CLI project. The CLI handles the setup and hosting of the backend code for you, simplifying the development process.

There are 2 types of API extensions:

- [Web method extensions](#web-methods)
- [HTTP function extensions](#http-functions)

### Web methods

Web method extensions allow you to define functions that you can call from your frontend code with type safety. You can declare and call web methods with direct imports from your frontend components.

Web method extensions require less boilerplate code than HTTP function extensions, as you don't have to manually extract values from a request, serialize responses, or handle HTTP headers and query parameters. Read more about [web method extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/web-methods/add-web-method-extensions-with-the-cli).

### HTTP functions

HTTP function extensions allow you to define HTTP functions that can be called from your frontend code using HTTP requests. Read more about [HTTP function extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/api/add-api-extensions-with-the-cli).

## Event extensions

Events are triggered when specific conditions on your app or a user’s site are met. Wix Apps can respond to these events using event extensions created in the CLI. Events in the CLI are built on Javascript SDK webhooks, and event extensions subscribe your app to these webhooks behind the scenes. Read more about [event extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/events/add-event-extensions-with-the-cli).

## Logging

You can use the CLI to view logs from the backend of any [version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#app-versions-and-deployment) of your app.

For instructions on how to do this, see [logs](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/command-reference#logs) in the CLI Command Reference.

## Limits

<blockquote class="important">

__Important:__
Limits are subject to change. We will notify you of any upcoming changes through the CLI and [Discord](https://discord.gg/aN9ubnrs2D), and note them here in the documentation.

</blockquote>

Backend extensions in the CLI have the following limits:

### Execution rate limits
- **1000 CPU MS per request** - Backend requests taking longer than 1000 CPU MS to complete are terminated.
- **20 sub-requests** - Sub-requests are requests made from your backend extensions, such as calls to Wix APIs, in response to a request. Your app can make up to 20 sub-requests in response to each request. Sub-requests beyond the 20th will not be made.

### Request rate limit
- **1000 requests per second** - This is the limit for the total number of backend requests from every instance of your app. Requests beyond this are ignored.

### Backend functionality for previews
Previews generated by `npm run preview` last indefinitely. However, any backend extensions in these previews stop functioning after 3 days.
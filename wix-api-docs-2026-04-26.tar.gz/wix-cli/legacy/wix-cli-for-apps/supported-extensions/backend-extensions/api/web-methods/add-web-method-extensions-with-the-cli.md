---
portal: wix-cli
name: "Add Web Method Extensions with the CLI"
type: ARTICLE_RESOURCE
resourceId: fd9f1ecd-68d0-4358-a237-a2dd60556533
---

# Add Web Method Extensions with the CLI

# Add Web Method Extensions with the Wix CLI for Apps

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>


[Web method extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/web-methods/about-web-method-extensions) in the CLI allow you to define functions in your app's backend that you can call from your frontend code.

Follow the instructions below to:

1. Create a web method extension for your app.
1. Try out the web method extension.
1. Deploy your app with the web method extension.

Once these tasks are complete, your app will have a web method extension with methods that can be called from your frontend code.

## Before you begin

+ You must have an app project that was [created using the Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/quick-start).
+ You must be logged into your Wix Studio account. If you don’t have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).

## Step 1 | Create the extension

In the terminal:

1. Run the following command in your project's repository.:

    ```tsx
    npm run generate -- --type=WEB_METHOD
    ```

1. The CLI displays a menu of extensions to generate.
1. The CLI prompts you to name the web method. You can only have one web method with a given name.

Upon completion, the web method extension file is created in your project directory with the following structure:

```tsx
.
└── <your-app-name>/
    └── src/
        └── backend/
            └── your-web-method.web.ts
```

The default code in this file creates a web method using the [Web Methods API](https://dev.wix.com/docs/sdk/core-modules/web-methods/introduction).

You can relocate this file to anywhere you want within the `src` directory. For example, if you have a dashboard page extension that calls your web methods, you may want to relocate the web methods extension file to the dashboard page's directory.

## Step 2 | Try out your web method extension

To try out your web method extension, call it from your frontend code:

1. Import the web method in your frontend component's code file using the following syntax:

    ```js
    import { yourWebMethodName } from '<path-to-your-web-methods-directory>/your-web-method-file.web';
    ```

1. Call the function in your frontend component and log the response to the console. For example, in a dashboard page extension's `.tsx` file, add the following code to the beginning of the component:

    ```js
    yourWebMethodName().then(result => console.log(result));
    ```

    Make sure that your web method returns a value that can be logged.

1. Start your local development environment:

    ```bash
    npm run dev
    ```

1. Open the extension with your frontend code. For example, if you added the code to a dashboard page extension, press `D` and select your dashboard page to open it in the browser.

1. Check the console output in your browser's developer tools to see the logged response.

## Step 3 | Build and deploy your app

Once your app is ready for production, you can build it and release a version in the app dashboard.

1. Run the following command to build your app:

    ```bash
    npm run build
    ```

2. Run the following command and follow the prompts to release an app version:

    ```bash
    npm run release
    ```

An app version allows you to publish an app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct install URL.

For more information about building and deploying your app, see [Build and Deploy an App with the CLI](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli).

## Delete a web method extension

To delete a web method from your app, delete the web method extension's file.
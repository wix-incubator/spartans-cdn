---
portal: wix-cli
name: "Add Service Plugin Extensions with the CLI"
type: ARTICLE_RESOURCE
resourceId: bb12234f-4332-4fcf-84f7-6049d169868a
---

# Add Service Plugin Extensions with the CLI

# Add Service Plugin Extensions with the Wix CLI for Apps

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>


[Service plugin extensions (formerly SPIs)](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions) are a set of APIs defined by Wix that you can use to enable your app to inject custom logic into existing app flows or to introduce entirely new flows to Wix sites.

You can implement service plugin extensions in your app using the CLI.

Follow the instructions below to:

1. Create a service plugin extension for your app.
1. Test your service plugin extension.

Once this task is complete, your app will have a service plugin extension with custom functions that Wix calls during a specific flow.

## Before you begin

+ You must have an app project that was [created using the Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/quick-start).
+ You must be logged into your Wix Studio account. If you don’t have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).

## Step 1 | Create the extension

In the terminal:

1. Navigate to your project repo.
1. Run the following command:

    ```tsx
    npm run generate -- --type=SERVICE_PLUGIN
    ```

1. The CLI will display a menu of extensions to generate.
1. The CLI will prompt you to select a service plugin from a list of available service plugins.
1. The CLI will prompt you to name your service plugin. This is the name of the folder in the project repo that contains the service plugin code, and the name of the plugin that appears in the app dashboard. Only you will see this name.

Upon completion, the extension files will be created in your project directory with the following structure:

```tsx
.
└── <your-app-name>/
    └── src/
        └── backend/
            └── service-plugins/
                └── <service-plugin-type>/
                    └── <your-service-plugin-name>
                        ├── plugin.ts
                        └── plugin.json
```

+ [**`plugin.ts`**](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code#plugints) - This file is required and contains handler functions that Wix calls automatically when the relevant site action triggers them. These functions are where you add your custom logic.
+ [**`plugin.json`**](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code#pluginjson) - This file is required and provides all required configuration for your plugin.

## Step 2 | Test your service plugin extension

To test your service plugin extension you must:

1. Add logging inside your backend logic.
2. Release a version with your changes.
3. Trigger the call to your service plugin.

Logging in the backend logic of service plugins can't be tested in the CLI's local development environment (`npm run dev`). Instead, you must trigger the service plugin from your development site on a deployed version (`npm run release`).

Your development site uses the latest version of your app. To ensure local changes are reflected in the app on your site, you must release a new version. You can view your [app versions](https://manage.wix.com/app-selector?title=Select+an+App&primaryButtonText=Select+Site&actionUrl=https%3A%2F%2Fdev.wix.com%2Fapps%2F%7BappId%7D%2Fversions-app) in the app dashboard.

### Add logging inside your backend logic

Inside your `plugin.ts` file, add a `console.log()` command to one of your functions. For example:

```tsx
import { shippingRates } from '@wix/ecom/service-plugins';

shippingRates.provideHandlers({
  getShippingRates: async ({ request, metadata }) => {
    console.log("Retrieved shipping rates.");
  }
});
```

### Release a version with your changes

1. Run the following command to build your app:

    ```bash
    npm run build
    ```

2. Run the following command and follow the prompts to release an app version:

    ```bash
    npm run release
    ```

For more information about building and deploying your app, see [Build and Deploy an App with the CLI](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli).

### Trigger the call to your service plugin

The process for triggering the call to your service plugins depends on the type of service plugin.

Follow these steps to navigate to your development site or its dashboard and trigger the call to the service plugin:

1. From your app's directory in the terminal, run the following command:

    ```tsx
    npm run logs -- --version <version>
    ```
    Replace `<version>` with the number of the version you released.
2. Go to [wix dashboard](https://manage.wix.com/) and open the site or dashboard you installed the app on.
3. Take an action that will trigger your service plugin call. The logs you set up will appear in the terminal.

## Delete a service plugin extension

To delete a service plugin extension from your app, delete the subfolder under `src/backend/service-plugins` that contains your service plugin extension's files.

> **Note**: If you've already [created a version](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/build-and-deploy-an-app-with-the-cli#step-3--create-an-app-version) of your app, deleting a service plugin's files from your project does not remove the service plugin from your app's latest version in the app dashboard. To remove the service plugin, create a new version after deleting the [service plugin's files](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code).
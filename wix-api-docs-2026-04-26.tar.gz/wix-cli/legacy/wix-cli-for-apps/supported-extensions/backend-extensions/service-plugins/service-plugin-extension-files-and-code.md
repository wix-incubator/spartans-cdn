---
portal: wix-cli
name: "Service Plugin Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: ab0a3c21-f66f-4d81-9f3d-ac31ed641495
---

# Service Plugin Extension Files and Code

# Service Plugin Extension Files and Code

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

Within your app project, the source code for service plugins is found in the `src/backend/service-plugins` folder.

Each page is defined in its own subfolder that contains two files:

+ **`plugin.ts`** - Contains functions that override the functions called by Wix for the plugin.
+ **`plugin.json`** - Provides all required configuration for your plugin.

## plugin.ts

This file is required and contains handler functions that Wix calls automatically when the relevant site action triggers them.

The file contains:

+ The relevant import statement for the plugin.
+ Empty placeholders for each of the functions where you can implement your logic.

For example, the `plugin.ts` for the shipping rates plugin looks like this:

```tsx
import { shippingRates } from '@wix/ecom/service-plugins';

shippingRates.provideHandlers({
  getShippingRates: async ({request, metadata}) => {
    // Add your code here.
  },
});
```

Your custom logic should be placed inside the `{}` for each of these functions. To find out what your function receives in the parameters and what it must return, see the documentation. Locate your service plugin in [this table](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#service-plugins) and click on the link to view its documentation, then navigate to the specific function in the menu.

## plugin.json

This file is required and provides all the necessary configuration for your plugin.

The file contains an object with each of the required fields you can use to customize your plugin. You will need to add any optional configuration fields yourself. 

You can find the details for each of these fields by locating your service plugin in [this table](https://dev.wix.com/docs/build-apps/get-started/overview/how-apps-extend-wix#service-plugins) and clicking on the link to view its documentation.

> **Note:** Your `plugin.json` file does not require a deployment URI as the CLI knows where to call your app's endpoint.
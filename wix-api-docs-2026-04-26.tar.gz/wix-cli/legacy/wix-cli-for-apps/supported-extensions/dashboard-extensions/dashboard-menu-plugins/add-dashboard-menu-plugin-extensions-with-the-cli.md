---
portal: wix-cli
name: "Add Dashboard Menu Plugin Extensions with the CLI"
type: ARTICLE_RESOURCE
resourceId: f3990feb-f71a-408e-8fc5-b17a2827a640
---

# Add Dashboard Menu Plugin Extensions with the CLI

# Add Dashboard Menu Plugin Extensions with the CLI

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

A dashboard menu plugin is an app extension that adds a menu item into a [pre-configured slot in a dashboard page](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) of an app made by Wix. When clicked, it either displays a dashboard modal or directs the site administrator to another dashboard page.

## Create a dashboard menu plugin extension with the CLI

Follow the instructions below to:

1. Create and configure a dashboard extension for a Wix CLI app.
2. Build and deploy your app.

Once this task is complete, the dashboard menu you specified in the installation process will contain the item you added.

### Before you begin

+ You must have an app project that was [created using the Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/quick-start).
+ You must be logged into your Wix Studio workspace. If you don’t already have one, [sign up for a Wix Studio workspace account](https://manage.wix.com/account/custom-apps).
+ Your site must already have installed the app you wish to extend.

### Step 1 | Create the extension

In your project directory, run the following command and follow the prompts to create a dashboard menu plugin extension:

```bash
npm run generate -- --type=DASHBOARD_MENU_PLUGIN
```

When the process is completed, you can find the extension files in the local app folder with the following structure:

```bash
src/
└── dashboard/
    └── menu-plugins/
        └── <your-menu-plugin-folder-name>/
            └── plugin.json/
```

Learn more about the [dashboard menu plugin extension file](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-menu-plugins/dashboard-menu-plugin-extension-files-and-code).

### Step 2 | Build and deploy your app

To make the extension available to your users, you must build your app and [release a new version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/build-and-deploy-an-app-with-the-cli#step-3--release-an-app-version) in the app dashboard. An app version allows you to publish an app to the [Wix App Market](https://www.wix.com/app-market) or install it on a site with a direct installation URL.

1. Run the following command to build your app:

  ```bash
  npm run build
  ```

2. Run the following command and follow the prompts to release a new app version in the app dashboard:

  ```bash
  npm run release
  ```

For more information about building and deploying your app, see [Build and Deploy an App with the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/build-and-deploy-an-app-with-the-cli).

## Delete a dashboard menu plugin

To delete an existing dashboard menu plugin from your app, navigate to `src/dashboard/menu-plugins` in your project's directory, and delete the subfolder that contains your [dashboard menu plugin's configuration file](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-menu-plugins/dashboard-menu-plugin-extension-files-and-code).

> **Note**: If you've already [released a version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/build-and-deploy-an-app-with-the-cli#step-3--release-an-app-version) of your app, deleting the dashboard menu plugin's files from your project does not remove the extension from your app's latest version in the app dashboard. To remove the dashboard menu plugin, [release a new version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/build-and-deploy-an-app-with-the-cli#step-3--release-an-app-version) after deleting the [dashboard menu plugin's configuration file](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/dashboard-extensions/dashboard-menu-plugins/dashboard-menu-plugin-extension-files-and-code#extension-configuration-metadata-pluginjson).

## Templates and Tutorials

Check out the following resources to learn more about using this extension:

+ [Create an App with Wix CLI](https://dev.wix.com/docs/build-apps/get-started/quick-start/create-an-app-with-wix-cli)

## See also

- [Tutorial | Set Up an App With the CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-set-up-an-app-with-the-cli)
- [Tutorial | Build a Locations App Using the Wix CLI](https://dev.wix.com/docs/build-apps/get-started/tutorials/tutorial-build-a-locations-app-with-the-cli#tutorial--build-a-locations-app-using-the-wix-cli)
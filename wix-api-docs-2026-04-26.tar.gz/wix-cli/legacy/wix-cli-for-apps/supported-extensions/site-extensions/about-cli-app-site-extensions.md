---
portal: wix-cli
name: "About CLI App Site Extensions"
type: ARTICLE_RESOURCE
resourceId: 960594f4-4364-4f79-92c9-2ef4ba0b5da5
---

# About CLI App Site Extensions

# About CLI App Site Extensions

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

The Wix CLI allows you to add [site extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/about-site-extensions) to your app.

The following site extensions are available in the CLI:

- [Site plugin extensions](#site-plugin-extensions)
- [Site widget extensions](#site-widget-extensions)
- [Embedded script extensions](#embedded-script-extensions)

You can add these extensions using the `npm run generate` command.

## Site plugin extensions

With site plugins, you can create interactive and feature-rich widgets that seamlessly integrate into Wix’s [business solutions](https://support.wix.com/en/business-solutions-apps) such as Wix Stores and Wix Bookings, extending their functionality and user experience. You can implement site plugin extensions in your app using the CLI. Read more about [site plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/add-a-site-plugin-extension-in-the-cli).

## Site widget extensions

Site widgets are draggable UI components that Wix site owners can add to pages on their website. They enhance a site's functionality by displaying content or enabling site visitors to perform various tasks. When working in the site editor, site owners can adjust the size of the widget, reposition it, and customize it using its settings panel.

The CLI provides two kinds of site widget extensions that you can implement in your app: custom element site widget extensions, and Blocks site widget extensions.

### Custom element site widgets

Custom element site widgets extensions are built in the CLI with [custom element](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements) technology. The custom element is a new HTML tag that you define in local code files. The custom element is made available in the Wix editors as a widget. 

Use the custom element site widget extension if you want to design your widget entirely with code, or you want to keep your development entirely within the CLI.

[Add a custom element site widget extension in the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/custom-element-site-widgets/add-a-site-widget-extension-in-the-cli).

### Blocks site widgets

<blockquote class="important">

**Important:** Blocks site widget extensions use the Blocks-CLI integration, which only works with the Wix CLI for Apps. We're introducing a [unified Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), which we recommend for developing apps and headless projects. The unified Wix CLI doesn't support this integration.

</blockquote>

Blocks site widget extensions are created with a hybrid development workflow that combines the visual design capabilities of [Wix Blocks](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/about-wix-blocks) with the CLI development environment. Read more about the [Blocks-CLI integration](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/code-in-blocks/about-the-blocks-cli-integration).

This extension allows you to use the drag-and-drop Blocks Editor and Wix-native elements to effortlessly design your widget's UI. You can sync your design in the Blocks editor to the CLI in one click, automatically creating code files for your widget and its panels. You can then develop your widget's logic in these code files in your local IDE.

Any changes synced from the Blocks Editor or made in your local code files are immediately reflected in your test site and editor in your local development environment.

Use the Blocks element site widget extension if you want to take advantage of the visual design capabilities of Blocks, or if you want to separate your design and coding concerns.

[Add a Blocks site widget extension in the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/add-a-blocks-site-widget-extension-in-the-cli).

## Embedded script extensions

An embedded script is an app extension that injects an HTML code fragment into the DOM of a site. You can implement an embedded script extension in your app using the CLI. Read more about [embedded script extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/about-embedded-scripts-and-the-cli).
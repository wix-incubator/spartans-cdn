---
portal: wix-cli
name: "Panel Files and Code"
type: ARTICLE_RESOURCE
resourceId: 8ba6f36a-80fd-4cfe-9d98-21906ca21f13
---

# Panel Files and Code

# Files and Code for Blocks Site Widget Panels

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 
  
</blockquote>

<blockquote class="important">

**Important:** The Blocks-CLI integration only works with the [Wix CLI for Apps](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/about-the-wix-cli-for-apps). The new [Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli), which is the recommended tool for new app projects, doesn’t support this integration.

</blockquote>

When you [add a Blocks site widget extension](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/add-a-blocks-site-widget-extension-in-the-cli) to your CLI project, the CLI generates the directory structure described in [Files and Code for Blocks Site Widgets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/widget-files-and-code).

When you add [panels](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/about-panels-in-blocks) to your widget in the Blocks editor and sync to the CLI, a `panels` directory is created inside your widget’s directory. `panels` contains subdirectories for each panel you added in Blocks. These subdirectories each contain the following files:

+ A `panel.json` file that contains the ID of your panel. Do not modify this file.
+ A [`panel.ts`](#panelts) file that contains the logic for your panel.

For example:

```tsx
.
└── <your-app-name>/
    └── src/
        └── site/
            └── widgets/
                └── blocks/
                    └── <your-widget-name>/
                        ├── panels/
                        │   └── <your-panel-name>/
                        │       ├── panel.json
                        │       └── panel.ts
                        ├── api.ts
                        ├── widget.json
                        └── widget.ts
```


## panel.ts

When you [add a Blocks site widget extension in the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/blocks-site-widgets/add-a-blocks-site-widget-extension-in-the-cli), a `panel.ts` file is generated for each of the widget’s custom panels. These `panel.ts` files contain the code for their associated panels. 

When the `panel.ts` file is generated, it looks like this:

```tsx
import {definePanel} from '@wix/blocks';
import wixEditor from '@wix/editor'; //The Widget API enables you to get and set the properties and design presets of a site widget

export default definePanel(<your-panel-id>, ($w) => {
  $w.onReady(() => {
    // Initialize the panel element values according to your widget's properties.
    // Add event handlers for panel elements to update your widget's properties whenever a user interacts with the panel.
    console.log("Panel is ready");
  });
});
```

### definePanel()

`definePanel()` accepts a function that will execute when your panel is added to a site. This function accepts the `$w` namespace as a parameter, allowing you to work with it in your code:

#### $w

[`$w`](https://dev.wix.com/docs/velo/velo-only-apis/$w/introduction) contains everything you need in order to work with your panel's components. It allows you to select elements in your panel and interact with them. Each element type exposes properties and functions that you use to enhance the functionality of your panel.

Custom panels use [specific elements](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/panel-elements-in-blocks#panel-elements), which are designated only for panels.

##### $w.onReady()

[`$w.onReady()`](https://dev.wix.com/docs/velo/velo-only-apis/$w/on-ready) is called when all page elements have finished loading.

Place your panel initialization logic inside the `$w.onReady` function.

#### Wix Javascript SDK

In the panel’s code, use Wix's [JavaScript SDK](https://dev.wix.com/docs/sdk) to [access widget properties](https://dev.wix.com/docs/sdk/host-modules/editor/widget/introduction) and [retrieve environmental data from the editor](https://dev.wix.com/docs/sdk/host-modules/editor/info/introduction), as well as access and manage Wix business solutions.

Use [`getProp()`](https://dev.wix.com/docs/sdk/host-modules/editor/widget/get-prop) to get properties from your widget and use them to set initial values for your panel’s elements.
To apply changes made in the custom panel to the widget, use the [`setProp()`](https://dev.wix.com/docs/sdk/host-modules/editor/widget/set-prop) function. 

##### Example:

```ts
import { definePanel } from "@wix/blocks";
import { widget } from "@wix/editor";

export default definePanel("c8e41d4e-2c58-40a1-8cc9-ead2d496bfc8", ($w) => {
  // This function runs when the panel is ready
  $w.onReady(() => {
    console.log("Panel is ready");
  });

  // Add an event listener for changes to the toggle switch
  $w("#panelToggleSwitch1").onChange(async () => {
    // Get the current value of the "saleIndicator" property
    const prop = await widget.getProp("saleIndicator");
    // Toggle the value of the "saleIndicator" property
    if (prop === "Sale") {
      await widget.setProp("saleIndicator", "No Sale");
    } else {
      await widget.setProp("saleIndicator", "Sale");
    }
  });
});

```

<!-- 
Use [`getDesignPreset()`](https://github.com/wix-private/developer-docs/blob/4d8ff861ea5a2b28d60f7b275dfca09cead74045/build-apps-portal/develop-your-app/frameworks/cli/supported-extensions/site-extensions/site-widgets) and [`setDesignPreset()`](https://github.com/wix-private/developer-docs/blob/4d8ff861ea5a2b28d60f7b275dfca09cead74045/build-apps-portal/develop-your-app/frameworks/cli/supported-extensions/site-extensions/site-widgets) to get and set information on your widget’s current preset. 


See an example of how to [interact with widget design presets](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-blocks/editor-experience-panels/add-code-to-custom-panels-in-blocks#interact-with-widget-design-presets).

-->
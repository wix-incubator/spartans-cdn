---
portal: wix-cli
name: "About Embedded Scripts and the CLI"
type: ARTICLE_RESOURCE
resourceId: 59959ed7-bc73-4433-8c5e-c90e0965384d
---

# About Embedded Scripts and the CLI

# About Embedded Scripts and the CLI

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>


The Wix CLI makes it easy to create and develop embedded script extensions.

For general information about this extension type, read [About Embedded Scripts](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/site-extensions/embedded-scripts/about-embedded-scripts).

## Why create an embedded script extension with the CLI

The Wix CLI simplifies setup, testing, and deployment for embedded script extensions.

+ **Single-command setup** - Generate an embedded script extension in your app with one command.
+ **Easy, early testing** - Test the embedded script extension on a development site before building an app. You can specify values for dynamic parameters to use during testing.
+ **Use local files** - Reference any file in your app's directory from your HTML code with a relative link — no need for external hosting or CORS handling.
+ **Simple embedding** - Offload the responsibility for embedding the script to the user, avoiding complex authentication procedures.

## Templates and tutorials

+ Learn how to [add embedded script extensions with the CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/add-embedded-script-extensions-with-the-cli)

The following embedded script CLI app templates are available:

+ [Mixpanel Analytics](https://dev.wix.com/apps-templates/template?id=c442b755-2276-4336-918a-915865a9fa2b) - Embed Mixpanel's tracking code directly onto the DOMs of sites.
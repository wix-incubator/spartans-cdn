---
portal: wix-cli
name: "Embedded Script Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: 2fda1fc6-5bf2-4864-9155-48c88e825ca0
---

# Embedded Script Extension Files and Code

# Embedded Script Extension Files and Code

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

The structure of an embedded script extension in a CLI app is as follows:

  ```tsx
  .
  └── <your-app-name>/
      └── src/
          └── site/
              └── embedded-scripts/
                  └── <your-script-name>/
                      ├── embedded.html
                      ├── embedded.json
                      └── params.dev.json
  ```

These files can be generated in your app by running the following command and selecting **Embedded Script extension**:

```tsx
npm run generate
```

## embedded.html

The file named `embedded.html` contains the code you wish to inject. Your code will be added to the page's head or body depending on your configuration.

In your HTML code, you can:
- [Reference local files](#referencing-local-files-in-your-html-code)
- [Use dynamic parameters](#using-dynamic-parameters-in-your-html-code)
- [Add global CSS](#adding-global-css-to-your-html-code)

### Referencing local files in your HTML code

Wix will host and deploy every file in your project unless you specify otherwise, including any that you add. Your HTML code can reference these files using a relative path.

When referencing local files in a `<script>` tag, the tag needs to have `type="module"`.

For example, to reference a file named `local-script.js` in the same directory as `embedded.html`, use the following code:

  ```tsx
  <script type = "module" src = "./local-script.js"></script>
  ```
>**Note:** TypeScript files are supported.

### Using dynamic parameters in your HTML code

Dynamic parameters are placeholders in your code that allow for the injection of custom information specific to each site where the code is deployed.

Dynamic parameters must:

* Be strings.
* Contain only alphanumeric characters (no special characters or spaces).
* Be wrapped in double curly braces (`{{`).
* Be enclosed in quotes (`"`) to prevent code evaluation.
* Be declared via the Embedded Scripts API as explained in [preparing your app for production](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/add-embedded-script-extensions-with-the-cli#step-2--prepare-your-app-for-production).

For example, the following code contains the dynamic parameters `googleTag` and `userName`:

  ```tsx
  <meta name = "google-tag" id = "{{googleTag}}"></meta>
  <script> console.log("Hello {{userName}} from the CLI.");</script>
  ```
See [below](#paramsdevjson) how to specify dynamic parameter values to use during development.

### Adding global CSS to your HTML code

You can add CSS directly to your `embedded.html` file, or you can reference a CSS stylesheet with a link. For example:

  ```tsx
  <link rel="stylesheet" href="./your-css-file.css"/>
  ```

This CSS applies to your site globally. For example, the following code would make the background of every page of your site red:

  ```tsx
  #tuckg {
    background: red;
  }
  ```

## embedded.json

This file contains information about your script, and must have the following structure:

  ```tsx
  {
    "id": "1347ffed-668c-4133-9d90-510f58f02c33",
    "name": "console-logger",
    "scriptType": "FUNCTIONAL",
    "placement": "HEAD"
  }
  ```

| Field          | Type   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|----------------|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `id`           | string | A unique identifier for your script. This is a randomly generated GUID.                                                                                                                                                                                                                                                                                                                                                                                   |
| `name`         | string | The name of your script as it will appear in your [app's dashboard](https://manage.wix.com/account/custom-apps). It can only contain letters and the hyphen (-) character. A descriptive name will help you identify your embedded script in your Extensions page.                                                                                                                                                                                           |
| `scriptType`   | enum   | An enum used by consent management apps to determine whether site visitors consent to having your script run during their visit. Possible values are: <ul><li>`"ESSENTIAL"`: Enables site visitors to move around the site and use essential features like secure and private areas crucial to the functioning of the site.</li><li>`"FUNCTIONAL"`: Remembers choices site visitors make to improve their experience, such as language.</li><li>`"ANALYTICS"`: Provides statistics to the site owner on how visitors use the site, such as which pages they visit. This helps improve the site by identifying errors and performance issues.</li><li>`"ADVERTISING"`: Provides visitor information to the site owner to help market their products, such as data on the impact of marketing campaigns, re-targeted advertising, and so on.</li></ul>**About types**<br>An embedded script must have a type. If your script falls into more than one type, choose the option closest to the bottom of the list above. For example, if your script has **Advertising** and **Analytics** aspects, choose **Advertising** as its type. It's unlikely that you'll need to mark it as **Essential**. |
| `placement`    | enum   | An enum indicating where in the page's DOM the HTML code will be injected. Possible values are: <ul><li>`"HEAD"`: Injects the code between the page's `<head>` and `</head>` tags.</li><li>`"BODY_START"`: Injects the code immediately after the page's opening `<body>` tag.</li><li>`"BODY_END"`: Injects the code immediately before the page's closing `</body>` tag.</li></ul>                                                                             |

 
## params.dev.json

This file specifies dynamic parameter values to use during development.

In production, dynamic parameter values are set after installation by embedding the script as explained in [Add an Embedded Script Extension Using the Wix CLI](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/embedded-scripts/add-embedded-script-extensions-with-the-cli#step-2--prepare-your-app-for-production).

This file includes an object containing key-value pairs for each of your dynamic parameters.

For example, the code:

```tsx
<script> console.log("Hello {{userName}} from the CLI. Your Google Tag ID is: {{googleTagId}}."); </script>
```

Requires a params.dev.json file in the following format:

```tsx
{
  "userName": "Jerry",
  "googleTagId": "GT-XXXXXXXXX"
}
```

Make sure the keys are the dynamic parameter names in quotes. The values will be assigned to the parameters when testing your script.
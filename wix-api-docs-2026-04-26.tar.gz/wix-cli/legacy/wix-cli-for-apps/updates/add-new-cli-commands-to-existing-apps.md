---
portal: wix-cli
name: "Add New CLI Commands to Existing Apps"
type: ARTICLE_RESOURCE
resourceId: e01fc75c-4c7d-4718-baaa-a9b2f332f784
---

# Add New CLI Commands to Existing Apps

# Add New CLI Commands to Existing Apps

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

When a new command is introduced to the CLI, it enhances the functionality and capabilities available for app development. 
However, it's important to note that apps created before the release of the new command will not automatically have it integrated into their environments. 
Instead, you need to add the new command to your `package.json` file manually in order to utilize it.

Failure to update the `package.json` with the new command will result in errors when you attempt to use the new command.

## Adding a new command

1. Identify the new command from the [CLI Command Reference](https://dev.wix.com/docs/wix-cli/legacy/wix-cli-for-apps/app-development/command-reference).
2. Open your project and locate the `package.json`. This file contains all the dependencies and configurations for your app.
> **Note**: Your app's file structure is documented in [CLI App Structure](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/get-started/cli-app-structure).
3. Under the `scripts` section in the `package.json` file, add the command and a name as a key:value pair.
For example:

   ```json
   "scripts": {
       ...
       "release": "wix app release",  
       ...
   }
   ```

4. Save your changes.
5. Ensure you are using the [latest version](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/app-development/development-overview#keeping-the-cli-up-to-date) of the CLI before using the new command.
---
portal: wix-cli
name: "Site Plugins: Logo URL Path Change"
type: ARTICLE_RESOURCE
resourceId: f7028211-85a0-4b6b-8ff6-2a5b521dee06
---

# PUBLIC_URL Is No Longer Supported

# Site Plugins: Logo URL Path Change

<blockquote classname="note">

**CLI Documentation Notice**

We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Apps. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses). 

</blockquote>

<blockquote class="important">

__Important:__
Perform this migration if you are using `{{PUBLIC_URL}}` in a site plugin's [plugin.json](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/site-plugin-extension-files-and-code#pluginjson)

</blockquote>

[Site plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/add-a-site-plugin-extension-in-the-cli) may provide an image file to use as the plugin's logo in the plugin explorer in the editor. In previous versions of the CLI, this image file was stored in your app's `public` directory, and the path to it was specified in the extension's `plugin.json` using `{{PUBLIC_URL}}`. This configuration is no longer supported.

If you use `{{PUBLIC_URL}}` in a site plugin extension's [`plugin.json`](https://dev.wix.com/docs/build-apps/develop-your-app/frameworks/wix-cli/supported-extensions/site-extensions/site-plugins/site-plugin-extension-files-and-code#pluginjson), you get the following error when you attempt to build your app:

```json
✖ Invalid configuration found at
`src/site/plugins/custom-elements/<your-site-plugin-name>/plugin.json`:
The following errors were found:
- `marketData.logoUrl`: `{{PUBLIC_URL}}` is no longer supported, please update
 `marketData.logoUrl` to a relative path.
```

If you get this error, perform the migration explained below.

## Migration process

1. Move the logo file from `public` to `src/assets`.
2. Update the value of `logoUrl` in your `plugin.json` file to reflect the relative path from your `plugin.json` to the logo file's new location in `src/assets`.
3. Save and commit your changes. You should now be able to build your app.

### Example

The following example shows an app before migration, details the migration process, then shows how the app looks after migration.

#### Before migration

##### Folder structure:

```json
.
├── public/
│   └── logo.svg
└── src/
    └── site/
        └── plugins/
            └── custom-elements/
                └── my-plugin/
                    └── plugin.json
```

##### plugin.json

```json
plugin.json:
{
  "$schema": "https://dev.wix.com/wix-cli/schemas/site-plugin.json",
  "id": "bcc537ca-9313-4c55-95b1-cb6ec19367c5",
  "referenceComponentId": "9abd6c0f-6159-48f2-8823-b80f360d4388",
  "marketData": {
    "name": "My Site Plugin",
    "logoUrl": "{{PUBLIC_URL}}/logo.svg"
  },
  "placements": [
    {
      "appDefinitionId": "13d21c63-b5ec-5912-8397-c3a5ddb27a97",
      "widgetId": "a91a0543-d4bd-4e6b-b315-9410aa27bcde",
      "slotId": "slot1"
    }
  ],
  "installation": {
    "autoAddToSite": true
  }
}
```

#### Migration process

1. Move `logo.svg` from `public/` to `src/assets/`.

2. Change `logoUrl` in the `plugin.json` to `../../../../assets/logo.svg`

#### After migration

##### Folder structure

```json
.
└── src/
    ├── assets/
    │   └── logo.svg
    └── site/
        └── plugins/
            └── custom-elements/
                └── my-plugin/
                    └── plugin.json
```

##### plugin.json

```json
plugin.json:
{
  "$schema": "https://dev.wix.com/wix-cli/schemas/site-plugin.json",
  "id": "bcc537ca-9313-4c55-95b1-cb6ec19367c5",
  "referenceComponentId": "9abd6c0f-6159-48f2-8823-b80f360d4388",
  "marketData": {
    "name": "My Site Plugin",
    "logoUrl": "../../../../assets/logo.svg"
  },
  "placements": [
    {
      "appDefinitionId": "13d21c63-b5ec-5912-8397-c3a5ddb27a97",
      "widgetId": "a91a0543-d4bd-4e6b-b315-9410aa27bcde",
      "slotId": "slot1"
    }
  ],
  "installation": {
    "autoAddToSite": true
  }
}
```
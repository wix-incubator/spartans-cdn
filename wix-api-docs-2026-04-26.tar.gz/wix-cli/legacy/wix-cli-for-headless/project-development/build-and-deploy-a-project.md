---
portal: wix-cli
name: "Build and Deploy a Project"
type: ARTICLE_RESOURCE
resourceId: 4d900ea1-17cc-41b5-881c-5eed34380048
---

# Build and Deploy a Project with the Wix CLI for Headless

# Build and Deploy a Project with the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


After developing and testing your Wix CLI for Headless project locally, you can take it to production. This article guides you through that process.

## Before you begin

Before getting started, make sure that:

+ You have [Node.js](https://nodejs.org/en/) (v20.11.0 or higher).
+ You're logged into your Wix account. If you don't already have one, [sign up for a Wix account](https://manage.wix.com/account/custom-apps).
+ You have a Wix CLI for Headless project. For instructions on creating a project, see [Quick Start](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).

## Step 1 | Build the project

Run the following command to build the assets for your project:

```bash
npm run build
```

## Step 2 (optional) | Create preview URLs

A preview URL is a link you can share with team members that allows them to preview and test your project's site and dashboard. Each preview URL directs to a unique version of your project hosted on Wix's servers. Subsequent updates to your project won't affect any previously created versions.

To push your project to Wix's servers for hosting and create preview URLs, run the following command:

```bash
npm run preview
```

This returns unique URLs linking to preview versions of your site and dashboard that you can share with others.

## Step 3 | Release your project

Now that you've built your project, it's time to release. Releasing pushes your project to Wix's servers and publishes your site.

To release a version, run the following command and follow the prompts:

```bash
npm run release
```

After releasing your project, the CLI provides preview URLs for your project's site and dashboard, and the URL of your published site.

## Next steps

You now have a fully working headless project with a publicly accessible frontend site.

Use the following resources to continue building your project:

+ [Add extensions to your project](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/about-app-extensions-in-the-wix-cli-for-headless).
+ [Learn more about how to develop your project](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/wix-cli-for-headless-development-overview).
+ [Learn about the project structure](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-project-structure).
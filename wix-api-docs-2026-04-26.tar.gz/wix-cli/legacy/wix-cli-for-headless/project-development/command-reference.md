---
portal: wix-cli
name: "Command Reference"
type: ARTICLE_RESOURCE
resourceId: f1878f50-6f49-471a-9d55-cc7dc983d537
---

# Wix CLI for Headless Commands

# Wix CLI for Headless Commands

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


This article documents the CLI commands for building Wix Headless projects.

For a detailed explanation of the process and how to initially create a project, see our [Quick Start article](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).

## Command overview

| Category         | Command      | Description                                                  |
|------------------|-------------|--------------------------------------------------------------|
| CLI for Headless | [create](#create)     | Creates a new Wix headless project.                          |
|                  | [dev](#dev)         | Starts a local development environment that serves your project. |
|                  | [build](#build)       | Builds your project.                                         |
|                  | [generate](#generate)    | Generates an extension for your project.                     |
|                  | [preview](#preview)     | Creates an online preview of your built project.             |
|                  | [release](#release)     | Starts a process that guides you through releasing your project. |
|                  | [env](#env)         | Work with environment variables.                             |
| Global CLI       | [login](#login)       | Logs in to your Wix account.                                  |
|                  | [logout](#logout)      | Logs out of your Wix account.                                 |
|                  | [telemetry](#telemetry)   | Opts in or out of sending anonymous usage information (telemetry) to Wix.    |
|                  | [whoami](#whoami)      | Displays the email address of the logged-in Wix user.         |

## create

Creates a new Wix Headless project. This command guides you through the process of setting up a new headless project, allowing you to choose from available templates.

```bash
npm create @wix/headless-site@latest
```

Once completed, your headless project will appear in your [Wix sites list](https://manage.wix.com/account/custom-apps) and the project files will be created in a local directory.

> **Note:** This setup also initializes useful headless settings for your project, such as adding allowed redirect domains and setting a Wix Pages domain.

## dev

Starts a local development environment that serves your project. Follow the prompts to open the site or dashboard of your project in the local development environment in your browser.

The development environment is set up for hot reloading, so any changes you make to your code are immediately reflected in the browser.

```bash
wix dev [options]
```

### Options

| Option                | Description                                                        |
|---------------------|--------------------------------------------------------------------|
| `--port <port>`     | Specify which port to run on. Defaults to 4321.                    |
| `--allowed-hosts <allowedHosts>` | Specify a comma-separated list of allowed hosts or allow any hostname. |

## build

Builds your project.

You must build your project before:

* Releasing your project.
* Previewing your project.

```bash
wix build
```

## generate

Starts a process that guides you through adding an extension to your project. After selecting an extension you are prompted for relevant configuration details, then your extension is generated in your project's local files.

```bash
wix generate
```

## preview

Creates an online preview of your built project and provides a preview URL in the console. By default, the code for your preview is hosted on Wix's servers.

```bash
wix preview
```

## release

Starts a process that guides you through releasing your project. Releasing pushes your project to Wix's servers and publishes your site. After releasing your project, the CLI provides preview URLs for your project's site and dashboard, and the URL of your published site.

```bash
wix release
```

## env

Work with environment variables. Your environment variables are stored locally in your project's `.env.local` file, and remotely on Wix's servers.

### env set

Sets an environment variable on Wix's servers.

```bash
wix env set [options]
```

#### Options

| Option                | Description                |
|---------------------|----------------------------|
| `--key <key>`       | Name of the variable.      |
| `--value <value>`   | Value of the variable.     |

#### Example

```bash
npm run env set -- --key exampleKey --value exampleValue
```

### env remove

Removes an environment variable from Wix's servers.

```bash
wix env remove [options]
```

#### Options

| Option                | Description                |
|---------------------|----------------------------|
| `--key <key>`       | Name of the variable.      |

#### Example

```bash
npm run env env remove -- --key exampleKey
```

### env pull

Pulls all your environment variables from Wix's servers and merges them into the `.env.local` file.

```bash
wix env pull
```

## login

Logs in to your Wix account.

```bash
wix login
```

## logout

Logs out of your Wix account.

> **Note:** To switch to another Wix account:
>1. Run `wix logout`.
>2. Run `wix login`, then click the link provided.
>3. Click **Log in with another account**.

```bash
wix logout
```

## telemetry

Opts in or out of sending anonymous usage information (telemetry) to Wix.

```bash
wix telemetry [on | off]
```

## whoami

Displays the email address of the logged-in Wix user. 

```bash
wix whoami
```
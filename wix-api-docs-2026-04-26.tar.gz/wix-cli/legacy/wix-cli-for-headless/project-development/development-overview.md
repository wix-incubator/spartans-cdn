---
portal: wix-cli
name: "Development Overview"
type: ARTICLE_RESOURCE
resourceId: ffc59bb6-d633-4f4e-b2f2-db7033fa216d
---

# Wix CLI for Headless Development Overview

# Wix CLI for Headless Development Overview

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>

<blockquote class="caution"> 
This feature is in Developer Preview and is subject to change.
</blockquote>

This article gives an overview of the methodologies for developing a project that you [created using the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).

## Understanding your project

After setting up a CLI for Headless project, your files will follow the structure described in [CLI Project Structure](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-project-structure).

To understand and modify your project's code, you should be familiar with the following:

- **Wix Headless projects**: Learn about building [headless projects](https://dev.wix.com/docs/go-headless/get-started/about-headless/about-wix-headless) with Wix.
- **Astro**: Learn about the [Astro](https://astro.build/) web framework used to build your headless project's frontend. Astro also provides support for backend development, including [Actions](https://docs.astro.build/en/guides/actions/) for type-safe backend functions, and [Endpoints](https://docs.astro.build/en/guides/endpoints/) for creating custom API endpoints.

## Working with Wix APIs

As you build your project, you may need to interact with Wix APIs to get information about the site your project is installed on, or to access Wix business solutions.

To call Wix APIs you use:

- The [Wix JavaScript SDK](https://dev.wix.com/docs/sdk/articles/get-started/about-the-wix-java-script-sdk)
- The [Wix REST API](https://dev.wix.com/docs/rest)

The SDK is the preferred method of consuming Wix APIs because Wix handles authentication for you.

## Adding extensions

You can add various extensions to your project's [private app](https://dev.wix.com/docs/go-headless/cli-for-headless/about-the-wix-cli-for-headless#wix-private-app-and-extensions) to extend the functionality of your project using the following command:

```bash
npm run generate
```

This command starts a process that guides you through adding an extension to your project. 

After you select an extension, you're prompted for relevant configuration details, then your extension code is generated in your project's local files.

You can use any framework you want for developing this app's extensions, but if you want to use the [Wix Design System](https://www.wixdesignsystem.com/) to give your extensions the look and feel of Wix, you must use React.

Read more about [CLI for Headless extensions](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/about-app-extensions-in-the-wix-cli-for-headless).

## Development and testing

As you work locally with the CLI, you can use the CLI to open the local version of your project's site or dashboard in your browser.

To do so, run the following command and select the part of your project to view.

```bash
npm run dev
```

This opens a local development environment in your browser. This environment is set up for hot reloading, so any changes you make to your code are immediately reflected in the browser.

## Building, previewing, and releasing a project

Before deploying a project, you need to [build it](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless). 

You can then:

- **Create preview URLs**: A preview URL is a link you can share with team members that allows them to preview and test your project's site and dashboard. Each preview URL directs to a unique version of your project hosted on Wix's servers. Subsequent updates to your project won't affect any previously created versions.
- **Release your project**: Releasing pushes the code for your project to Wix's servers and publishes your site. After releasing your project, the CLI provides preview URLs for your project's site and dashboard, and the URL of your published site.

This process is documented in [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless).

## See also

- [CLI for Headless Command Reference](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/wix-cli-for-headless-commands)

<!-- + [Integrate Your Own Backend](https://github.com/wix-private/developer-docs/blob/4d8ff861ea5a2b28d60f7b275dfca09cead74045/headless-docs/cli/project-development/TODO: add link if relevant for Headless*original::TODO: add link if relevant for Headless) -->
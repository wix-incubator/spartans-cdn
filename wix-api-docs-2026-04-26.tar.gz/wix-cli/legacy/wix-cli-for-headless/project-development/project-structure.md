---
portal: wix-cli
name: "Project Structure"
type: ARTICLE_RESOURCE
resourceId: b2486cc9-6bcf-47cf-b163-1dd09b25a7f2
---

# Wix CLI for Headless Project Structure

# Wix CLI for Headless Project Structure

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>

<blockquote class="caution"> 
This feature is in Developer Preview and is subject to change.
</blockquote>

This article describes the structure of a Wix CLI for Headless project created using the [Blank Astro template](https://github.com/wix/headless-templates/tree/main/astro/blank). If you're using a different template, your file structure will contain different files, but the general structure will be the same.

A Wix CLI for Headless project is built on top of Astro, so it follows the standard [Astro project structure](https://docs.astro.build/en/basics/project-structure/) with additional Wix-specific files and directories for extensions and configuration.

## Project file structure

```text
.
├── .astro/
├── .wix/
├── dist/
├── public/
├── src/
│   ├── assets/
│   ├── components/
│   ├── extensions/
│   ├── layouts/
│   └── pages/
├── astro.config.mjs
├── .env.local
├── package-lock.json
├── package.json
├── tsconfig.json
├── wix.config.json
└── .gitignore
```

> **Note:** Some of these files and directories don't exist when you initially create your project. They're created when you add extensions, and when you build or run your project.

## .astro/
Astro build and type files. Managed by Astro.

## .wix/
Contains configuration and log files related to the Wix environment. 

<blockquote class="caution">

__Caution:__
This directory contains internal data. Don't edit it.

</blockquote>

## dist/
Contains the production build output of your project. This directory is created automatically when you build your project. You generally don't need to edit files here.

## node_modules/

## public/
Static files served at the root of your site.

## src/
Source directory. Contains all the source code and core resources of your application.

### assets/
A directory for storing static assets such as images and media files.

### components/
Reusable UI components for your frontend.

### extensions/
Contains your project's extensions. Each extension has its own subdirectory here. For more information, see [About CLI Headless Extensions](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/about-app-extensions-in-the-wix-cli-for-headless).

### layouts/
Layout components for your frontend.

### pages/
Frontend route files for your site.

## astro.config.mjs
Astro configuration file.

## .env.local
Holds the [environment variables](https://docs.astro.build/en/guides/environment-variables/) for project. It initially holds the environmental variables required for authenticating your private app, which all have names beginning with `WIX_CLIENT`. Don't edit any of the `WIX_CLIENT` variables.

## package.json
Holds various metadata relevant to the project. It manages the project's dependencies, scripts, and more.

## tsconfig.json
Configuration for the TypeScript compiler.

## wix.config.json
Defines basic information about your project, including `appId` of your private app, and `projectId` of your headless project. Don't edit this file.

## See also

+ [CLI Command Reference](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/wix-cli-for-headless-commands)
+ [Development Overview](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/wix-cli-for-headless-development-overview)
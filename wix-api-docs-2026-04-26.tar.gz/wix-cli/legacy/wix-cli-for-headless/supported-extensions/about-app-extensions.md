---
portal: wix-cli
name: "About App Extensions"
type: ARTICLE_RESOURCE
resourceId: 00d3be2b-574f-4798-8c14-d0135898c409
---

# About App Extensions in the Wix CLI for Headless

# About App Extensions in the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


> **Note:** Extensions created with the Wix CLI for Headless are added to your headless project's private app. For more information about the private app and how extensions work in this context, see [About the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/about-the-wix-cli-for-headless).

Your project's private app lets you extend both its dashboard and backend functionality. For example, you can add custom dashboard pages or implement backend logic to handle events. Each distinct type of functionality your private app provides is called an extension.

For general information about Wix extensions, read [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions).

Wix CLI for Headless supports multiple [extension types](#supported-extension-types). The creation and setup process for extensions in the CLI takes place in the terminal. Then to edit your extensions, you write code directly in your project's local files.

## Adding extensions

You can add extensions to your project using the generate command:

```bash
npm run generate
```

This command starts a process that guides you through adding an extension to your project. 

After selecting an extension, you'll be prompted for the relevant configuration details. Your extension will then be generated in your project's local files, specifically in its own subdirectory under `src/extensions/`.

## Supported extension types

Wix CLI for Headless currently supports the following extensions:

**Dashboard Extensions**
+ [Dashboard pages](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-pages/add-dashboard-page-extensions-with-the-wix-cli-for-headless)
+ [Dashboard plugins](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-plugins/add-dashboard-plugin-extensions-with-the-wix-cli-for-headless)
+ [Dashboard menu plugins](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-menu-plugins/add-dashboard-menu-plugin-extensions-with-the-wix-cli-for-headless)
+ [Dashboard modals](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-modals/add-dashboard-modal-extensions-with-the-wix-cli-for-headless)


**Backend Extensions**
+ [Events](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/backend-extensions/events/add-event-extensions-with-the-wix-cli-for-headless)
+ [Service plugins](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/backend-extensions/service-plugins/add-service-plugin-extensions-with-the-wix-cli-for-headless)

## See also
- [About the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/about-the-wix-cli-for-headless)
- [Map your functionality to Wix's extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/map-your-app-s-functionality-to-wix-s-extensions)
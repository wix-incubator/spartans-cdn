---
portal: wix-cli
name: "Add Service Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: bb1d64d7-9686-4c7a-93fb-a08872ed4936
---

# Add Service Plugin Extensions with the Wix CLI for Headless

# Add Service Plugin Extensions with the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


[Service plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/backend-extensions/service-plugins/about-service-plugin-extensions) are a set of APIs defined by Wix that you can use to enable your headless project to inject custom logic into the backend flows of [Wix business solutions](https://dev.wix.com/docs/go-headless/get-started/about-headless/wix-headless-business-solutions) or to introduce entirely new flows.

You can implement service plugin extensions in your project using the CLI for Headless.

Follow the instructions below to:

1. Create a service plugin extension for your project.
1. Test your service plugin extension.

Once this task is complete, your project will have a service plugin extension with custom functions that Wix calls during a specific flow in your project.

## Before you begin

+ You must have a project that was [created using the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).
+ You must be logged into your Wix Studio account. If you don't have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).

## Step 1 | Create the extension

In the terminal:

1. Navigate to your project repo.
1. Run the following command:

    ```bash
    npm run generate
    ```

1. The CLI will display a menu of extensions to generate. Select **Service Plugin** and hit enter to continue.
1. The CLI will prompt you to select a service plugin from a list of available service plugins.
1. The CLI will prompt you to name your service plugin. This is the name of the folder in the project repo that contains the service plugin code, and the name of the plugin that appears in your project. Only you will see this name.

Upon completion, the extension files will be created in your project directory with the following structure:

```text
.
└── <your-project-name>/
    └── src/
        └── extensions/
            └── <your-service-plugin-name>/
                ├── extension.json
                └── plugin.ts
```

+ [**`extension.json`**](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code#extensionjson) - This file is required and provides all required configuration for your plugin.
+ [**`plugin.ts`**](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/backend-extensions/service-plugins/service-plugin-extension-files-and-code#plugints) - This file is required and contains handler functions that Wix calls automatically when the relevant action in your project triggers them. These functions are where you add your custom logic.

## Step 2 | Test your service plugin extension

To test your service plugin extension you must:

1. Release a version with your changes.
2. Trigger the call to your service plugin.

New service plugins or changes to existing service plugins won't take affect until you've built and released your project.

<blockquote class="important">

__Important:__

Logging in the backend logic of service plugins can't be tested in the CLI's local development environment (`npm run dev`). Instead, you must trigger the call to the service plugin from your development site and check for the expected result.

For example, to test a service plugin extension for [Additional Fees](https://dev.wix.com/docs/sdk/backend-modules/ecom/service-plugins/additional-fees/introduction) that adds a $5 packaging fee to all orders:

1. Go to your site's store in the local development environment.
1. Select any product and add it to the cart, then view the cart.
1. Check if the additional fee is listed in the order summary.

</blockquote>

### Release your project with your changes

1. Run the following command to build your project:

    ```bash
    npm run build
    ```

2. Run the following command and follow the prompts to release your project:

    ```bash
    npm run release
    ```

For more information about building and deploying your project, see [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless).

## Delete a service plugin extension

To delete a service plugin extension from your project, delete the subfolder under `src/extensions` that contains your service plugin extension's files.
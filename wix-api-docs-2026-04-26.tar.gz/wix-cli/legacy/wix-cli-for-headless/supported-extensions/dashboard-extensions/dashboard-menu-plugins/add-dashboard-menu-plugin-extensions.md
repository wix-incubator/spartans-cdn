---
portal: wix-cli
name: "Add Dashboard Menu Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: 3ae21807-70ae-4b93-a485-7e6ddd242520
---

# Add Dashboard Menu Plugin Extensions with the Wix CLI for Headless

# Add Dashboard Menu Plugin Extensions with the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


[Dashboard menu plugin extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/dashboard-menu-plugins/dashboard-menu-plugin-extensions) add menu items into [pre-configured slots in dashboard pages](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) of apps made by Wix in your headless project. When clicked, it either displays a dashboard modal or directs the project administrator to another dashboard page.

Follow the instructions below to:

1. Create and configure a dashboard menu plugin extension for your project.
2. Build and deploy your project.

Once this task is complete, the dashboard menu you specified in the installation process will contain the item you added, visible only in your project's dashboard.

## Before you begin

+ You must have a project that was [created using the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).
+ You must be logged into your Wix Studio workspace. If you don't already have one, [sign up for a Wix Studio workspace account](https://manage.wix.com/account/custom-apps).

## Step 1 | Create the extension

In your project directory, run the following command and follow the prompts to create a dashboard menu plugin extension:

```bash
npm run generate
```

When the process is completed, you can find the extension files in the local project folder with the following structure:

```text
src/
└── extensions/
    └── <your-menu-plugin-folder-name>/
        └── plugin.json
```

Learn more about the [dashboard menu plugin extension files](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-menu-plugins/dashboard-menu-plugin-extension-files-and-code).

## Step 2 | Customize your dashboard plugin

1. Run the following command to open the dev menu:

    ```bash
    npm run dev
    ```

1. Click the link to open your project's dashboard in the browser, then navigate to the dashboard page hosting your menu plugin.

1. Go to your `extension.json` file and edit the `title` to "Hello world!".

  ```json
  {
    "compId": "502e239d-c151-4cf2-b76b-a4e7e7e88260",
    "compType": "BACK_OFFICE_EXTENSION_MENU_ITEM",
    "compName": "my-plugin",
    "compData": {
      "backOfficeExtensionMenuItem": {
        "hostingPlatform": "BUSINESS_MANAGER",
        "title": "Hello world!",
        "iconKey": "Sparkles",
        "extends": "79963a99-8680-4164-8961-8867fcb1751a",
        "action": {
          "openModal": {
            "componentId": "771be659-261e-4938-9661-b4c6efc26708"
          }
        }
      }
    }
  }
  ```
 
1. Save your file.

1. Navigate back to the dashboard page in your browser and see your changes.

## Step 3 | Build and deploy your project

Now that your project is ready for production with your new plugin, you can build your project and release your project.

1. Run the following command to build your project:

  ```bash
  npm run build
  ```

2. Run the following command and follow the prompts to release a new version:

  ```bash
  npm run release
  ```

For more information about building and deploying your project, see [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless).

## Delete a dashboard menu plugin

To delete an existing dashboard menu plugin from your project, delete the subfolder under `src/extensions/` that contains your dashboard menu plugin's files.
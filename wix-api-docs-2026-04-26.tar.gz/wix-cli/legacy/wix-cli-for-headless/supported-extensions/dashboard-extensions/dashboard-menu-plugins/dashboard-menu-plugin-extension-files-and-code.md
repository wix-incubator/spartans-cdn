---
portal: wix-cli
name: "Dashboard Menu Plugin Extension Files and Code"
type: ARTICLE_RESOURCE
resourceId: 4801a3b9-bd13-4d11-b749-ef3d2268d7c3
---

# Dashboard Menu Plugin Extension Files and Code

# Dashboard Menu Plugin Extension Files and Code

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


In your project, the configuration files for dashboard menu plugins are located in the `src/extensions/` folder. Each menu plugin is defined in its own subdirectory. Each subdirectory contains one file, `extension.json`, that has the plugin configuration details.

```text
src/
└── extensions/
    └── <your-dashboard-menu-plugin-name>/
        └── extension.json
```

## Extension configuration (extension.json)

The `extension.json` file contains the dashboard menu plugin configuration details. You can edit some its fields manually to modify its appearance or behavior. The structure is as follows:

```json
{
  "compId": "<unique-id>",
  "compType": "BACK_OFFICE_EXTENSION_MENU_ITEM",
  "compName": "<your-dashboard-menu-plugin-name>",
  "compData": {
    "backOfficeExtensionMenuItem": {
      "hostingPlatform": "BUSINESS_MANAGER",
      "title": "<Menu Item Title>",
      "iconKey": "Activity",
      "extends": "<dashboard-page-id>",
      "action": {
        "openModal": {
          "componentId": "<modal-compId>",
          "componentParams": {
            "origin": "calendar-page"
          }
        },
        "navigateToPage": {
          "pageId": "<dashboard-page-id>",
          "relativeUrl": "?origin=import-modal"
        }
      }
    }
  }
}
```

| Field  | Type  | Description  |
|--------|-------|--------------|
| `compId`     | String  | Extension's unique identifier. The ID is used to register the menu plugin and must be unique across all extensions in the project. |
| `compType`   | String  | Always `BACK_OFFICE_EXTENSION_MENU_ITEM` for dashboard menu plugins. |
| `compName`   | String  | Name of the menu plugin. |
| `compData.backOfficeExtensionMenuItem.hostingPlatform` | String | Always `BUSINESS_MANAGER`. |
| `compData.backOfficeExtensionMenuItem.title`  | String  | Text of the menu item the extension adds. |
| `compData.backOfficeExtensionMenuItem.iconKey`  | String | Icon that appears next to your extension's title. |
| `compData.backOfficeExtensionMenuItem.extends`  | String | Slot ID into which the extension plugs in. |
| `compData.backOfficeExtensionMenuItem.action`  | Object  | Navigation configuration object that determines the action taken when the extension is clicked. Possible values are either `openModal` or `navigateToPage`. |
| `compData.backOfficeExtensionMenuItem.action.openModal`  | Object  | Dashboard modal configuration object. Contains the ID of the dashboard modal to display when the extension's menu item is clicked, along with additional parameters. |
| `compData.backOfficeExtensionMenuItem.action.openModal.componentId`  | String | ID of the dashboard modal to display when the extension's menu item is clicked. |
| `compData.backOfficeExtensionMenuItem.action.openModal.componentParams`  | Object | Additional configuration parameters you can pass to the dashboard modal. |
| `compData.backOfficeExtensionMenuItem.action.navigateToPage`  | Object  | Page navigation configuration object. Contains the ID of the target dashboard page, as well as additional configuration parameters. |
| `compData.backOfficeExtensionMenuItem.action.navigateToPage.pageId`  | String | ID of the dashboard page to which site administrators are directed. |
| `compData.backOfficeExtensionMenuItem.action.navigateToPage.relativeUrl`  | String  | URI segment appended to the base URI of the target dashboard page. |

## Example

Here's an example `extension.json` file:

```json
{
  "compId": "e357ba12-da11-4bb3-b5db-45921fcb36e4",
  "compType": "BACK_OFFICE_EXTENSION_MENU_ITEM",
  "compName": "Activity Statistics",
  "compData": {
    "backOfficeExtensionMenuItem": {
      "hostingPlatform": "BUSINESS_MANAGER",
      "title": "Activity Statistics",
      "iconKey": "Activity",
      "extends": "084a82b9-c9a5-4bb0-bf82-e071f2f79d2a",
      "action": {
        "openModal": {
          "componentId": "9157ba1d-da11-4bb3-a5db-45911fcb36e5",
          "componentParams": {
            "origin": "calendar-page"
          }
        },
        "navigateToPage": {
          "pageId": "e357ba12-da11-4bb3-b5db-45921fcb36e4",
          "relativeUrl": "?origin=import-modal"
        }
      }
    }
  }
}
```
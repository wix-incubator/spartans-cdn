---
portal: wix-cli
name: "Add Dashboard Modal Extensions"
type: ARTICLE_RESOURCE
resourceId: 92ef24ee-38e4-4462-ad4b-8a2d422c1571
---

# Add Dashboard Modal Extensions with the Wix CLI for Headless

# Add Dashboard Modal Extensions with the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


[Dashboard modal extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-modals/about-dashboard-modals) allow you to add modals to your headless project's dashboard. You can control the modal using `openModal()` and `closeModal()` from the [dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/open-modal). 

Follow the instructions below to:

1. Create a dashboard modal extension for your project.
1. Customize and test your dashboard modal extension.

## Before you begin

- You must have a project that was [created using the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).
- You must be logged in to your Wix Studio account. If you don't already have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).
- Learn how to interact with the Wix Dashboard using the [Wix Dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/introduction).

## Step 1 | Create the extension 

1. Run the following command and follow the prompts to create a dashboard modal extension:

    ```bash
    npm run generate
    ```

1. Enter a name for your modal's folder. The CLI will create this directory with the chosen name containing your modal's files.

1. Enter the name of your modal. This name will be used to refer to your modal in your project's dashboard.

Upon completion, the dashboard modal extension folder and files will be created in your local project files in the 'src/extensions/' folder with the following structure:

```text
src/
└── extensions/
    └── <your-modal-folder-name>
        ├── extension.json
        └── modal.tsx
```

For more on the files and their structure, see [Dashboard Modal Extensions Files and Code](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-modals/dashboard-modal-extensions-files-and-code).

## Step 2 | Customize your modal

1. Run the following command to open the dev menu:

    ```bash
    npm run dev
    ```
    
1. Choose a dashboard page to display. This will open a browser window previewing your project's dashboard page.

1. Add code to your dashboard page that triggers your modal to open. Use `openModal()` from the [dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/open-modal). You can find your modal's ID in the `modal.json` file.

1. Edit your `modal.tsx` file to customize the modal itself. For example, change the text inside `<Text>` to `My Dashboard Modal`:
    ```tsx
    function Modal() {
      const { closeModal } = useDashboard();

      return (
        <WixDesignSystemProvider>
          <MessageModalLayout
            title="Wix CLI Modal"
            primaryButtonText="Close"
            primaryButtonOnClick={() => closeModal()}
          >
             <Box direction="vertical" align="center" paddingTop="4">
             <Text>My Dashboard Modal</Text>
           </Box>
         </MessageModalLayout>
       </WixDesignSystemProvider>
      );
    }
    ``` 

1. Set your dashboard modal extension to interact with custom data passed by the `openModal()` function or any data passed from the dashboard page hosting a menu plugin that navigates to your modal. 
    1. To retrieve the data, use the [`observeState()`](https://dev.wix.com/docs/sdk/host-modules/dashboard/observe-state) function. 

        ```js
        dashboard.observeState((componentParams) => {
          console.log("componentParams:", componentParams);
        });
        ```

    1. Use React to add code and logic to your modal. 
    
1. Save your files.

1. Go back to your dashboard page, open your modal, and see your changes.
 

## Step 3 | Build and deploy your project

Now that your project is ready for production, you can build your project and release your project.

1. Run the following command to build your project:
    ```bash
    npm run build
    ```

1. Run the following command and follow the prompts to release your project:
    ```bash
    npm run release
    ```

For more information about building and deploying your project, see [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless).

## Delete a dashboard modal

To delete an existing dashboard modal from your project, delete the subfolder under `src/extensions/` that contains your dashboard modal's files.
---
portal: wix-cli
name: "Dashboard Modal Extensions Files and Code"
type: ARTICLE_RESOURCE
resourceId: 5d8474b4-5e9d-4440-84db-2204a75be249
---

# Dashboard Modal Extensions Files and Code

# Dashboard Modal Extensions Files and Code

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


Within your project, the source code for dashboard modals is located in the `src/extensions/` folder. Each modal is defined in its own subdirectory:

```text
src/
└── extensions/
    └── <your-dashboard-modal-name>/
        ├── extension.json
        └── modal.tsx
```

## Modal metadata (extension.json)

The `extension.json` file contains the dashboard modal metadata. The structure is as follows:

```json
{
  "compId": "<unique-id>",
  "compType": "BACK_OFFICE_MODAL",
  "compName": "<your-dashboard-modal-name>",
  "compData": {
    "backOfficeModal": {
      "hostingPlatform": "BUSINESS_MANAGER",
      "title": "<Your Modal Title>",
 "width": 600,
 "height": 400
}
  }
}
```

| Field  | Type   | Description |
|--------|--------|-------------|
| `compId`   | string | The modal ID ([GUID](https://en.wikipedia.org/wiki/Universally_unique_identifier)) is automatically generated and shouldn't be changed. Must be unique across all extensions in the project. |
| `compType` | string | Always `BACK_OFFICE_MODAL` for dashboard modals. |
| `compName` | string | The modal name. |
| `compData.backOfficeModal.hostingPlatform` | string | Always `BUSINESS_MANAGER`. |
| `compData.backOfficeModal.title` | string | The modal title. |
| `compData.backOfficeModal.width` | number | Initial width of the modal in pixels. |
| `compData.backOfficeModal.height` | number | Initial height of the modal in pixels. |

## Modal content (modal.tsx)

The `modal.tsx` file contains the dashboard modal content.

The content is defined as a [React](https://react.dev/) component that renders when the modal is active.

Inside a dashboard modal component you may choose to use:

- The [Wix Dashboard React SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard-react-deprecated/introduction) to navigate users to pages in the dashboard, display other dashboard modals, or send users alerts and updates using toasts.
- The [Wix Design System](https://www.wix-pages.com/wix-design-system/?path=/story/getting-started--about) to use the same React components Wix uses to build its own dashboard pages.
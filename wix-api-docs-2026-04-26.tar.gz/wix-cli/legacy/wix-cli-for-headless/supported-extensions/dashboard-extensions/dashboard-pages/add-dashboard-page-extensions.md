---
portal: wix-cli
name: "Add Dashboard Page Extensions"
type: ARTICLE_RESOURCE
resourceId: d16fdad0-188b-4d8e-beaf-a20e29e3d0c9
---

# Add Dashboard Page Extensions with the Wix CLI for Headless

# Add Dashboard Page Extensions with the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


You can add new dashboard pages to your headless project using dashboard page extensions. You can use dashboard pages to help you manage your project.

The Wix CLI for Headless makes it easy to create and develop dashboard page extensions, and to manage dashboard pages in your project's dashboard sidebar.

For general information about this extension type, read [About Dashboard Page Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-pages/about-dashboard-page-extensions)

Follow the instructions below to:

1. Create a dashboard page extension for your project.
2. Customize your dashboard page.
3. Build and deploy your project.

Once this task is complete, your project will have a dashboard page extension that adds a new page to your project's dashboard.

## Before you begin

+ You must have a project that was [created using the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).
+ You must be logged into your Wix Studio account. If you don't have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).
+ Learn how to interact with the Wix Dashboard using the [Wix Dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/introduction).


## Step 1 | Create the extension

1. Run the following command and follow the prompts to create a dashboard page extension:

    ```bash
    npm run generate
    ```

1. Enter a name for your page's folder. The CLI will create this directory with the chosen name containing your page's files.

1. Enter the route for your page. The route is the path that is appended to your project's dashboard base URL to access the dashboard page.

The extension files will be created in your local project files under `src/extensions/<your-dashboard-page-name>/` with the following structure:

```text
src/
└── extensions/
    └── <your-dashboard-page-name>/
        ├── extension.json
        └── page.tsx
```

For more information about these files, see [Dashboard Page Extension Files and Code](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-pages/dashboard-page-extension-files-and-code)

## Step 2 | Customize your dashboard page

1. Run the following command to open the `dev menu`:

   ```bash
   npm run dev
   ```

1. Click the link to open your project's dashboard in your browser and navigate to the page you've created. Leave this window open.

1. Go to your dashboard page's `page.tsx` file and change `subtitle` in `Page.Content` to `"Hello world!"`:

    ```tsx
    export default function() {
      return (
        <WixDesignSystemProvider>
          <Page>
            <Page.Header
              title="My Page"
              subtitle="This is a subtitle for your page"
            />
            <Page.Content>
              <EmptyState
                title="My Page"
                subtitle="Hello World!"
                theme="page"
              />
            </Page.Content>
          </Page>
        </WixDesignSystemProvider>
      );
    }
    ```

1. If you use a menu plugin to navigate to your dashboard page, you can customize your dashboard page extension to interact with any data that is passed from the dashboard page that hosts the menu plugin. 

    1. Make sure the `@wix/dashboard` package is installed in your project. 
    1. Add the following import statement to your code: 
        ```js
        import { dashboard } from '@wix/dashboard';
        ```
    1. To retrieve the data from the dashboard page, use the [`observeState()`](https://dev.wix.com/docs/sdk/host-modules/dashboard/observe-state) function. 
        ```js
        dashboard.observeState((componentParams) => {
          console.log("componentParams:", componentParams);
        });
        ```
    1. Use React to add code and logic to your dashboard page. 
 
1. Save your file.

1. Navigate back to the dashboard page in your browser and see your changes.

## Step 3 | Build and deploy your project

Now that your project is ready for production, you can build and release your project.

1. Run the following command to build your project:

  ```bash
  npm run build
  ```

2. Run the following command and follow the prompts to release your project:

  ```bash
  npm run release
  ```

For more information about building and deploying your project, see [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless).

## Delete a dashboard page

To delete an existing dashboard page from your project, delete the subfolder under `src/extensions` that contains your [dashboard page's files](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-pages/dashboard-page-extension-files-and-code).
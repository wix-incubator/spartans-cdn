---
portal: wix-cli
name: "Add Dashboard Plugin Extensions"
type: ARTICLE_RESOURCE
resourceId: b3a442e9-0802-4721-87ae-f2d01f2100fc
---

# Add Dashboard Plugin Extensions with the Wix CLI for Headless

# Add Dashboard Plugin Extensions with the Wix CLI for Headless

<blockquote classname="note">

**CLI Documentation Notice**
We've released a [new Wix CLI](https://dev.wix.com/docs/wix-cli/guides/about-the-wix-cli). Continue here if your project uses the Wix CLI for Headless. [Determine which CLI your project uses](https://dev.wix.com/docs/wix-cli/guides/development/determine-which-cli-your-project-uses).


</blockquote>


Dashboard plugins allow you to extend and enhance the functionality of your headless project's dashboard.  

The Wix CLI for Headless makes it easy to create and develop dashboard plugins for the dashboard pages of apps made by Wix. 
You build your plugin using Wix's React/Node.js stack. Your plugin is then deployed and hosted on the Wix cloud. 

For more information on dashboard plugin extensions, read [About Dashboard Plugins](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/about-dashboard-plugin-extensions).

Follow the instructions below to:

1. Create a dashboard plugin extension for your project.
1. Customize your dashboard plugin.

Once this task is complete, your project will have a dashboard plugin extension that adds a plugin to the dashboard page of an app made by Wix in your headless project.  

## Before you begin

- You must have a project that was [created using the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/get-started/wix-cli-for-headless-quick-start).
- You must be logged into your Wix Studio account. If you don't already have one, [sign up for a Wix Studio account](https://manage.wix.com/account/custom-apps).
- Learn how to interact with the Wix Dashboard using the [Wix Dashboard SDK](https://dev.wix.com/docs/sdk/host-modules/dashboard/introduction).

## Step 1 | Create the plugin extension

In the terminal: 

1. Navigate to your project repo.
1. Run the following command.

    ```bash
    npm run generate
    ```

1. Follow the prompts for creating a dashboard plugin.

Upon completion, the extension files will be created in your project directory with the following structure:

```text
src/
└── extensions/
    └── <your-plugin-folder-name>/
        ├── extension.json
        └── plugin.tsx
```

- [`extension.json`](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-plugins/dashboard-plugin-extension-files-and-code#plugin-extension-configuration-extensionjson): This file contains your plugin's JSON configuration.
- [`plugin.tsx`](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-plugins/dashboard-plugin-extension-files-and-code#plugin-content-plugintsx): This file contains your plugin's React component.

Learn more about [dashboard plugin extension files and code](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-plugins/dashboard-plugin-extension-files-and-code).

## Step 2 | Customize your dashboard plugin

Once you finish generating your dashboard plugin, you can find your plugin's auto-generated React component in the `plugin.tsx` file. 

1. Run the following command to open the dev menu:

    ```bash
    npm run dev
    ```

1. Click the link to open your project's dashboard in the browser, then navigate to the dashboard page hosting your plugin. This will open a browser window previewing your project's dashboard page.
    
    ![page plugin](https://wixmp-833713b177cebf373f611808.wixmp.com/images/0c0abb842afe77025cdda857476dd5a9.png)
    Leave this window open.

1. Go to your `plugin.tsx` file and edit the subtitle in the `<Card.Content>`  component to "Hello world!".

    ```tsx
    function PagePlugin() {
      return (
        <WixDesignSystemProvider>
          <Card>
            <Card.Header
              title="Page Plugin"
              subtitle={
                <Box direction="horizontal" gap="1">
                  <Text secondary>This is your page plugin.</Text>
                  <TextButton as="a" href="https://wix.to/JaXp37C" target="_blank">
                    Learn more
                  </TextButton>
                </Box>
              }
            />
            <Card.Divider />
            <Card.Content size="medium">
              <EmptyState
                theme="section"
                title="Here is some content"
                subtitle="Hello world!"
              />
            </Card.Content>
          </Card>
        </WixDesignSystemProvider>
      );
    }
    ```

    >**Note:** When it comes to designing the UI for your plugin, consider using the [Wix Design System](https://www.wixdesignsystem.com/), a collection of reusable React components that you can use to make your project appear and feel like a native Wix experience. 


1. Customize your plugin to interact with the dashboard page data passed to the [plugin's slot](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/dashboard-extensions/dashboard-plugins/supported-wix-app-dashboard-pages/about-dashboard-page-slots) using the [`observeState()`](https://dev.wix.com/docs/sdk/host-modules/dashboard/observe-state) function from the Dashboard SDK:

    1. Make sure the [`@wix/dashboard`](https://dev.wix.com/docs/sdk/host-modules/dashboard/introduction) package is installed in your project. 
    1. Add the following import statement to your code: 
        ```js
        import { dashboard } from '@wix/dashboard';
        ```
    1. To retrieve the data from the dashboard page, use the `observeState()` function. 
        ```js
        dashboard.observeState((componentParams) => {
          console.log("componentParams:", componentParams);
        });
        ```
    1. Use React to add code and logic to your plugin. 
 
1. Save your file.

1. Navigate back to the dashboard page in your browser and see your changes. 


## Step 3 | Build and deploy your project 
Now that your project is ready for production with your new plugin, you can build your project and release your project.

1. Run the following command to build your project:

    ```bash
    npm run build
    ```

1. Run the following command and follow the prompts to release your project:

    ```bash
    npm run release
    ```

For more information about building and deploying your project, see [Build and Deploy a Project with the Wix CLI for Headless](https://dev.wix.com/docs/go-headless/cli-for-headless/project-development/build-and-deploy-a-project-with-the-wix-cli-for-headless).

## Delete a dashboard plugin
To delete an existing dashboard plugin from your project, delete the subfolder under `src/extensions/` that contains your dashboard plugin's files. 

## See also
- [Dashboard Plugin Extension Files and Code](https://dev.wix.com/docs/go-headless/cli-for-headless/supported-extensions/dashboard-extensions/dashboard-plugins/dashboard-plugin-extension-files-and-code)
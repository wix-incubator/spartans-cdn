---
portal: build-apps
name: "About the Wix MCP for App Development"
type: ARTICLE_RESOURCE
resourceId: 69d56ebb-ad3f-46e0-ad71-a1bc2cad6e76
---

# About the Wix MCP for App Development

# About the Wix MCP for App Development

The [Wix MCP](https://dev.wix.com/docs/sdk/articles/use-the-wix-mcp/about-the-wix-mcp) connects your AI client to Wix's platform, so you can search documentation, write code, and make API calls directly from your AI client. For app developers, this means you can configure extensions, integrate Wix APIs, and build features faster by describing what you need in natural language.

## What you can do

With the Wix MCP configured in your AI client, you can:

- Search the [Build Apps](https://dev.wix.com/docs/build-apps), [REST](https://dev.wix.com/docs/rest), and [SDK](https://dev.wix.com/docs/sdk) documentation directly from your AI chat.
- Generate code for [extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions) like dashboard pages, site widgets, events, and service plugins.
- Make authenticated API calls to Wix sites to test your app's functionality.
- Build complete app flows, from data models to dashboard UIs to site widgets.

## Get started

To set up the Wix MCP, follow the configuration instructions in [About the Wix MCP](https://dev.wix.com/docs/sdk/articles/use-the-wix-mcp/about-the-wix-mcp#configure-the-wix-mcp). Once configured, try the [sample prompts for app developers](https://dev.wix.com/docs/build-apps/develop-your-app/ai/wix-mcp-sample-prompts-for-app-developers) to see what's possible.

## See also

- [About the Wix MCP](https://dev.wix.com/docs/sdk/articles/use-the-wix-mcp/about-the-wix-mcp)
- [Wix MCP Sample Prompts for App Developers](https://dev.wix.com/docs/build-apps/develop-your-app/ai/wix-mcp-sample-prompts-for-app-developers)
- [About Extensions](https://dev.wix.com/docs/build-apps/develop-your-app/extensions/about-extensions)
---
portal: go-headless
name: "About Member Login"
type: ARTICLE_RESOURCE
resourceId: c73bd2ea-b9ea-453d-97d9-31eaa6f6efc5
---

# About Member Login

# About Member Login

Member login allows users to authenticate and access personalized content on your site. 

## Types of member login

Wix Headless supports 3 types of member login:

- **Wix login page**: Redirect users to a Wix login page. After authenticating, Wix redirects the member back to your site.
- **Custom login page**: Use API calls to create your own custom login page with Wix-managed authentication.
- **Externally-managed login**: Create your own custom login page that supports login and authentication with an external identity provider.

> **Note:** [Wix-managed headless](https://dev.wix.com/docs/go-headless/develop-your-project/wix-managed-headless/about-the-wix-cli-for-headless) only supports Wix login pages.

## See also 

- [About Wix Login Pages](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/wix-managed-login-page/about-wix-login-pages)
- [About Custom Login Pages](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/custom-login-page/about-custom-login-pages)
- [About Externally-Managed Login Pages](https://dev.wix.com/docs/go-headless/develop-your-project/authentication/members/externally-managed-login-page/about-externally-managed-login-pages)
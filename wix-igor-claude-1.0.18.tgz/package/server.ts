import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync, existsSync, mkdirSync } from 'fs';
import { homedir } from 'os';
import { execSync } from 'child_process';
import { createLogger, logDir } from './src/lib/logger';

// Import server services
import {
  Marketplace,
  MARKETPLACE_PATH,
  MARKETPLACE_JSON,
  loadMarketplaceFrom,
  downloadMarketplace,
  resolvePluginPath,
} from './src/server/services/marketplace';
import {
  listSessions,
  loadSession,
  deleteSession,
  getOriginalCwd,
} from './src/server/services/sessions';
import {
  readSettings,
  writeSettings,
  readProjectSettings,
  writeProjectSettings,
} from './src/server/services/settings';
import {
  getPluginsWithCommands,
  getEnabledPluginPaths,
} from './src/server/services/plugins';
import { initChatRoute, handleChatRequest } from './src/server/routes/chat';

// Create server-specific logger
const log = createLogger('server');

// =============================================================================
// Configuration
// =============================================================================

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Package root - use IGOR_CLAUDE_ROOT if running from CLI, otherwise use __dirname
const PACKAGE_ROOT = process.env.IGOR_CLAUDE_ROOT || __dirname;
const DIST_PATH = join(PACKAGE_ROOT, 'dist');
const IGOR_CLAUDE_DIR = join(homedir(), '.igor-claude');

// Version will be set after checking for embedded assets
let VERSION = 'unknown';

// Marketplace will be loaded after we sync files
let MARKETPLACE: Marketplace | null = null;

// Detect claude CLI path (needed for binary mode where __dirname is virtual)
function getClaudeExecutablePath(): string | undefined {
  try {
    const path = execSync('which claude', { encoding: 'utf-8' }).trim();
    if (path) {
      log.info({ path }, 'Claude CLI found');
      return path;
    }
  } catch {
    // Try common paths
    const commonPaths = [
      '/usr/local/bin/claude',
      '/opt/homebrew/bin/claude',
      `${homedir()}/.local/bin/claude`,
      `${homedir()}/.npm-global/bin/claude`,
    ];
    for (const p of commonPaths) {
      if (existsSync(p)) {
        log.info({ path: p }, 'Claude CLI found');
        return p;
      }
    }
  }
  log.warn('Claude CLI not found - SDK may fail in binary mode');
  return undefined;
}

// Read version from package.json (fallback for non-binary mode)
function getVersionFromPackageJson(): string {
  try {
    const packageJsonPath = join(PACKAGE_ROOT, 'package.json');
    if (existsSync(packageJsonPath)) {
      const pkg = JSON.parse(readFileSync(packageJsonPath, 'utf-8'));
      return pkg.version || 'unknown';
    }
  } catch {}
  return 'unknown';
}

const CLAUDE_EXECUTABLE_PATH = getClaudeExecutablePath();

// Ensure ~/.igor-claude/ directory exists
if (!existsSync(IGOR_CLAUDE_DIR)) {
  mkdirSync(IGOR_CLAUDE_DIR, { recursive: true });
}

// =============================================================================
// Express App Setup
// =============================================================================

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3001;

// CORS middleware for development (direct SSE connections bypass Vite proxy)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Middleware
app.use(express.json({ limit: '50mb' })); // Increased for base64 images

// =============================================================================
// Binary Mode Detection & Asset Loading
// =============================================================================

// Try to load embedded assets (for binary mode)
let embeddedAssets: { 
  getEmbeddedAsset: (path: string) => { content: Buffer | string; mimeType: string } | null;
  EMBEDDED_VERSION?: string;
} | null = null;
let IS_BINARY_MODE = false;

try {
  // Dynamic import to avoid errors when embedded-assets.ts doesn't exist
  // @ts-ignore - File only exists after binary build
  const embedded = await import('./dist/statics/embedded-assets').catch(() => null);
  if (embedded?.getEmbeddedAsset) {
    embeddedAssets = embedded;
    IS_BINARY_MODE = true;
    
    // Get version from embedded assets
    const embeddedData = embedded as { EMBEDDED_VERSION?: string };
    VERSION = embeddedData.EMBEDDED_VERSION || 'unknown';
    
    log.info({ version: VERSION }, 'Running in BINARY mode with embedded assets');
  } else {
    // npm mode - get version from package.json
    VERSION = getVersionFromPackageJson();
  }
} catch {
  // Fallback
  VERSION = getVersionFromPackageJson();
}

// Log startup banner (after version detection)
log.info({ version: VERSION }, 'Igor Claude starting');
log.info({ logDir }, 'Logs directory');
log.info({ marketplace: MARKETPLACE_JSON }, 'Marketplace source');

// Download marketplace from CDN (for both binary and npm modes)
await downloadMarketplace();

// Load marketplace from synced location
MARKETPLACE = loadMarketplaceFrom(MARKETPLACE_PATH);
if (MARKETPLACE) {
  log.info({ marketplace: MARKETPLACE.name, plugins: MARKETPLACE.plugins.length }, 'Loaded marketplace');
}

// =============================================================================
// Static File Serving
// =============================================================================

// Serve built frontend files
// Priority: 1) Embedded assets (binary mode), 2) Filesystem dist/, 3) Let Vite handle it
app.use((req, res, next) => {
  // Skip API routes
  if (req.path.startsWith('/api')) {
    return next();
  }
  
  // Normalize path for index
  let assetPath = req.path === '/' ? '/index.html' : req.path;
  
  // Try embedded assets first (binary mode)
  if (embeddedAssets) {
    const asset = embeddedAssets.getEmbeddedAsset(assetPath);
    if (asset) {
      res.setHeader('Content-Type', asset.mimeType);
      return res.send(asset.content);
    }
  }
  
  // Try filesystem dist/ (npm mode with pre-built frontend)
  const fsPath = join(DIST_PATH, assetPath);
  if (existsSync(fsPath)) {
    return res.sendFile(fsPath);
  }
  
  // For SPA routing: serve index.html for non-file paths
  if (!req.path.includes('.')) {
    if (embeddedAssets) {
      const indexAsset = embeddedAssets.getEmbeddedAsset('/index.html');
      if (indexAsset) {
        res.setHeader('Content-Type', indexAsset.mimeType);
        return res.send(indexAsset.content);
      }
    }
    const indexPath = join(DIST_PATH, 'index.html');
    if (existsSync(indexPath)) {
      return res.sendFile(indexPath);
    }
  }
  
  next();
});

// =============================================================================
// Chat Route (SSE)
// =============================================================================

// Store abort controllers for active requests
const abortControllers = new Map<string, AbortController>();

// MCP status tracking
let lastMcpStatus: Array<{ name: string; status: string; serverInfo?: any }> = [];
function updateMcpStatus(status: Array<{ name: string; status: string; serverInfo?: any }>): void {
  lastMcpStatus = status;
}

// Initialize chat route with dependencies
initChatRoute({
  marketplace: MARKETPLACE,
  claudeExecutablePath: CLAUDE_EXECUTABLE_PATH,
  abortControllersMap: abortControllers,
  onMcpStatusUpdate: updateMcpStatus,
});

app.post('/api/chat', handleChatRequest);

// =============================================================================
// Session Management Routes
// =============================================================================

app.get('/api/sessions', (_req: Request, res: Response) => {
  try {
    const sessions = listSessions();
    res.json({ sessions });
  } catch (err) {
    log.error({ err }, 'Failed to list sessions');
    res.status(500).json({ error: 'Failed to list sessions' });
  }
});

app.get('/api/sessions/:sessionId', (req: Request, res: Response) => {
  const { sessionId } = req.params;
  
  try {
    const result = loadSession(sessionId);
    if (!result) {
      return res.status(404).json({ error: 'Session not found' });
    }
    res.json(result);
  } catch (err) {
    log.error({ err, sessionId }, 'Failed to load session');
    res.status(500).json({ error: 'Failed to load session' });
  }
});

app.post('/api/sessions/new', (_req: Request, res: Response) => {
  // Just return success - the actual session is created by the SDK
  res.json({ success: true });
});

app.delete('/api/session/:sessionId', (req: Request, res: Response) => {
  const { sessionId } = req.params;
  const success = deleteSession(sessionId);
  res.json({ success });
});

// =============================================================================
// Health & Version Routes
// =============================================================================

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: VERSION,
  });
});

app.get('/api/version', (_req: Request, res: Response) => {
  res.json({
    version: VERSION,
    cwd: getOriginalCwd(),
    mode: IS_BINARY_MODE ? 'binary' : 'npm',
    marketplace: MARKETPLACE?.name || null,
  });
});

// =============================================================================
// Settings Routes (stored in .igor-claude/settings.json)
// =============================================================================

app.get('/api/settings', (_req: Request, res: Response) => {
  try {
    const settings = readSettings();
    res.json(settings);
  } catch (err) {
    log.error({ err }, 'Failed to read settings');
    res.status(500).json({ error: 'Failed to read settings' });
  }
});

app.post('/api/settings', (req: Request, res: Response) => {
  try {
    const settings = req.body;
    writeSettings(settings);
    res.json({ success: true });
  } catch (err) {
    log.error({ err }, 'Failed to save settings');
    res.status(500).json({ error: 'Failed to save settings' });
  }
});

// =============================================================================
// Plugin Management Routes
// =============================================================================

app.get('/api/plugins', (_req: Request, res: Response) => {
  try {
    const plugins = getPluginsWithCommands(MARKETPLACE);
    log.debug({ pluginCount: plugins.length }, 'Returning plugins');
    res.json({ plugins });
  } catch (err) {
    log.error({ err }, 'Failed to get plugins');
    res.status(500).json({ error: 'Failed to get plugins', plugins: [] });
  }
});

// =============================================================================
// Abort Route
// =============================================================================

app.post('/api/abort', (req: Request, res: Response) => {
  const { sessionId } = req.body;
  log.debug({ sessionId }, 'Abort request');
  
  let aborted = false;
  for (const [key, controller] of abortControllers.entries()) {
    if (key.startsWith(sessionId)) {
      log.debug({ key }, 'Aborting request');
      controller.abort();
      abortControllers.delete(key);
      aborted = true;
    }
  }
  
  if (aborted) {
    res.json({ success: true, message: 'Request aborted' });
  } else {
    res.json({ success: false, message: 'No active request found for session' });
  }
});

// =============================================================================
// MCP Server Management Routes (stored in .claude/settings.json)
// =============================================================================

app.get('/api/mcp', (_req: Request, res: Response) => {
  try {
    const settings = readProjectSettings();
    const mcpServers = settings.mcpServers || {};
    
    // Merge with last known status
    const serversWithStatus = Object.entries(mcpServers).map(([name, config]: [string, any]) => {
      const statusInfo = lastMcpStatus.find(s => s.name === name);
      return {
        name,
        ...config,
        status: statusInfo?.status || 'unknown',
        serverInfo: statusInfo?.serverInfo,
      };
    });
    
    res.json({ servers: serversWithStatus });
  } catch (err) {
    log.error({ err }, 'Failed to get MCP servers');
    res.status(500).json({ error: 'Failed to get MCP servers' });
  }
});

app.post('/api/mcp', (req: Request, res: Response) => {
  try {
    const { name, config } = req.body;
    
    if (!name || !config) {
      return res.status(400).json({ error: 'Name and config are required' });
    }
    
    const settings = readProjectSettings();
    if (!settings.mcpServers) {
      settings.mcpServers = {};
    }
    
    settings.mcpServers[name] = config;
    writeProjectSettings(settings);
    
    log.info({ name }, 'MCP server added');
    res.json({ success: true });
  } catch (err) {
    log.error({ err }, 'Failed to add MCP server');
    res.status(500).json({ error: 'Failed to add MCP server' });
  }
});

app.delete('/api/mcp/:name', (req: Request, res: Response) => {
  try {
    const { name } = req.params;
    
    const settings = readProjectSettings();
    if (settings.mcpServers && settings.mcpServers[name]) {
      delete settings.mcpServers[name];
      writeProjectSettings(settings);
      log.info({ name }, 'MCP server removed');
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'MCP server not found' });
    }
  } catch (err) {
    log.error({ err }, 'Failed to remove MCP server');
    res.status(500).json({ error: 'Failed to remove MCP server' });
  }
});

app.get('/api/mcp/status', (_req: Request, res: Response) => {
  res.json({ servers: lastMcpStatus });
});

// =============================================================================
// Server Startup
// =============================================================================

// Validate required environment variables before starting server
if (!process.env.ANTHROPIC_API_KEY) {
  console.error('\n❌ ERROR: ANTHROPIC_API_KEY environment variable is required\n');
  console.error('   Please set it using one of these methods:');
  console.error('   1. Export: export ANTHROPIC_API_KEY=your_api_key_here');
  console.error('   2. .env file: Create a .env file with ANTHROPIC_API_KEY=your_api_key_here');
  console.error('   3. CLI: ANTHROPIC_API_KEY=your_api_key_here yarn server\n');
  log.error('ANTHROPIC_API_KEY environment variable is required');
  process.exit(1);
}

// Start server (bind to 0.0.0.0 for Docker compatibility)
app.listen(PORT, '0.0.0.0', () => {
  log.info({ port: PORT, cwd: getOriginalCwd() }, 'Server listening');
  console.log(`\n🚀 Igor Claude v${VERSION} running at http://localhost:${PORT}`);
  console.log(`📁 Working directory: ${getOriginalCwd()}`);
  console.log(`📝 Logs: ${logDir}\n`);
});

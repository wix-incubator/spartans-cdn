import { Card, CardContent } from '@/components/ui/card';
import { formatTime } from '@/lib/utils';
import type { Message } from '@/types';

interface ToolCallBubbleProps {
  message: Message;
}

export function ToolCallBubble({ message }: ToolCallBubbleProps) {
  return (
    <div className="w-full my-1">
      <Card className="border-border max-h-48 overflow-y-auto">
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-medium font-mono text-muted-foreground">{message.tool}</span>
            <span className="text-[9px] text-muted-foreground/60">{formatTime(message.timestamp)}</span>
          </div>
          {message.args && (
            <pre className="font-mono text-[9px] text-muted-foreground/80 whitespace-pre-wrap break-words">
              {JSON.stringify(message.args, null, 2)}
            </pre>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


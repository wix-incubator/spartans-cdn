import { useState, useEffect } from 'react';
import { History, Loader2, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatTime } from '@/lib/utils';
import type { Message, TokenUsage } from '@/types';

interface SessionInfo {
  sessionId: string;
  startTime: string;
  lastUpdated: string;
  messageCount: number;
  preview: string;
}

interface SessionHistoryProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentSessionId: string | null;
  onLoadSession: (sessionId: string, messages: Message[], tokenUsage: TokenUsage | null) => void;
}

export function SessionHistory({ open, onOpenChange, currentSessionId, onLoadSession }: SessionHistoryProps) {
  const [sessions, setSessions] = useState<SessionInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingSession, setLoadingSession] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchSessions = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/sessions');
      if (res.ok) {
        const data = await res.json();
        setSessions(data.sessions || []);
      } else {
        setError('Failed to load sessions');
      }
    } catch (err) {
      setError('Failed to fetch sessions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchSessions();
    }
  }, [open]);

  const loadSession = async (sessionId: string) => {
    setLoadingSession(sessionId);
    try {
      const res = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}`);
      if (res.ok) {
        const data = await res.json();
        const rawMessages = data.session?.messages || data.messages || [];
        const clientMessages: Message[] = rawMessages.map((msg: any, idx: number) => ({
          id: idx,
          role: msg.type === 'user' ? 'user' : 'assistant',
          type: 'text',
          content: msg.content,
          timestamp: new Date(msg.timestamp).getTime(),
        }));
        onLoadSession(sessionId, clientMessages, data.tokenUsage || null);
        onOpenChange(false);
      } else {
        setError('Failed to load session');
      }
    } catch (err) {
      setError('Failed to load session');
    } finally {
      setLoadingSession(null);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-[350px] sm:w-[400px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <History className="h-4 w-4" />
            History
          </SheetTitle>
        </SheetHeader>
        
        <div className="flex-1 min-h-0 mt-4">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-5 w-5 animate-spin" />
            </div>
          ) : error ? (
            <div className="text-sm text-destructive py-4 text-center">{error}</div>
          ) : sessions.length === 0 ? (
            <div className="text-sm text-muted-foreground py-8 text-center">No saved conversations</div>
          ) : (
            <ScrollArea className="h-[calc(100vh-180px)]">
              <div className="space-y-2 pr-4">
                {sessions.map((session) => (
                  <Card
                    key={session.sessionId}
                    className={`cursor-pointer hover:bg-accent/50 transition-colors ${
                      currentSessionId === session.sessionId ? 'border-primary bg-primary/5' : ''
                    }`}
                    onClick={() => loadSession(session.sessionId)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        {loadingSession === session.sessionId ? (
                          <Loader2 className="h-4 w-4 animate-spin mt-0.5 shrink-0" />
                        ) : (
                          <MessageSquare className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-xs font-medium">
                              {formatTime(new Date(session.lastUpdated).getTime())}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {session.messageCount} msgs
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {session.preview || 'Empty conversation'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>

        <div className="absolute bottom-4 left-6 right-6">
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={fetchSessions}
            disabled={loading}
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Refresh
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}

import type { SettingSource } from '@/types';

// API endpoints
export const API_BASE = '/api';
export const CHAT_API_BASE = typeof window !== 'undefined' && window.location.hostname === 'localhost'
  ? 'http://localhost:3001/api'
  : '/api';

// Available Claude models
export const CLAUDE_MODELS = [
  { id: 'claude-opus-4-5-20251101', name: 'Claude Opus 4.5 (Latest flagship)' },
  { id: 'claude-sonnet-4-5', name: 'Claude Sonnet 4.5 (Strong coding/agent & reasoning)' },
  { id: 'claude-haiku-4-5', name: 'Claude Haiku 4.5 (Lightweight/cost-efficient)' },
] as const;

export type ClaudeModelId = typeof CLAUDE_MODELS[number]['id'];

// Defaults
export const DEFAULT_MODEL: ClaudeModelId = 'claude-sonnet-4-5';
export const DEFAULT_SYSTEM_PROMPT = 'Your name is IGOR';
export const DEFAULT_SETTING_SOURCES: SettingSource[] = ['user', 'project', 'local'];

// App info
export const APP_NAME = '@wix/igor-claude';


import { useState, useRef, useCallback } from 'react';
import type { Message, TokenUsage, ImageData, McpServerWithStatus } from '@/types';
import { API_BASE, CHAT_API_BASE } from '@/constants';
import { enrichCommand } from '@/lib/builtin-commands';

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  isWaitingForFirstChunk: boolean;
  sessionId: string | null;
  status: string;
  error: string | null;
  tokenUsage: TokenUsage | null;
  slashCommands: Array<{ name: string; description?: string; argumentHint?: string }>;
}

export interface UseChatOptions {
  onMcpStatusUpdate?: (servers: Array<{ name: string; status: string }>) => void;
}

export interface UseChatReturn extends ChatState {
  sendMessage: (message: string, options?: SendMessageOptions) => Promise<void>;
  stopRequest: () => Promise<void>;
  startNewChat: () => void;
  loadSession: (newSessionId: string, newMessages: Message[], historicalTokenUsage: TokenUsage | null) => void;
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
  setSessionId: React.Dispatch<React.SetStateAction<string | null>>;
  setTokenUsage: React.Dispatch<React.SetStateAction<TokenUsage | null>>;
}

export interface SendMessageOptions {
  images?: ImageData[];
  systemPrompt?: string;
  systemPromptMode?: 'append' | 'replace';
  model?: string;
  mcpServers?: Record<string, McpServerWithStatus>;
}

export function useChat(options: UseChatOptions = {}): UseChatReturn {
  const { onMcpStatusUpdate } = options;
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isWaitingForFirstChunk, setIsWaitingForFirstChunk] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [status, setStatus] = useState('ready');
  const [error, setError] = useState<string | null>(null);
  const [tokenUsage, setTokenUsage] = useState<TokenUsage | null>(null);
  const [slashCommands, setSlashCommands] = useState<Array<{ name: string; description?: string; argumentHint?: string }>>([]);
  
  const abortControllerRef = useRef<AbortController | null>(null);
  const toolNamesByIdRef = useRef<Map<string, string>>(new Map());

  const startNewChat = useCallback(() => {
    setMessages([]);
    setSessionId(null);
    setTokenUsage(null);
    setSlashCommands([]);
  }, []);

  const loadSession = useCallback((newSessionId: string, newMessages: Message[], historicalTokenUsage: TokenUsage | null) => {
    setSessionId(newSessionId);
    setMessages(newMessages);
    setTokenUsage(historicalTokenUsage);
  }, []);

  const stopRequest = useCallback(async () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    if (sessionId) {
      try {
        await fetch(`${API_BASE}/abort`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId })
        });
      } catch (err) {
        console.error('Error aborting request:', err);
      }
    }
    setIsLoading(false);
    setIsWaitingForFirstChunk(false);
    setStatus('ready');
    setError(null);
  }, [sessionId]);

  // Process individual SSE event
  const processEvent = useCallback((data: any) => {
    // Hide spinner only when we receive actual content (not system/metadata events)
    const contentEvents = ['chunk', 'text_delta', 'thinking_delta', 'tool_call', 'tool_result'];
    if (contentEvents.includes(data.type)) {
      setIsWaitingForFirstChunk(false);
    }

    switch (data.type) {
      case 'init':
        setSessionId(data.sessionId);
        break;

      case 'chunk':
      case 'text_delta':
        setMessages(prev => {
          const lastMsg = prev[prev.length - 1];
          const content = data.text || data.content || '';
          if (lastMsg && lastMsg.role === 'assistant' && lastMsg.type === 'text') {
            return prev.map(msg =>
              msg.id === lastMsg.id
                ? { ...msg, content: (msg.content || '') + content }
                : msg
            );
          } else {
            return [...prev, {
              id: Date.now(),
              role: 'assistant',
              type: 'text',
              content,
              timestamp: Date.now()
            }];
          }
        });
        break;

      case 'assistant_message':
        console.log('🔵 [useChat] Assistant message complete:', data.message);
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'raw_event',
          content: '[ASSISTANT_MESSAGE_COMPLETE]',
          rawData: data,
          timestamp: Date.now()
        }]);
        break;

      case 'thinking_start':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          type: 'thinking',
          content: '',
          timestamp: Date.now()
        }]);
        break;

      case 'thinking_delta':
        setMessages(prev => {
          const lastThinkingIndex = prev.map((m, i) => ({ msg: m, idx: i }))
            .filter(({ msg }) => msg.role === 'assistant' && msg.type === 'thinking')
            .pop()?.idx;

          if (lastThinkingIndex !== undefined) {
            const existingContent = prev[lastThinkingIndex].content || '';
            const newContent = existingContent
              ? `${existingContent}${data.content || ''}`
              : (data.content || '');
            return prev.map((msg, idx) =>
              idx === lastThinkingIndex
                ? { ...msg, content: newContent }
                : msg
            );
          } else {
            return [...prev, {
              id: Date.now(),
              role: 'assistant',
              type: 'thinking',
              content: data.content || '',
              timestamp: Date.now()
            }];
          }
        });
        break;

      case 'thinking_stop':
        // No action needed
        break;

      case 'tool_use_start':
        {
          const toolUseId = String(data.id || Date.now());
          const toolName = data.name || 'tool';
          toolNamesByIdRef.current.set(toolUseId, toolName);
          const messageId = typeof data.id === 'number' ? data.id : Date.now();
          setMessages(prev => [...prev, {
            id: messageId,
            role: 'assistant',
            type: 'tool_call',
            tool: toolName,
            args: {},
            timestamp: Date.now()
          }]);
        }
        break;

      case 'tool_result':
        setMessages(prev => {
          const toolUseId = data.tool_use_id ? String(data.tool_use_id) : null;
          let toolName = 'tool';

          if (toolUseId) {
            toolName = toolNamesByIdRef.current.get(toolUseId) || 'tool';
            if (toolName === 'tool') {
              const toolCallMsg = prev.find(m => String(m.id) === toolUseId && m.type === 'tool_call');
              if (toolCallMsg && toolCallMsg.tool) {
                toolName = toolCallMsg.tool;
                toolNamesByIdRef.current.set(toolUseId, toolName);
              }
            }
          } else {
            const recentToolCall = prev
              .filter(m => m.type === 'tool_call' && m.role === 'assistant')
              .pop();
            if (recentToolCall && recentToolCall.tool) {
              toolName = recentToolCall.tool;
            }
          }

          return [...prev, {
            id: Date.now(),
            role: 'assistant',
            type: 'tool_result',
            tool: toolName,
            response: data.content || '',
            content: data.content || '',
            timestamp: Date.now()
          }];
        });
        break;

      case 'tool_input_delta':
        setMessages(prev => {
          const toolCallIndex = prev.map((m, i) => ({ msg: m, idx: i }))
            .filter(({ msg }) => msg.type === 'tool_call' && msg.role === 'assistant')
            .pop()?.idx;

          if (toolCallIndex !== undefined) {
            const existingArgs = prev[toolCallIndex].args || {};
            const delta = data.partial_json || '';
            const currentStreaming = (existingArgs._streaming as string) || '';
            const accumulatedJson = currentStreaming + delta;

            let parsedArgs: Record<string, unknown> = {};
            try {
              parsedArgs = JSON.parse(accumulatedJson);
              return prev.map((msg, idx) =>
                idx === toolCallIndex
                  ? { ...msg, args: parsedArgs }
                  : msg
              );
            } catch {
              return prev.map((msg, idx) =>
                idx === toolCallIndex
                  ? { ...msg, args: { _streaming: accumulatedJson } }
                  : msg
              );
            }
          }
          return prev;
        });
        break;

      case 'message_start':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'raw_event',
          content: 'message_start',
          rawData: data,
          timestamp: Date.now()
        }]);
        break;

      case 'message_delta':
        if (data.usage) {
          setTokenUsage(prev => {
            if (!prev) {
              return {
                input: data.usage.input_tokens || 0,
                output: data.usage.output_tokens || 0,
                total: (data.usage.input_tokens || 0) + (data.usage.output_tokens || 0),
              };
            }
            return {
              input: prev.input + (data.usage.input_tokens || 0),
              output: prev.output + (data.usage.output_tokens || 0),
              total: prev.total + (data.usage.input_tokens || 0) + (data.usage.output_tokens || 0),
            };
          });
        }
        break;

      case 'message_stop':
        setStatus('ready');
        break;

      case 'system_message':
        if (data.session_id) {
          setSessionId(data.session_id);
        }
        if (data.mcp_servers && Array.isArray(data.mcp_servers) && onMcpStatusUpdate) {
          onMcpStatusUpdate(data.mcp_servers);
        }
        if (data.slash_commands && Array.isArray(data.slash_commands)) {
          console.log('[useChat] Received slash commands from SDK:', data.slash_commands);
          const sdkCommands = data.slash_commands.map((cmd: string | { name: string; description?: string; argumentHint?: string }) => {
            const baseCmd = typeof cmd === 'string' ? { name: cmd } : cmd;
            // Enrich with built-in descriptions if available
            return enrichCommand(baseCmd);
          });
          setSlashCommands(prev => {
            const existingByName = new Map(prev.map(c => [c.name, c]));
            const merged = sdkCommands.map((sdkCmd: { name: string; description?: string; argumentHint?: string }) => {
              const existing = existingByName.get(sdkCmd.name);
              return {
                name: sdkCmd.name,
                description: sdkCmd.description || existing?.description,
                argumentHint: sdkCmd.argumentHint || existing?.argumentHint,
              };
            });
            console.log('[useChat] Merged slash commands:', merged);
            return merged;
          });
        }
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'raw_event',
          content: 'system_message',
          rawData: data,
          timestamp: Date.now()
        }]);
        break;

      case 'auth_status':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'auth_status',
          content: data.output?.join('\n') || (data.isAuthenticating ? 'Authenticating...' : 'Auth complete'),
          rawData: data,
          timestamp: Date.now()
        }]);
        break;

      case 'result':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'raw_event',
          content: 'result',
          rawData: data.data || data,
          timestamp: Date.now()
        }]);
        break;

      case 'warning':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'text',
          content: `Warning: ${data.message}`,
          timestamp: Date.now()
        }]);
        break;

      case 'status':
        if (data.message) {
          setMessages(prev => {
            let lastStatusIndex = -1;
            for (let i = prev.length - 1; i >= 0; i--) {
              if (prev[i].type === 'system_info' && prev[i].content?.startsWith('Status:')) {
                lastStatusIndex = i;
                break;
              }
            }

            if (lastStatusIndex >= 0) {
              const newMessages = [...prev];
              newMessages[lastStatusIndex] = {
                ...newMessages[lastStatusIndex],
                content: `Status: ${data.message}`,
                timestamp: Date.now()
              };
              return newMessages;
            } else {
              return [...prev, {
                id: Date.now(),
                role: 'system',
                type: 'system_info',
                content: `Status: ${data.message}`,
                timestamp: Date.now()
              }];
            }
          });
        }
        if (data.waiting) {
          setStatus(`waiting: ${data.message}`);
        }
        break;

      case 'media':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          type: 'media',
          mimeType: data.mimeType,
          timestamp: Date.now()
        }]);
        break;

      case 'code':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          type: 'code',
          content: data.code,
          language: data.language,
          timestamp: Date.now()
        }]);
        break;

      case 'code_result':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          type: 'code_result',
          content: data.output,
          outcome: data.outcome,
          timestamp: Date.now()
        }]);
        break;

      case 'usage':
        setTokenUsage(prev => {
          if (!prev) return data.tokens;
          return {
            input: prev.input + (data.tokens.input || 0),
            output: prev.output + (data.tokens.output || 0),
            total: prev.total + (data.tokens.total || 0),
          };
        });
        break;

      case 'done':
        setStatus('ready');
        break;

      case 'aborted':
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          type: 'text',
          content: 'Request cancelled.',
          timestamp: Date.now()
        }]);
        setStatus('ready');
        break;

      case 'error':
        {
          const errorText = data.error || 'An error occurred';
          setError(errorText);
          setMessages(prev => [...prev, {
            id: Date.now(),
            role: 'assistant',
            type: 'text',
            content: `**Error:** ${errorText}`,
            timestamp: Date.now()
          }]);
          setStatus('error');
        }
        break;

      default:
        console.log('[useChat] Displaying unhandled event type as raw:', data.type);
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'system',
          type: 'raw_event',
          content: data.type || 'unknown_event',
          rawData: data,
          timestamp: Date.now()
        }]);
    }
  }, [onMcpStatusUpdate]);

  const sendMessage = useCallback(async (message: string, sendOptions: SendMessageOptions = {}) => {
    const { images, systemPrompt, systemPromptMode, model, mcpServers } = sendOptions;
    const trimmedMessage = message.trim();
    const hasImages = images && images.length > 0;

    if (!trimmedMessage && !hasImages) return;
    if (isLoading) return;

    setError(null);

    // Create user message
    const userMessage: Message = {
      id: Date.now(),
      role: 'user',
      type: 'text',
      content: trimmedMessage || '',
      images: hasImages ? images : undefined,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setIsWaitingForFirstChunk(true);
    setStatus('sending');

    abortControllerRef.current = new AbortController();
    const currentAbortController = abortControllerRef.current;

    try {
      const requestBody: {
        message: string;
        sessionId: string | null;
        systemPrompt?: string;
        systemPromptMode?: 'append' | 'replace';
        model?: string;
        mcpServers?: Record<string, any>;
        images?: ImageData[];
      } = {
        message: trimmedMessage,
        sessionId,
        model
      };

      if (systemPrompt?.trim()) {
        requestBody.systemPrompt = systemPrompt.trim();
        requestBody.systemPromptMode = systemPromptMode;
      }

      if (hasImages) {
        requestBody.images = images;
      }

      if (mcpServers && Object.keys(mcpServers).length > 0) {
        const mcpForSdk: Record<string, any> = {};
        for (const [name, config] of Object.entries(mcpServers)) {
          mcpForSdk[name] = {
            type: config.type,
            url: config.url,
            ...(config.headers && { headers: config.headers }),
          };
        }
        requestBody.mcpServers = mcpForSdk;
      }

      const response = await fetch(`${CHAT_API_BASE}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
        signal: currentAbortController.signal
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `HTTP ${response.status}`;
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      setStatus('connected');
      if (!response.body) {
        throw new Error('Response body is null');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (currentAbortController.signal.aborted) break;

        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split('\n\n');
        buffer = parts.pop() || '';

        for (const part of parts) {
          const lines = part.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const rawData = line.slice(6);
                const data = JSON.parse(rawData);
                processEvent(data);
              } catch (err) {
                console.error('Parse error:', err, 'Line:', line);
              }
            }
          }
        }
      }

      // Process remaining buffer
      if (buffer.trim()) {
        const lines = buffer.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.type === 'done') setStatus('ready');
            } catch (err) {}
          }
        }
      }

    } catch (error) {
      console.error('Error:', error);
      if (error instanceof Error && error.name === 'AbortError') {
        setStatus('ready');
      } else {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        setError(errorMessage);
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          type: 'text',
          content: `Error: ${errorMessage}`,
          timestamp: Date.now()
        }]);
        setStatus('error');
      }
    } finally {
      setIsLoading(false);
      setIsWaitingForFirstChunk(false);
      abortControllerRef.current = null;
      if (status !== 'error') {
        setStatus('ready');
      }
    }
  }, [isLoading, sessionId, status, processEvent]);

  return {
    messages,
    isLoading,
    isWaitingForFirstChunk,
    sessionId,
    status,
    error,
    tokenUsage,
    slashCommands,
    sendMessage,
    stopRequest,
    startNewChat,
    loadSession,
    setMessages,
    setSessionId,
    setTokenUsage,
  };
}


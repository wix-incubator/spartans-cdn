import { useState, useEffect, useCallback } from 'react';
import type { McpServerWithStatus, PluginWithStatus } from '@/types';
import {
  API_BASE,
  CLAUDE_MODELS,
  DEFAULT_MODEL,
  DEFAULT_SYSTEM_PROMPT,
  DEFAULT_SETTING_SOURCES,
} from '@/constants';

// Re-export for convenience
export { CLAUDE_MODELS };

export type SettingSource = 'user' | 'project' | 'local';

export interface UseSettingsReturn {
  // System prompt
  systemPrompt: string;
  setSystemPrompt: (value: string) => void;
  systemPromptMode: 'append' | 'replace';
  setSystemPromptMode: (value: 'append' | 'replace') => void;
  
  // Model
  model: string;
  setModel: (value: string) => void;
  
  // Setting sources
  settingSources: SettingSource[];
  setSettingSources: (sources: SettingSource[]) => void;
  
  // MCP servers
  mcpServers: Record<string, McpServerWithStatus>;
  addMcpServer: (name: string, config: McpServerWithStatus) => void;
  removeMcpServer: (name: string) => void;
  updateMcpStatusFromSystem: (status: Array<{ name: string; status: string; serverInfo?: any }>) => void;
  mcpLoading: boolean;
  
  // Plugins
  plugins: PluginWithStatus[];
  pluginsLoading: boolean;
  
  // Display settings
  showSystemMessages: boolean;
  setShowSystemMessages: (show: boolean) => void;
  
  // App info
  appVersion: string | undefined;
  appCwd: string | undefined;
  
  // Actions
  saveSettings: () => Promise<void>;
  clearPrompt: () => Promise<void>;
}

export function useSettings(): UseSettingsReturn {
  // System prompt state
  const [systemPrompt, setSystemPrompt] = useState(DEFAULT_SYSTEM_PROMPT);
  const [systemPromptMode, setSystemPromptMode] = useState<'append' | 'replace'>('append');
  
  // Model state
  const [model, setModel] = useState(DEFAULT_MODEL);
  
  // Setting sources
  const [settingSources, setSettingSources] = useState<SettingSource[]>(DEFAULT_SETTING_SOURCES);
  
  // MCP servers
  const [mcpServers, setMcpServers] = useState<Record<string, McpServerWithStatus>>({});
  const [mcpLoading, setMcpLoading] = useState(false);
  
  // Plugins
  const [plugins, setPlugins] = useState<PluginWithStatus[]>([]);
  const [pluginsLoading, setPluginsLoading] = useState(false);
  
  // Display settings
  const [showSystemMessages, setShowSystemMessages] = useState(false);
  
  // App info
  const [appVersion, setAppVersion] = useState<string | undefined>();
  const [appCwd, setAppCwd] = useState<string | undefined>();

  // Load settings from server on mount
  useEffect(() => {
    fetch(`${API_BASE}/settings`)
      .then(res => res.json())
      .then(settings => {
        if (settings.systemPrompt) setSystemPrompt(settings.systemPrompt);
        if (settings.systemPromptMode) setSystemPromptMode(settings.systemPromptMode);
        if (settings.model) {
          const isValidModel = CLAUDE_MODELS.some(m => m.id === settings.model);
          if (isValidModel) {
            setModel(settings.model);
          }
        }
        if (settings.settingSources && Array.isArray(settings.settingSources)) {
          setSettingSources(settings.settingSources);
        }
        if (settings.mcpServers && typeof settings.mcpServers === 'object') {
          setMcpServers(settings.mcpServers);
        }
        if (typeof settings.showSystemMessages === 'boolean') {
          setShowSystemMessages(settings.showSystemMessages);
        }
      })
      .catch(err => {
        console.error('Failed to load settings:', err);
      });
  }, []);

  // Fetch version and cwd on mount
  useEffect(() => {
    fetch(`${API_BASE}/version`)
      .then(res => res.json())
      .then(data => {
        setAppVersion(data.version);
        setAppCwd(data.cwd);
      })
      .catch(() => {
        setAppVersion(undefined);
        setAppCwd(undefined);
      });
  }, []);

  // Fetch plugins on mount
  useEffect(() => {
    setPluginsLoading(true);
    fetch(`${API_BASE}/plugins`)
      .then(res => res.json())
      .then(data => {
        if (data.plugins && Array.isArray(data.plugins)) {
          setPlugins(data.plugins);
        }
      })
      .catch(err => {
        console.error('Failed to load plugins:', err);
      })
      .finally(() => {
        setPluginsLoading(false);
      });
  }, []);

  // MCP server management
  const addMcpServer = useCallback((name: string, config: McpServerWithStatus) => {
    setMcpServers(prev => ({ ...prev, [name]: config }));
  }, []);

  const removeMcpServer = useCallback((name: string) => {
    setMcpServers(prev => {
      const updated = { ...prev };
      delete updated[name];
      return updated;
    });
  }, []);

  const updateMcpStatusFromSystem = useCallback((mcpStatus: Array<{ name: string; status: string; serverInfo?: any }>) => {
    if (!mcpStatus || mcpStatus.length === 0) return;
    
    setMcpServers(prev => {
      const updated = { ...prev };
      for (const server of mcpStatus) {
        if (updated[server.name]) {
          updated[server.name] = {
            ...updated[server.name],
            status: server.status as McpServerWithStatus['status'],
            serverInfo: server.serverInfo,
          };
        }
      }
      return updated;
    });
  }, []);

  // Save settings to server
  const saveSettings = useCallback(async () => {
    const cleanMcpServers: Record<string, { type: 'http'; url: string; headers?: Record<string, string> }> = {};
    for (const [name, config] of Object.entries(mcpServers)) {
      cleanMcpServers[name] = {
        type: 'http',
        url: config.url,
        ...(config.headers && { headers: config.headers }),
      };
    }

    await fetch(`${API_BASE}/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemPrompt,
        systemPromptMode,
        model,
        settingSources,
        mcpServers: cleanMcpServers,
        showSystemMessages,
      }),
    });
  }, [systemPrompt, systemPromptMode, model, settingSources, mcpServers, showSystemMessages]);

  // Clear system prompt
  const clearPrompt = useCallback(async () => {
    setSystemPrompt('');
    await fetch(`${API_BASE}/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemPrompt: '',
        systemPromptMode,
        model,
        settingSources,
        showSystemMessages,
      }),
    });
  }, [systemPromptMode, model, settingSources, showSystemMessages]);

  return {
    systemPrompt,
    setSystemPrompt,
    systemPromptMode,
    setSystemPromptMode,
    model,
    setModel,
    settingSources,
    setSettingSources,
    mcpServers,
    addMcpServer,
    removeMcpServer,
    updateMcpStatusFromSystem,
    mcpLoading,
    plugins,
    pluginsLoading,
    showSystemMessages,
    setShowSystemMessages,
    appVersion,
    appCwd,
    saveSettings,
    clearPrompt,
  };
}


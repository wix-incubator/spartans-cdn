import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { formatDistanceToNow, format, isToday } from "date-fns"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTime(timestamp: number): string {
  const date = new Date(timestamp);
  const now = Date.now();
  const diff = now - timestamp;
  
  // Less than 1 minute - show relative
  if (diff < 60 * 1000) {
    return 'just now';
  }
  
  // Less than 1 hour - show relative (e.g. "5 minutes ago")
  if (diff < 60 * 60 * 1000) {
    return formatDistanceToNow(date, { addSuffix: true });
  }
  
  // Today - show time with seconds
  if (isToday(date)) {
    return format(date, 'HH:mm:ss');
  }
  
  // Older - show date and time
  return format(date, 'MMM d, HH:mm');
}


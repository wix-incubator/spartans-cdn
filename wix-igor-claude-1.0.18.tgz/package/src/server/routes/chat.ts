import { type Request, type Response, type Router } from 'express';
import { existsSync } from 'fs';
import { query } from '@anthropic-ai/claude-agent-sdk';
import { createLogger } from '../../lib/logger';
import { getOriginalCwd } from '../config';
import type { Marketplace, ImageData } from '../types';
import { resolvePluginPath } from '../services/marketplace';

const log = createLogger('chat');

// These will be set by the parent server
let MARKETPLACE: Marketplace | null = null;
let CLAUDE_EXECUTABLE_PATH: string | undefined;
let abortControllers: Map<string, AbortController>;
let updateMcpStatus: (servers: Array<{ name: string; status: string }>) => void;

export function initChatRoute(options: {
  marketplace: Marketplace | null;
  claudeExecutablePath: string | undefined;
  abortControllersMap: Map<string, AbortController>;
  onMcpStatusUpdate: (servers: Array<{ name: string; status: string }>) => void;
}) {
  MARKETPLACE = options.marketplace;
  CLAUDE_EXECUTABLE_PATH = options.claudeExecutablePath;
  abortControllers = options.abortControllersMap;
  updateMcpStatus = options.onMcpStatusUpdate;
}

export async function handleChatRequest(req: Request, res: Response) {
  const { message, sessionId, model, systemPromptMode, images } = req.body as {
    message?: string;
    sessionId?: string | null;
    model?: string;
    systemPromptMode?: 'append' | 'replace';
    images?: ImageData[];
  };

  const hasImages = images && Array.isArray(images) && images.length > 0;

  log.info({
    sessionId: sessionId || 'new',
    messageType: typeof message,
    messagePreview: message?.substring(0, 50),
    model: model || 'default',
    imageCount: hasImages ? images.length : 0,
  }, 'POST /api/chat');

  if (hasImages) {
    log.debug({ imageCount: images.length }, 'Images received');
    images.forEach((img, i) => {
      log.debug({
        index: i + 1,
        fileName: img.fileName,
        mediaType: img.mediaType,
        dataLength: img.data?.length || 0
      }, 'Image details');
    });
  }

  // Allow empty message if images are provided
  if ((!message || message.trim() === '') && !hasImages) {
    log.warn('Message or images are required');
    return res.status(400).json({ error: 'Message or images are required' });
  }

  // Extract optional system prompt
  const systemPrompt = req.body.systemPrompt;
  const mode = systemPromptMode || 'append';

  // Debug logging for system prompt
  if (process.env.DEBUG === 'true') {
    log.debug({
      bodyKeys: Object.keys(req.body),
      systemPrompt: req.body.systemPrompt,
      systemPromptMode: req.body.systemPromptMode,
      systemPromptVar: systemPrompt,
      systemPromptType: typeof systemPrompt,
      systemPromptTrimmed: systemPrompt?.trim(),
      mode,
    }, 'System prompt debug');
  }

  const sid = sessionId || `session-${Date.now()}`;

  // Set up SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  // Helper to write SSE and flush
  const sseWrite = (data: string) => {
    if (!res.closed && !res.destroyed) {
      res.write(data);
      if (typeof (res as any).flush === 'function') {
        (res as any).flush();
      }
    }
  };

  // Create abort signal and request ID
  const abortController = new AbortController();
  const requestId = `${sid}-${Date.now()}`;
  abortControllers.set(requestId, abortController);

  let isCompleted = false;

  // Helper function to safely send error to client
  const sendError = (errorMessage: string, errorDetails?: any) => {
    try {
      if (!res.closed && !res.destroyed) {
        const errorData = {
          type: 'error',
          error: errorMessage,
          ...(errorDetails && { details: errorDetails }),
        };
        sseWrite(`data: ${JSON.stringify(errorData)}\n\n`);
        log.debug({ errorMessage, errorDetails }, 'Error sent to client');
      } else {
        log.warn({ errorMessage }, 'Cannot send error - connection closed');
      }
    } catch (err) {
      log.error({ err }, 'Failed to send error to client');
    }
  };

  // Cleanup on close
  res.on('close', () => {
    if (!isCompleted) {
      log.debug({ sessionId: sid }, 'SSE connection closed');
      abortControllers.delete(requestId);
    }
  });

  let keepAliveInterval: NodeJS.Timeout | null = null;

  try {
    // Double-check API key
    if (!process.env.ANTHROPIC_API_KEY) {
      sendError('ANTHROPIC_API_KEY environment variable is required.');
      return res.end();
    }

    // Send initial event
    sseWrite(`data: ${JSON.stringify({ type: 'init', sessionId: sid })}\n\n`);

    let lastActivityTime = Date.now();

    // Send periodic status updates
    keepAliveInterval = setInterval(() => {
      if (!res.closed && !isCompleted) {
        try {
          const waitTime = Math.round((Date.now() - lastActivityTime) / 1000);
          if (waitTime > 5) {
            sseWrite(`data: ${JSON.stringify({
              type: 'status',
              message: `Waiting for response... (${waitTime}s)`,
              waiting: true
            })}\n\n`);
          } else {
            sseWrite(`: keepalive\n\n`);
          }
        } catch (err) {
          if (keepAliveInterval) clearInterval(keepAliveInterval);
        }
      } else {
        if (keepAliveInterval) clearInterval(keepAliveInterval);
      }
    }, 3000);

    const markActivity = () => { lastActivityTime = Date.now(); };

    log.debug({ sessionId: sid }, 'Starting to stream response');
    const messageToSend: string = String(message).trim();

    if (!messageToSend && !hasImages) {
      if (keepAliveInterval) clearInterval(keepAliveInterval);
      abortControllers.delete(requestId);
      throw new Error('Message cannot be empty');
    }

    log.debug({ sessionId: sid }, 'Starting Claude query');

    let accumulatedText = '';
    let chunkCount = 0;
    let currentSessionId: string | null = sid;

    // Prepare prompt input
    let promptInput: string | AsyncIterable<any>;

    if (hasImages) {
      log.debug({ imageCount: images.length }, 'Creating prompt with images');

      promptInput = (async function* () {
        const contentBlocks: any[] = [];

        if (messageToSend.trim()) {
          contentBlocks.push({ type: 'text', text: messageToSend });
        }

        for (const img of images!) {
          contentBlocks.push({
            type: 'image',
            source: {
              type: 'base64',
              media_type: img.mediaType,
              data: img.data,
            },
          });
        }

        log.debug({ blockCount: contentBlocks.length }, 'Creating async generator with content blocks');

        const userMessage = {
          type: 'user',
          message: { role: 'user', content: contentBlocks },
          parent_tool_use_id: null,
          session_id: sessionId || 'default',
        };

        log.debug({ blockCount: contentBlocks.length }, 'Yielding user message');
        yield userMessage;
      })();
    } else {
      promptInput = messageToSend;
    }

    // MCP servers from request
    const mcpServers = req.body.mcpServers || {};
    if (Object.keys(mcpServers).length > 0) {
      log.debug({ mcpServers }, 'MCP servers from request');
    }

    // Load marketplace plugins
    const plugins: { type: 'local'; path: string }[] = [];
    if (MARKETPLACE) {
      for (const plugin of MARKETPLACE.plugins) {
        const pluginPath = resolvePluginPath(plugin.source);
        if (existsSync(pluginPath)) {
          plugins.push({ type: 'local', path: pluginPath });
          log.debug({ plugin: plugin.name, path: pluginPath }, 'Plugin loaded');
        } else {
          log.warn({ plugin: plugin.name, path: pluginPath }, 'Plugin path not found');
        }
      }
    }

    if (plugins.length > 0) {
      log.info({ pluginCount: plugins.length, plugins: plugins.map(p => p.path) }, 'Loaded marketplace plugins');
    }

    const queryOptions: any = {
      cwd: getOriginalCwd(),
      model: model || undefined,
      permissionMode: 'bypassPermissions',
      maxTurns: 1000,
      settingSources: ['user', 'project', 'local'],
      resume: sessionId || undefined,
      includePartialMessages: true,
      ...(CLAUDE_EXECUTABLE_PATH && { pathToClaudeCodeExecutable: CLAUDE_EXECUTABLE_PATH }),
      ...(Object.keys(mcpServers).length > 0 && { mcpServers }),
      ...(plugins.length > 0 && { plugins }),
    };

    // Add system prompt
    if (systemPrompt && systemPrompt.trim()) {
      if (mode === 'replace') {
        queryOptions.systemPrompt = systemPrompt.trim();
        log.debug({ mode: 'replace', systemPrompt: queryOptions.systemPrompt }, 'Using REPLACE mode');
      } else {
        queryOptions.systemPrompt = {
          type: 'preset',
          preset: 'claude_code',
          append: systemPrompt.trim(),
        };
        log.debug({ mode: 'append', systemPrompt: queryOptions.systemPrompt }, 'Using APPEND mode');
      }
    } else {
      log.debug('No system prompt provided - using default');
    }

    // Add env
    queryOptions.env = {
      PATH: process.env.PATH || '',
      ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
      MAX_THINKING_TOKENS: process.env.MAX_THINKING_TOKENS || '10000',
      IS_SANDBOX: process.env.IS_SANDBOX || '0',
      SANDBOX_ID: process.env.SANDBOX_ID || '',
      ...(process.env.ANTHROPIC_BASE_URL && { ANTHROPIC_BASE_URL: process.env.ANTHROPIC_BASE_URL }),
      ...(process.env.ANTHROPIC_CUSTOM_HEADERS && { ANTHROPIC_CUSTOM_HEADERS: process.env.ANTHROPIC_CUSTOM_HEADERS }),
      ...process.env,
    };

    if (process.env.DEBUG === 'true') {
      log.debug({ systemPrompt: queryOptions.systemPrompt }, 'Final queryOptions.systemPrompt');
    }

    const queryIterator = query({
      prompt: promptInput,
      options: queryOptions,
    });

    const contentBlocksByIndex = new Map<number, string>();

    try {
      for await (const message of queryIterator) {
        if (abortController.signal.aborted) {
          log.debug({ sessionId: sid }, 'Stream aborted');
          if (!res.closed) {
            sseWrite(`data: ${JSON.stringify({ type: 'aborted' })}\n\n`);
          }
          break;
        }

        markActivity();
        const msgType = message.type;

        if (process.env.DEBUG === 'true') {
          log.debug({ msgType, message }, 'Full raw message');
        }

        if (msgType === 'assistant') {
          sseWrite(`data: ${JSON.stringify({
            type: 'assistant_message',
            message: (message as any).message,
            timestamp: new Date().toISOString()
          })}\n\n`);
        } else if (msgType === 'result') {
          const resultMessage = message as any;
          const result = resultMessage.result;

          if (result && typeof result === 'object' && 'tool_use_id' in result) {
            sseWrite(`data: ${JSON.stringify({
              type: 'tool_result',
              content: result.content || null,
              tool_use_id: result.tool_use_id || null,
              timestamp: new Date().toISOString()
            })}\n\n`);
          } else {
            sseWrite(`data: ${JSON.stringify({
              type: 'result',
              data: message,
              timestamp: new Date().toISOString()
            })}\n\n`);
            if (typeof (res as any).flush === 'function') {
              (res as any).flush();
            }
          }
        } else if (msgType === 'system') {
          const sessionIdFromMessage = (message as any).session_id;
          if (sessionIdFromMessage && sessionIdFromMessage !== currentSessionId) {
            log.debug({ sessionId: sessionIdFromMessage }, 'Captured session ID');
            currentSessionId = sessionIdFromMessage;
          }

          const mcpServersStatus = (message as any).mcp_servers;
          if (mcpServersStatus && Array.isArray(mcpServersStatus)) {
            log.debug({ mcpServers: mcpServersStatus }, 'MCP servers status');
            updateMcpStatus(mcpServersStatus);
          }

          const systemEvent = {
            ...message,
            type: 'system_message',
            timestamp: new Date().toISOString()
          };
          sseWrite(`data: ${JSON.stringify(systemEvent)}\n\n`);
          if (typeof (res as any).flush === 'function') {
            (res as any).flush();
          }

          if (sessionIdFromMessage) {
            sseWrite(`data: ${JSON.stringify({ type: 'init', sessionId: sessionIdFromMessage })}\n\n`);
          }
        } else if (msgType === 'stream_event') {
          const event = (message as any).event;

          if (event?.type === 'content_block_start') {
            const contentBlock = event.content_block;
            contentBlocksByIndex.set(event.index, contentBlock?.type);

            if (contentBlock?.type === 'thinking') {
              sseWrite(`data: ${JSON.stringify({ type: 'thinking_start', timestamp: new Date().toISOString() })}\n\n`);
            } else if (contentBlock?.type === 'tool_use') {
              sseWrite(`data: ${JSON.stringify({
                type: 'tool_use_start',
                id: contentBlock.id,
                name: contentBlock.name,
                index: event.index,
                timestamp: new Date().toISOString()
              })}\n\n`);
            }
          } else if (event?.type === 'content_block_delta') {
            const delta = event.delta;
            if (delta?.type === 'thinking_delta' && delta.thinking) {
              sseWrite(`data: ${JSON.stringify({
                type: 'thinking_delta',
                content: delta.thinking,
                timestamp: new Date().toISOString()
              })}\n\n`);
            } else if (delta?.type === 'text_delta' && delta.text) {
              accumulatedText += delta.text;
              chunkCount++;
              sseWrite(`data: ${JSON.stringify({
                type: 'text_delta',
                content: delta.text,
                timestamp: new Date().toISOString()
              })}\n\n`);
            } else if (delta?.type === 'input_json_delta') {
              sseWrite(`data: ${JSON.stringify({
                type: 'tool_input_delta',
                index: event.index,
                partial_json: delta.partial_json || '',
                timestamp: new Date().toISOString()
              })}\n\n`);
            }
          } else if (event?.type === 'content_block_stop') {
            const blockType = contentBlocksByIndex.get(event.index);
            if (blockType === 'thinking') {
              sseWrite(`data: ${JSON.stringify({ type: 'thinking_stop', timestamp: new Date().toISOString() })}\n\n`);
            } else if (blockType === 'tool_use') {
              sseWrite(`data: ${JSON.stringify({
                type: 'content_block_stop',
                index: event.index,
                timestamp: new Date().toISOString()
              })}\n\n`);
            }
          } else if (event?.type === 'message_start') {
            sseWrite(`data: ${JSON.stringify({
              type: 'message_start',
              model: event.message?.model,
              usage: event.message?.usage,
              timestamp: new Date().toISOString()
            })}\n\n`);
          } else if (event?.type === 'message_delta') {
            sseWrite(`data: ${JSON.stringify({
              type: 'message_delta',
              stop_reason: event.delta?.stop_reason,
              usage: event.usage,
              timestamp: new Date().toISOString()
            })}\n\n`);

            if (event.usage) {
              sseWrite(`data: ${JSON.stringify({
                type: 'usage',
                tokens: {
                  input: event.usage.input_tokens || 0,
                  output: event.usage.output_tokens || 0,
                  total: (event.usage.input_tokens || 0) + (event.usage.output_tokens || 0),
                }
              })}\n\n`);
            }
          } else if (event?.type === 'message_stop') {
            sseWrite(`data: ${JSON.stringify({ type: 'message_stop', timestamp: new Date().toISOString() })}\n\n`);
          } else {
            log.debug({ eventType: event?.type }, 'Unhandled stream event');
          }
        } else if (msgType === 'auth_status') {
          const authMessage = message as any;
          sseWrite(`data: ${JSON.stringify({
            type: 'auth_status',
            isAuthenticating: authMessage.isAuthenticating,
            output: authMessage.output || [],
            error: authMessage.error,
            timestamp: new Date().toISOString()
          })}\n\n`);
        } else if ((msgType as string) === 'error') {
          const errorMessage = (message as any).error?.message || 'Unknown error';
          log.error({ errorMessage }, 'Stream error');
          sendError(errorMessage);
        } else {
          log.debug({ msgType }, 'Unhandled message type');
        }
      }
    } catch (error) {
      if (abortController.signal.aborted) {
        log.debug({ sessionId: sid }, 'Stream aborted (caught in error handler)');
        if (!res.closed && !res.destroyed) {
          sseWrite(`data: ${JSON.stringify({ type: 'aborted' })}\n\n`);
        }
      } else {
        throw error;
      }
    } finally {
      if (keepAliveInterval) clearInterval(keepAliveInterval);
      abortControllers.delete(requestId);
    }

    isCompleted = true;
    log.info({ sessionId: sid, chunkCount, textLength: accumulatedText.length }, 'Query complete');
    if (!res.closed) {
      sseWrite(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
      res.end();
    }
  } catch (error) {
    log.error({ err: error, sessionId: sid }, 'Error in chat stream');
    if (error instanceof Error && error.stack) {
      log.debug({ stack: error.stack }, 'Error stack');
    }

    if (requestId) {
      abortControllers.delete(requestId);
    }

    isCompleted = true;
    if (keepAliveInterval) clearInterval(keepAliveInterval);

    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    const errorDetails = error instanceof Error ? { stack: error.stack } : undefined;
    sendError(errorMessage, errorDetails);

    try {
      if (!res.closed && !res.destroyed) {
        sseWrite(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
        res.end();
      }
    } catch (writeError) {
      log.error({ err: writeError }, 'Failed to end response');
    }
  }
}


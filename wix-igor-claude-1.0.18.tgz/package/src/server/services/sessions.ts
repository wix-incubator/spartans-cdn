import { existsSync, readdirSync, readFileSync, statSync, unlinkSync } from 'fs';
import { join, basename } from 'path';
import { createHash } from 'crypto';
import { createLogger } from '../../lib/logger';
import { CLAUDE_DIR, getOriginalCwd } from '../config';

const log = createLogger('sessions');

// Re-export for convenience
export { getOriginalCwd };

export interface SessionInfo {
  id: string;
  lastMessage: string;
  timestamp: number;
  messageCount?: number;
  messages?: any[];
  tokenUsage?: {
    input: number;
    output: number;
    total: number;
  };
}

interface ConversationRecord {
  role: string;
  type: string;
  content: string;
  timestamp: number;
  rawData?: any;
  toolName?: string;
  toolUseId?: string;
  input?: any;
  images?: any[];
}

function getProjectHash(projectRoot: string): string {
  return createHash('sha256').update(projectRoot).digest('hex');
}

// Get project storage directory for Claude sessions
export function getProjectStorageDir(): string {
  const projectRoot = getOriginalCwd();
  const hash = getProjectHash(projectRoot);
  return join(CLAUDE_DIR, 'projects', `-${hash}`);
}

// Helper function to extract readable content from various message formats
function extractContent(data: any): string {
  if (!data) return '';
  
  // Handle string directly
  if (typeof data === 'string') return data;
  
  // Handle arrays (like Claude's content blocks)
  if (Array.isArray(data)) {
    return data
      .filter(block => block.type === 'text' && block.text)
      .map(block => block.text)
      .join('\n');
  }
  
  // Handle message object with content
  if (data.content) {
    return extractContent(data.content);
  }
  
  // Handle message object with text
  if (data.text) {
    return data.text;
  }
  
  // Handle result object
  if (data.result && typeof data.result === 'string') {
    return data.result;
  }
  
  // Try to stringify for debugging
  try {
    const str = JSON.stringify(data);
    if (str.length < 200) return str;
    return str.substring(0, 200) + '...';
  } catch {
    return '[Complex object]';
  }
}

// Helper function to parse a single JSONL entry
function parseEntry(data: any): ConversationRecord | null {
  const type = data.type;
  
  // User messages
  if (type === 'user') {
    const content = extractContent(data.message);
    return {
      role: 'user',
      type: 'text',
      content,
      timestamp: data.timestamp ? new Date(data.timestamp).getTime() : Date.now(),
      rawData: data.message,
    };
  }
  
  // Assistant messages
  if (type === 'assistant') {
    const content = extractContent(data.message);
    return {
      role: 'assistant',
      type: 'text',
      content,
      timestamp: data.timestamp ? new Date(data.timestamp).getTime() : Date.now(),
      rawData: data.message,
    };
  }
  
  // Result messages (tool results)
  if (type === 'result') {
    const result = data.result;
    if (result && typeof result === 'object' && 'tool_use_id' in result) {
      return {
        role: 'system',
        type: 'tool_result',
        content: extractContent(result.content),
        toolUseId: result.tool_use_id,
        timestamp: data.timestamp ? new Date(data.timestamp).getTime() : Date.now(),
        rawData: result,
      };
    }
    // Final result with usage stats
    return {
      role: 'system',
      type: 'result',
      content: 'Query complete',
      timestamp: data.timestamp ? new Date(data.timestamp).getTime() : Date.now(),
      rawData: data,
    };
  }
  
  // System messages
  if (type === 'system') {
    return {
      role: 'system',
      type: 'system',
      content: data.subtype || 'system',
      timestamp: data.timestamp ? new Date(data.timestamp).getTime() : Date.now(),
      rawData: data,
    };
  }
  
  return null;
}

// List all sessions
export function listSessions(): SessionInfo[] {
  const projectDir = getProjectStorageDir();
  
  if (!existsSync(projectDir)) {
    return [];
  }
  
  const sessions: SessionInfo[] = [];
  
  try {
    const files = readdirSync(projectDir).filter(f => f.endsWith('.jsonl'));
    
    for (const file of files) {
      const filePath = join(projectDir, file);
      const stat = statSync(filePath);
      const sessionId = basename(file, '.jsonl');
      
      try {
        const content = readFileSync(filePath, 'utf-8');
        const lines = content.trim().split('\n').filter(line => line.trim());
        
        let lastMessage = '';
        let messageCount = 0;
        
        for (const line of lines) {
          try {
            const entry = JSON.parse(line);
            if (entry.type === 'user' || entry.type === 'assistant') {
              messageCount++;
              lastMessage = extractContent(entry.message);
            }
          } catch {
            // Skip malformed lines
          }
        }
        
        sessions.push({
          id: sessionId,
          lastMessage: lastMessage.substring(0, 100),
          timestamp: stat.mtime.getTime(),
          messageCount,
        });
      } catch (err) {
        log.warn({ file, err }, 'Failed to parse session file');
      }
    }
  } catch (err) {
    log.error({ err }, 'Failed to list sessions');
  }
  
  // Sort by most recent first
  return sessions.sort((a, b) => b.timestamp - a.timestamp);
}

// Load a specific session
export function loadSession(sessionId: string): { messages: ConversationRecord[]; tokenUsage: any } | null {
  const projectDir = getProjectStorageDir();
  const sessionPath = join(projectDir, `${sessionId}.jsonl`);
  
  if (!existsSync(sessionPath)) {
    return null;
  }
  
  const messages: ConversationRecord[] = [];
  let tokenUsage = { input: 0, output: 0, total: 0 };
  
  try {
    const content = readFileSync(sessionPath, 'utf-8');
    const lines = content.trim().split('\n').filter(line => line.trim());
    
    for (const line of lines) {
      try {
        const entry = JSON.parse(line);
        const parsed = parseEntry(entry);
        if (parsed) {
          messages.push(parsed);
        }
        
        // Extract token usage from result messages
        if (entry.type === 'result' && entry.result?.usage) {
          const usage = entry.result.usage;
          tokenUsage.input += usage.input_tokens || 0;
          tokenUsage.output += usage.output_tokens || 0;
          tokenUsage.total += (usage.input_tokens || 0) + (usage.output_tokens || 0);
        }
      } catch {
        // Skip malformed lines
      }
    }
  } catch (err) {
    log.error({ sessionId, err }, 'Failed to load session');
    return null;
  }
  
  return { messages, tokenUsage };
}

// Delete a session
export function deleteSession(sessionId: string): boolean {
  const projectDir = getProjectStorageDir();
  const sessionPath = join(projectDir, `${sessionId}.jsonl`);
  
  if (!existsSync(sessionPath)) {
    return false;
  }
  
  try {
    unlinkSync(sessionPath);
    log.info({ sessionId }, 'Session deleted');
    return true;
  } catch (err) {
    log.error({ sessionId, err }, 'Failed to delete session');
    return false;
  }
}

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: process.env.VITE_PORT ? parseInt(process.env.VITE_PORT, 10) : 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
        // Increase timeout for long-running SSE connections
        timeout: 600000, // 10 minutes
        proxyTimeout: 600000,
        // Don't close the connection on client abort during streaming
        selfHandleResponse: false,
      },
    },
  },
  build: {
    outDir: 'dist',
  },
});


import { useState, useCallback } from 'react';
import { ChatHeader } from '@/components/chat-header';
import { MessageList } from '@/components/message-list';
import { ChatInput } from '@/components/chat-input';
import { SettingsDialog } from '@/components/settings-dialog';
import { SessionHistory } from '@/components/session-history';
import { ErrorBoundary } from '@/components/error-boundary';
import { useChat } from '@/hooks/useChat';
import { useSettings, CLAUDE_MODELS } from '@/hooks/useSettings';
import { useSlashCommands } from '@/hooks/useSlashCommands';
import type { ImageData } from '@/types';

function App() {
  // UI state (local to App)
  const [input, setInput] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Settings hook - handles all settings state and persistence
  const settings = useSettings();

  // Chat hook - handles messages, SSE, and chat state
  const chat = useChat({
    onMcpStatusUpdate: settings.updateMcpStatusFromSystem,
  });

  // Slash commands hook - merges plugin, SDK, and built-in commands
  const slashCommands = useSlashCommands({
    plugins: settings.plugins,
    sdkCommands: chat.slashCommands,
  });

  // Wrap sendMessage to include settings
  const handleSendMessage = useCallback(async (e?: React.FormEvent, images?: ImageData[]) => {
    e?.preventDefault();
    const message = input.trim();
    const hasImages = images && images.length > 0;

    if (!message && !hasImages) return;
    
    setInput('');
    
    await chat.sendMessage(message, {
      images,
      systemPrompt: settings.systemPrompt,
      systemPromptMode: settings.systemPromptMode,
      model: settings.model,
      mcpServers: settings.mcpServers,
    });
  }, [input, chat, settings.systemPrompt, settings.systemPromptMode, settings.model, settings.mcpServers]);

  // Start new chat - reset both chat and UI state
  const handleNewChat = useCallback(() => {
    chat.startNewChat();
    setShowSettings(false);
    setShowHistory(false);
  }, [chat]);

  // Load session from history
  const handleLoadSession = useCallback((newSessionId: string, newMessages: any[], historicalTokenUsage: any) => {
    chat.loadSession(newSessionId, newMessages, historicalTokenUsage);
    setShowHistory(false);
  }, [chat]);

  // Save settings and close dialog
  const handleSaveSettings = useCallback(async () => {
    await settings.saveSettings();
    setShowSettings(false);
  }, [settings]);

  // Clear prompt and close dialog
  const handleClearPrompt = useCallback(async () => {
    await settings.clearPrompt();
    setShowSettings(false);
  }, [settings]);

  // MCP server management wrapper
  const handleAddMcpServer = useCallback((name: string, url: string, headers?: Record<string, string>) => {
    settings.addMcpServer(name, {
      type: 'http',
      url,
      ...(headers && Object.keys(headers).length > 0 && { headers }),
      status: 'pending',
    });
  }, [settings]);

  return (
    <div className="flex flex-col h-screen bg-background">
      <SettingsDialog
        open={showSettings}
        onOpenChange={setShowSettings}
        systemPrompt={settings.systemPrompt}
        onSystemPromptChange={settings.setSystemPrompt}
        systemPromptMode={settings.systemPromptMode}
        onSystemPromptModeChange={settings.setSystemPromptMode}
        model={settings.model}
        onModelChange={settings.setModel}
        availableModels={CLAUDE_MODELS}
        settingSources={settings.settingSources}
        onSettingSourcesChange={settings.setSettingSources}
        mcpServers={settings.mcpServers}
        onAddMcpServer={handleAddMcpServer}
        onRemoveMcpServer={settings.removeMcpServer}
        mcpLoading={settings.mcpLoading}
        plugins={settings.plugins}
        showSystemMessages={settings.showSystemMessages}
        onShowSystemMessagesChange={settings.setShowSystemMessages}
        onSave={handleSaveSettings}
        onClearPrompt={handleClearPrompt}
        onSessionClear={() => chat.setSessionId(null)}
        version={settings.appVersion}
        cwd={settings.appCwd}
      />

      <ErrorBoundary>
        <SessionHistory
          open={showHistory}
          onOpenChange={setShowHistory}
          currentSessionId={chat.sessionId}
          onLoadSession={handleLoadSession}
        />
      </ErrorBoundary>

      <ChatHeader
        sessionId={chat.sessionId}
        status={chat.status}
        messages={chat.messages}
        version={settings.appVersion}
        onNewChat={handleNewChat}
        onOpenSettings={() => setShowSettings(true)}
        onOpenHistory={() => setShowHistory(true)}
      />

      <ErrorBoundary>
      <MessageList
          messages={chat.messages}
          isLoading={chat.isLoading}
          status={chat.status}
          showSystemMessages={settings.showSystemMessages}
          isWaitingForFirstChunk={chat.isWaitingForFirstChunk}
      />
      </ErrorBoundary>

      <ChatInput
        input={input}
        isLoading={chat.isLoading}
        tokenUsage={chat.tokenUsage}
        sessionId={chat.sessionId}
        cwd={settings.appCwd}
        slashCommands={slashCommands}
        onInputChange={setInput}
        onSend={handleSendMessage}
        onStop={chat.stopRequest}
      />
    </div>
  );
}

export default App;

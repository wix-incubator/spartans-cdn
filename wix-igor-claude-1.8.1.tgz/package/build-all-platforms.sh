#!/bin/bash
set -e

# Build igor-claude for multiple platforms
# Requires: bun, yarn
# Uses BUN env var if set, otherwise looks for bun in PATH

BUN="${BUN:-bun}"

echo "🔨 Building igor-claude for all platforms..."

cd "$(dirname "$0")"

# Build frontend and generate embedded assets first
echo "📦 Building frontend..."
yarn build

echo "📦 Generating embedded assets..."
"$BUN" run -e "
import { readFileSync, readdirSync, statSync, writeFileSync } from 'fs';
import { join, relative } from 'path';

const DIST_DIR = './dist';
const OUTPUT_FILE = './dist/statics/embedded-assets.ts';

function getAllFiles(dir, baseDir = dir) {
  const files = [];
  for (const entry of readdirSync(dir)) {
    const fullPath = join(dir, entry);
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      files.push(...getAllFiles(fullPath, baseDir));
    } else {
      const relativePath = '/' + relative(baseDir, fullPath);
      const content = readFileSync(fullPath);
      const ext = entry.split('.').pop()?.toLowerCase();
      const mimeTypes = { html: 'text/html', css: 'text/css', js: 'application/javascript', json: 'application/json' };
      const mimeType = mimeTypes[ext] || 'application/octet-stream';
      const isBinary = mimeType.startsWith('image/');
      files.push({ path: relativePath, content: isBinary ? content.toString('base64') : content.toString('utf-8'), mimeType, isBinary });
    }
  }
  return files;
}

const files = getAllFiles(DIST_DIR);
const code = \`// Auto-generated
export const EMBEDDED_ASSETS = {\${files.map(f => \`
  \${JSON.stringify(f.path)}: { content: \${JSON.stringify(f.content)}, mimeType: \${JSON.stringify(f.mimeType)}, isBase64: \${f.isBinary} }\`).join(',')}
};
export function getEmbeddedAsset(path) {
  let p = path.startsWith('/') ? path : '/' + path;
  if (p === '/') p = '/index.html';
  const asset = EMBEDDED_ASSETS[p];
  if (!asset) return null;
  return { content: asset.isBase64 ? Buffer.from(asset.content, 'base64') : asset.content, mimeType: asset.mimeType };
}
\`;
writeFileSync(OUTPUT_FILE, code);
console.log('Generated embedded-assets.ts with', files.length, 'files');
"

# Create output directory
mkdir -p ./dist/statics

# Build for each platform
PLATFORMS=(
    "darwin-arm64"
    "darwin-x64"
    "linux-arm64"
    "linux-x64"
)

for PLATFORM in "${PLATFORMS[@]}"; do
    echo ""
    echo "🔧 Building for $PLATFORM..."
    
    TARGET=""
    case "$PLATFORM" in
        darwin-arm64) TARGET="bun-darwin-arm64" ;;
        darwin-x64) TARGET="bun-darwin-x64" ;;
        linux-arm64) TARGET="bun-linux-arm64" ;;
        linux-x64) TARGET="bun-linux-x64" ;;
    esac
    
    OUTPUT="./dist/statics/igor-claude-${PLATFORM}"
    
    "$BUN" build ./server.ts --compile --target="$TARGET" --outfile "$OUTPUT" 2>/dev/null || {
        echo "⚠️  Skipping $PLATFORM (cross-compilation not available on this machine)"
        continue
    }
    
    # Get file size
    if [ -f "$OUTPUT" ]; then
        SIZE=$(ls -lh "$OUTPUT" | awk '{print $5}')
        echo "✅ Built $OUTPUT ($SIZE)"
    fi
done

echo ""
echo "📊 Build summary:"
ls -lh ./dist/statics/igor-claude-* 2>/dev/null || echo "No binaries built"
echo ""
echo "Done! Binaries are in ./dist/statics/ (will be uploaded to CDN)"


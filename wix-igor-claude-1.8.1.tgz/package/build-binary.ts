#!/usr/bin/env bun
/**
 * Build script that:
 * 1. Builds the frontend (vite build)
 * 2. Generates embedded-assets.ts with all dist files inlined
 * 3. Compiles everything into a single binary
 * 
 * Note: Marketplace/plugins are NOT embedded - they're downloaded from CDN at runtime
 */

import { readFileSync, readdirSync, statSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, relative } from 'path';
import { execSync } from 'child_process';

const DIST_DIR = './dist';
const STATICS_DIR = './dist/statics';
const OUTPUT_FILE = './dist/statics/embedded-assets.ts';

// Read version from package.json to embed in binary
const packageJson = JSON.parse(readFileSync('./package.json', 'utf-8'));
const EMBEDDED_VERSION = packageJson.version || 'unknown';

// Recursively get all files in a directory
function getAllFiles(dir: string, baseDir: string = dir): { path: string; content: string; mimeType: string }[] {
  const files: { path: string; content: string; mimeType: string }[] = [];
  
  for (const entry of readdirSync(dir)) {
    const fullPath = join(dir, entry);
    const stat = statSync(fullPath);
    
    if (stat.isDirectory()) {
      files.push(...getAllFiles(fullPath, baseDir));
    } else {
      const relativePath = '/' + relative(baseDir, fullPath);
      const content = readFileSync(fullPath);
      const mimeType = getMimeType(entry);
      
      // For binary files, use base64 encoding
      const isBinary = mimeType.startsWith('image/') || mimeType === 'application/octet-stream';
      const encoded = isBinary 
        ? content.toString('base64')
        : content.toString('utf-8');
      
      files.push({
        path: relativePath,
        content: encoded,
        mimeType,
      });
    }
  }
  
  return files;
}

function getMimeType(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase();
  const mimeTypes: Record<string, string> = {
    'html': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
    'json': 'application/json',
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'gif': 'image/gif',
    'svg': 'image/svg+xml',
    'ico': 'image/x-icon',
    'woff': 'font/woff',
    'woff2': 'font/woff2',
    'ttf': 'font/ttf',
  };
  return mimeTypes[ext || ''] || 'application/octet-stream';
}

async function main() {
  console.log('🔨 Starting binary build process...');
  console.log('');
  console.log('🔨 Building frontend...');
  execSync('yarn build:client', { stdio: 'inherit' });
  
  if (!existsSync(DIST_DIR)) {
    console.error('❌ dist/ directory not found after build');
    process.exit(1);
  }
  
  // Create statics directory
  if (!existsSync(STATICS_DIR)) {
    mkdirSync(STATICS_DIR, { recursive: true });
  }
  
  console.log('📦 Embedding static assets (frontend only, marketplace downloaded at runtime)...');
  const files = getAllFiles(DIST_DIR);
  
  // Generate the embedded assets module
  const embeddedCode = `// Auto-generated - DO NOT EDIT
// Contains frontend static assets embedded for binary distribution
// Marketplace/plugins are downloaded from CDN at runtime

// Embedded version for binary mode
export const EMBEDDED_VERSION = ${JSON.stringify(EMBEDDED_VERSION)};

export const EMBEDDED_ASSETS: Record<string, { content: string; mimeType: string; isBase64: boolean }> = {
${files.map(f => {
  const isBase64 = f.mimeType.startsWith('image/') || f.mimeType === 'application/octet-stream';
  return `  ${JSON.stringify(f.path)}: {
    content: ${JSON.stringify(f.content)},
    mimeType: ${JSON.stringify(f.mimeType)},
    isBase64: ${isBase64},
  }`;
}).join(',\n')}
};

export function getEmbeddedAsset(path: string): { content: Buffer | string; mimeType: string } | null {
  // Normalize path
  let normalizedPath = path;
  if (!normalizedPath.startsWith('/')) normalizedPath = '/' + normalizedPath;
  if (normalizedPath === '/') normalizedPath = '/index.html';
  
  const asset = EMBEDDED_ASSETS[normalizedPath];
  if (!asset) return null;
  
  return {
    content: asset.isBase64 ? Buffer.from(asset.content, 'base64') : asset.content,
    mimeType: asset.mimeType,
  };
}
`;

  writeFileSync(OUTPUT_FILE, embeddedCode);
  console.log(`✅ Generated ${OUTPUT_FILE} with ${files.length} files`);
  
  // Show what's embedded
  for (const f of files) {
    console.log(`   ${f.path} (${f.mimeType})`);
  }
  
  console.log('🔧 Compiling binary for macOS (darwin-arm64)...');
  const bunPath = process.env.BUN || 'bun';
  const binaryPath = './dist/statics/igor-claude';
  
  // Build for macOS ARM64 (Apple Silicon) - cross-compile from any platform
  // Use Wix npm registry for cross-compilation runtime download (needed in CI)
  const crossCompileEnv = {
    ...process.env,
    BUN_COMPILE_TARGET_TARBALL_URL: 'https://npm.dev.wixpress.com/api/npm/npm-repos/@oven/bun-darwin-aarch64/-/bun-darwin-aarch64-1.3.2.tgz'
  };
  execSync(`${bunPath} build ./server.ts --compile --target bun-darwin-arm64 --outfile ${binaryPath}`, { 
    stdio: 'inherit',
    env: crossCompileEnv
  });
  
  // Verify binary was created
  if (!existsSync(binaryPath)) {
    console.error('❌ Binary compilation failed - output file not found');
    process.exit(1);
  }
  
  // Copy install.sh to dist/statics/ so it gets uploaded to CDN
  console.log('📋 Copying install.sh to dist/statics/...');
  if (existsSync('./install.sh')) {
    execSync('cp ./install.sh ./dist/statics/install.sh');
    console.log('✅ install.sh copied');
  } else if (existsSync('../../install.sh')) {
    execSync('cp ../../install.sh ./dist/statics/install.sh');
    console.log('✅ install.sh copied from repo root');
  } else {
    console.log('⚠️ install.sh not found, skipping');
  }
  
  // Show binary size
  const stat = statSync(binaryPath);
  const sizeMB = (stat.size / 1024 / 1024).toFixed(1);
  
  console.log('');
  console.log('✅ Binary build succeeded!');
  console.log(`   📦 Binary: ${binaryPath} (darwin-arm64)`);
  console.log(`   📊 Size: ${sizeMB} MB`);
  console.log(`   🌐 Will be uploaded to CDN by CI`);
  console.log(`   📥 Marketplace will be downloaded from CDN at runtime`);
  console.log('');
}

main().catch(console.error);

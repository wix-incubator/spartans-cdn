#!/bin/bash

# Ensure Bun is installed and return its path
# Used by build-binary.ts to compile the binary

# Check if bun is already installed
if command -v bun &> /dev/null; then
    echo "$(command -v bun)"
    exit 0
fi

# Check common installation paths
COMMON_PATHS=(
    "$HOME/.bun/bin/bun"
    "/usr/local/bin/bun"
    "/opt/homebrew/bin/bun"
)

for path in "${COMMON_PATHS[@]}"; do
    if [ -x "$path" ]; then
        echo "$path"
        exit 0
    fi
done

# Bun not found - try to install it
echo "Bun not found, installing..." >&2

# Install specific version to match CI
BUN_VERSION="1.3.2"

if command -v curl &> /dev/null; then
    curl -fsSL https://bun.sh/install | bash -s "bun-v${BUN_VERSION}"
elif command -v wget &> /dev/null; then
    wget -qO- https://bun.sh/install | bash -s "bun-v${BUN_VERSION}"
else
    echo "Error: Neither curl nor wget found. Please install Bun manually." >&2
    exit 1
fi

# Check if installation succeeded
if [ -x "$HOME/.bun/bin/bun" ]; then
    echo "$HOME/.bun/bin/bun"
    exit 0
fi

echo "Error: Failed to install Bun" >&2
exit 1





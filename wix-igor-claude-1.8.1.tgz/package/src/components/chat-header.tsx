import { useState } from 'react';
import { Plus, Settings, Copy, Check, History, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Message } from '@/types';

interface ChatHeaderProps {
  sessionId: string | null;
  status: string;
  messages: Message[];
  version?: string;
  onNewChat: () => void;
  onOpenSettings: () => void;
  onOpenHistory: () => void;
}

export function ChatHeader({ sessionId, status, messages, version, onNewChat, onOpenSettings, onOpenHistory }: ChatHeaderProps) {
  const [copied, setCopied] = useState(false);
  const [copying, setCopying] = useState(false);

  const copyConversation = async () => {
    if (!sessionId && messages.length === 0) return;
    
    setCopying(true);
    try {
      let text: string;
      
      // Try to fetch from server first (gets full conversation with thinking, tokens, etc.)
      if (sessionId) {
        const res = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}?raw=true`);
        if (res.ok) {
          text = await res.text();
        } else {
          throw new Error('Failed to fetch session');
        }
      } else {
        // Fallback to client-side messages if no sessionId
        text = `# Claude Code Conversation\n# Exported: ${new Date().toISOString()}\n\n` +
          messages.map(msg => {
            const time = new Date(msg.timestamp).toISOString();
            return `[${time}] ${msg.role.toUpperCase()}:\n${msg.content}`;
          }).join('\n\n---\n\n');
      }
      
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    } finally {
      setCopying(false);
    }
  };


  return (
    <header className="border-b border-border px-4 py-2">
      <div className="flex items-center justify-between">
        {/* Left: Title and status */}
        <div className="flex items-center gap-3">
          <h1 className="text-sm font-semibold">
            IGOR Claude
            {version && <span className="ml-1 text-[10px] text-muted-foreground font-normal">v{version}</span>}
          </h1>
        </div>
        
        {/* Right: Actions */}
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="sm"
            className="h-7 px-2 text-xs gap-1"
            onClick={copyConversation} 
            disabled={(!sessionId && messages.length === 0) || copying}
          >
            {copying ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : copied ? (
              <Check className="h-3 w-3 text-green-500" />
            ) : (
              <Copy className="h-3 w-3" />
            )}
            Copy
          </Button>
          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={onOpenHistory}>
            <History className="h-3 w-3" />
            History
          </Button>
          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={onNewChat}>
            <Plus className="h-3 w-3" />
            New
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onOpenSettings}>
            <Settings className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </header>
  );
}

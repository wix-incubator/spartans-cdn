import { useRef, useEffect, useState } from 'react';
import { ArrowUp, Square, ImagePlus, X, Coins, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import type { ImageData, TokenUsage } from '@/types';

interface SlashCommand {
  name: string;
  description?: string;
  argumentHint?: string;
}

interface ChatInputProps {
  input: string;
  isLoading: boolean;
  tokenUsage: TokenUsage | null;
  sessionId: string | null;
  cwd?: string;
  slashCommands?: SlashCommand[];
  onInputChange: (value: string) => void;
  onSend: (e?: React.FormEvent, images?: ImageData[]) => void;
  onStop: () => void;
}

export function ChatInput({ input, isLoading, tokenUsage, sessionId, cwd, slashCommands = [], onInputChange, onSend, onStop }: ChatInputProps) {
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [attachedImages, setAttachedImages] = useState<ImageData[]>([]);
  const [sessionCopied, setSessionCopied] = useState(false);
  const [showCommandMenu, setShowCommandMenu] = useState(false);
  const [selectedCommandIndex, setSelectedCommandIndex] = useState(0);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Detect slash command input and filter commands
  const getCommandQuery = () => {
    const cursorPos = inputRef.current?.selectionStart ?? input.length;
    const textBeforeCursor = input.substring(0, cursorPos);
    const lastSlashIndex = textBeforeCursor.lastIndexOf('/');
    
    if (lastSlashIndex === -1) return null;
    
    // Check if there's a space after the slash (command already completed)
    const textAfterSlash = textBeforeCursor.substring(lastSlashIndex + 1);
    if (textAfterSlash.includes(' ')) return null;
    
    // Check if there's a newline after the slash (command on previous line)
    if (textAfterSlash.includes('\n')) return null;
    
    return {
      query: textAfterSlash.toLowerCase(),
      startIndex: lastSlashIndex,
    };
  };

  const commandQuery = getCommandQuery();
  const filteredCommands = commandQuery
    ? slashCommands.filter(cmd => {
        const query = commandQuery.query;
        // If query is empty (just "/"), show all commands
        if (!query) return true;
        // Otherwise filter by query
        const cmdName = typeof cmd === 'string' ? cmd : cmd.name;
        return cmdName.toLowerCase().startsWith(query) || cmdName.toLowerCase().includes(query);
      })
    : [];

  // Show menu when typing "/" and there are commands available
  useEffect(() => {
    const query = getCommandQuery();
    
    if (!query) {
      setShowCommandMenu(false);
      return;
    }
    
    const filtered = slashCommands.filter(cmd => {
      const q = query.query;
      if (!q) return true; // Show all when just "/"
      const cmdName = typeof cmd === 'string' ? cmd : cmd.name;
      return cmdName.toLowerCase().startsWith(q) || cmdName.toLowerCase().includes(q);
    });
    
    const shouldShow = filtered.length > 0 && slashCommands.length > 0;
    setShowCommandMenu(shouldShow);
    if (shouldShow) {
      setSelectedCommandIndex(0);
    }
  }, [input, slashCommands]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (showCommandMenu && filteredCommands.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedCommandIndex(prev => (prev + 1) % filteredCommands.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedCommandIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        if (commandQuery) {
          const selectedCommand = filteredCommands[selectedCommandIndex];
          const cmdName = typeof selectedCommand === 'string' ? selectedCommand : selectedCommand.name;
          const beforeSlash = input.substring(0, commandQuery.startIndex);
          const afterCursor = input.substring(inputRef.current?.selectionStart || input.length);
          onInputChange(beforeSlash + '/' + cmdName + ' ' + afterCursor);
          setShowCommandMenu(false);
          // Set cursor position after the inserted command
          setTimeout(() => {
            const newPos = beforeSlash.length + cmdName.length + 2;
            inputRef.current?.setSelectionRange(newPos, newPos);
            inputRef.current?.focus();
          }, 0);
        }
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setShowCommandMenu(false);
        return;
      }
    }
    
    if (e.key === 'Enter' && !e.shiftKey && !showCommandMenu) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() && attachedImages.length === 0) return;
    onSend(e, attachedImages.length > 0 ? attachedImages : undefined);
    setAttachedImages([]); // Clear after sending
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: ImageData[] = [];
    
    for (const file of Array.from(files)) {
      if (!file.type.startsWith('image/')) continue;
      
      try {
        const base64 = await fileToBase64(file);
        newImages.push({
          data: base64,
          mediaType: file.type,
          fileName: file.name,
        });
      } catch (err) {
        console.error('Failed to read image:', err);
      }
    }
    
    setAttachedImages(prev => [...prev, ...newImages]);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeImage = (index: number) => {
    setAttachedImages(prev => prev.filter((_, i) => i !== index));
  };

  const copySessionId = async () => {
    if (!sessionId) return;
    try {
      await navigator.clipboard.writeText(sessionId);
      setSessionCopied(true);
      setTimeout(() => setSessionCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy session ID:', err);
    }
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (const item of Array.from(items)) {
      if (item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (!file) continue;
        
        try {
          const base64 = await fileToBase64(file);
          setAttachedImages(prev => [...prev, {
            data: base64,
            mediaType: file.type,
            fileName: `pasted-image-${Date.now()}.${file.type.split('/')[1]}`,
          }]);
        } catch (err) {
          console.error('Failed to read pasted image:', err);
        }
      }
    }
  };

  return (
    <div className="px-4 py-3">
      <form onSubmit={handleSend} className="max-w-2xl mx-auto">
        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />
        
        {/* Input bubble container */}
        <div className="border border-border rounded-lg bg-muted/30">
          {/* Attached Images Preview */}
          {attachedImages.length > 0 && (
            <div className="flex flex-wrap gap-2 p-2 pb-0">
              {attachedImages.map((img, index) => (
                <div key={index} className="relative group">
                  <img
                    src={`data:${img.mediaType};base64,${img.data}`}
                    alt={img.fileName}
                    className="h-12 w-12 object-cover rounded border border-border"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute -top-1 -right-1 bg-muted text-muted-foreground rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {/* Textarea with relative positioning for command menu */}
          <div className="relative">
            <Textarea
              ref={inputRef}
              value={input}
              onChange={(e) => onInputChange(e.target.value)}
              onKeyDown={handleKeyDown}
              onPaste={handlePaste}
              placeholder={attachedImages.length > 0 ? "Add a message..." : "Type a message..."}
              disabled={isLoading}
              rows={1}
              className="text-xs resize-none border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
              style={{ minHeight: '36px', maxHeight: '120px' }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = Math.min(target.scrollHeight, 120) + 'px';
              }}
            />
            
            {/* Command autocomplete menu */}
            {showCommandMenu && filteredCommands.length > 0 && (
              <div
                ref={menuRef}
                className="absolute bottom-full left-0 mb-1 w-full max-w-md bg-popover border border-border rounded-lg shadow-lg z-[100] max-h-64 overflow-y-auto"
                style={{ position: 'absolute' }}
              >
                {filteredCommands.map((cmd, index) => {
                  const cmdObj = typeof cmd === 'string' ? { name: cmd } : cmd;
                  return (
                    <button
                      key={cmdObj.name}
                      type="button"
                      onClick={() => {
                        if (commandQuery) {
                          const beforeSlash = input.substring(0, commandQuery.startIndex);
                          const afterCursor = input.substring(inputRef.current?.selectionStart || input.length);
                          onInputChange(beforeSlash + '/' + cmdObj.name + ' ' + afterCursor);
                          setShowCommandMenu(false);
                          setTimeout(() => {
                            const newPos = beforeSlash.length + cmdObj.name.length + 2;
                            inputRef.current?.setSelectionRange(newPos, newPos);
                            inputRef.current?.focus();
                          }, 0);
                        }
                      }}
                      className={`w-full text-left px-3 py-2 text-xs hover:bg-accent transition-colors ${
                        index === selectedCommandIndex ? 'bg-accent' : ''
                      }`}
                    >
                      <div className="flex items-baseline gap-2 flex-wrap">
                        <span className="font-mono text-muted-foreground/80 shrink-0">/{cmdObj.name}</span>
                        {cmdObj.argumentHint && (
                          <span className="text-muted-foreground/60 font-mono text-[10px] shrink-0">
                            {cmdObj.argumentHint}
                          </span>
                        )}
                      </div>
                      {cmdObj.description && (
                        <div className="text-muted-foreground/70 mt-0.5 text-[10px]">
                          {cmdObj.description}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
          
          {/* Buttons row */}
          <div className="flex items-center justify-between px-2 pb-2">
            {/* Token usage on left */}
            {tokenUsage && tokenUsage.total > 0 ? (
              <span className="text-[10px] text-muted-foreground flex items-center gap-1" title={`Input: ${tokenUsage.input.toLocaleString()} | Output: ${tokenUsage.output.toLocaleString()}`}>
                <Coins className="h-3 w-3 shrink-0" />
                {tokenUsage.total.toLocaleString()} tokens
              </span>
            ) : (
              <span className="text-[10px] text-muted-foreground/30 flex items-center gap-1">
                <Coins className="h-3 w-3 shrink-0 opacity-30" />
                <span className="invisible">0 tokens</span>
              </span>
            )}
            
            {/* Buttons on right */}
            <div className="flex items-center gap-1">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                title="Attach image"
                className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              >
                <ImagePlus className="h-4 w-4" />
              </Button>
              
              {isLoading ? (
                <Button
                  type="button"
                  onClick={onStop}
                  variant="ghost"
                  size="sm"
                  title="Stop"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                >
                  <Square className="h-4 w-4" />
                </Button>
              ) : (
                <Button
                  type="submit"
                  variant="ghost"
                  size="sm"
                  disabled={!input.trim() && attachedImages.length === 0}
                  title="Send"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground disabled:opacity-30"
                >
                  <ArrowUp className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
        
        {/* Second line: CWD and Session ID - always visible to prevent layout shift */}
        <div className="flex items-center justify-between mt-2 px-1 h-4">
          <div className="flex items-center gap-3 min-w-0">
            {cwd ? (
              <span className="text-[10px] text-muted-foreground font-mono truncate" title="Working directory">
                {cwd}
              </span>
            ) : (
              <span className="text-[10px] text-muted-foreground/30 font-mono">
                <span className="invisible">/placeholder/path</span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 min-w-0">
            {sessionId ? (
              <button
                type="button"
                onClick={copySessionId}
                className="text-[10px] text-muted-foreground font-mono hover:text-foreground transition-colors flex items-center gap-1"
                title="Click to copy conversation session ID"
              >
                {sessionCopied ? (
                  <>
                    <Check className="h-3 w-3 text-green-500 shrink-0" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3 shrink-0" />
                    <span className="truncate">Session: {sessionId.slice(0, 8)}...</span>
                  </>
                )}
              </button>
            ) : (
              <span className="text-[10px] text-muted-foreground/30 font-mono flex items-center gap-1">
                <Copy className="h-3 w-3 shrink-0 opacity-30" />
                <span className="invisible">Session: 00000000...</span>
              </span>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}

// Helper to convert File to base64
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the data:image/xxx;base64, prefix
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}


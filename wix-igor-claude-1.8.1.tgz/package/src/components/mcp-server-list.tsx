import { useState } from 'react';
import { Plus, Trash2, Server, Loader2, CheckCircle2, XCircle, AlertCircle, Clock, Wrench, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import type { McpServerWithStatus, McpServerStatus } from '@/types';

interface MCPServerListProps {
  servers: Record<string, McpServerWithStatus>;
  onAdd: (name: string, url: string, headers?: Record<string, string>) => Promise<void>;
  onRemove: (name: string) => Promise<void>;
  onSessionClear: () => void;
  isLoading?: boolean;
}

export function MCPServerList({ servers, onAdd, onRemove, onSessionClear, isLoading }: MCPServerListProps) {
  const [newMcpName, setNewMcpName] = useState('');
  const [newMcpUrl, setNewMcpUrl] = useState('');
  const [headersJson, setHeadersJson] = useState('');
  const [mcpLoading, setMcpLoading] = useState(false);
  const [mcpError, setMcpError] = useState<string | null>(null);

  const getStatusIcon = (status?: McpServerStatus) => {
    switch (status) {
      case 'connected':
        return <CheckCircle2 className="h-3 w-3 text-green-500" />;
      case 'pending':
        return <Clock className="h-3 w-3 text-gray-400" />;
      case 'needs-auth':
        return <AlertCircle className="h-3 w-3 text-orange-500" />;
      case 'failed':
        return <XCircle className="h-3 w-3 text-red-500" />;
      default:
        return <Clock className="h-3 w-3 text-gray-400" />;
    }
  };

  const getStatusBadge = (status?: McpServerStatus) => {
    switch (status) {
      case 'connected':
        return <Badge variant="default" className="text-[10px] px-1.5 py-0 bg-green-600">Connected</Badge>;
      case 'pending':
        return <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-gray-600">Pending</Badge>;
      case 'needs-auth':
        return <Badge variant="default" className="text-[10px] px-1.5 py-0 bg-orange-600">Needs Auth</Badge>;
      case 'failed':
        return <Badge variant="destructive" className="text-[10px] px-1.5 py-0">Failed</Badge>;
      default:
        return <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-gray-600">Pending</Badge>;
    }
  };

  const handleAdd = async () => {
    if (!newMcpName.trim() || !newMcpUrl.trim()) {
      setMcpError('Name and URL are required');
      return;
    }

    // Basic URL validation
    try {
      new URL(newMcpUrl.trim());
    } catch {
      setMcpError('Invalid URL format');
      return;
    }

    // Parse headers JSON if provided
    let headers: Record<string, string> | undefined;
    if (headersJson.trim()) {
      try {
        headers = JSON.parse(headersJson.trim());
        if (typeof headers !== 'object' || Array.isArray(headers)) {
          setMcpError('Headers must be a JSON object');
          return;
        }
      } catch {
        setMcpError('Invalid JSON for headers');
        return;
      }
    }

    setMcpLoading(true);
    setMcpError(null);

    try {
      await onAdd(newMcpName.trim(), newMcpUrl.trim(), headers);
      
      // Reset form
      setNewMcpName('');
      setNewMcpUrl('');
      setHeadersJson('');
      onSessionClear();
    } catch (err) {
      setMcpError(err instanceof Error ? err.message : 'Failed to add server');
    } finally {
      setMcpLoading(false);
    }
  };

  const handleRemove = async (name: string) => {
    setMcpLoading(true);
    setMcpError(null);

    try {
      await onRemove(name);
      onSessionClear();
    } catch (err) {
      setMcpError(err instanceof Error ? err.message : 'Failed to remove server');
    } finally {
      setMcpLoading(false);
    }
  };

  const serverEntries = Object.entries(servers);

  return (
    <div className="space-y-4 border-t pt-4">
      <div className="flex items-center gap-2">
        <Server className="h-4 w-4 text-muted-foreground" />
        <h3 className="text-sm font-medium">MCP Servers (HTTP)</h3>
        {isLoading && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />}
      </div>
      
      {mcpError && (
        <Card className="border-destructive">
          <CardContent className="p-3">
            <p className="text-xs text-destructive">{mcpError}</p>
          </CardContent>
        </Card>
      )}

      {/* Existing Servers */}
      {serverEntries.length > 0 ? (
        <div className="space-y-2">
          {serverEntries.map(([name, config]) => (
            <Card key={name}>
              <CardContent className="p-3 space-y-2">
                <div className="flex items-center gap-2">
                  {getStatusIcon(config.status)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-medium truncate">{name}</p>
                      {config.headers && Object.keys(config.headers).length > 0 && (
                        <Key className="h-3 w-3 text-green-500" title="Has API key" />
                      )}
                      {getStatusBadge(config.status)}
                    </div>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {config.url}
                    </p>
                    {config.serverInfo && (
                      <p className="text-[10px] text-muted-foreground">
                        {config.serverInfo.name} v{config.serverInfo.version}
                      </p>
                    )}
                    {config.error && (
                      <p className="text-[10px] text-destructive truncate">
                        {config.error}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-1">
                    {config.status === 'needs-auth' && (
                      <Badge variant="outline" className="text-[9px] px-1.5 py-0 border-orange-500 text-orange-400">
                        Add API Key
                      </Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemove(name)}
                      disabled={mcpLoading}
                      className="h-6 w-6 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                {/* Show tools when connected */}
                {config.status === 'connected' && config.tools && config.tools.length > 0 && (
                  <div className="pl-5 pt-1 border-t border-border/50">
                    <div className="flex items-center gap-1 mb-1">
                      <Wrench className="h-2.5 w-2.5 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground">
                        {config.tools.length} tool{config.tools.length !== 1 ? 's' : ''} available
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {config.tools.slice(0, 5).map((tool) => (
                        <Badge key={tool} variant="secondary" className="text-[9px] px-1 py-0">
                          {tool}
                        </Badge>
                      ))}
                      {config.tools.length > 5 && (
                        <Badge variant="secondary" className="text-[9px] px-1 py-0">
                          +{config.tools.length - 5} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground text-center py-2">
          No MCP servers configured
        </p>
      )}

      {/* Add New Server */}
      <div className="space-y-2 pt-2 border-t border-border/50">
        <p className="text-[10px] text-muted-foreground font-medium">Add HTTP MCP Server</p>
        <div className="flex gap-2">
          <Input
            value={newMcpName}
            onChange={(e) => setNewMcpName(e.target.value)}
            placeholder="Server name (e.g., my-api)"
            className="text-xs"
          />
        </div>
        <div className="flex gap-2">
          <Input
            value={newMcpUrl}
            onChange={(e) => setNewMcpUrl(e.target.value)}
            placeholder="https://api.example.com/mcp"
            className="text-xs"
          />
          <Button
            onClick={handleAdd}
            disabled={mcpLoading || !newMcpName.trim() || !newMcpUrl.trim()}
            size="sm"
          >
            {mcpLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
          </Button>
        </div>
        
        {/* Headers (JSON) */}
        <div className="space-y-1">
          <label className="text-[10px] text-muted-foreground flex items-center gap-1">
            <Key className="h-3 w-3" />
            Headers (JSON, optional)
          </label>
          <Textarea
            value={headersJson}
            onChange={(e) => setHeadersJson(e.target.value)}
            placeholder='{"Authorization": "Bearer your-token"}'
            className="text-xs font-mono h-16 resize-none"
          />
        </div>
        
        <p className="text-[10px] text-muted-foreground">
          Saved locally. Connection tested on first message.
        </p>
      </div>
    </div>
  );
}

import { useRef, useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageBubble } from './message-bubble';
import type { Message } from '@/types';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  status: string;
  showSystemMessages?: boolean;
  isWaitingForFirstChunk?: boolean;
}

// System message types that should be hidden by default
const SYSTEM_MESSAGE_CONTENTS = [
  'system_message', 
  'message_start', 
  'message_delta',
  'message_stop',
  'content_block_stop',
  'thinking_stop',
  'result',
  'aborted',
];

function isSystemMessage(msg: Message): boolean {
  if (msg.type === 'raw_event') {
    const content = msg.content?.toLowerCase() || '';
    // Check for known system event contents
    if (SYSTEM_MESSAGE_CONTENTS.some(s => content.includes(s.toLowerCase()))) {
      return true;
    }
    // Check for assistant_message (finished thinking/text)
    if (msg.rawData?.type === 'assistant_message') {
      return true;
    }
  }
  return false;
}

export function MessageList({ messages, isLoading, status, showSystemMessages = false, isWaitingForFirstChunk = false }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isWaitingForFirstChunk]);

  // Filter messages based on showSystemMessages setting
  const visibleMessages = showSystemMessages 
    ? messages 
    : messages.filter(msg => !isSystemMessage(msg));

  return (
    <ScrollArea className="flex-1">
      <div className="px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-4">
          {visibleMessages.map((msg) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              isLoading={isLoading}
              status={status}
              allMessages={messages}
            />
          ))}
          {isWaitingForFirstChunk && (
            <div className="w-full my-1">
              <Loader2 className="h-3 w-3 animate-spin text-muted-foreground/50" />
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
    </ScrollArea>
  );
}


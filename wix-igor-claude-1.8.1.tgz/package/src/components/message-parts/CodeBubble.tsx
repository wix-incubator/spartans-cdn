import { cn } from '@/lib/utils';
import type { Message } from '@/types';

interface CodeBubbleProps {
  message: Message;
}

export function CodeBubble({ message }: CodeBubbleProps) {
  return (
    <div className="w-full my-1">
      <div className="text-[9px] text-muted-foreground/50 mb-1">code ({message.language})</div>
      <pre className="text-xs font-mono whitespace-pre-wrap break-words bg-muted/30 rounded p-2">
        {message.content}
      </pre>
    </div>
  );
}

interface CodeResultBubbleProps {
  message: Message;
}

export function CodeResultBubble({ message }: CodeResultBubbleProps) {
  return (
    <div className="w-full my-1">
      <div className={cn("text-[9px] mb-1", message.outcome === 'success' ? 'text-green-500/60' : 'text-red-500/60')}>
        {message.outcome}
      </div>
      <pre className="text-xs font-mono whitespace-pre-wrap break-words">
        {message.content}
      </pre>
    </div>
  );
}


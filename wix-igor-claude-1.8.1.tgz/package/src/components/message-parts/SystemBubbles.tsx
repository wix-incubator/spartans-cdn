import { cn } from '@/lib/utils';
import type { Message } from '@/types';

interface RawEventBubbleProps {
  message: Message;
}

export function RawEventBubble({ message }: RawEventBubbleProps) {
  // Minimal, collapsed system event
  let displayLabel = message.content?.toLowerCase() || 'event';
  if (message.rawData?.type === 'assistant_message' && message.rawData?.message?.content?.[0]?.type) {
    const contentType = message.rawData.message.content[0].type;
    displayLabel = `finished ${contentType}`;
  }

  return (
    <div className="w-full my-0.5">
      <details className="text-[9px] text-muted-foreground/40 hover:text-muted-foreground/60">
        <summary className="cursor-pointer font-mono">
          [{displayLabel}]
        </summary>
        <pre className="text-[8px] font-mono whitespace-pre-wrap break-words max-h-48 overflow-y-auto pl-4 mt-1 text-muted-foreground/50">
          {JSON.stringify(message.rawData, null, 2)}
        </pre>
      </details>
    </div>
  );
}

interface AuthStatusBubbleProps {
  message: Message;
}

export function AuthStatusBubble({ message }: AuthStatusBubbleProps) {
  const isAuthenticating = message.rawData?.isAuthenticating;
  const hasError = message.rawData?.error;

  return (
    <div className="w-full my-2">
      <div className={cn("text-xs font-medium mb-1", hasError ? 'text-red-400' : 'text-orange-400')}>
        {isAuthenticating ? '🔐 MCP Authentication Required' : hasError ? '❌ Auth Error' : '✓ Authenticated'}
      </div>
      <pre className="text-xs font-mono whitespace-pre-wrap break-words max-h-32 overflow-y-auto text-muted-foreground">
        {message.content}
      </pre>
      {hasError && (
        <p className="text-xs text-red-400 mt-1">Error: {message.rawData.error}</p>
      )}
    </div>
  );
}

interface SystemInfoBubbleProps {
  message: Message;
}

export function SystemInfoBubble({ message }: SystemInfoBubbleProps) {
  return (
    <div className="w-full my-1">
      <div className="text-[9px] text-muted-foreground/50">{message.content}</div>
    </div>
  );
}

interface MediaBubbleProps {
  message: Message;
}

export function MediaBubble({ message }: MediaBubbleProps) {
  return (
    <div className="w-full my-1">
      <div className="text-[9px] text-muted-foreground/50">media: {message.mimeType}</div>
    </div>
  );
}

interface QueryResultBubbleProps {
  message: Message;
}

export function QueryResultBubble({ message }: QueryResultBubbleProps) {
  return (
    <div className="w-full my-1">
      <div className="text-xs whitespace-pre-wrap break-words max-h-96 overflow-y-auto">
        {message.content}
      </div>
    </div>
  );
}


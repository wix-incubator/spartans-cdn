import { Loader2 } from 'lucide-react';
import type { Message } from '@/types';

interface ThinkingBubbleProps {
  message: Message;
  isComplete: boolean;
}

export function ThinkingBubble({ message, isComplete }: ThinkingBubbleProps) {
  return (
    <div className="w-full my-1">
      <details className="text-sm text-muted-foreground">
        <summary className="cursor-pointer flex items-center gap-1 text-xs text-muted-foreground/60 hover:text-muted-foreground">
          {!isComplete && <Loader2 className="h-3 w-3 animate-spin" />}
          <span>thinking</span>
        </summary>
        <div className="text-xs whitespace-pre-wrap break-words mt-1 italic text-muted-foreground/80">
          {message.content}
        </div>
      </details>
    </div>
  );
}


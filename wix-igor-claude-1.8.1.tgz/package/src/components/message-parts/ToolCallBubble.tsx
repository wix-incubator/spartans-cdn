import { Card, CardContent } from '@/components/ui/card';
import { formatTime } from '@/lib/utils';
import type { Message } from '@/types';
import { getToolRenderer, getToolHeader, INLINE_TOOLS, TOOLS_WITH_CUSTOM_HEADER } from './tool-renderers';

interface ToolCallBubbleProps {
  message: Message;
}

export function ToolCallBubble({ message }: ToolCallBubbleProps) {
  const toolName = message.tool || 'unknown';
  const args = message.args || {};
  const normalizedName = toolName.toLowerCase();
  
  // Get the appropriate renderer for this tool
  const ToolRenderer = getToolRenderer(toolName);
  const ToolHeader = getToolHeader(toolName);
  
  // Some tools render inline without a card
  const isInline = INLINE_TOOLS.includes(normalizedName);
  const hasCustomHeader = TOOLS_WITH_CUSTOM_HEADER.includes(normalizedName);

  // Inline rendering (Read, Glob, Grep, Task)
  // Format: <icon> <tool-name> <args...> <time>
  if (isInline) {
    return (
      <div className="w-full my-0.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0 flex-1">
          <ToolRenderer args={args} toolName={toolName} />
        </div>
        <span className="text-[8px] text-muted-foreground/40 flex-shrink-0">
          {formatTime(message.timestamp)}
        </span>
      </div>
    );
  }

  // Card rendering for other tools
  // Format: <icon> <tool-name> <path...> | <time>
  return (
    <div className="w-full my-1">
      <Card className="border-border max-h-64 overflow-y-auto">
        <CardContent className="p-2">
          <div className="flex items-center justify-between mb-1 gap-2">
            {hasCustomHeader && ToolHeader ? (
              <div className="flex items-center gap-1.5 min-w-0 flex-1">
                <ToolHeader args={args} toolName={toolName} />
              </div>
            ) : (
              <span className="text-[10px] font-medium font-mono text-muted-foreground">
                {toolName}
              </span>
            )}
            <span className="text-[8px] text-muted-foreground/50 flex-shrink-0">
              {formatTime(message.timestamp)}
            </span>
          </div>
          <ToolRenderer args={args} />
        </CardContent>
      </Card>
    </div>
  );
}

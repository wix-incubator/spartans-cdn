import { Terminal } from 'lucide-react';

interface BashToolRendererProps {
  args: {
    command?: string;
    description?: string;
    timeout?: number;
  };
}

export function BashToolRenderer({ args }: BashToolRendererProps) {
  const command = args.command || '';

  return (
    <div className="bg-zinc-900 rounded px-2 py-1.5">
      <code className="font-mono text-[10px] text-green-300 whitespace-pre-wrap break-all">
        {command}
      </code>
    </div>
  );
}

interface BashToolHeaderProps {
  toolName?: string;
  args?: BashToolRendererProps['args'];
}

// Export header component with icon for ToolCallBubble
export function BashToolHeader({ toolName, args }: BashToolHeaderProps) {
  const description = args?.description;
  
  return (
    <>
      <Terminal className="h-3 w-3 text-green-400 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Bash'}</span>
      {description && (
        <>
          <span className="text-[9px] text-muted-foreground/30">·</span>
          <span className="text-[9px] font-mono text-muted-foreground/70">{description}</span>
        </>
      )}
    </>
  );
}

interface DefaultToolRendererProps {
  args: Record<string, unknown>;
}

export function DefaultToolRenderer({ args }: DefaultToolRendererProps) {
  return (
    <pre className="font-mono text-[9px] text-muted-foreground/80 whitespace-pre-wrap break-words">
      {JSON.stringify(args, null, 2)}
    </pre>
  );
}


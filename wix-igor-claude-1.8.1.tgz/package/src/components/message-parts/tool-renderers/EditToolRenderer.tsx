import { useState } from 'react';
import { FileEdit, ChevronDown, ChevronRight } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface EditToolRendererProps {
  args: {
    file_path?: string;
    old_string?: string;
    new_string?: string;
  };
}

// Infer language from file extension
function getLanguage(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase() || '';
  const langMap: Record<string, string> = {
    ts: 'typescript',
    tsx: 'tsx',
    js: 'javascript',
    jsx: 'jsx',
    py: 'python',
    rb: 'ruby',
    go: 'go',
    rs: 'rust',
    java: 'java',
    kt: 'kotlin',
    swift: 'swift',
    css: 'css',
    scss: 'scss',
    html: 'html',
    json: 'json',
    yaml: 'yaml',
    yml: 'yaml',
    md: 'markdown',
    sql: 'sql',
    sh: 'bash',
    bash: 'bash',
    zsh: 'bash',
  };
  return langMap[ext] || 'text';
}

export function EditToolRenderer({ args }: EditToolRendererProps) {
  const [expanded, setExpanded] = useState(false);
  const filePath = args.file_path || '';
  const oldString = args.old_string || '';
  const newString = args.new_string || '';
  const language = getLanguage(filePath);

  const codeStyle = {
    margin: 0,
    padding: '0.5rem',
    fontSize: '9px',
    lineHeight: '1.4',
    maxHeight: '150px',
    overflow: 'auto',
  };

  const oldLines = oldString.split('\n').length;
  const newLines = newString.split('\n').length;

  return (
    <div>
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1 text-[9px] text-muted-foreground/60 hover:text-muted-foreground transition-colors"
      >
        {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        <span className="text-red-400/70">−{oldLines}</span>
        <span className="text-green-400/70">+{newLines}</span>
      </button>
      
      {expanded && (
        <div className="mt-1 space-y-1">
          {/* Old string */}
          <div className="rounded overflow-hidden border border-red-500/20">
            <div className="text-[8px] text-red-400/70 font-medium px-2 py-0.5 bg-red-500/5">− remove</div>
            <SyntaxHighlighter
              style={oneDark}
              language={language}
              customStyle={{
                ...codeStyle,
                background: 'rgba(239, 68, 68, 0.03)',
              }}
            >
              {oldString}
            </SyntaxHighlighter>
          </div>

          {/* New string */}
          <div className="rounded overflow-hidden border border-green-500/20">
            <div className="text-[8px] text-green-400/70 font-medium px-2 py-0.5 bg-green-500/5">+ add</div>
            <SyntaxHighlighter
              style={oneDark}
              language={language}
              customStyle={{
                ...codeStyle,
                background: 'rgba(34, 197, 94, 0.03)',
              }}
            >
              {newString}
            </SyntaxHighlighter>
          </div>
        </div>
      )}
    </div>
  );
}

interface EditToolPathProps extends EditToolRendererProps {
  toolName?: string;
}

// Export path component for use in ToolCallBubble header
export function EditToolPath({ args, toolName }: EditToolPathProps) {
  const filePath = args.file_path || '';
  const fileName = filePath.split('/').pop() || filePath;
  const directory = filePath.replace(fileName, '');

  return (
    <>
      <FileEdit className="h-3 w-3 text-amber-400 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Edit'}</span>
      <span className="text-[10px] font-mono text-muted-foreground/60 truncate">{directory}</span>
      <span className="text-[10px] font-mono text-foreground/80">{fileName}</span>
    </>
  );
}

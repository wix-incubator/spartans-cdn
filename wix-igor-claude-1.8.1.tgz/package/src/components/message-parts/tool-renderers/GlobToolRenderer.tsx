import { FolderSearch } from 'lucide-react';

interface GlobToolRendererProps {
  args: {
    pattern?: string;
    glob_pattern?: string;
    path?: string;
  };
  toolName?: string;
}

export function GlobToolRenderer({ args, toolName }: GlobToolRendererProps) {
  const pattern = args.pattern || args.glob_pattern || '';
  const path = args.path || '';

  return (
    <>
      <FolderSearch className="h-3 w-3 text-muted-foreground/60 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Glob'}</span>
      <span className="text-[10px] font-mono text-foreground/70">{pattern}</span>
      {path && <span className="text-[9px] text-muted-foreground/50">in {path}</span>}
    </>
  );
}

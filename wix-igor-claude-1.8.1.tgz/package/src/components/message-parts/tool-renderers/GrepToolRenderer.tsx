import { Search } from 'lucide-react';

interface GrepToolRendererProps {
  args: {
    pattern?: string;
    path?: string;
    include?: string;
  };
  toolName?: string;
}

export function GrepToolRenderer({ args, toolName }: GrepToolRendererProps) {
  const pattern = args.pattern || '';
  const path = args.path || '';

  return (
    <>
      <Search className="h-3 w-3 text-muted-foreground/60 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Grep'}</span>
      <span className="text-[10px] font-mono text-foreground/70">{pattern}</span>
      {path && <span className="text-[9px] text-muted-foreground/50">in {path}</span>}
    </>
  );
}

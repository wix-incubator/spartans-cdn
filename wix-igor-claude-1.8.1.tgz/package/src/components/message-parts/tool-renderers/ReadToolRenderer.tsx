import { FileText } from 'lucide-react';

interface ReadToolRendererProps {
  args: {
    file_path?: string;
  };
  toolName?: string;
}

export function ReadToolRenderer({ args, toolName }: ReadToolRendererProps) {
  const filePath = args.file_path || '';
  const fileName = filePath.split('/').pop() || filePath;
  const directory = filePath.replace(fileName, '');

  return (
    <>
      <FileText className="h-3 w-3 text-blue-400 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Read'}</span>
      <span className="text-[10px] font-mono text-muted-foreground/60 truncate">{directory}</span>
      <span className="text-[10px] font-mono text-foreground/80">{fileName}</span>
    </>
  );
}

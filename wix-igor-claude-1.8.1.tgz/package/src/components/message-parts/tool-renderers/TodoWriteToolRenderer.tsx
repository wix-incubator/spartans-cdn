import { Circle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Todo {
  content?: string;
  status?: 'pending' | 'in_progress' | 'completed' | 'cancelled';
}

interface TodoWriteToolRendererProps {
  args: {
    todos?: Todo[];
  };
}

function StatusIcon({ status }: { status: Todo['status'] }) {
  const isCompleted = status === 'completed';
  return (
    <Circle 
      className={cn(
        "h-2.5 w-2.5",
        isCompleted ? "fill-current text-foreground/70" : "text-muted-foreground/40"
      )} 
    />
  );
}

export function TodoWriteToolRenderer({ args }: TodoWriteToolRendererProps) {
  const todos = args.todos || [];

  if (todos.length === 0) {
    return (
      <div className="text-[10px] text-muted-foreground/50 italic">
        No todos
      </div>
    );
  }

  return (
    <ul className="space-y-0.5">
      {todos.map((todo, index) => (
        <li 
          key={index}
          className="flex items-start gap-1.5"
        >
          <div className="mt-0.5 flex-shrink-0">
            <StatusIcon status={todo.status} />
          </div>
          <span className={cn(
            "text-[10px] leading-tight",
            todo.status === 'completed' ? 'text-muted-foreground/60' : 'text-foreground/80',
            todo.status === 'cancelled' && 'line-through text-muted-foreground/40'
          )}>
            {todo.content}
          </span>
        </li>
      ))}
    </ul>
  );
}

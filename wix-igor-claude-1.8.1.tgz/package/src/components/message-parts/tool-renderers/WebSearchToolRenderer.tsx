import { Globe } from 'lucide-react';

interface WebSearchToolRendererProps {
  args: {
    query?: string;
  };
  toolName?: string;
}

export function WebSearchToolRenderer({ args, toolName }: WebSearchToolRendererProps) {
  const query = args.query || '';

  return (
    <>
      <Globe className="h-3 w-3 text-muted-foreground/60 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'WebSearch'}</span>
      <span className="text-[9px] text-muted-foreground/30">·</span>
      <span className="text-[9px] font-mono text-muted-foreground/70 truncate">"{query}"</span>
    </>
  );
}


import { FilePlus } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface WriteToolRendererProps {
  args: {
    file_path?: string;
    content?: string;
  };
}

// Infer language from file extension
function getLanguage(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase() || '';
  const langMap: Record<string, string> = {
    ts: 'typescript',
    tsx: 'tsx',
    js: 'javascript',
    jsx: 'jsx',
    py: 'python',
    rb: 'ruby',
    go: 'go',
    rs: 'rust',
    java: 'java',
    kt: 'kotlin',
    swift: 'swift',
    css: 'css',
    scss: 'scss',
    html: 'html',
    json: 'json',
    yaml: 'yaml',
    yml: 'yaml',
    md: 'markdown',
    sql: 'sql',
    sh: 'bash',
    bash: 'bash',
    zsh: 'bash',
  };
  return langMap[ext] || 'text';
}

export function WriteToolRenderer({ args }: WriteToolRendererProps) {
  const filePath = args.file_path || '';
  const content = args.content || '';
  const fileName = filePath.split('/').pop() || filePath;
  const directory = filePath.replace(fileName, '');
  const language = getLanguage(filePath);

  // Truncate content for display (show first ~15 lines)
  const lines = content.split('\n');
  const truncated = lines.length > 15;
  const displayContent = truncated ? lines.slice(0, 15).join('\n') + '\n...' : content;

  return (
    <div className="space-y-1">
      <div className="text-[9px] text-muted-foreground/50">{lines.length} lines</div>
      {content && (
        <div className="rounded overflow-hidden">
          <SyntaxHighlighter
            style={oneDark}
            language={language}
            customStyle={{
              margin: 0,
              padding: '0.5rem',
              fontSize: '9px',
              lineHeight: '1.3',
              maxHeight: '120px',
              overflow: 'auto',
            }}
          >
            {displayContent}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  );
}

interface WriteToolPathProps extends WriteToolRendererProps {
  toolName?: string;
}

// Export path component for use in ToolCallBubble header
export function WriteToolPath({ args, toolName }: WriteToolPathProps) {
  const filePath = args.file_path || '';
  const fileName = filePath.split('/').pop() || filePath;
  const directory = filePath.replace(fileName, '');

  return (
    <>
      <FilePlus className="h-3 w-3 text-green-400 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Write'}</span>
      <span className="text-[10px] font-mono text-muted-foreground/60 truncate">{directory}</span>
      <span className="text-[10px] font-mono text-foreground/80">{fileName}</span>
    </>
  );
}

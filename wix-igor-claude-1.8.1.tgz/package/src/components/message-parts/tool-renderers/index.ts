export { ReadToolRenderer } from './ReadToolRenderer';
export { WriteToolRenderer, WriteToolPath } from './WriteToolRenderer';
export { EditToolRenderer, EditToolPath } from './EditToolRenderer';
export { BashToolRenderer, BashToolHeader } from './BashToolRenderer';
export { TodoWriteToolRenderer } from './TodoWriteToolRenderer';
export { GlobToolRenderer } from './GlobToolRenderer';
export { GrepToolRenderer } from './GrepToolRenderer';
export { TaskToolRenderer } from './TaskToolRenderer';
export { WebSearchToolRenderer } from './WebSearchToolRenderer';
export { DefaultToolRenderer } from './DefaultToolRenderer';

import { ReadToolRenderer } from './ReadToolRenderer';
import { WriteToolRenderer, WriteToolPath } from './WriteToolRenderer';
import { EditToolRenderer, EditToolPath } from './EditToolRenderer';
import { BashToolRenderer, BashToolHeader } from './BashToolRenderer';
import { TodoWriteToolRenderer } from './TodoWriteToolRenderer';
import { GlobToolRenderer } from './GlobToolRenderer';
import { GrepToolRenderer } from './GrepToolRenderer';
import { TaskToolRenderer } from './TaskToolRenderer';
import { WebSearchToolRenderer } from './WebSearchToolRenderer';
import { DefaultToolRenderer } from './DefaultToolRenderer';

// Tools that render inline (no card wrapper needed)
export const INLINE_TOOLS = ['read', 'glob', 'grep', 'task', 'websearch'];

// Tools that have custom header content (icon before tool name)
export const TOOLS_WITH_CUSTOM_HEADER = ['write', 'edit', 'bash'];

// Map tool names to their renderers
export function getToolRenderer(toolName: string) {
  const normalizedName = toolName.toLowerCase();
  
  switch (normalizedName) {
    case 'read':
      return ReadToolRenderer;
    case 'write':
      return WriteToolRenderer;
    case 'edit':
      return EditToolRenderer;
    case 'bash':
      return BashToolRenderer;
    case 'todowrite':
      return TodoWriteToolRenderer;
    case 'glob':
      return GlobToolRenderer;
    case 'grep':
      return GrepToolRenderer;
    case 'task':
      return TaskToolRenderer;
    case 'websearch':
      return WebSearchToolRenderer;
    default:
      return DefaultToolRenderer;
  }
}

// Get custom header component for tools that need it
export function getToolHeader(toolName: string) {
  const normalizedName = toolName.toLowerCase();
  
  switch (normalizedName) {
    case 'write':
      return WriteToolPath;
    case 'edit':
      return EditToolPath;
    case 'bash':
      return BashToolHeader;
    default:
      return null;
  }
}

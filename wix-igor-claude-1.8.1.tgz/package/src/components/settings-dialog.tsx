import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MCPServerList } from './mcp-server-list';
import { Switch } from '@/components/ui/switch';
import type { McpServerWithStatus, SettingSource, PluginWithStatus } from '@/types';

interface ModelOption {
  id: string;
  name: string;
}

// Settings shape for JSON view
interface SettingsJson {
  model: string;
  systemPrompt: string;
  systemPromptMode: 'append' | 'replace';
  settingSources: SettingSource[];
  mcpServers: Record<string, {
    type: 'http';
    url: string;
    headers?: Record<string, string>;
  }>;
}

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  systemPrompt: string;
  onSystemPromptChange: (value: string) => void;
  systemPromptMode: 'append' | 'replace';
  onSystemPromptModeChange: (value: 'append' | 'replace') => void;
  model: string;
  onModelChange: (value: string) => void;
  availableModels: readonly ModelOption[];
  // Settings sources
  settingSources: SettingSource[];
  onSettingSourcesChange: (sources: SettingSource[]) => void;
  // MCP servers
  mcpServers: Record<string, McpServerWithStatus>;
  onAddMcpServer: (name: string, url: string, headers?: Record<string, string>) => void;
  onRemoveMcpServer: (name: string) => void;
  mcpLoading?: boolean;
  // Plugins (read-only, all marketplace plugins are enabled)
  plugins?: PluginWithStatus[];
  // Display
  showSystemMessages?: boolean;
  onShowSystemMessagesChange?: (show: boolean) => void;
  // Actions
  onSave: () => void;
  onClearPrompt: () => void;
  onSessionClear: () => void;
  onResetSettings?: () => void;
  // For JSON view - need ability to set all at once
  onBulkUpdate?: (settings: Partial<SettingsJson>) => void;
  version?: string;
  cwd?: string;
  proxyConfig?: { baseUrl?: string; customHeaders?: boolean };
}

const ALL_SETTING_SOURCES: { id: SettingSource; label: string; description: string }[] = [
  { id: 'user', label: 'User', description: '~/.claude/settings.json' },
  { id: 'project', label: 'Project', description: '.claude/settings.json' },
  { id: 'local', label: 'Local', description: '.claude/settings.local.json' },
];

export function SettingsDialog({
  open,
  onOpenChange,
  systemPrompt,
  onSystemPromptChange,
  systemPromptMode,
  onSystemPromptModeChange,
  model,
  onModelChange,
  availableModels,
  settingSources,
  onSettingSourcesChange,
  mcpServers,
  onAddMcpServer,
  onRemoveMcpServer,
  mcpLoading,
  plugins = [],
  showSystemMessages = false,
  onShowSystemMessagesChange,
  onSave,
  onClearPrompt,
  onSessionClear,
  onResetSettings,
  onBulkUpdate,
  version,
  cwd,
  proxyConfig,
}: SettingsDialogProps) {
  const [viewMode, setViewMode] = useState<'form' | 'json'>('form');
  const [jsonText, setJsonText] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);
  
  // Build current settings object (strip status from mcpServers)
  const buildSettingsJson = (): SettingsJson => {
    const cleanMcpServers: Record<string, { type: 'http'; url: string; headers?: Record<string, string> }> = {};
    for (const [name, config] of Object.entries(mcpServers)) {
      cleanMcpServers[name] = {
        type: 'http',
        url: config.url,
        ...(config.headers && { headers: config.headers }),
      };
    }
    return {
      model,
      systemPrompt,
      systemPromptMode,
      settingSources,
      mcpServers: cleanMcpServers,
    };
  };

  // Sync JSON text when switching to JSON view or when props change
  useEffect(() => {
    if (viewMode === 'json') {
      setJsonText(JSON.stringify(buildSettingsJson(), null, 2));
      setJsonError(null);
    }
  }, [viewMode, model, systemPrompt, systemPromptMode, settingSources, mcpServers, plugins]);

  const toggleSettingSource = (source: SettingSource) => {
    if (settingSources.includes(source)) {
      if (settingSources.length > 1) {
        onSettingSourcesChange(settingSources.filter(s => s !== source));
      }
    } else {
      onSettingSourcesChange([...settingSources, source]);
    }
  };

  const handleJsonSave = () => {
    try {
      const parsed = JSON.parse(jsonText) as SettingsJson;
      
      // Validate and apply
      if (parsed.model) onModelChange(parsed.model);
      if (typeof parsed.systemPrompt === 'string') onSystemPromptChange(parsed.systemPrompt);
      if (parsed.systemPromptMode === 'append' || parsed.systemPromptMode === 'replace') {
        onSystemPromptModeChange(parsed.systemPromptMode);
      }
      if (Array.isArray(parsed.settingSources) && parsed.settingSources.length > 0) {
        onSettingSourcesChange(parsed.settingSources);
      }
      
      // Handle MCP servers - need to sync with existing
      if (parsed.mcpServers && typeof parsed.mcpServers === 'object') {
        // Remove servers that are no longer in JSON
        for (const name of Object.keys(mcpServers)) {
          if (!(name in parsed.mcpServers)) {
            onRemoveMcpServer(name);
          }
        }
        // Add/update servers from JSON
        for (const [name, config] of Object.entries(parsed.mcpServers)) {
          if (config.url) {
            onAddMcpServer(name, config.url, config.headers);
          }
        }
      }
      
      setJsonError(null);
      onSave();
    } catch (err) {
      setJsonError(err instanceof Error ? err.message : 'Invalid JSON');
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex flex-col">
        <SheetHeader>
          <div className="flex items-center justify-between pr-8">
            <div>
              <SheetTitle>Settings</SheetTitle>
              <SheetDescription>
                Configure agent behavior
              </SheetDescription>
            </div>
            {/* View Mode Toggle */}
            <div className="flex gap-1 bg-muted rounded-md p-0.5">
              <button
                onClick={() => setViewMode('form')}
                className={`px-3 py-1 text-xs rounded transition-colors ${
                  viewMode === 'form' 
                    ? 'bg-background shadow-sm' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Form
              </button>
              <button
                onClick={() => setViewMode('json')}
                className={`px-3 py-1 text-xs rounded transition-colors ${
                  viewMode === 'json' 
                    ? 'bg-background shadow-sm' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                JSON
              </button>
            </div>
          </div>
        </SheetHeader>
        
        <div className="flex-1 overflow-hidden mt-4">
          {viewMode === 'json' ? (
            /* JSON View */
            <div className="h-full flex flex-col gap-2">
              <Textarea
                value={jsonText}
                onChange={(e) => {
                  setJsonText(e.target.value);
                  setJsonError(null);
                }}
                className="flex-1 font-mono text-xs resize-none"
                placeholder="{}"
              />
              {jsonError && (
                <p className="text-xs text-destructive">{jsonError}</p>
              )}
            </div>
          ) : (
            /* Form View */
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-6 pb-4 pr-4">
              {/* Model Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Model
                </label>
                <Select value={model} onValueChange={onModelChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableModels.map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Choose which Claude model to use for responses.
                </p>
              </div>

              {/* Settings Sources */}
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none">
                  Settings Sources
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_SETTING_SOURCES.map((source) => (
                    <button
                      key={source.id}
                      onClick={() => toggleSettingSource(source.id)}
                      className={`px-3 py-1.5 rounded-md text-xs border transition-colors ${
                        settingSources.includes(source.id)
                          ? 'bg-primary text-primary-foreground border-primary'
                          : 'bg-background hover:bg-muted border-border'
                      }`}
                      title={source.description}
                    >
                      {source.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  SDK loads settings from these sources. At least one must be selected.
                </p>
              </div>

              {/* System Prompt */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    System Prompt
                  </label>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={onClearPrompt}
                      className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
                    >
                      Clear
                    </Button>
                    <Select value={systemPromptMode} onValueChange={(v: 'append' | 'replace') => onSystemPromptModeChange(v)}>
                      <SelectTrigger className="w-28 h-7 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="append">Append</SelectItem>
                        <SelectItem value="replace">Replace</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Textarea
                  value={systemPrompt}
                  onChange={(e) => onSystemPromptChange(e.target.value)}
                  placeholder="Leave empty to use default behavior..."
                  className="min-h-[100px] text-xs"
                />
                <p className="text-xs text-muted-foreground">
                  {systemPromptMode === 'append' 
                    ? 'Appends to the default Claude Code preset instructions.'
                    : 'Replaces the default Claude Code preset instructions entirely.'}
                </p>
              </div>

              {/* Plugins */}
              {plugins.length > 0 && (
                <div className="space-y-2">
                  <label className="text-sm font-medium leading-none">
                    Plugins ({plugins.length})
                  </label>
                  <div className="space-y-3">
                    {plugins.map((plugin) => (
                      <div
                        key={plugin.name}
                        className="rounded-lg border bg-muted/30"
                      >
                        <div className="p-4">
                          <p className="font-medium text-sm">{plugin.name}</p>
                          {plugin.description && (
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {plugin.description}
                            </p>
                          )}
                        </div>
                        {/* Commands list */}
                        {plugin.commands && plugin.commands.length > 0 && (
                          <div className="px-4 pb-3 pt-0 border-t border-border/50">
                            <p className="text-[10px] font-medium text-muted-foreground mb-1.5 mt-2">
                              Commands:
                            </p>
                            <div className="space-y-2">
                              {plugin.commands.map((cmd) => (
                                <div
                                  key={cmd.name}
                                  className="text-[11px]"
                                >
                                  <div className="flex items-baseline gap-2 flex-wrap">
                                    <span className="font-mono text-muted-foreground/80 shrink-0">
                                      /{cmd.name}
                                    </span>
                                    {cmd.argumentHint && (
                                      <span className="text-muted-foreground/60 font-mono shrink-0">
                                        {cmd.argumentHint}
                                      </span>
                                    )}
                                  </div>
                                  {cmd.description && (
                                    <div className="text-muted-foreground/70 mt-0.5 ml-0">
                                      {cmd.description}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    All marketplace plugins are enabled by default.
                  </p>
                </div>
              )}

              {/* Display Settings */}
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none">Display</label>
                <label className="flex items-center justify-between p-3 rounded-lg border bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors">
                  <div className="flex-1 min-w-0 pr-4">
                    <p className="font-medium text-sm">Show system messages</p>
                    <p className="text-xs text-muted-foreground">
                      Show init, message_start, finished, result events
                    </p>
                  </div>
                  <Switch
                    checked={showSystemMessages}
                    onCheckedChange={(checked) => onShowSystemMessagesChange?.(checked)}
                    className="shrink-0"
                  />
                </label>
              </div>

              {/* MCP Servers */}
              <MCPServerList
                servers={mcpServers}
                onAdd={onAddMcpServer}
                onRemove={onRemoveMcpServer}
                onSessionClear={onSessionClear}
                isLoading={mcpLoading}
              />

              {/* Proxy Configuration */}
              {proxyConfig && (
                <div className="space-y-2">
                  <label className="text-sm font-medium leading-none">Proxy Configuration</label>
                  <div className="rounded-lg border bg-muted/30 p-3 space-y-2">
                    {proxyConfig.baseUrl && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-0.5">Base URL</p>
                        <p className="text-xs font-mono break-all text-foreground">{proxyConfig.baseUrl}</p>
                      </div>
                    )}
                    {proxyConfig.customHeaders && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-0.5">Custom Headers</p>
                        <p className="text-xs text-foreground">Configured</p>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Proxy settings are configured via environment variables (ANTHROPIC_BASE_URL, ANTHROPIC_CUSTOM_HEADERS).
                  </p>
                </div>
              )}

              {/* Version Info */}
              {(version || cwd) && (
                <div className="pt-4 border-t border-border space-y-1">
                  {version && (
                    <p className="text-xs text-muted-foreground text-center">
                      igor-claude v{version}
                    </p>
                  )}
                  {cwd && (
                    <p className="text-xs text-muted-foreground text-center font-mono break-all">
                      CWD: {cwd}
                    </p>
                  )}
                </div>
              )}
            </div>
            </ScrollArea>
          )}
        </div>
        
        <SheetFooter className="mt-4 flex-col gap-2 sm:flex-row">
          {onResetSettings && (
            <Button 
              onClick={onResetSettings} 
              variant="outline" 
              size="sm" 
              className="w-full sm:w-auto"
            >
              Reset to Defaults
            </Button>
          )}
          <Button onClick={viewMode === 'json' ? handleJsonSave : onSave} size="sm" className="w-full sm:flex-1">
            Save
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

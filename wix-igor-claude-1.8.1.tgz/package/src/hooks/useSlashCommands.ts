import { useMemo } from 'react';
import { BUILTIN_COMMANDS } from '@/lib/builtin-commands';
import type { PluginWithStatus } from '@/types';

export interface SlashCommand {
  name: string;
  description?: string;
  argumentHint?: string;
}

interface UseSlashCommandsOptions {
  plugins: PluginWithStatus[];
  sdkCommands: SlashCommand[];
}

/**
 * Hook to manage slash commands from multiple sources:
 * 1. Plugin commands (custom, from marketplace)
 * 2. SDK commands (from system_message after first query)
 * 3. Built-in commands (hardcoded, always available)
 * 
 * Returns commands sorted with custom commands on top, built-in at bottom.
 */
export function useSlashCommands({ plugins, sdkCommands }: UseSlashCommandsOptions): SlashCommand[] {
  // Extract commands from plugins
  const pluginCommands = useMemo(() => {
    const commands: SlashCommand[] = [];
    plugins.forEach((plugin) => {
      if (plugin.commands) {
        plugin.commands.forEach((cmd) => {
          commands.push({
            name: cmd.name,
            description: cmd.description,
            argumentHint: cmd.argumentHint,
          });
        });
      }
    });
    return commands;
  }, [plugins]);

  // Merge all command sources with proper ordering
  const allCommands = useMemo(() => {
    const customCommands: SlashCommand[] = [];
    const builtinCommandsList: SlashCommand[] = [];
    const seenNames = new Set<string>();
    
    // 1. Plugin commands first (custom, highest priority)
    pluginCommands.forEach(cmd => {
      if (!seenNames.has(cmd.name)) {
        customCommands.push(cmd);
        seenNames.add(cmd.name);
      }
    });
    
    // 2. SDK commands (may include custom user commands from ~/.claude/commands/)
    sdkCommands.forEach(cmd => {
      if (!seenNames.has(cmd.name)) {
        // Check if it's a built-in or custom
        if (cmd.name in BUILTIN_COMMANDS) {
          builtinCommandsList.push(cmd);
        } else {
          customCommands.push(cmd);
        }
        seenNames.add(cmd.name);
      }
    });
    
    // 3. Add remaining built-in commands (lowest priority, at the bottom)
    Object.entries(BUILTIN_COMMANDS).forEach(([name, info]) => {
      if (!seenNames.has(name)) {
        builtinCommandsList.push({ name, ...info });
        seenNames.add(name);
      }
    });
    
    // Custom commands on top, built-in commands below
    return [...customCommands, ...builtinCommandsList];
  }, [pluginCommands, sdkCommands]);

  return allCommands;
}





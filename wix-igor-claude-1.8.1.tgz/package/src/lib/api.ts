/**
 * Centralized API client for igor-claude
 * Handles all REST API calls to the backend
 */

import { API_BASE } from '@/constants';

// Error handling wrapper
async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorText = await response.text();
    let errorMessage = `HTTP ${response.status}`;
    try {
      const errorData = JSON.parse(errorText);
      errorMessage = errorData.error || errorMessage;
    } catch {
      errorMessage = errorText || errorMessage;
    }
    throw new Error(errorMessage);
  }
  return response.json();
}

// Settings API
export const settingsApi = {
  get: async () => {
    const response = await fetch(`${API_BASE}/settings`);
    return handleResponse<Record<string, any>>(response);
  },
  
  save: async (settings: Record<string, any>) => {
    const response = await fetch(`${API_BASE}/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    return handleResponse<{ success: boolean; path: string }>(response);
  },
};

// Version API
export const versionApi = {
  get: async () => {
    const response = await fetch(`${API_BASE}/version`);
    return handleResponse<{
      version: string;
      name: string;
      cwd: string;
      binaryMode: boolean;
    }>(response);
  },
};

// Plugins API
export const pluginsApi = {
  list: async () => {
    const response = await fetch(`${API_BASE}/plugins`);
    return handleResponse<{
      marketplace: string;
      plugins: Array<{
        name: string;
        source: string;
        description?: string;
        path: string;
        commands: Array<{
          name: string;
          description?: string;
          argumentHint?: string;
        }>;
      }>;
    }>(response);
  },
};

// Sessions API
export const sessionsApi = {
  list: async () => {
    const response = await fetch(`${API_BASE}/sessions`);
    return handleResponse<{
      sessions: Array<{
        sessionId: string;
        filePath: string;
        startTime: string;
        lastUpdated: string;
        messageCount: number;
        preview: string;
        agentId?: string | null;
        cwd?: string;
        gitBranch?: string;
      }>;
    }>(response);
  },
  
  get: async (sessionId: string, raw: boolean = false) => {
    const url = raw 
      ? `${API_BASE}/sessions/${sessionId}?raw=true`
      : `${API_BASE}/sessions/${sessionId}`;
    const response = await fetch(url);
    
    if (raw) {
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return { raw: true, content: await response.text() };
    }
    
    return handleResponse<{
      session: {
        sessionId: string;
        messages: any[];
        startTime: string;
        lastUpdated: string;
      };
      filePath: string;
      tokenUsage?: {
        input: number;
        output: number;
        total: number;
      } | null;
    }>(response);
  },
  
  create: async () => {
    const response = await fetch(`${API_BASE}/sessions/new`, { method: 'POST' });
    return handleResponse<{ sessionId: string }>(response);
  },
  
  delete: async (sessionId: string) => {
    const response = await fetch(`${API_BASE}/session/${sessionId}`, { method: 'DELETE' });
    return handleResponse<{ success: boolean; message: string }>(response);
  },
};

// Chat API (abort only - SSE is handled separately)
export const chatApi = {
  abort: async (sessionId: string) => {
    const response = await fetch(`${API_BASE}/abort`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
    });
    return handleResponse<{ success: boolean; aborted: number }>(response);
  },
};

// MCP API
export const mcpApi = {
  list: async () => {
    const response = await fetch(`${API_BASE}/mcp`);
    return handleResponse<{
      mcpServers: Record<string, any>;
      source: string;
    }>(response);
  },
  
  add: async (name: string, config: { type: string; url: string; headers?: Record<string, string> }) => {
    const response = await fetch(`${API_BASE}/mcp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, config }),
    });
    return handleResponse<{ success: boolean }>(response);
  },
  
  remove: async (name: string) => {
    const response = await fetch(`${API_BASE}/mcp/${name}`, { method: 'DELETE' });
    return handleResponse<{ success: boolean }>(response);
  },
};

// Health API
export const healthApi = {
  check: async () => {
    const response = await fetch(`${API_BASE}/health`);
    return handleResponse<{ status: string; timestamp: string }>(response);
  },
};


/**
 * Built-in Claude Code slash commands with descriptions
 * Source: https://code.claude.com/docs/en/slash-commands.md
 */

export const BUILTIN_COMMANDS: Record<string, { description: string; argumentHint?: string }> = {
  'add-dir': { description: 'Add additional working directories' },
  'agents': { description: 'Manage custom AI subagents for specialized tasks' },
  'bashes': { description: 'List and manage background tasks' },
  'bug': { description: 'Report bugs (sends conversation to Anthropic)' },
  'clear': { description: 'Clear conversation history' },
  'compact': { description: 'Compact conversation with optional focus instructions', argumentHint: '[instructions]' },
  'config': { description: 'Open the Settings interface (Config tab)' },
  'context': { description: 'Visualize current context usage as a colored grid' },
  'cost': { description: 'Show token usage statistics' },
  'doctor': { description: 'Checks the health of your Claude Code installation' },
  'exit': { description: 'Exit the REPL' },
  'export': { description: 'Export the current conversation to a file or clipboard', argumentHint: '[filename]' },
  'help': { description: 'Get usage help' },
  'hooks': { description: 'Manage hook configurations for tool events' },
  'ide': { description: 'Manage IDE integrations and show status' },
  'init': { description: 'Initialize project with CLAUDE.md guide' },
  'install-github-app': { description: 'Set up Claude GitHub Actions for a repository' },
  'login': { description: 'Switch Anthropic accounts' },
  'logout': { description: 'Sign out from your Anthropic account' },
  'mcp': { description: 'Manage MCP server connections and OAuth authentication' },
  'memory': { description: 'Edit CLAUDE.md memory files' },
  'model': { description: 'Select or change the AI model' },
  'output-style': { description: 'Set the output style directly or from a selection menu', argumentHint: '[style]' },
  'permissions': { description: 'View or update permissions' },
  'plugin': { description: 'Manage Claude Code plugins' },
  'pr-comments': { description: 'View pull request comments' },
  'privacy-settings': { description: 'View and update your privacy settings' },
  'release-notes': { description: 'View release notes' },
  'resume': { description: 'Resume a conversation' },
  'review': { description: 'Request code review' },
  'rewind': { description: 'Rewind the conversation and/or code' },
  'sandbox': { description: 'Enable sandboxed bash tool with filesystem and network isolation' },
  'security-review': { description: 'Complete a security review of pending changes' },
  'status': { description: 'Show version, model, account, and connectivity status' },
  'statusline': { description: "Set up Claude Code's status line UI" },
  'terminal-setup': { description: 'Install Shift+Enter key binding for newlines' },
  'todos': { description: 'List current todo items' },
  'usage': { description: 'Show plan usage limits and rate limit status' },
  'vim': { description: 'Enter vim mode for alternating insert and command modes' },
};

/**
 * Enrich a command with built-in description if available
 */
export function enrichCommand(cmd: { name: string; description?: string; argumentHint?: string }): {
  name: string;
  description?: string;
  argumentHint?: string;
} {
  const builtin = BUILTIN_COMMANDS[cmd.name];
  if (builtin) {
    return {
      name: cmd.name,
      description: cmd.description || builtin.description,
      argumentHint: cmd.argumentHint || builtin.argumentHint,
    };
  }
  return cmd;
}





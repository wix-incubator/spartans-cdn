import pino from 'pino';
import { join } from 'path';
import { existsSync, mkdirSync } from 'fs';
import { homedir } from 'os';

// Log directory - ~/.igor-claude/logs/
const LOG_DIR = join(homedir(), '.igor-claude', 'logs');

// Ensure log directory exists
if (!existsSync(LOG_DIR)) {
  mkdirSync(LOG_DIR, { recursive: true });
}

// Determine if we're in development mode (for console formatting only)
const isDev = process.env.NODE_ENV !== 'production' && !process.env.IGOR_PROD_LOGS;

// Create the logger with appropriate transport
// Always write to files, but format console differently in dev vs prod
const logger = pino(
  {
    level: process.env.LOG_LEVEL || 'info',
    timestamp: pino.stdTimeFunctions.isoTime,
    base: {
      pid: process.pid,
    },
    serializers: {
      err: pino.stdSerializers.err,
      error: pino.stdSerializers.err,
    },
  },
  pino.transport({
    targets: [
      // Console output - pretty in dev, JSON in prod
      isDev
        ? {
            target: 'pino-pretty',
            options: {
              colorize: true,
              translateTime: 'SYS:HH:MM:ss',
              ignore: 'pid,hostname',
            },
            level: 'info',
          }
        : {
            target: 'pino/file',
            options: { destination: 1 }, // stdout
            level: 'info',
          },
      // File output with daily rotation (always enabled)
      {
        target: 'pino-roll',
        options: {
          file: join(LOG_DIR, 'igor-claude'),
          frequency: 'daily',
          mkdir: true,
          size: '10m', // Rotate at 10MB
          limit: { count: 7 }, // Keep 7 days of logs
        },
        level: 'debug',
      },
    ],
  })
);

// Export child loggers for different modules
export const createLogger = (module: string) => logger.child({ module });

// Main logger instance
export default logger;

// Log directory path for reference
export const logDir = LOG_DIR;
export const getLogFilePath = () => join(LOG_DIR, 'igor-claude');


import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { homedir } from 'os';
import { existsSync, mkdirSync, readFileSync } from 'fs';
import { execSync } from 'child_process';
import { createLogger } from '../lib/logger';

const log = createLogger('config');

// Path resolution
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Package root - use IGOR_CLAUDE_ROOT if running from CLI, otherwise derive from __dirname
// Note: __dirname in this file is src/server/, so we go up 2 levels to get package root
export const PACKAGE_ROOT = process.env.IGOR_CLAUDE_ROOT || join(__dirname, '..', '..');
export const DIST_PATH = join(PACKAGE_ROOT, 'dist');

// Igor Claude directory for user data
export const IGOR_CLAUDE_DIR = join(homedir(), '.igor-claude');
export const MARKETPLACE_PATH = join(IGOR_CLAUDE_DIR, 'marketplace');

// Claude CLI directory
export const CLAUDE_DIR = join(homedir(), '.claude');

// CDN URLs
export const MARKETPLACE_CDN_BASE = process.env.MARKETPLACE_CDN_URL || 'https://static.parastorage.com/services/igor-marketplace';

// Server configuration
export const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3001;

// Ensure directories exist
if (!existsSync(IGOR_CLAUDE_DIR)) {
  mkdirSync(IGOR_CLAUDE_DIR, { recursive: true });
}

// Detect Claude CLI path (needed for binary mode where __dirname is virtual)
export function getClaudeExecutablePath(): string | undefined {
  try {
    const path = execSync('which claude', { encoding: 'utf-8' }).trim();
    if (path) {
      log.info({ path }, 'Claude CLI found');
      return path;
    }
  } catch {
    // Try common paths
    const commonPaths = [
      '/usr/local/bin/claude',
      '/opt/homebrew/bin/claude',
      `${homedir()}/.local/bin/claude`,
      `${homedir()}/.npm-global/bin/claude`,
    ];
    for (const p of commonPaths) {
      if (existsSync(p)) {
        log.info({ path: p }, 'Claude CLI found');
        return p;
      }
    }
  }
  log.warn('Claude CLI not found - SDK may fail in binary mode');
  return undefined;
}

// Get the original working directory (where user ran the command)
// Important when running via npx, which changes CWD to the cache directory
export function getOriginalCwd(): string {
  return process.env.IGOR_CLAUDE_ORIGINAL_CWD || process.cwd();
}

// Read version from package.json
export function getVersionFromPackageJson(): string {
  try {
    const packageJsonPath = join(PACKAGE_ROOT, 'package.json');
    if (existsSync(packageJsonPath)) {
      const pkg = JSON.parse(readFileSync(packageJsonPath, 'utf-8'));
      return pkg.version || 'unknown';
    }
  } catch {}
  return 'unknown';
}


import { type Request, type Response, type Router } from 'express';
import { existsSync } from 'fs';
import { query } from '@anthropic-ai/claude-agent-sdk';
import { createLogger } from '../../lib/logger';
import { getOriginalCwd } from '../config';
import type { Marketplace, ImageData } from '../types';
import { resolvePluginPath } from '../services/marketplace';

const log = createLogger('chat');

// These will be set by the parent server
let MARKETPLACE: Marketplace | null = null;
let CLAUDE_EXECUTABLE_PATH: string | undefined;
let abortControllers: Map<string, AbortController>;
let updateMcpStatus: (servers: Array<{ name: string; status: string }>) => void;

export function initChatRoute(options: {
  marketplace: Marketplace | null;
  claudeExecutablePath: string | undefined;
  abortControllersMap: Map<string, AbortController>;
  onMcpStatusUpdate: (servers: Array<{ name: string; status: string }>) => void;
}) {
  MARKETPLACE = options.marketplace;
  CLAUDE_EXECUTABLE_PATH = options.claudeExecutablePath;
  abortControllers = options.abortControllersMap;
  updateMcpStatus = options.onMcpStatusUpdate;
}

export async function handleChatRequest(req: Request, res: Response) {
  const { message, sessionId, model, systemPromptMode, images } = req.body as {
    message?: string;
    sessionId?: string | null;
    model?: string;
    systemPromptMode?: 'append' | 'replace';
    images?: ImageData[];
  };

  const hasImages = images && Array.isArray(images) && images.length > 0;

  log.info({
    sessionId: sessionId || 'new',
    messageType: typeof message,
    messagePreview: message?.substring(0, 50),
    model: model || 'default',
    imageCount: hasImages ? images.length : 0,
  }, 'POST /api/chat');

  if (hasImages) {
    log.debug({ imageCount: images.length }, 'Images received');
    images.forEach((img, i) => {
      log.debug({
        index: i + 1,
        fileName: img.fileName,
        mediaType: img.mediaType,
        dataLength: img.data?.length || 0
      }, 'Image details');
    });
  }

  // Allow empty message if images are provided
  if ((!message || message.trim() === '') && !hasImages) {
    log.warn('Message or images are required');
    return res.status(400).json({ error: 'Message or images are required' });
  }

  // Extract optional system prompt
  const systemPrompt = req.body.systemPrompt;
  const mode = systemPromptMode || 'append';

  // Debug logging for system prompt
  if (process.env.DEBUG === 'true') {
    log.debug({
      bodyKeys: Object.keys(req.body),
      systemPrompt: req.body.systemPrompt,
      systemPromptMode: req.body.systemPromptMode,
      systemPromptVar: systemPrompt,
      systemPromptType: typeof systemPrompt,
      systemPromptTrimmed: systemPrompt?.trim(),
      mode,
    }, 'System prompt debug');
  }

  const sid = sessionId || `session-${Date.now()}`;

  // Set up SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  // Helper to write SSE and flush
  const sseWrite = (data: string) => {
    if (!res.closed && !res.destroyed) {
      res.write(data);
      if (typeof (res as any).flush === 'function') {
        (res as any).flush();
      }
    }
  };

  // Create abort signal and request ID
  const abortController = new AbortController();
  const requestId = `${sid}-${Date.now()}`;
  abortControllers.set(requestId, abortController);

  let isCompleted = false;

  // Helper function to safely send error to client
  const sendError = (errorMessage: string, errorDetails?: any) => {
    try {
      if (!res.closed && !res.destroyed) {
        const errorData = {
          type: 'error',
          error: errorMessage,
          ...(errorDetails && { details: errorDetails }),
        };
        sseWrite(`data: ${JSON.stringify(errorData)}\n\n`);
        log.debug({ errorMessage, errorDetails }, 'Error sent to client');
      } else {
        log.warn({ errorMessage }, 'Cannot send error - connection closed');
      }
    } catch (err) {
      log.error({ err }, 'Failed to send error to client');
    }
  };

  // Cleanup on close
  res.on('close', () => {
    if (!isCompleted) {
      log.debug({ sessionId: sid }, 'SSE connection closed');
      abortControllers.delete(requestId);
    }
  });

  let keepAliveInterval: NodeJS.Timeout | null = null;

  try {
    // Double-check API key
    if (!process.env.ANTHROPIC_API_KEY) {
      sendError('ANTHROPIC_API_KEY environment variable is required.');
      return res.end();
    }

    // Send initial event
    sseWrite(`data: ${JSON.stringify({ type: 'init', sessionId: sid })}\n\n`);

    let lastActivityTime = Date.now();

    // Send periodic status updates
    keepAliveInterval = setInterval(() => {
      if (!res.closed && !isCompleted) {
        try {
          const waitTime = Math.round((Date.now() - lastActivityTime) / 1000);
          if (waitTime > 5) {
            sseWrite(`data: ${JSON.stringify({
              type: 'status',
              message: `Waiting for response... (${waitTime}s)`,
              waiting: true
            })}\n\n`);
          } else {
            sseWrite(`: keepalive\n\n`);
          }
        } catch (err) {
          if (keepAliveInterval) clearInterval(keepAliveInterval);
        }
      } else {
        if (keepAliveInterval) clearInterval(keepAliveInterval);
      }
    }, 3000);

    const markActivity = () => { lastActivityTime = Date.now(); };

    log.debug({ sessionId: sid }, 'Starting to stream response');
    const messageToSend: string = String(message).trim();

    if (!messageToSend && !hasImages) {
      if (keepAliveInterval) clearInterval(keepAliveInterval);
      abortControllers.delete(requestId);
      throw new Error('Message cannot be empty');
    }

    log.debug({ sessionId: sid }, 'Starting Claude query');

    let accumulatedText = '';
    let chunkCount = 0;
    let currentSessionId: string | null = sid;

    // Prepare prompt input
    let promptInput: string | AsyncIterable<any>;

    if (hasImages) {
      log.debug({ imageCount: images.length }, 'Creating prompt with images');

      promptInput = (async function* () {
        const contentBlocks: any[] = [];

        if (messageToSend.trim()) {
          contentBlocks.push({ type: 'text', text: messageToSend });
        }

        for (const img of images!) {
          contentBlocks.push({
            type: 'image',
            source: {
              type: 'base64',
              media_type: img.mediaType,
              data: img.data,
            },
          });
        }

        log.debug({ blockCount: contentBlocks.length }, 'Creating async generator with content blocks');

        const userMessage = {
          type: 'user',
          message: { role: 'user', content: contentBlocks },
          parent_tool_use_id: null,
          session_id: sessionId || 'default',
        };

        log.debug({ blockCount: contentBlocks.length }, 'Yielding user message');
        yield userMessage;
      })();
    } else {
      promptInput = messageToSend;
    }

    // MCP servers from request
    const mcpServers = req.body.mcpServers || {};
    if (Object.keys(mcpServers).length > 0) {
      log.debug({ mcpServers }, 'MCP servers from request');
    }

    // Load marketplace plugins
    const plugins: { type: 'local'; path: string }[] = [];
    if (MARKETPLACE) {
      for (const plugin of MARKETPLACE.plugins) {
        const pluginPath = resolvePluginPath(plugin.source);
        if (existsSync(pluginPath)) {
          plugins.push({ type: 'local', path: pluginPath });
          log.debug({ plugin: plugin.name, path: pluginPath }, 'Plugin loaded');
        } else {
          log.warn({ plugin: plugin.name, path: pluginPath }, 'Plugin path not found');
        }
      }
    }

    if (plugins.length > 0) {
      log.info({ pluginCount: plugins.length, plugins: plugins.map(p => p.path) }, 'Loaded marketplace plugins');
    }

    const queryOptions: any = {
      cwd: getOriginalCwd(),
      model: model || undefined,
      permissionMode: 'bypassPermissions',
      maxTurns: 1000,
      settingSources: ['user', 'project', 'local'],
      resume: sessionId || undefined,
      includePartialMessages: true,
      ...(CLAUDE_EXECUTABLE_PATH && { pathToClaudeCodeExecutable: CLAUDE_EXECUTABLE_PATH }),
      ...(Object.keys(mcpServers).length > 0 && { mcpServers }),
      ...(plugins.length > 0 && { plugins }),
    };

    // Add system prompt
    if (systemPrompt && systemPrompt.trim()) {
      if (mode === 'replace') {
        queryOptions.systemPrompt = systemPrompt.trim();
        log.debug({ mode: 'replace', systemPrompt: queryOptions.systemPrompt }, 'Using REPLACE mode');
      } else {
        queryOptions.systemPrompt = {
          type: 'preset',
          preset: 'claude_code',
          append: systemPrompt.trim(),
        };
        log.debug({ mode: 'append', systemPrompt: queryOptions.systemPrompt }, 'Using APPEND mode');
      }
    } else {
      log.debug('No system prompt provided - using default');
    }

    // Add env
    queryOptions.env = {
      PATH: process.env.PATH || '',
      ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
      MAX_THINKING_TOKENS: process.env.MAX_THINKING_TOKENS || '10000',
      IS_SANDBOX: process.env.IS_SANDBOX || '0',
      SANDBOX_ID: process.env.SANDBOX_ID || '',
      ...process.env,
    };

    // Log custom Anthropic SDK configuration if used
    if (process.env.ANTHROPIC_BASE_URL) {
      log.info({ baseUrl: process.env.ANTHROPIC_BASE_URL }, 'Using custom ANTHROPIC_BASE_URL');
    }
    if (process.env.ANTHROPIC_CUSTOM_HEADERS) {
      log.info({ customHeaders: process.env.ANTHROPIC_CUSTOM_HEADERS }, 'Using ANTHROPIC_CUSTOM_HEADERS');
    }

    if (process.env.DEBUG === 'true') {
      log.debug({ systemPrompt: queryOptions.systemPrompt }, 'Final queryOptions.systemPrompt');
    }

    // Log query start with key details
    log.info({ 
      sessionId: sid,
      hasApiKey: !!process.env.ANTHROPIC_API_KEY,
      apiKeyPrefix: process.env.ANTHROPIC_API_KEY?.substring(0, 10) || 'none',
      baseUrl: process.env.ANTHROPIC_BASE_URL || 'default',
      customHeaders: !!process.env.ANTHROPIC_CUSTOM_HEADERS,
    }, 'Starting Claude query');

    let queryIterator;
    try {
      queryIterator = query({
        prompt: promptInput,
        options: queryOptions,
      });
      log.debug({ sessionId: sid }, 'Query iterator created successfully');
    } catch (queryError) {
      log.error({ 
        err: queryError, 
        sessionId: sid,
        errorName: queryError instanceof Error ? queryError.name : 'Unknown',
        errorMessage: queryError instanceof Error ? queryError.message : String(queryError),
        errorStack: queryError instanceof Error ? queryError.stack : undefined,
      }, 'Failed to create query iterator');
      throw queryError;
    }

    const contentBlocksByIndex = new Map<number, string>();
    let firstMessageReceived = false;
    const queryStartTime = Date.now();

    try {
      for await (const message of queryIterator) {
        if (!firstMessageReceived) {
          firstMessageReceived = true;
          const timeToFirstMessage = Date.now() - queryStartTime;
          log.info({ sessionId: sid, timeToFirstMessage }, 'First message received from query iterator');
        }
        if (abortController.signal.aborted) {
          log.debug({ sessionId: sid }, 'Stream aborted');
          if (!res.closed) {
            sseWrite(`data: ${JSON.stringify({ type: 'aborted' })}\n\n`);
          }
          break;
        }

        markActivity();
        const msgType = message.type;

        // Log message type only (full details in DEBUG mode)
        if (process.env.DEBUG === 'true') {
          log.debug({ msgType, message }, 'Received message');
        }

        if (msgType === 'assistant') {
          sseWrite(`data: ${JSON.stringify({
            type: 'assistant_message',
            message: (message as any).message,
            timestamp: new Date().toISOString()
          })}\n\n`);
        } else if (msgType === 'result') {
          const resultMessage = message as any;
          const result = resultMessage.result;
          
          // Log result message summary
          if (resultMessage.is_error || resultMessage.errors?.length > 0) {
            log.warn({ 
              sessionId: sid,
              subtype: resultMessage.subtype,
              is_error: resultMessage.is_error,
              errors: resultMessage.errors,
            }, 'Result message with errors');
          } else {
            log.debug({ 
              sessionId: sid,
              subtype: resultMessage.subtype,
              num_turns: resultMessage.num_turns,
            }, 'Result message received');
          }

          // Check if this is an error result
          if (resultMessage.subtype && resultMessage.subtype.startsWith('error_')) {
            const errorSubtype = resultMessage.subtype;
            const errors = resultMessage.errors || [];
            const errorText = errors.join('; ') || `Error: ${errorSubtype}`;
            
            log.error({ 
              subtype: errorSubtype,
              errors,
              sessionId: sid,
            }, 'Result message with error subtype');
            
            sendError(errorText, { subtype: errorSubtype, errors });
          }

          if (result && typeof result === 'object' && 'tool_use_id' in result) {
            sseWrite(`data: ${JSON.stringify({
              type: 'tool_result',
              content: result.content || null,
              tool_use_id: result.tool_use_id || null,
              timestamp: new Date().toISOString()
            })}\n\n`);
          } else {
            sseWrite(`data: ${JSON.stringify({
              type: 'result',
              data: message,
              timestamp: new Date().toISOString()
            })}\n\n`);
            if (typeof (res as any).flush === 'function') {
              (res as any).flush();
            }
          }
        } else if (msgType === 'system') {
          const systemMessage = message as any;
          
          // Log system message in a readable format
          const systemLog: any = {
            sessionId: sid,
            subtype: systemMessage.subtype,
            session_id: systemMessage.session_id,
            apiKeySource: systemMessage.apiKeySource,
            cwd: systemMessage.cwd,
            model: systemMessage.model,
            permissionMode: systemMessage.permissionMode,
            output_style: systemMessage.output_style,
            claude_code_version: systemMessage.claude_code_version,
          };
          
          if (systemMessage.tools && systemMessage.tools.length > 0) {
            systemLog.tools = systemMessage.tools;
            systemLog.toolCount = systemMessage.tools.length;
          }
          
          if (systemMessage.mcp_servers && systemMessage.mcp_servers.length > 0) {
            systemLog.mcp_servers = systemMessage.mcp_servers.map((s: any) => ({
              name: s.name,
              status: s.status,
            }));
          }
          
          if (systemMessage.slash_commands && systemMessage.slash_commands.length > 0) {
            systemLog.slash_commands = systemMessage.slash_commands;
            systemLog.slashCommandCount = systemMessage.slash_commands.length;
          }
          
          if (systemMessage.plugins && systemMessage.plugins.length > 0) {
            systemLog.plugins = systemMessage.plugins.map((p: any) => ({
              name: p.name,
              path: p.path,
            }));
            systemLog.pluginCount = systemMessage.plugins.length;
          }
          
          if (systemMessage.agents && systemMessage.agents.length > 0) {
            systemLog.agents = systemMessage.agents;
          }
          
          if (systemMessage.skills && systemMessage.skills.length > 0) {
            systemLog.skills = systemMessage.skills;
          }
          
          log.info(systemLog, 'System message received');
          
          const sessionIdFromMessage = systemMessage.session_id;
          if (sessionIdFromMessage && sessionIdFromMessage !== currentSessionId) {
            log.debug({ sessionId: sessionIdFromMessage }, 'Captured session ID');
            currentSessionId = sessionIdFromMessage;
          }

          const mcpServersStatus = systemMessage.mcp_servers;
          if (mcpServersStatus && Array.isArray(mcpServersStatus)) {
            log.debug({ mcpServers: mcpServersStatus }, 'MCP servers status');
            updateMcpStatus(mcpServersStatus);
          }

          const systemEvent = {
            ...message,
            type: 'system_message',
            timestamp: new Date().toISOString()
          };
          sseWrite(`data: ${JSON.stringify(systemEvent)}\n\n`);
          if (typeof (res as any).flush === 'function') {
            (res as any).flush();
          }

          if (sessionIdFromMessage) {
            sseWrite(`data: ${JSON.stringify({ type: 'init', sessionId: sessionIdFromMessage })}\n\n`);
          }
        } else if (msgType === 'stream_event') {
          const event = (message as any).event;
          
          // Log stream events only in DEBUG mode
          if (process.env.DEBUG === 'true') {
            log.debug({ 
              sessionId: sid,
              eventType: event?.type,
              event,
            }, `Stream event: ${event?.type}`);
          }

          if (event?.type === 'content_block_start') {
            const contentBlock = event.content_block;
            contentBlocksByIndex.set(event.index, contentBlock?.type);

            if (contentBlock?.type === 'thinking') {
              sseWrite(`data: ${JSON.stringify({ type: 'thinking_start', timestamp: new Date().toISOString() })}\n\n`);
            } else if (contentBlock?.type === 'tool_use') {
              sseWrite(`data: ${JSON.stringify({
                type: 'tool_use_start',
                id: contentBlock.id,
                name: contentBlock.name,
                index: event.index,
                timestamp: new Date().toISOString()
              })}\n\n`);
            }
          } else if (event?.type === 'content_block_delta') {
            const delta = event.delta;
            if (delta?.type === 'thinking_delta' && delta.thinking) {
              sseWrite(`data: ${JSON.stringify({
                type: 'thinking_delta',
                content: delta.thinking,
                timestamp: new Date().toISOString()
              })}\n\n`);
            } else if (delta?.type === 'text_delta' && delta.text) {
              accumulatedText += delta.text;
              chunkCount++;
              sseWrite(`data: ${JSON.stringify({
                type: 'text_delta',
                content: delta.text,
                timestamp: new Date().toISOString()
              })}\n\n`);
            } else if (delta?.type === 'input_json_delta') {
              sseWrite(`data: ${JSON.stringify({
                type: 'tool_input_delta',
                index: event.index,
                partial_json: delta.partial_json || '',
                timestamp: new Date().toISOString()
              })}\n\n`);
            }
          } else if (event?.type === 'content_block_stop') {
            const blockType = contentBlocksByIndex.get(event.index);
            if (blockType === 'thinking') {
              sseWrite(`data: ${JSON.stringify({ type: 'thinking_stop', timestamp: new Date().toISOString() })}\n\n`);
            } else if (blockType === 'tool_use') {
              sseWrite(`data: ${JSON.stringify({
                type: 'content_block_stop',
                index: event.index,
                timestamp: new Date().toISOString()
              })}\n\n`);
            }
          } else if (event?.type === 'message_start') {
            sseWrite(`data: ${JSON.stringify({
              type: 'message_start',
              model: event.message?.model,
              usage: event.message?.usage,
              timestamp: new Date().toISOString()
            })}\n\n`);
          } else if (event?.type === 'message_delta') {
            sseWrite(`data: ${JSON.stringify({
              type: 'message_delta',
              stop_reason: event.delta?.stop_reason,
              usage: event.usage,
              timestamp: new Date().toISOString()
            })}\n\n`);

            if (event.usage) {
              sseWrite(`data: ${JSON.stringify({
                type: 'usage',
                tokens: {
                  input: event.usage.input_tokens || 0,
                  output: event.usage.output_tokens || 0,
                  total: (event.usage.input_tokens || 0) + (event.usage.output_tokens || 0),
                }
              })}\n\n`);
            }
          } else if (event?.type === 'message_stop') {
            sseWrite(`data: ${JSON.stringify({ type: 'message_stop', timestamp: new Date().toISOString() })}\n\n`);
          } else {
            log.debug({ eventType: event?.type }, 'Unhandled stream event');
          }
        } else if (msgType === 'auth_status') {
          const authMessage = message as any;
          
          // Log auth errors
          if (authMessage.error) {
            log.error({ 
              authError: authMessage.error,
              isAuthenticating: authMessage.isAuthenticating,
              sessionId: sid,
            }, 'Authentication error in auth_status message');
          }
          
          sseWrite(`data: ${JSON.stringify({
            type: 'auth_status',
            isAuthenticating: authMessage.isAuthenticating,
            output: authMessage.output || [],
            error: authMessage.error,
            timestamp: new Date().toISOString()
          })}\n\n`);
          
          // If auth failed, send error to client
          if (authMessage.error && !authMessage.isAuthenticating) {
            sendError(`Authentication failed: ${authMessage.error}`, { authError: authMessage.error });
          }
        } else if ((msgType as string) === 'error') {
          const errorMessage = (message as any).error?.message || 'Unknown error';
          const errorDetails = (message as any).error;
          log.error({ 
            errorMessage, 
            errorDetails,
            sessionId: sid,
            fullError: message,
          }, 'Stream error message received');
          sendError(errorMessage, errorDetails);
        } else {
          log.debug({ msgType }, 'Unhandled message type');
        }
      }

      // Check if we never received any messages
      if (!firstMessageReceived) {
        const totalTime = Date.now() - queryStartTime;
        log.warn({ 
          sessionId: sid, 
          totalTime,
          hasApiKey: !!process.env.ANTHROPIC_API_KEY,
          baseUrl: process.env.ANTHROPIC_BASE_URL || 'default',
        }, 'Query iterator completed but no messages were received');
      }
    } catch (error) {
      const errorTime = Date.now() - queryStartTime;
      
      // Extract additional error details if available
      const errorObj = error as any;
      const errorDetails: any = {
        err: error,
        sessionId: sid,
        errorTime,
        errorName: error instanceof Error ? error.name : 'Unknown',
        errorMessage: error instanceof Error ? error.message : String(error),
        errorStack: error instanceof Error ? error.stack : undefined,
        firstMessageReceived,
        hasApiKey: !!process.env.ANTHROPIC_API_KEY,
        baseUrl: process.env.ANTHROPIC_BASE_URL || 'default',
      };
      
      // Check for process exit error details
      if (errorObj?.message?.includes('process exited')) {
        errorDetails.processExitError = true;
        // Check if error has any additional properties
        if (errorObj.code !== undefined) errorDetails.exitCode = errorObj.code;
        if (errorObj.signal !== undefined) errorDetails.exitSignal = errorObj.signal;
        if (errorObj.stdout !== undefined) errorDetails.stdout = String(errorObj.stdout).substring(0, 1000);
        if (errorObj.stderr !== undefined) errorDetails.stderr = String(errorObj.stderr).substring(0, 1000);
        // Log all error properties
        errorDetails.allErrorKeys = Object.keys(errorObj);
        errorDetails.fullError = JSON.stringify(errorObj, Object.getOwnPropertyNames(errorObj), 2).substring(0, 2000);
      }
      
      log.error(errorDetails, 'Error iterating query stream');
      
      if (abortController.signal.aborted) {
        log.debug({ sessionId: sid }, 'Stream aborted (caught in error handler)');
        if (!res.closed && !res.destroyed) {
          sseWrite(`data: ${JSON.stringify({ type: 'aborted' })}\n\n`);
        }
      } else {
        throw error;
      }
    } finally {
      if (keepAliveInterval) clearInterval(keepAliveInterval);
      abortControllers.delete(requestId);
    }

    isCompleted = true;
    log.info({ sessionId: sid, chunkCount, textLength: accumulatedText.length }, 'Query complete');
    if (!res.closed) {
      sseWrite(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
      res.end();
    }
  } catch (error) {
    const errorObj = error as any;
    const outerErrorDetails: any = {
      err: error, 
      sessionId: sid,
      errorName: error instanceof Error ? error.name : 'Unknown',
      errorMessage: error instanceof Error ? error.message : String(error),
      errorStack: error instanceof Error ? error.stack : undefined,
      errorCause: error instanceof Error && 'cause' in error ? error.cause : undefined,
      hasApiKey: !!process.env.ANTHROPIC_API_KEY,
      apiKeyPrefix: process.env.ANTHROPIC_API_KEY?.substring(0, 10) || 'none',
      baseUrl: process.env.ANTHROPIC_BASE_URL || 'default',
      customHeaders: !!process.env.ANTHROPIC_CUSTOM_HEADERS,
    };
    
    // Check for process exit error details
    if (errorObj?.message?.includes('process exited')) {
      outerErrorDetails.processExitError = true;
      if (errorObj.code !== undefined) outerErrorDetails.exitCode = errorObj.code;
      if (errorObj.signal !== undefined) outerErrorDetails.exitSignal = errorObj.signal;
      if (errorObj.stdout !== undefined) outerErrorDetails.stdout = String(errorObj.stdout).substring(0, 1000);
      if (errorObj.stderr !== undefined) outerErrorDetails.stderr = String(errorObj.stderr).substring(0, 1000);
      outerErrorDetails.allErrorKeys = Object.keys(errorObj);
      outerErrorDetails.fullError = JSON.stringify(errorObj, Object.getOwnPropertyNames(errorObj), 2).substring(0, 2000);
    }
    
    log.error(outerErrorDetails, 'Error in chat stream');

    if (requestId) {
      abortControllers.delete(requestId);
    }

    isCompleted = true;
    if (keepAliveInterval) clearInterval(keepAliveInterval);

    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    const errorDetails = error instanceof Error ? { stack: error.stack } : undefined;
    sendError(errorMessage, errorDetails);

    try {
      if (!res.closed && !res.destroyed) {
        sseWrite(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
        res.end();
      }
    } catch (writeError) {
      log.error({ err: writeError }, 'Failed to end response');
    }
  }
}


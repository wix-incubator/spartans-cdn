import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { createHash } from 'crypto';
import { createLogger } from '../../lib/logger';
import { MARKETPLACE_PATH as BASE_MARKETPLACE_PATH, PACKAGE_ROOT } from '../config';

const log = createLogger('marketplace');

// Plugin marketplace types
export interface MarketplacePlugin {
  name: string;
  source: string;
  description?: string;
}

export interface Marketplace {
  name: string;
  owner?: { name: string; email?: string };
  plugins: MarketplacePlugin[];
}

// Extended types for download (using official Claude schema)
interface MarketplacePluginExtended extends MarketplacePlugin {
  commands?: string[];  // Official Claude schema field
  agents?: string[];
  hooks?: string | object;
  mcpServers?: string | object;
}

interface MarketplaceExtended extends Marketplace {
  plugins: MarketplacePluginExtended[];
}

// Marketplace JSON path (URL or local file path)
// - URL: https://static.parastorage.com/services/igor-marketplace/1.3.0/marketplace.json
// - Local: ../igor-marketplace/marketplace.json, /absolute/path/marketplace.json
export const MARKETPLACE_JSON = process.env.MARKETPLACE_URL || 'https://static.parastorage.com/services/igor-marketplace/1.3.0/marketplace.json';

// Check if it's a local path (not a URL)
const isLocalPath = (path: string) => !path.startsWith('http://') && !path.startsWith('https://');
const IS_LOCAL = isLocalPath(MARKETPLACE_JSON);

// Get base directory from JSON path (for downloading plugin files)
const getBaseDir = (jsonPath: string) => dirname(jsonPath);

// Re-export for convenience
export const MARKETPLACE_PATH = BASE_MARKETPLACE_PATH;

// Possible local marketplace sources (for dev/fallback)
const LOCAL_MARKETPLACE_PATHS = [
  join(PACKAGE_ROOT, '..', 'igor-marketplace'),
];

// Load marketplace from a given path
export function loadMarketplaceFrom(basePath: string): Marketplace | null {
  const marketplaceFile = join(basePath, 'marketplace.json');
  if (existsSync(marketplaceFile)) {
    try {
      const content = readFileSync(marketplaceFile, 'utf-8');
      return JSON.parse(content) as Marketplace;
    } catch (err) {
      log.warn({ err, path: basePath }, 'Failed to load marketplace');
    }
  }
  return null;
}

// Resolve plugin path from source (always uses runtime MARKETPLACE_PATH)
export function resolvePluginPath(source: string): string {
  const cleanSource = source.startsWith('./') ? source.slice(2) : source;
  return join(MARKETPLACE_PATH, cleanSource);
}

// Copy directory recursively
function copyDirRecursive(src: string, dest: string): void {
  if (!existsSync(dest)) {
    mkdirSync(dest, { recursive: true });
  }
  for (const entry of readdirSync(src)) {
    const srcPath = join(src, entry);
    const destPath = join(dest, entry);
    const stat = statSync(srcPath);
    if (stat.isDirectory()) {
      copyDirRecursive(srcPath, destPath);
    } else {
      writeFileSync(destPath, readFileSync(srcPath));
    }
  }
}

// Copy marketplace from a specific local path
function copyFromPath(localPath: string): boolean {
  const localLog = log.child({ module: 'marketplace-local' });
  
  // Ensure marketplace directory exists
  if (!existsSync(MARKETPLACE_PATH)) {
    mkdirSync(MARKETPLACE_PATH, { recursive: true });
  }
  
  localLog.debug({ path: localPath }, 'Checking local path');
  const marketplaceJson = join(localPath, 'marketplace.json');
  const pluginsDir = join(localPath, 'plugins');
  
  const hasJson = existsSync(marketplaceJson);
  const hasPlugins = existsSync(pluginsDir);
  localLog.debug({ hasJson, hasPlugins }, 'Path check result');
  
  if (hasJson && hasPlugins) {
    localLog.info({ path: localPath }, 'Found valid local source');
    
    // Read and copy marketplace.json
    const marketplaceContent = readFileSync(marketplaceJson, 'utf-8');
    writeFileSync(join(MARKETPLACE_PATH, 'marketplace.json'), marketplaceContent);
    localLog.debug('Copied marketplace.json');
    
    // Parse to get plugin names
    const marketplace = JSON.parse(marketplaceContent) as MarketplaceExtended;
    
    // Copy plugins directory
    const destPlugins = join(MARKETPLACE_PATH, 'plugins');
    copyDirRecursive(pluginsDir, destPlugins);
    
    // List plugins from marketplace.json (the source of truth)
    const pluginNames = marketplace.plugins.map(p => p.name);
    localLog.info({ plugins: pluginNames }, 'Copied plugins');
    
    // Write version marker
    writeFileSync(join(MARKETPLACE_PATH, '.version'), `local:${localPath}`);
    localLog.debug({ path: localPath }, 'Marked as local source');
    
    return true;
  }
  
  localLog.warn({ path: localPath }, 'Invalid local source');
  return false;
}

// Try to copy from default local sources (workspace sibling)
function copyFromLocalMarketplace(): boolean {
  for (const localPath of LOCAL_MARKETPLACE_PATHS) {
    if (copyFromPath(localPath)) {
      return true;
    }
  }
  return false;
}

// Download marketplace from configured JSON path (URL or local)
export async function downloadMarketplace(): Promise<void> {
  const downloadLog = log.child({ module: 'marketplace-download' });
  const versionFile = join(MARKETPLACE_PATH, '.version');
  
  // Ensure marketplace directory exists
  if (!existsSync(MARKETPLACE_PATH)) {
    mkdirSync(MARKETPLACE_PATH, { recursive: true });
  }
  
  // Handle local path
  if (IS_LOCAL) {
    const localJsonPath = MARKETPLACE_JSON.startsWith('/') 
      ? MARKETPLACE_JSON 
      : join(PACKAGE_ROOT, MARKETPLACE_JSON);
    const localDir = dirname(localJsonPath);
    
    downloadLog.info({ path: localJsonPath }, 'Using local marketplace');
    
    if (copyFromPath(localDir)) {
      downloadLog.info('Copied from local path');
      return;
    }
    downloadLog.error({ path: localDir }, 'Local marketplace not found');
    return;
  }
  
  // Handle remote URL
  const baseUrl = getBaseDir(MARKETPLACE_JSON);
  downloadLog.info({ url: MARKETPLACE_JSON }, 'Starting marketplace download');
  
  // Use URL as cache key
  const urlHash = createHash('md5').update(MARKETPLACE_JSON).digest('hex').slice(0, 12);
  
  // Check if we already have this URL cached
  if (existsSync(versionFile)) {
    const cachedKey = readFileSync(versionFile, 'utf-8').trim();
    downloadLog.debug({ cachedKey }, 'Found cached version');
    if (!cachedKey.startsWith('local:') && cachedKey === urlHash) {
      downloadLog.info('Cache hit! Using cached marketplace');
      return;
    }
    downloadLog.debug({ cachedKey, needed: urlHash }, 'Cache miss');
  }
  
  try {
    downloadLog.debug({ url: MARKETPLACE_JSON }, 'Fetching marketplace.json');
    
    const marketplaceRes = await fetch(MARKETPLACE_JSON);
    if (!marketplaceRes.ok) {
      throw new Error(`Download returned ${marketplaceRes.status}`);
    }
    const marketplaceJsonContent = await marketplaceRes.text();
    writeFileSync(join(MARKETPLACE_PATH, 'marketplace.json'), marketplaceJsonContent);
    downloadLog.info('Downloaded marketplace.json');
    
    const marketplace = JSON.parse(marketplaceJsonContent) as MarketplaceExtended;
    downloadLog.info({ pluginCount: marketplace.plugins.length }, 'Found plugins to download');
    
    // Download each plugin using official Claude schema
    for (const plugin of marketplace.plugins) {
      const pluginSource = plugin.source.startsWith('./') ? plugin.source.slice(2) : plugin.source;
      const commands = plugin.commands || [];
      downloadLog.debug({ plugin: plugin.name, commandCount: commands.length }, 'Downloading plugin');
      
      // Always download .claude-plugin/plugin.json (required by convention)
      const pluginJsonPath = '.claude-plugin/plugin.json';
      const pluginJsonUrl = `${baseUrl}/${pluginSource}/${pluginJsonPath}`;
      try {
        const pluginJsonRes = await fetch(pluginJsonUrl);
        if (pluginJsonRes.ok) {
          const filePath = join(MARKETPLACE_PATH, pluginSource, pluginJsonPath);
          mkdirSync(dirname(filePath), { recursive: true });
          writeFileSync(filePath, await pluginJsonRes.text());
          downloadLog.debug({ file: pluginJsonPath }, 'Downloaded plugin.json');
        } else {
          downloadLog.warn({ plugin: plugin.name, status: pluginJsonRes.status }, 'Failed to download plugin.json');
        }
      } catch (err) {
        downloadLog.warn({ plugin: plugin.name, err }, 'Error downloading plugin.json');
      }
      
      // Download commands from the official 'commands' field
      for (const cmd of commands) {
        const cmdPath = cmd.startsWith('./') ? cmd.slice(2) : cmd;
        const cmdUrl = `${baseUrl}/${pluginSource}/${cmdPath}`;
        try {
          const cmdRes = await fetch(cmdUrl);
          if (cmdRes.ok) {
            const filePath = join(MARKETPLACE_PATH, pluginSource, cmdPath);
            mkdirSync(dirname(filePath), { recursive: true });
            writeFileSync(filePath, await cmdRes.text());
            downloadLog.debug({ file: cmdPath }, 'Downloaded command');
          } else {
            downloadLog.warn({ file: cmdPath, status: cmdRes.status }, 'Failed to download command');
          }
        } catch (err) {
          downloadLog.warn({ file: cmdPath, err }, 'Error downloading command');
        }
      }
    }
    
    // Write cache key file
    writeFileSync(versionFile, urlHash);
    downloadLog.info({ url: MARKETPLACE_JSON }, 'Download complete');
    return;
    
  } catch (err) {
    downloadLog.warn({ err }, 'Download failed');
  }
  
  // Fallback: try default local sources (workspace sibling)
  downloadLog.debug('Falling back to default local sources');
  if (copyFromLocalMarketplace()) {
    downloadLog.info('Copied from local source');
    return;
  }
  
  // Last resort: use cached version if available
  if (existsSync(join(MARKETPLACE_PATH, 'marketplace.json'))) {
    downloadLog.warn('Using previously cached marketplace (may be outdated)');
  } else {
    downloadLog.error('No marketplace available - plugins will not work!');
  }
}

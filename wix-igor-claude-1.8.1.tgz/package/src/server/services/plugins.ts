import { existsSync, readdirSync, readFileSync } from 'fs';
import { join } from 'path';
import { createLogger } from '../../lib/logger';
import { Marketplace, MARKETPLACE_PATH, resolvePluginPath } from './marketplace';

const log = createLogger('plugins');

export interface PluginCommand {
  name: string;
  description: string;
  argumentHint?: string;
}

export interface PluginWithStatus {
  name: string;
  source: string;
  description?: string;
  path: string;
  commands: PluginCommand[];
}

// Parse frontmatter from a command markdown file
function parseCommandFrontmatter(content: string, filename: string): PluginCommand | null {
  // Check if file starts with frontmatter
  if (!content.startsWith('---')) {
    // No frontmatter, use filename as command name
    return {
      name: filename.replace('.md', ''),
      description: '',
    };
  }
  
  const endOfFrontmatter = content.indexOf('---', 3);
  if (endOfFrontmatter === -1) {
    return {
      name: filename.replace('.md', ''),
      description: '',
    };
  }
  
  const frontmatter = content.substring(3, endOfFrontmatter).trim();
  const lines = frontmatter.split('\n');
  
  let name = filename.replace('.md', '');
  let description = '';
  let argumentHint = '';
  
  for (const line of lines) {
    const colonIndex = line.indexOf(':');
    if (colonIndex === -1) continue;
    
    const key = line.substring(0, colonIndex).trim().toLowerCase();
    let value = line.substring(colonIndex + 1).trim();
    
    // Remove quotes if present
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    
    switch (key) {
      case 'name':
        name = value;
        break;
      case 'description':
        description = value;
        break;
      case 'argument_hint':
      case 'argumenthint':
      case 'argument-hint':
        argumentHint = value;
        break;
    }
  }
  
  return {
    name,
    description,
    ...(argumentHint && { argumentHint }),
  };
}

// Discover commands from a plugin's directory
export function discoverPluginCommands(pluginPath: string): PluginCommand[] {
  const commands: PluginCommand[] = [];
  const commandsDir = join(pluginPath, 'commands');
  
  if (!existsSync(commandsDir)) {
    return commands;
  }
  
  try {
    const files = readdirSync(commandsDir).filter(f => f.endsWith('.md'));
    
    for (const file of files) {
      try {
        const content = readFileSync(join(commandsDir, file), 'utf-8');
        const command = parseCommandFrontmatter(content, file);
        if (command) {
          commands.push(command);
        }
      } catch (err) {
        log.warn({ file, pluginPath, err }, 'Failed to parse command file');
      }
    }
  } catch (err) {
    log.warn({ commandsDir, err }, 'Failed to read commands directory');
  }
  
  return commands;
}

// Get all plugins with their commands
export function getPluginsWithCommands(marketplace: Marketplace | null): PluginWithStatus[] {
  if (!marketplace) {
    return [];
  }
  
  return marketplace.plugins.map(plugin => {
    const pluginPath = resolvePluginPath(plugin.source);
    const commands = discoverPluginCommands(pluginPath);
    
    return {
      name: plugin.name,
      source: plugin.source,
      description: plugin.description,
      path: pluginPath,
      commands: commands.map(cmd => ({
        ...cmd,
        name: `${plugin.name}:${cmd.name}` // Namespace commands
      })),
    };
  });
}

// Get plugin paths for SDK (all plugins are always enabled)
export function getEnabledPluginPaths(marketplace: Marketplace | null): { type: 'local'; path: string }[] {
  if (!marketplace) {
    return [];
  }
  
  const plugins: { type: 'local'; path: string }[] = [];
  
  for (const plugin of marketplace.plugins) {
    const pluginPath = resolvePluginPath(plugin.source);
    if (existsSync(pluginPath)) {
      plugins.push({ type: 'local', path: pluginPath });
      log.debug({ plugin: plugin.name, path: pluginPath }, 'Plugin enabled');
    } else {
      log.warn({ plugin: plugin.name, path: pluginPath }, 'Plugin path not found');
    }
  }
  
  return plugins;
}

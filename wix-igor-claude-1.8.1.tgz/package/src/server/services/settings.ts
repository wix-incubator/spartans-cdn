import { existsSync, mkdirSync, readFileSync, writeFileSync, unlinkSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { createLogger } from '../../lib/logger';
import { getOriginalCwd } from '../config';

const log = createLogger('settings');

// Get path to default settings file (in package)
function getDefaultSettingsPath(): string {
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename);
  return join(__dirname, 'default-settings.json');
}

export function readDefaultSettings(): Record<string, any> {
  const defaultPath = getDefaultSettingsPath();
  try {
    if (existsSync(defaultPath)) {
      return JSON.parse(readFileSync(defaultPath, 'utf-8'));
    }
  } catch (err) {
    log.warn({ err, path: defaultPath }, 'Failed to read default settings');
  }
  // Fallback to hardcoded defaults if file doesn't exist
  return {
    model: 'claude-sonnet-4-5',
    systemPrompt: 'Your name is IGOR',
    systemPromptMode: 'append',
    settingSources: ['user', 'project', 'local'],
    mcpServers: {},
    showSystemMessages: false,
  };
}

// Igor-claude settings stored in .igor-claude/settings.json in project root
function getSettingsPath(): string {
  const cwd = getOriginalCwd();
  return join(cwd, '.igor-claude', 'settings.json');
}

export function readSettings(): Record<string, any> {
  const settingsPath = getSettingsPath();
  const defaults = readDefaultSettings();
  
  try {
    if (existsSync(settingsPath)) {
      const saved = JSON.parse(readFileSync(settingsPath, 'utf-8'));
      // Merge defaults with saved settings (saved takes precedence)
      return { ...defaults, ...saved };
    }
  } catch (err) {
    log.warn({ err, path: settingsPath }, 'Failed to read settings');
  }
  
  // Return defaults if no saved settings
  return defaults;
}

export function writeSettings(settings: Record<string, any>): void {
  const settingsPath = getSettingsPath();
  try {
    const dir = dirname(settingsPath);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
    log.debug({ path: settingsPath }, 'Settings saved');
  } catch (err) {
    log.error({ err, path: settingsPath }, 'Failed to write settings');
    throw err;
  }
}

// Claude project settings stored in .claude/settings.json
function getProjectSettingsPath(): string {
  const cwd = getOriginalCwd();
  return join(cwd, '.claude', 'settings.json');
}

export function readProjectSettings(): any {
  const projectSettingsPath = getProjectSettingsPath();
  try {
    if (existsSync(projectSettingsPath)) {
      const content = readFileSync(projectSettingsPath, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    log.warn({ err, path: projectSettingsPath }, 'Failed to read project settings');
  }
  return {};
}

export function writeProjectSettings(settings: any): void {
  const projectSettingsPath = getProjectSettingsPath();
  try {
    const dir = dirname(projectSettingsPath);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(projectSettingsPath, JSON.stringify(settings, null, 2));
    log.debug({ path: projectSettingsPath }, 'Project settings saved');
  } catch (err) {
    log.error({ err, path: projectSettingsPath }, 'Failed to write project settings');
    throw err;
  }
}

export function resetSettings(): void {
  const settingsPath = getSettingsPath();
  try {
    if (existsSync(settingsPath)) {
      unlinkSync(settingsPath);
      log.info({ path: settingsPath }, 'Settings reset to defaults');
    }
  } catch (err) {
    log.error({ err, path: settingsPath }, 'Failed to reset settings');
    throw err;
  }
}

// Re-export marketplace types from the service
export type { Marketplace, MarketplacePlugin } from './services/marketplace';

// Session types
export interface SessionInfo {
  sessionId: string;
  filePath: string;
  startTime: string;
  lastUpdated: string;
  messageCount: number;
  preview: string;
  agentId?: string | null;
  cwd?: string;
  gitBranch?: string;
}

export interface ConversationRecord {
  sessionId: string;
  projectHash: string;
  startTime: string;
  lastUpdated: string;
  messages: Array<{
    id: string;
    timestamp: string;
    type: string;
    content: string;
    thoughts?: Array<{ subject: string; description: string; timestamp: string }>;
    tokens?: { input: number; output: number; total: number };
    model?: string;
  }>;
}

// Image data for multi-modal prompts
export interface ImageData {
  data: string;       // Base64 encoded image data
  mediaType: string;  // MIME type: 'image/png', 'image/jpeg', etc.
  fileName: string;   // Original file name
}

// Embedded assets interface (for binary mode)
export interface EmbeddedAssets {
  getEmbeddedAsset: (path: string) => { content: Buffer | string; mimeType: string } | null;
  EMBEDDED_VERSION?: string;
}

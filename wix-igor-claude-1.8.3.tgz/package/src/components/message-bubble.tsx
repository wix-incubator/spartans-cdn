import type { Message } from '@/types';
import {
  ThinkingBubble,
  ToolCallBubble,
  ToolResultBubble,
  CodeBubble,
  CodeResultBubble,
  RawEventBubble,
  AuthStatusBubble,
  SystemInfoBubble,
  MediaBubble,
  QueryResultBubble,
  UserMessage,
  AssistantMessage,
} from '@/components/message-parts';

interface MessageBubbleProps {
  message: Message;
  isLoading: boolean;
  status: string;
  allMessages: Message[];
}

export function MessageBubble({ message, isLoading, status, allMessages }: MessageBubbleProps) {
  // Thinking messages
  if (message.type === 'thinking') {
    const msgIndex = allMessages.findIndex(m => m.id === message.id);
    // Thinking is complete if ANY message comes after it, or if status is ready
    const hasMessageAfter = allMessages.length > msgIndex + 1;
    const isComplete = hasMessageAfter || status === 'ready';
    return <ThinkingBubble message={message} isComplete={isComplete} />;
  }

  // Tool calls
  if (message.type === 'tool_call') {
    return <ToolCallBubble message={message} />;
  }

  // Tool results
  if (message.type === 'tool_result') {
    return <ToolResultBubble message={message} />;
  }

  // Code blocks
  if (message.type === 'code') {
    return <CodeBubble message={message} />;
  }

  // Code execution results
  if (message.type === 'code_result') {
    return <CodeResultBubble message={message} />;
  }

  // Media attachments
  if (message.type === 'media') {
    return <MediaBubble message={message} />;
  }

  // Query results
  if (message.type === 'query_result') {
    return <QueryResultBubble message={message} />;
  }

  // System info
  if (message.type === 'system_info') {
    return <SystemInfoBubble message={message} />;
  }

  // Raw events (collapsed system events)
  if (message.type === 'raw_event') {
    return <RawEventBubble message={message} />;
  }

  // Auth status messages
  if (message.type === 'auth_status') {
    return <AuthStatusBubble message={message} />;
  }

  // User messages
  if (message.role === 'user') {
    return <UserMessage message={message} />;
  }

  // Assistant messages (default for text type with assistant role)
  return <AssistantMessage message={message} isLoading={isLoading} />;
}

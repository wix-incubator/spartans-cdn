import { useRef, useEffect, useState, useCallback } from 'react';
import { Loader2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageBubble } from './message-bubble';
import type { Message } from '@/types';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  status: string;
  showSystemMessages?: boolean;
  isWaitingForFirstChunk?: boolean;
}

// System message types that should be hidden by default
const SYSTEM_MESSAGE_CONTENTS = [
  'system_message', 
  'message_start', 
  'message_delta',
  'message_stop',
  'content_block_stop',
  'thinking_stop',
  'result',
  'aborted',
];

function isSystemMessage(msg: Message): boolean {
  if (msg.type === 'raw_event') {
    const content = msg.content?.toLowerCase() || '';
    // Check for known system event contents
    if (SYSTEM_MESSAGE_CONTENTS.some(s => content.includes(s.toLowerCase()))) {
      return true;
    }
    // Check for assistant_message (finished thinking/text)
    if (msg.rawData?.type === 'assistant_message') {
      return true;
    }
  }
  return false;
}

// Threshold in pixels - if within this distance from bottom, consider "at bottom"
const SCROLL_THRESHOLD = 100;

export function MessageList({ messages, isLoading, status, showSystemMessages = false, isWaitingForFirstChunk = false }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const [isAtBottom, setIsAtBottom] = useState(true);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  // Check if scrolled to bottom
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    const { scrollTop, scrollHeight, clientHeight } = target;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    setIsAtBottom(distanceFromBottom < SCROLL_THRESHOLD);
  }, []);

  // Only auto-scroll if user is at bottom
  useEffect(() => {
    if (isAtBottom) {
      scrollToBottom();
    }
  }, [messages, isWaitingForFirstChunk, isAtBottom, scrollToBottom]);

  // Filter messages based on showSystemMessages setting
  const visibleMessages = showSystemMessages 
    ? messages 
    : messages.filter(msg => !isSystemMessage(msg));
  
  const lastVisibleMessage = visibleMessages[visibleMessages.length - 1];

  return (
    <ScrollArea className="flex-1" viewportRef={viewportRef} onScroll={handleScroll}>
      <div className="px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-4">
          {visibleMessages.map((msg) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              isLoading={isLoading}
              status={status}
              allMessages={messages}
            />
          ))}
          {isWaitingForFirstChunk && (
            <div className="w-full my-1">
              <Loader2 className="h-3 w-3 animate-spin text-muted-foreground/50" />
            </div>
          )}
          {isLoading && !isWaitingForFirstChunk && lastVisibleMessage?.type !== 'thinking' && (
            <div className="w-full my-1 flex items-center gap-1 text-muted-foreground/50">
              <Loader2 className="h-3 w-3 animate-spin" />
              <span className="text-xs">working...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
    </ScrollArea>
  );
}


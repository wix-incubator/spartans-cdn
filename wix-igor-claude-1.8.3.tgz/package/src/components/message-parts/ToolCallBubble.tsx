import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import type { Message } from '@/types';
import { getToolRenderer, getToolHeader, INLINE_TOOLS, TOOLS_WITH_CUSTOM_HEADER } from './tool-renderers';

interface ToolCallBubbleProps {
  message: Message;
}

// Height limits
const COLLAPSED_HEIGHT = 'max-h-24'; // ~96px when collapsed
const EXPANDED_HEIGHT = 'max-h-96';  // ~384px when expanded

export function ToolCallBubble({ message }: ToolCallBubbleProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const toolName = message.tool || 'unknown';
  const args = message.args || {};
  const normalizedName = toolName.toLowerCase();
  const hasResult = !!message.result;
  const resultContent = message.result 
    ? (typeof message.result === 'string' ? message.result : JSON.stringify(message.result, null, 2))
    : '';
  
  // Get the appropriate renderer for this tool
  const ToolRenderer = getToolRenderer(toolName);
  const ToolHeader = getToolHeader(toolName);
  
  // Some tools render inline without a card
  const isInline = INLINE_TOOLS.includes(normalizedName);
  const hasCustomHeader = TOOLS_WITH_CUSTOM_HEADER.includes(normalizedName);

  const handleClick = () => {
    setIsExpanded(!isExpanded);
  };

  // Inline tools (Read, Glob, Grep, Task, WebSearch, WebFetch) - no card wrapper
  if (isInline) {
    return (
      <div 
        className="w-full my-0.5 cursor-pointer"
        onClick={handleClick}
      >
        <div className="flex items-center gap-1.5 min-w-0 hover:bg-muted/30 rounded px-1 -mx-1">
          <ToolRenderer args={args} toolName={toolName} />
        </div>
        {isExpanded && hasResult && (
          <pre className="font-mono text-[9px] whitespace-pre-wrap break-words max-h-64 overflow-y-auto mt-1 p-2 bg-muted/30 rounded text-muted-foreground/70">
            {resultContent}
          </pre>
        )}
      </div>
    );
  }

  // Card rendering for other tools (Bash, Write, Edit, etc.)
  // Collapsed: clipped, no scroll. Expanded: scroll for content only, header stays fixed
  return (
    <div className="w-full my-1">
      <Card 
        className="border-border cursor-pointer"
        onClick={handleClick}
      >
        <CardContent className="p-2">
          {/* Header - always visible, not scrolled */}
          <div className="flex items-center gap-1.5 mb-1">
            {hasCustomHeader && ToolHeader ? (
              <ToolHeader args={args} toolName={toolName} />
            ) : (
              <span className="text-[10px] font-medium font-mono text-muted-foreground">
                {toolName}
              </span>
            )}
          </div>
          {/* Content - scrollable area */}
          <div className={isExpanded ? EXPANDED_HEIGHT + ' overflow-y-auto' : COLLAPSED_HEIGHT + ' overflow-hidden'}>
            <ToolRenderer args={args} />
            {isExpanded && hasResult && (
              <div className="mt-2 pt-2 border-t border-border">
                <div className="text-[9px] text-muted-foreground/50 mb-1">result</div>
                <pre className="font-mono text-[9px] whitespace-pre-wrap break-words p-2 bg-muted/30 rounded text-muted-foreground/70">
                  {resultContent}
                </pre>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

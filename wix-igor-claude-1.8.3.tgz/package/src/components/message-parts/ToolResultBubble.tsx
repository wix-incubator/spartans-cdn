import { Card, CardContent } from '@/components/ui/card';
import { formatTime, formatFullTime } from '@/lib/utils';
import type { Message } from '@/types';

interface ToolResultBubbleProps {
  message: Message;
}

export function ToolResultBubble({ message }: ToolResultBubbleProps) {
  const summary = message.response 
    ? (typeof message.response === 'string' ? message.response : JSON.stringify(message.response)) 
    : '';
  const rawContent = message.content 
    ? (typeof message.content === 'string' ? message.content : JSON.stringify(message.content))
    : '';
  const rawContentStr = String(rawContent);
  const showRaw = rawContentStr && rawContentStr !== summary && !summary.includes(rawContentStr.substring(0, 100));

  return (
    <div className="w-full my-1">
      <Card className="border-border">
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="text-[10px] font-medium text-muted-foreground flex items-center gap-1">
              ✓ {message.tool || 'result'}
            </div>
            <span className="text-[9px] text-muted-foreground/60" title={formatFullTime(message.timestamp)}>{formatTime(message.timestamp)}</span>
          </div>
          {summary && (
            <div className="text-[10px] text-muted-foreground/80 whitespace-pre-wrap break-words max-h-48 overflow-y-auto">
              {summary}
            </div>
          )}
          {showRaw && (
            <details className="mt-2">
              <summary className="text-[9px] text-muted-foreground/60 cursor-pointer hover:text-muted-foreground">raw</summary>
              <pre className="font-mono text-[9px] whitespace-pre-wrap break-words max-h-48 overflow-y-auto mt-1 text-muted-foreground/60">
                {rawContentStr}
              </pre>
            </details>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


import { Card, CardContent } from '@/components/ui/card';
import { formatTime, formatFullTime } from '@/lib/utils';
import type { Message } from '@/types';

interface UserMessageProps {
  message: Message;
}

export function UserMessage({ message }: UserMessageProps) {
  return (
    <div className="w-full my-2">
      <Card className="border-blue-500/30">
        <CardContent className="p-3">
          {message.images && message.images.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2">
              {message.images.map((img, index) => (
                <img
                  key={index}
                  src={`data:${img.mediaType};base64,${img.data}`}
                  alt={img.fileName}
                  className="max-w-[200px] max-h-[150px] object-contain rounded border border-border"
                />
              ))}
            </div>
          )}
          <div className="text-xs whitespace-pre-wrap break-words">
            {message.content}
          </div>
          <div className="text-[9px] text-muted-foreground/60 mt-1" title={formatFullTime(message.timestamp)}>
            {formatTime(message.timestamp)}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


import { Sparkles } from 'lucide-react';

interface TaskToolRendererProps {
  args: {
    subagent_type?: string;
    description?: string;
    prompt?: string;
  };
  toolName?: string;
}

export function TaskToolRenderer({ args, toolName }: TaskToolRendererProps) {
  const subagentType = args.subagent_type || '';
  const description = args.description || args.prompt || '';
  
  // Truncate for inline display
  const truncated = description.length > 50 ? description.slice(0, 50) + '...' : description;

  return (
    <>
      <Sparkles className="h-3 w-3 text-muted-foreground/60 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'Task'}</span>
      {subagentType && (
        <>
          <span className="text-[9px] text-muted-foreground/30">·</span>
          <span className="text-[9px] font-mono text-muted-foreground/70">{subagentType}</span>
        </>
      )}
      {truncated && (
        <>
          <span className="text-[9px] text-muted-foreground/30">·</span>
          <span className="text-[9px] text-muted-foreground/50 truncate">{truncated}</span>
        </>
      )}
    </>
  );
}

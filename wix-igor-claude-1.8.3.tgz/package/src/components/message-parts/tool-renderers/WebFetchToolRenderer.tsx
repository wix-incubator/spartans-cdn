import { Link } from 'lucide-react';

interface WebFetchToolRendererProps {
  args: {
    url?: string;
    prompt?: string;
  };
  toolName?: string;
}

export function WebFetchToolRenderer({ args, toolName }: WebFetchToolRendererProps) {
  const url = args.url || '';
  const prompt = args.prompt || '';
  
  // Extract domain from URL for cleaner display
  let displayUrl = url;
  try {
    const urlObj = new URL(url);
    displayUrl = urlObj.hostname + (urlObj.pathname !== '/' ? urlObj.pathname : '');
  } catch {
    // Keep original if invalid URL
  }

  return (
    <>
      <Link className="h-3 w-3 text-muted-foreground/60 flex-shrink-0" />
      <span className="text-[9px] font-mono text-muted-foreground/50">{toolName || 'WebFetch'}</span>
      <span className="text-[9px] text-muted-foreground/30">·</span>
      <span className="text-[9px] font-mono text-muted-foreground/70 truncate">{displayUrl}</span>
      {prompt && (
        <>
          <span className="text-[9px] text-muted-foreground/30">·</span>
          <span className="text-[9px] text-muted-foreground/50 truncate">"{prompt}"</span>
        </>
      )}
    </>
  );
}


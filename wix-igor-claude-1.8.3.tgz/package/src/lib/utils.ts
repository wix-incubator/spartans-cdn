import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { formatDistanceToNow, format, isToday } from "date-fns"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTime(timestamp: number): string {
  // Guard against invalid timestamps
  if (!timestamp || !Number.isFinite(timestamp) || isNaN(timestamp)) {
    return 'Unknown';
  }
  
  const date = new Date(timestamp);
  
  // Check if date is valid
  if (isNaN(date.getTime())) {
    return 'Unknown';
  }
  
  const now = Date.now();
  const diff = now - timestamp;
  
  // Less than 1 minute - show relative
  if (diff < 60 * 1000) {
    return 'just now';
  }
  
  // Less than 1 hour - show relative (e.g. "5 minutes ago")
  if (diff < 60 * 60 * 1000) {
    return formatDistanceToNow(date, { addSuffix: true });
  }
  
  // Today - show time with seconds
  if (isToday(date)) {
    return format(date, 'HH:mm:ss');
  }
  
  // Older - show date and time
  return format(date, 'MMM d, HH:mm');
}

// Full locale-formatted time for tooltips
export function formatFullTime(timestamp: number): string {
  if (!timestamp || !Number.isFinite(timestamp) || isNaN(timestamp)) {
    return '';
  }
  const date = new Date(timestamp);
  if (isNaN(date.getTime())) {
    return '';
  }
  return date.toLocaleString();
}

// Safe date parsing - returns timestamp or 0 if invalid
export function safeParseDate(value: string | number | Date | undefined | null): number {
  if (!value) return 0;
  
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }
  
  const date = new Date(value);
  const timestamp = date.getTime();
  return Number.isFinite(timestamp) ? timestamp : 0;
}

// Path utilities for browser (no Node path module)
export function getBasename(filepath: string): string {
  if (!filepath) return '';
  const parts = filepath.replace(/\\/g, '/').split('/');
  return parts[parts.length - 1] || '';
}

export function getDirname(filepath: string): string {
  if (!filepath) return '';
  const normalized = filepath.replace(/\\/g, '/');
  const lastSlash = normalized.lastIndexOf('/');
  return lastSlash > 0 ? normalized.slice(0, lastSlash) : '';
}


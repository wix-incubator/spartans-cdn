export type MessageType = 'text' | 'thinking' | 'tool_call' | 'tool_result' | 'media' | 'code' | 'code_result' | 'query_result' | 'system_info' | 'raw_event' | 'auth_status';

// Image data for sending images with prompts
export interface ImageData {
  data: string;       // Base64 encoded image data (without data: prefix)
  mediaType: string;  // MIME type: 'image/png', 'image/jpeg', 'image/gif', 'image/webp'
  fileName: string;   // Original file name
}

export interface TokenUsage {
  input: number;
  output: number;
  total: number;
  // Claude SDK doesn't provide cached/thoughts/tool breakdown
}

export interface SessionCost {
  totalCost: number;
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  cacheWriteTokens: number;
  durationMs: number;
  durationApiMs: number;
  turns: number;
}

export interface Message {
  id: number;
  role: 'user' | 'assistant' | 'system';
  type: MessageType;
  content?: string;
  tool?: string;
  toolUseId?: string; // For tool_call - used to match with tool_result
  args?: any;
  response?: any;
  result?: any; // For tool_call - the tool result content
  resultTimestamp?: number; // When the result arrived
  mimeType?: string;
  language?: string;
  outcome?: string;
  rawData?: any; // For raw_event type - stores the complete event data
  images?: ImageData[]; // For user messages with attached images
  timestamp: number; // Unix timestamp in ms
}

// MCP Server Types - matching Claude Agent SDK
export type McpServerStatus = 'connected' | 'failed' | 'needs-auth' | 'pending';

export interface McpHttpServerConfig {
  type: 'http';
  url: string;
  headers?: Record<string, string>;
}

export interface McpServerWithStatus extends McpHttpServerConfig {
  status?: McpServerStatus;
  serverInfo?: {
    name: string;
    version: string;
  };
  tools?: string[];
  error?: string;
}

// Settings sources that SDK can load from
export type SettingSource = 'user' | 'project' | 'local';

// Plugin types
export interface PluginManifest {
  name: string;
  description?: string;
  version?: string;
  author?: {
    name: string;
    email?: string;
  };
}

export interface MarketplacePlugin {
  name: string;
  source: string;
  description?: string;
}

export interface Marketplace {
  name: string;
  owner: {
    name: string;
  };
  plugins: MarketplacePlugin[];
}

export interface PluginCommand {
  name: string;
  description?: string;
  argumentHint?: string;
}

export interface PluginWithStatus extends MarketplacePlugin {
  enabled: boolean;
  manifest?: PluginManifest;
  commands?: PluginCommand[];
  path?: string;
}

